# -*- coding: utf-8 -*-
"""

"""
import pandas as pd
import numpy as np 
import datetime as datetime
import sqlite3 as db
from timeit import default_timer as timer
from dateutil import parser
import scipy.stats
from termcolor import colored, cprint
import warnings
from P_commons import to_sql_append, to_sql_replace, read_sql, type_convert,to_sql_delete, get_conn, tbl_nodupe_append
from P_commons import * 
from R_stat import stat_VIEW, stat_run_base, stat_PLOT
from R_plot import plot_base
from R_getdata import get_FUN, get_DIV, get_SI
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format

"""
    logic: risk control by delta (i_delta) and weigh( i_ip)
    var_id_max=cap * Max_loss_per_pos/ Buff_var_id
    delta_max=var_id_max/ var_id
    var_id= atr_hd * iv_hv
    ic_max_id= delta_max/ i_detla
    weigh_max= cap * weigh_per_pos
    ic_max_weigh= weigh_max/ i_ip
    i_ic@entry = min (ic_max_id, ic_max_weigh)
"""
weigh_per_pos=0.05   
MAX_loss_per_pos=0.03
BUFF_var_id=3  # R: stop@ 3 std_daily
#    v_stk_vol_pct=2.5
key_level_pct=0.01    
exit_days_pct=0.5
event_days=5
itm_pct=0.02
spike_min=1
stop_spike=BUFF_var_id
stop_spike_etd=1.1
hiv_chg_pct=0.2
hv_rank_chg_min=0.1
loss_size_pct_max=0.2
gain_size_pct_min=0.9
size_chg_days_pct_max=0.3
vega_min= 15
days_pct_tgt_p=0.3
oi_chg_min=500
oi_chg_pct_min=0.3
o_vol_pct_min=2


#%%
def pid_calc(dg):
    """
    use: re_calc lc, lp, mp for group_by_pid
    """
    dc=pd.DataFrame()
    g_lc=np.abs(dg['lc']).min()
    g_lp=(dg['lc']*dg['lp']).sum()/g_lc
    g_mp=(dg['lc']*dg['mp']).sum()/g_lc
    return g_lc, g_lp, g_mp

def report_by(q_date, rpt_by=''): 
    """
    use: get report_by_pid/ ticker/ cid
    tip: groupby (,as_index=False).agg()
    """
    # tbl_oc & tbl_cid    
    dt=read_sql("select * from tbl_oc where exit_dt ='N'")
    dt=dt[~(dt['pid'].str[:1]=='U')]
    
    dcid=read_sql("select * from tbl_cid")
    dcid['date']=pd.to_datetime(dcid['date'])
    dcid=dcid[dcid.date==q_date]
    
    df=dt.merge(dcid, on=['ticker', 'cid'],how='left')
    df.sort_values(['cid','entry_dt'], inplace=True)
    
    col_g=['pl','pl_delta', 'pl_gamma','pl_theta','pl_vega', 'pl_exp',\
         'pl_p', 'pl_p_delta', 'pl_p_gamma','pl_p_theta','pl_p_vega', 'pl_p_exp', \
         'pl_ur', 'risk_live',\
         'delta_p', 'gamma_p', 'theta_p', 'vega_p',\
         'delta_i', 'gamma_i', 'theta_i', 'vega_i',\
#         'var_delta', 'var_gamma', 'var_theta',\
         'delta_c',  'gamma_c', 'theta_c', 'vega_c', 'comm_c']
    #common fields
    dt_g=['oexp_dt','entry_dt','play','sec','act','earn_dt']
    #@below @cid level, above is cid*lc
    col_cid=['delta', 'gamma', 'theta', 'vega',\
             'lc', 'lp', 'mp']
    col=col_g + col_cid
    df=type_convert(df, col, 'float')
    dg=pd.DataFrame()
    #re_calc lp, mp, pl_ur_pct, pl_exp_pct, pl_p_exp_pct
    for x in col_g:
        dg[x]=df.groupby(rpt_by)[x].sum()
    for y in dt_g:
        dg[y]=df.groupby(rpt_by)[y].min()

    dg['pl_ur_pct']=dg['pl_ur']/(dg['risk_live']-dg['pl_ur'])
    dg['pl_exp_pct']=dg['pl_exp']/dg['pl_ur']
    dg['pl_p_exp_pct']=dg['pl_p_exp']/dg['pl_p']
    dg.reset_index(inplace=True)
    
    #re_cacl lc, lp, mp for pid only
    if rpt_by==['ticker','pid']:
        dc=df.groupby(['ticker','pid']).apply(pid_calc)
        dc=dc.to_frame()
        dc['lc']=dc[0].str[0]
        dc['lp']=dc[0].str[1]
        dc['mp']=dc[0].str[2]
#        dc['var_iv']=np.abs(df['var_delta'])+np.abs(df['var_gamma']+df['var_theta'])
        dc.reset_index(inplace=True)
        col_c=['ticker','pid','lc','lp','mp']
        dg=pd.merge(dg, dc[col_c], on=['ticker','pid'], how='left')
#    show=['ticker','pl', 'pl_ur_pct','lc', 'lp', 'mp','pl_exp', 'pl_exp_pct',\
#          'pl_delta', 'pl_gamma', 'pl_theta','pl_vega', 'pl_p', 'pl_p_exp_pct']   
    #merge back with other fields from tbl_cid, tbl_oc

    elif rpt_by==['cid']:
        col_share=list(set(df.columns.tolist()) - set(dg.columns.tolist()))
        col_add=col_share + list(rpt_by)
        dg=dg.merge(df[col_add], on=rpt_by, how='left')

    return dg
#%%
def cid_report(df):
    """
    use: risk_view@cid by sec/oexp_dt
    """
    #tbl_act        
    df_cap=read_sql("SELECT * FROM tbl_act", q_date)
    df=df.merge(df_cap[['act','cap']], on='act',how='left')
    df['weigh']=df['risk_live']/df['cap']
    dt_overview=dx.groupby('act').agg({'risk_live':'sum', 'weigh':'sum', 'pl':'sum'})   
    print (" - --Overview ---- \n # of tickers: %s \n"%dt.shape[0], dt_overview)   
    col_rpt=['var_iv', 'var_id', 'risk_live','weigh','pl_ur',  'pl', 'pl_p',\
             'delta_c','gamma_c','theta_c', 'vega_c'] 
    dt[col_rpt]=dt[col_rpt].replace('',0)      
    rpt_1=dt.pivot_table(index=['oexp_dt','sec'], values= col_rpt, aggfunc= 'sum', \
            fill_value= 0, margins = True, margins_name= 'total')

    rpt_2=dt.pivot_table(index=['sec', 'oexp_dt'], values= col_rpt, aggfunc= 'sum', \
            fill_value= 0, margins = True, margins_name= 'total')
    print(rpt_1)
    print(rpt_2)
#%%
def size_pid(df_all):
    """
    use: pid calc size_max, size_adj
    """
    weigh_per_pos=0.05   
    MAX_loss_per_pos=0.025
    BUFF_var_id=3 #3 times of expected move (based on iv)
    
#@ticker, update cap data
    df_cap=read_sql("SELECT * FROM tbl_act")
    dt_all=dt_all.merge(df_cap[['act','cap']], on='act',how='left')
# @ticker, updte with latest stat_VIEW (var_hd, rsi)
    ds=stat_VIEW(q_date, dt_all['ticker'].tolist())
    ds.drop('sec', axis=1, inplace=True)
    col_share=list(set(dt_all.columns).intersection(set(ds.columns)))
    #preserve sec value from tbl_c for non-sp ticker
    col_drop=[x for x in col_share if x not in ['ticker', 'sec']]
    dt_all.drop(col_drop, axis=1, inplace=True)
    dt=pd.merge(dt_all, ds, on='ticker')
    
             
            
#%%
def oraw(q_date): 
    '''
    Use: track@q_date
    Source: tbl_oc (), tbl_cid (pl@cid), tbl_iv(iv@ticker)
            tbl_mc_raw, tbl_obc_raw, tbl_act, stat_VIEW, tbl_risk, flask_trd
    Goal:
    ? unop hold: o_vol@cid, vol_pct, oi_c_chg_pct@iv, unop@bc_mc_raw
    ? stop/exit: pl_ur_pct
    ? 
  
    
    Immediate control:
    0) daily update IBQ_cap
    1) con_weigh (risk_live/cap)>max_weigh_per_pos
    2) size_pct: max(var_id,var_hd)*BUFF_var_id )/(cap* MAX_loss_per_pos))
    3) spike>Buff_var_id(R multiple: 3* std)
    4) spike_etf>1   
    '''
    oi_chg_min=500
    oi_chg_pct_min=0.3
    o_vol_pct_min=2
# tbl_oc & tbl_cid    
    dx=report_by('cid')
    dy=report_by(['ticker','pid'])
    dz=report_by('ticker')
    
    dt_all=dy  #pid, or should be dt for live_oc only

#@ticker, update cap data
    df_cap=read_sql("SELECT * FROM tbl_act", q_date)
    dt_all=dt_all.merge(df_cap[['act','cap']], on='act',how='left')

    #get risk profile (r, rx, risky)
    dr=read_sql("SELECT * FROM tbl_risk")
    dr=type_convert(dr, ['r','rx'], 'float')
    col_risk=[x for x in dr.columns if x not in ['index','play']]
#    dt.drop(col_risk, axis=1, inplace=True)    
    #update with tbl_risk profile
    dt=pd.merge(dt, dr, on='play')  
    dt['weigh']=dt['risk_live']/dt['cap']
    dt['size_pct']=np.abs((dt[['var_id','var_hd']].max(axis=1)*BUFF_var_id )/  \
              ( dt['cap']* MAX_loss_per_pos))
    dt['size_buff']=( dt['cap']*MAX_loss_per_pos)- \
            np.abs(dt[['var_id','var_hd']].max(axis=1)* BUFF_var_id ) 
            
            
     
#@get ticker level data from tbl_iv
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date'])
    div.sort_values('date', inplace=True)
    col_iv=['oi','oi_c', 'iv_chg_pct','oi_p', 'vol_pct']
    div=reg_convert(col_iv, div, 'float')
    div['oi_chg']=div['oi']-div['oi'].shift(1)
    div['oi_c_chg']=div['oi_c']-div['oi_c'].shift(1)   
    div['oi_p_chg']=div['oi_p']-div['oi_p'].shift(1)   
    div=div[div.date==q_date]
    div['oi_c_chg_pct']=div['oi_c_chg']/(div['oi_c']-div['oi_c_chg'])
    div['oi_p_chg_pct']=div['oi_p_chg']/(div['oi_p']-div['oi_p_chg'])
    
    col_iv=['div', 'div_dt', 'earn_dt_mc', 'ind','iv', 'iv_1y',\
       'iv_chg_pct', 'iv_rank', 'mcap', 'oi', 'oi_p_pct', 'p', 'p_chg',
       'p_chg_pct', 'ticker', 'vol', 'vol_pct', 'vol_stk', 'yld',\
       'oi_c_chg','oi_c','oi_p','oi_p_chg','oi_chg', 'spike_iv',\
       'oi_c_chg_pct','oi_p_chg_pct']
    div=div[col_iv]
    
    dt_all=dt_all.merge(div, on='ticker', how='left')
    

# @ticker, updte with latest stat_VIEW
    ds=stat_VIEW(q_date, dt_all['ticker'].unique().tolist())
    ds.drop('sec', axis=1, inplace=True)
    col_share=list(set(dt_all.columns).intersection(set(ds.columns)))
    #preserve sec value from tbl_c for non-sp ticker
    col_drop=[x for x in col_share if x not in ['ticker', 'sec']]
    dt_all.drop(col_drop, axis=1, inplace=True)
#    dt=pd.merge(dt_all, ds, on='ticker')
    dt=dt_all.merge(ds, on='ticker', how='left')
    
#@ticker,  in mc_raw or bc_raw?
    df_mc=read_sql("SELECT * FROM tbl_mc_raw ", q_date)
    df_mc['date']=pd.to_datetime(df_mc['date'])
    df_mc=df_mc[df_mc.date==q_date]
    loc_mc=dt['ticker'].isin(df_mc['ticker'])
    if loc_mc.any():
        dt.loc[loc_mc,'mc']=df_mc['ticker'] +'|' + df_mc['v_pct'].astype(str)\
            +'|'+df_mc['pct_c'].astype(str)
    else:
        dt['mc']=np.NaN
    df_bc=read_sql("SELECT * FROM tbl_obc_raw ", q_date)
    df_bc['date']=pd.to_datetime(df_bc['date'])
    df_bc=df_bc[df_bc.date==q_date]
    loc_bc=dt['ticker'].isin(df_bc['ticker'])
    if loc_bc.any():
        dt.loc[loc_bc,'bc']=df_bc['ticker'] +'|' + df_bc['v_oi'].astype(str)\
            +'|'+df_bc['type'].astype(str)
    else:
        dt['bc']=np.NaN
    dt['entry_dt']=pd.to_datetime(dt['entry_dt']).dt.date
#if first date then update si, div_dt , earn_dt
    con_new=dt['entry_dt']==q_date
    dt.loc[pd.isnull(dt.earn_dt), 'earn_dt']=dt['earn_dt_mc']
    
    for index, row in dt[con_new].iterrows():
        try:
#            fun_col=[ 'beta', 'earn_dt', 'earn_last', 'pe',  'ta', 'yld', 'sector'] 
            fun_col=['beta','pe','ta']
            FUN=get_FUN(row.ticker)  
            for k in fun_col:
                dt.loc[index, k]=FUN[k]
        except:
            for k in fun_col:
                dt.loc[index, k]=0
        try:
            si_col= ['si'] 
            SI=get_SI(row.ticker)
            for k in si_col:
                dt.loc[index, k]=SI[k]
        except:
            for k in si_col:
                dt.loc[index, k]=0
#Clean/convert data
    #1. from flask 
    dt['date']=q_date
#    dt['date']=pd.to_datetime(dt['date'])
    dummy_dt='2000-1-1'
#    flask_val=['ioc','iop','comm','strike']
    flask_dt=['entry_dt', 'oexp_dt', 'earn_dt', 'div_dt','date']
#          
#    for x in flask_val:
#        dt.loc[con_new, x]=dt.loc[con_new, x].replace('',0).replace('None',0).astype(float)
    
    for x in flask_dt:
        dt[x]=pd.to_datetime(dt[x])
    #data prep for cal
    col_float=['delta_c','vega_c','pl', 'pl_ur','theta_c', 'iv',\
               'pl_ur_pct']
    dt=type_convert(dt, col_float)
#    """
#    for x in flask_dt:
#        for ch in ['','None','N','N/A','0']:
#            dt.loc[con_new, x]=dt.loc[con_new, x].str.strip()
#            dt.loc[con_new, x]=dt.loc[con_new, x].replace(ch,dummy_dt).astype(str)
#        dt.loc[con_new, x]=dt.loc[con_new, x].apply(lambda i: parser.parse(i))
#    """
    dt['tgt_dt']=dt['entry_dt']+(dt['oexp_dt']-dt['entry_dt'])/2
    dt['days_to_exp']=dt['oexp_dt'].subtract(dt['date']).dt.days   
    dt['days_all']= dt['oexp_dt'].subtract(dt['entry_dt']).dt.days   
    dt['days_pct']=(1-dt['days_to_exp']/dt['days_all']).round(2)
    dt['days_to_div']=dt['div_dt'].subtract(dt['date']).dt.days
    dt['days_to_earn']=dt['earn_dt'].subtract(dt['date']).dt.days
    dt['days_to_tgt_dt']=dt['tgt_dt'].subtract(dt['entry_dt']).dt.days
#    dt['days_to_event']=dt['event_dt'].subtract(dt['date']).dt.days

# insert var_greeks cacl once from tbl_cid
    dt['var_hd']=dt['delta_c']*dt['atr_hd']
    dt['var_hv']=dt['vega_c']*dt['atr_hv']*100
    dt['atr_id']=dt['close']*dt['iv']/(252**0.5)
    dt['var_id']=dt['delta_c']*dt['atr_id']
    dt['var_iv']=dt['vega_c']*dt['atr_id']
    dt['iv_hv']=dt['iv']/dt['hv_22']
# prob of profit
#    dt=prob_oc(dt, q_date)
#ALERT data prepare
    #    dt['fm_strike']=(dt['close']/dt['strike']-1).round(2)
    
#    dt['srtn_22_chg']=dt['srtn_22_pct']-dt['i_srtn_22_pct']
#    dt['rtn_22_chg']=dt['rtn_22_pct']-dt['i_rtn_22_pct']
#    dt['hv_22_chg_pct']=dt['hv_22']/dt['i_hv_22']-1
    #    dt['rsi_chg']=dt['rsi']<dt['i_rsi']
    
#    dt['days_etd']=dt['days_all']-dt['days_to_exp']
#    dt['sig_etd']=dt['entry_p']*dt['i_iv']*np.sqrt(dt['days_etd']/252)
#    dt['spike_etd']=(dt['close']-dt['entry_p'])/dt['sig_etd']
#    dt['sig_etd2']=dt['entry_p']*dt['i_hv_22']*np.sqrt(dt['days_etd']/252)
#    dt['spike_etd2']=(dt['close']-dt['entry_p'])/dt['sig_etd2']   
#    dt['spike_etd']=dt[['spike_etd','spike_etd2']].max(axis=1)
    
    #get risk profile (r, rx, risky)
    dr=read_sql("SELECT * FROM tbl_risk")
    dr=type_convert(dr, ['r','rx'], 'float')
    col_risk=[x for x in dr.columns if x not in ['index','play']]
#    dt.drop(col_risk, axis=1, inplace=True)    
    #update with tbl_risk profile
    dt=pd.merge(dt, dr, on='play', how='left')  
    dt['size_pct']=np.abs((dt[['var_id','var_hd']].max(axis=1)*BUFF_var_id )/  \
              ( dt['cap']* MAX_loss_per_pos))
    dt['size_buff']=( dt['cap']*MAX_loss_per_pos)- \
            np.abs(dt[['var_id','var_hd']].max(axis=1)* BUFF_var_id )
    #reporting            
    dt['v_und']=dt['delta_c']*dt['close']
    spy=read_sql("select close from tbl_pv_etf where ticker ='SPY'")
    spy=spy.tail(1).iloc[0,0]
    dt['beta']=dt['beta'].replace('',1).astype(float)
    dt['v_spy']=dt['v_und']*dt['beta']/spy

    #size_chg
    dt['delta_to_adj']=dt['delta_c']*(1-dt['size_pct'])
    dt['weigh_to_adj']=(weigh_per_pos - dt['weigh'])*dt['cap']
#, no new column from here onward
# for proper risk calc, move dead to tbl_c_hist
    scm_t_c=list(dict.fromkeys(dt.columns.tolist()))
    scm_t_c=[x for x in scm_t_c if x not in ['index','index_x','index_y',\
        'r_x', 'r_y','rx_x', 'rx_y', 'risky_x','risky_y']]
    dt=dt[scm_t_c]
    con_live=dt['exit_dt']=='N'
    dt_dead=dt[~ con_live]
    try:
        z3_test=dt.groupby('act')['pl'].sum()
    except:
        print("track_raw: ln341:  Must produce aggregated value")
    #validate dead trade
    con_lc=dt['lc']==0  #no live contract
    if (con_live & con_lc).any() | (~con_live & ~con_lc).any():
        print("track_raw: ln337, con_live <>con_lc")
    if ~ dt_dead.empty:
        to_sql_append(dt_dead, 'tbl_track_hist')
        print("track_raw: tbl_c_hist appended: %s"%dt_dead.ticker.tolist())
    dt=dt[con_live]
    if dt.empty:
        print("track_raw: ln367, dt.empty")
        return
    else:
        to_sql_replace(dt, 'tbl_track')
        #Track @ Act & asset level

    """
    con_plot=(rpt_2['weigh']>=0.05)|(np.abs(rpt_2['var_id'])>50)
#    stat_PLOT(q_date, rpt_2[con_plot].sec.tolist())
    CON_stop= (dt['pl_ur_pct'].astype(float) <= dt['r'].astype(float))
    CON_out=(dt['tgt_dt']<q_date) | (dt['days_pct']>=exit_days_pct)
    CON_exit=dt['pl_ur_pct'].astype(float) > dt['rx'].astype(float)
# alert_itm:    
    con_l=dt['delta_c']>0
    con_s=dt['delta_c']<0
#    con_n=dt['lsnv']=='N'
#    con_v=dt['lsnv']=='V'
#    con_fm_strike_up=(dt['close']/dt['strike']-1)>=itm_pct
#    con_fm_strike_dn=(dt['close']/dt['strike']-1)<=(0 - itm_pct)
#    con_sc_up=(dt['play'].isin(['SC','SCV','SCP','BW'])) & con_fm_strike_up
#    con_sp_dn=(dt['play'].isin(['SP','SPV','SCP','SYN'])) & con_fm_strike_dn
#    con_nc_up= ((dt['pc']=='C') & (dt['play'].isin(['CAL','BF']))) & con_fm_strike_up
#    con_np_dn= ((dt['pc']=='P') & (dt['play'].isin(['CAL','BF']))) & con_fm_strike_up
#    CON_itm=con_sc_up | con_sp_dn | con_nc_up |con_np_dn
    
#a_be
#    CON_be=(dt.close>dt.beup) | (dt.close< dt.bedn)
#a_event        
    con_earn_dt=dt['days_to_earn']>0
    con_div_dt=dt['days_to_div']>0
#    con_event_dt=dt['days_to_event']>0
    CON_event=(dt['days_to_div']<=event_days & con_div_dt)\
            |(dt['days_to_earn']<=event_days & con_earn_dt)
#              |(dt['days_to_event']<=event_days & con_event_dt )  
#a_momt    
#    con_momt_l= con_l & (  (dt['srtn_22_pct']<dt['i_srtn_22_pct']) \
#                    | (dt['rtn_22_pct']<dt['i_rtn_22_pct']) )
#    con_momt_s= con_s & ( (dt['srtn_22_pct']>dt['i_srtn_22_pct']) \
#                   | (dt['rtn_22_pct']>dt['i_rtn_22_pct']) )
#    CON_momt= con_momt_l | con_momt_s
#a_key_level
    CON_key_level=(np.abs(dt['fm_50'])<= key_level_pct) \
          |(np.abs(dt['fm_200'])<= key_level_pct) \
          |(np.abs(dt['fm_hi'])<= key_level_pct) \
          |(np.abs(dt['fm_lo'])<= key_level_pct)   
#a_unop or oi_chg
    con_oi_c = (np.abs(dt['oi_c_chg'])> oi_chg_min) & (np.abs(dt['oi_c_chg_pct'])>oi_chg_pct_min)
    con_oi_p = (np.abs(dt['oi_p_chg'])> oi_chg_min) & (np.abs(dt['oi_p_chg_pct'])>oi_chg_pct_min)    
    con_oi = con_oi_c | con_oi_p
#    con_vol=dt['vol_pct']> o_vol_pct_min 
    con_o_oi=np.abs(dt['o_oi_i_chg_pct']> oi_chg_pct_min)
    con_bmc=pd.notnull(dt['mc']) |pd.notnull(dt['bc'])  
    CON_unop=con_bmc | con_oi |con_o_oi
#a_vol
#    con_lv_play=dt['vega']< vega_min
#    con_hv_play=dt['vega']> vega_min
#    con_hiv_up=(dt['hv_22']/dt['i_hv_22']> (1+hiv_chg_pct)) & con_lv_play
#    con_hiv_dn=(dt['hv_22']/dt['i_hv_22']< (1-hiv_chg_pct)) & con_hv_play
#    CON_spike= (np.abs(dt['spike'])>spike_min) 
    CON_spike= (np.abs(dt['spike'])>spike_min) |(np.abs(dt['spike_iv'])>spike_min)
#    con_hv_rankup=dt['hv_rank']>dt['i_hv_rank']*1.1
#    con_hv_rankdn=dt['hv_rank']<dt['i_hv_rank']*0.9
#    con_hiv= con_hiv_up | con_hiv_dn
#    CON_spike= (np.abs(dt['spike'])>spike_min)
#    CON_spike_stop=(np.abs(dt['spike'])>stop_spike ) |(np.abs(dt['spike_etd'])>stop_spike_etd)
    #a_delta vega wrong
#    con_dv_ln=(dt['lsnv']=='LN') & (dt['delta']<0)
#    con_dv_sn=(dt['lsnv']=='SN') & (dt['delta']>0)
#    con_dv_n=(dt['lsnv']=='N') & CON_spike  #main play is N, start trending
#    con_dv_v=(dt['lsnv']=='V') & con_hiv  # main play is Vol
#    CON_dv=(con_dv_ln | con_dv_sn |con_dv_n | con_dv_v)
    #a_size
    con_weigh=dt['weigh'] >=weigh_per_pos
    con_oversize=dt['size_pct']>=1
    con_add=(dt['pl_ur_pct']>0) & (dt['days_pct']<size_chg_days_pct_max) & (dt['size_pct']<gain_size_pct_min)
    con_cut=(dt['pl_ur_pct']<0) & (dt['days_pct']>=size_chg_days_pct_max) & (dt['size_pct']>=loss_size_pct_max)
    con_cut=con_cut | con_weigh | con_oversize
    CON_size=con_add | con_cut
    #a_tgt_p, pre-order?
#    CON_tgt_p= (dt['days_pct']>days_pct_tgt_p) & (dt['tgt_p']==0)
#UPDATE alert
    dt['a_out']=CON_out
    dt['a_stop']=CON_stop
    dt['a_exit']=CON_exit
    dt['a_size']=CON_size
#    dt['a_be']=CON_be
#    dt['a_dv']=CON_dv
    dt['a_spike']=CON_spike
#    dt['a_itm']=CON_itm
    dt['a_event']=CON_event
#    dt['a_momt']=CON_momt 
    dt['a_key']=CON_key_level
    dt['a_unop']=CON_unop
#    dt['a_tgt_p']=CON_tgt_p
    dt.loc[con_add, 'a_size']='+'
    dt.loc[con_cut, 'a_size']='-'
#clean display
    dt.replace(False, "", inplace=True)
    dt.replace(np.nan, "", inplace=True)
#    dt.loc[~con_event_dt, 'event_dt']=np.nan
    dt.loc[~con_earn_dt, 'earn_dt']=np.nan    
    dt.loc[~con_div_dt, 'div_dt']=np.nan
    CON_event_show=pd.notnull(dt['div_dt'])|pd.notnull(dt['earn_dt'])
#        |pd.notnull(dt['event_dt'])
    show_alerts=['ticker','risk_live', 'pl_ur_pct', 'pl_ur','var_id',\
                 'a_out', 'a_stop', 'a_exit','a_unop', 'a_size',  'a_spike', \
                'a_unop', 'a_key','theta_c','delta_c']
    print(dt[show_alerts])
    return dt
    """
    show_base=['ticker','risk_live','pl_ur_pct','days_pct', 'prob', 'close', 'iv_hv', 'iv', 'delta_c', 'theta_c','var_id']
    show_stop=show_base + ['bedn','beup','theta']
    show_out=show_base 
    show_exit=show_base + ['days_to_exp']
    show_size=['ticker','a_size','pl_pct','size_pct', 'weigh','size_buff','delta_to_adj',\
               'risk_live','weigh_to_adj', 'mp','days_pct','iv_hv', 'risky','play']
    show_be=['ticker','close','bedn','beup', 'play', 'delta', 'days_pct', 'prob_t','prob']
    show_dv=['ticker','var_id', 'vega','iv','i_iv', 'hv_22','hv_22_chg_pct','iv_hv','play']
    show_spike=['ticker','spike','spike_etd', 'beup','bedn','close',\
                'entry_p', 'iv', 'i_iv','pl_pct','days_pct']
    show_itm=['ticker','days_pct','close', 'strike','prob_t','prob', 'div_dt', 'lsnv','pc','play']
    show_unop=['ticker','mc','bc']
    show_event= ['ticker','days_pct','close','div_dt','event_dt', 'earn_dt']
    show_momt=['ticker', 'delta','rtn_22_chg','srtn_22_chg','entry_p','strike','close', 'play','sec']
    show_tgt_p=['ticker', 'days_pct','tgt_p','pl_pct', 'tgt_dt', 'prob_t', 'prob']

    dt.sort_values(['risk_live','pl_pct','days_pct'], ascending=False, inplace=True)
    pd.set_option('display.expand_frame_repr', False)
    print(" \n---- ALERT  ---  \n ", dt[show_alerts].to_string(index=False))
    print("\n ---- STOP ---   \n ", dt[CON_stop][show_stop])
    print("\n ---- OUT ---    \n ", dt[CON_out][show_out])
    print("\n ---- EXIT ---   \n ", dt[CON_exit][show_exit])
    print("\n ---- SIZE ---   \n ", dt[CON_size][show_size].sort_values(['size_pct','weigh'], ascending=False))
    print("\n ---- BE ---   \n ", dt[CON_be][show_be])
    print("\n ---- SPIKE OUT ---   \n ", dt[CON_spike_stop][show_spike].sort_values(['spike','spike_etd']))
    print("\n ---- SPIKE actioin ---   \n ", dt[CON_spike][show_spike].sort_values(['spike','spike_etd']))
    print("\n ---- LSNV or PLAY wrong ---   \n ", dt[CON_dv][show_dv])
    print("\n ---- ITM ---    \n ", dt[CON_itm][show_itm])
    print("\n ---- UNOP ---    \n ", dt[CON_unop][show_unop])
    print("\n ---- EVENT---   \n ", dt[CON_event & CON_event_show][show_event])
    print("\n ---- MOMT ---    \n ", dt[CON_momt][show_momt].sort_values(['delta'], ascending=False))
    print("\n ---- TGT_P ---    \n ", dt[CON_tgt_p][show_tgt_p]) 
    pd.set_option('display.expand_frame_repr', True)
    return dt
    """
#%%
def cid_track(q_date):
    """
    use: plot chg_mp, iv, vol, close@cid level
    raw source: tbl_oc, tbl_cid, tbl_iv, tbl_pv_all
    intel: i_chg in (o_oi, mp, iv, close, volume)
    alert: mp_i_chg_pct (add)
    
    2. risk_view_by_sec_exp
    """
    print("  cid_track started  ")
# aggr data@cid level, incl. 'U1' tid
    dt=read_sql("select * from tbl_oc where exit_dt ='N'")
    dt['oexp_dt']=pd.to_datetime(dt['oexp_dt'])
    dt['entry_dt']=pd.to_datetime(dt['entry_dt'])    
    dt['days_to_exp']=dt['oexp_dt'].subtract(q_date).dt.days   
    dt['days_all']= dt['oexp_dt'].subtract(dt['entry_dt']).dt.days   
    dt['days_pct']=(1-dt['days_to_exp']/dt['days_all']).round(2)
    col_dt=['cid','days_pct', 'pid']
#    list_t=dt.ticker.unique().tolist()
    
    do=read_sql("select * from tbl_cid")
    do['date']=pd.to_datetime(do['date'])
    do['ticker']=do['cid'].str.split('-').str[0]
    col_cid=['cid', 'mp', 'pl', 'o_oi','o_vol','date', 'ticker']
    dot=do[col_cid].merge(dt[col_dt], on='cid', how='left')
#    do=do[do.ticker.isin(list_t)]
    
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date'])  
    col_iv=['ticker','date', 'iv', 'oi', 'oi_c', 'oi_p', 'vol']
    
    dpv=read_sql("select * from tbl_pv_all")
    dpv['date']=pd.to_datetime(dpv['date'])      
    col_pv=['ticker','date','close','volume']
    
    df=dot.merge(div[col_iv], on=['ticker','date'], how='left')
    df=df.merge( dpv[col_pv], on=['ticker','date'], how='left' )
#rolling chg from i_date
    df['o_oi_i_chg']=df.groupby('cid')['o_oi'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['mp_i_chg']=df.groupby('cid')['mp'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['iv_i_chg']=df.groupby('cid')['iv'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['close_i_chg']=df.groupby('cid')['close'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['volume_i_chg']=df.groupby('cid')['volume'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    con_u= df['pid'].str[:1]=='U'
    con_days_pct=df['days_pct']<0.5
    
    dft=df[(~con_u) & con_days_pct]
    dv_q=dft[dft.date==q_date][['cid','mp_i_chg', 'mp','days_pct']].sort_values('mp_i_chg')
    print(dv_q)
    dv_1=pd.pivot_table(dft, index='date', columns='cid', values='mp_i_chg')
# plot mp_chg for all cid    
    dv_1.sort_values(by=q_date, ascending=False, axis=1, inplace=True)
    dv_1.plot(kind='line',  figsize=(16,8), rot=45, alpha=0.7)    

    dfu=df[con_u & con_days_pct]  
    dv_u=dfu[dfu.date==q_date][['cid','mp_i_chg', 'mp','days_pct']].sort_values('mp_i_chg')
    print(dv_u)
    du_1=pd.pivot_table(dfu, index='date', columns='cid', values='mp_i_chg')
#    dv_2.plot(kind='line',  figsize=(16,8), rot=45, alpha=0.7)
    du_1.sort_values(by=q_date, ascending=False, axis=1, inplace=True)
    du_1.plot(kind='line',  figsize=(16,8), rot=45, alpha=0.7)
#plot mp_chg, close_chg, iv_chg for each cid
#    for c in df.cid.unique().tolist():
#        dg=df[df.cid==c]
#        dg.plot(x='date', y=['close_chg','mp_chg','iv_chg'])
    

#%%
def cid_track_new(q_date):
    """
    use: plot chg_mp, iv, vol, close@cid level
    raw source: tbl_oc, tbl_cid, tbl_iv, tbl_pv_all
    link: 'cid' : tbl_oc, tbl_cid
    
    """
    print("  cid_track started  ")
# aggr data@cid level, incl. 'U1' tid
    dt=read_sql("select * from tbl_oc where exit_dt ='N'")
    dt['oexp_dt']=pd.to_datetime(dt['oexp_dt'])
    dt['entry_dt']=pd.to_datetime(dt['entry_dt'])    
    dt['days_to_exp']=dt['oexp_dt'].subtract(q_date).dt.days   
    dt['days_all']= dt['oexp_dt'].subtract(dt['entry_dt']).dt.days   
    dt['days_pct']=(1-dt['days_to_exp']/dt['days_all']).round(2)
    col_dt=['cid','days_pct', 'pid']
#    list_t=dt.ticker.unique().tolist()
    
    do=read_sql("select * from tbl_cid")
    do['date']=pd.to_datetime(do['date'])
    do['ticker']=do['cid'].str.split('-').str[0]
    col_cid=['cid', 'mp', 'pl', 'o_oi','o_vol','date', 'ticker']
    dot=do[col_cid].merge(dt[col_dt], on='cid', how='left')
#    do=do[do.ticker.isin(list_t)]
    
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date'])  
    col_iv=['ticker','date', 'iv', 'oi', 'oi_c', 'oi_p', 'vol']
    
    dpv=read_sql("select * from tbl_pv_all")
    dpv['date']=pd.to_datetime(dpv['date'])      
    col_pv=['ticker','date','close','volume']
    
    df=dot.merge(div[col_iv], on=['ticker','date'], how='left')
    df=df.merge( dpv[col_pv], on=['ticker','date'], how='left' )
#rolling chg from i_date
    df['o_oi_i_chg']=df.groupby('cid')['o_oi'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    
    
 #%%    
def prob_oc(df, q_date):  
    import scipy.stats
    #lc: live contract, lp: live price
    con_lc= (df.lc >0) & (df.type == 'C')
    con_sc= (df.lc <0) & (df.type == 'C')
    con_lp= (df.lc >0) & (df.type == 'P')
    con_sp= (df.lc <0) & (df.type == 'P')
 
    df.loc[con_lc, 'bedn']=df.loc[con_lc, 'strike'] + df.loc[con_lc, 'iop']
    df.loc[con_sc, 'beup']=df.loc[con_sc, 'strike'] + df.loc[con_sc, 'iop']
    df.loc[con_lp, 'beup']=df.loc[con_lp, 'strike'] - df.loc[con_lp, 'iop']
    df.loc[con_sp, 'bedn']=df.loc[con_sp, 'strike'] - df.loc[con_sp, 'iop']
    
    df['oexp_dt']=pd.to_datetime(df['oexp_dt'])
    df['dte']=df['oexp_dt'].subtract(q_date).dt.days
    df['std']=df['iv']*np.sqrt(df['dte']/252)
    df=type_convert(df, ['p','std'])
    for index, row in df.iterrows():
        std_p=row['p']*row['std']
        if row['beup']>0:
            df.loc[index, 'prob']=scipy.stats.norm.cdf(row['beup'], row['p'], std_p)
        elif row.bedn>0:
            df.loc[index, 'prob']=scipy.stats.norm.sf(row['bedn'], row['p'], std_p)
        else:
            pass
    df['prob']=df['prob'].astype(float).apply(lambda x: "{0:.0f}%".format(x*100))
    return df


#%%    
def calc_tbl_iv():  
    """
    use: cacl iv_i_chg, iv_i_rank, p_i_chg, iv_p ('i_date' depends on 'entry_dt'@tbl_oc
       , prep for pl_attr_cid()
    source: tbl_oc, tbl_iv, tbl_pv_all
    dest: pl_attr_cid()
    """
    div=read_sql("select * from tbl_iv")
    #tbl_oc: for entry_dt to decide i_date
    dt=read_sql("select * from tbl_oc where exit_dt ='N' ")  
    #tbl_pv_all: for p_i in case watchlist is added later
    dp=read_sql("select * from tbl_pv_all")
    dp['date']=pd.to_datetime(dp['date'])
    dtv=div.merge(dt[['ticker','entry_dt']], on ='ticker', how='right')
    dtv['date']=pd.to_datetime(dtv['date'])
    dtv['entry_dt']=pd.to_datetime(dtv['entry_dt'])
    df=pd.DataFrame()
    for t in dtv.ticker.unique().tolist():
        dg=dtv[dtv.ticker==t]
        dg.sort_values('date', inplace=True)
        #exclude tikcer from previous trade 
        dg=dg[dg.date>=dg.entry_dt]   
        dpt=dp[dp.ticker==t] 
        entry_dt=dg['entry_dt'].head(1).values[0]
        try:
            p_i=dpt[dpt.date==entry_dt]['close'].values[0]
            dg['iv_i_chg']=dg['iv'].tail(1).values[0]-dg['iv'].head(1).values[0] 
            dg['iv_chg']=dg['iv'].tail(1).values[0]-dg['iv'].tail(2).head(1).values[0]
            dg['iv_i_rank']=dg['iv_rank'].head(1).values[0]
            dg['p_i_chg']=dg['p'].tail(1).values[0]- p_i

        except:
            print(t)
            pass
        #get snapshot @q_date only
        dg=dg.tail(1)
        df=pd.concat([df, dg], axis=0)
    col=['date', 'div','div_dt', 'earn_dt_mc', 'entry_dt', 'ind', 'iv', 'iv_1y', 'iv_chg_pct',
       'iv_d', 'iv_i_chg_pct', 'iv_i_rank', 'iv_rank', 'mcap', 'oi', 'oi_c',
       'oi_p', 'oi_p_pct', 'p', 'p_chg', 'p_chg_pct', 'p_i_chg', 'sec',
       'spike_iv', 'ticker', 'vol', 'vol_pct', 'vol_stk', 'yld']
    return df

#%%
def var_cid(df):
    """
    use: cacl var_greeks,
    source: tbl_cid, calc_tbl_iv(need iv)
    dest: tbl_cid
    
    """

    
    df['atr_iv']=df['p']*df['iv']*np.sqrt(1/252)
    df['var_delta']=df['atr_iv']*df['delta'] *df['lc']*100
    df['var_gamma']=df['gamma']* 0.5 * 0.5* df['atr_iv']*df['lc']*100
    df['var_theta']=df['theta']*df['lc']*100
    return df
#    df['var_iv']=np.abs(df['var_delta'])+np.abs(df['var_gamma']+df['var_theta'])
    
 #%%    
def pl_attr_cid(q_date): 
    """
    use: append tbl_cid with pl_attr explained & outlier
    source: tbl_cid, calc_tbl_iv() (from tbl_iv, tbl_oc)
    dest: tbl_cid
    alert: pl_ur_pct, 
    note: p_u_chg is accuare (based on entry_dt, tbl_pv_all)
    pl_greek (greek_i depends on tbl_iv avaibability - up to watchlist updated date), can be off
    #https://www.elitetrader.com/et/threads/explaining-options-p-l-by-greeks.321460/
    """
    print("pl_attr_cid started" )
    pl_exp_pct=0.7
    pl_ur_pct_min=0.3
#get iv data    
    div=calc_tbl_iv()
    div['date']=pd.to_datetime(div['date'])
    div['entry_dt']=pd.to_datetime(div['entry_dt'])    
    
    #exclude unop trade, but might include exired cid as tbl_cid has not expir info
    #this will be updated by tbl_iv data
    did=read_sql("select * from tbl_cid WHERE comm_c IS NOT NULL")  
    did['date']=pd.to_datetime(did['date'])
# !! get mp_chg, pl_chg wiht new approach
    did['mp_p_chg']=did.sort_values('date').groupby('cid')['mp'].apply(lambda x:x-x.shift(1))
    did['pl_p']=did['mp_p_chg']*did['lc']*100
    
    did=did[did.date==q_date]
    did['ticker']=did['cid'].str.split('-').str[0]
    share_vd=['iv_d', 'iv_i_chg', 'iv_i_rank', 'p_i_chg']
    col_did=[x for x in did.columns.tolist() if not x in share_vd]
    #merge on live div only
    df=did[col_did].merge(div, on=['ticker','date'], how='right')
    col_val=['delta_p', 'theta_p', 'gamma_p', 'vega_p']
    df=type_convert(df, col_val, 'float')
    df['pl_delta']=df['delta_i']  *df['lc']*100* df['p_i_chg']
    df['pl_vega']=df['vega_i'] *df['lc']*100* df['iv_i_chg']*100  
    df['pl_gamma']= (df['gamma_i'] + df['gamma']) * 0.5 *df['lc']*100* 0.5* (df['p_i_chg'] **2 )
    df['theta_dt']=df['date'].subtract(df['entry_dt']).dt.days      
    df['pl_theta']=(df['theta'] + df['theta_i'])*0.5 * df['lc']*100* df['theta_dt']   
    df['pl_exp']=df['pl_delta']+df['pl_vega']+df['pl_theta']+df['pl_gamma']
    df['pl_exp_pct']=df['pl_exp']/df['pl'].astype(float)
   
# daily pl_attr
    df['pl_p_delta']=df['delta_p']*df['lc']*100* df['p_chg'] 
    df['pl_p_vega']=df['vega_p']*df['lc']*100* df['iv_chg']*100  
    df['pl_p_gamma']= df['gamma_p']*df['lc']*100* 0.5* (df['p_chg'] **2 )
    df['pl_p_theta']= df['theta_p'] * df['lc']*100
    df['pl_p_exp']= df['pl_p_delta'] +  df['pl_p_vega']+ df['pl_p_gamma']+ df['pl_p_theta']
    df['pl_p_exp_pct']=df['pl_p_exp']/df['pl_p'].astype(float)
    
    df=var_cid(df)

    con_out=np.abs(df['pl_exp_pct']-1)> (1- pl_exp_pct)
    con_p_out_1=np.abs(df['pl_p_exp_pct']-1)> (1- pl_exp_pct)
    con_p_out_2= df['pl_p_exp_pct']< (pl_exp_pct-1)
    con_p_out= con_p_out_1 | con_p_out_2
    col=['cid','pl_ur_pct','pl',  'lc', 'lp', 'mp', 'pl_exp_pct','pl_exp',  'pl_delta','pl_vega', 'pl_gamma', 'pl_theta',\
         'pl_p_exp_pct', 'pl_p', 'pl_p_exp','pl_p_delta','pl_p_vega', 'pl_p_gamma', 'pl_p_theta']

    df[['pl_ur_pct', 'pl_exp_pct', 'pl_p_exp_pct']] =df[['pl_ur_pct', 'pl_exp_pct', 'pl_p_exp_pct']].astype(float).applymap(lambda x: "{0:.0f}%".format(x*100))



    print("pl_outlier \n", df[con_out][col])
    print("pl_explainable: \n", df[~con_out][col])
    print("pl_p_outlier: \n", df[con_p_out][col])
    
 # drop tbl_cid@q_date then add enriched back
    col_cid=did.columns.tolist()
    col_pl= ['pl_theta', 'pl_gamma', 'iv_i_rank', 'pl_exp', 'theta_dt', \
        'pl_delta', 'pl_vega', 'iv_i_chg', 'pl_exp_pct', 'p_i_chg', 'iv_d',\
        'pl_p_exp_pct', 'pl_p_exp','pl_p_delta','pl_p_vega', 'pl_p_gamma', 'pl_p_theta',\
        'pl_p', 'mp_p_chg']
    col_new=col_cid + col_pl
    col=list(set(col_new))  #drop duplicated
    
    if df.empty | (df.shape[0]==0) | (df.shape[0] !=did.shape[0]):
        print("pl_attr_cid: df empty")
        return
    conn=get_conn()
    cur=conn.cursor()
    cur.execute("DELETE FROM tbl_cid WHERE date='%s' "%q_date) 
    conn.commit()
    cur.close()
    
    tbl_nodupe_append(q_date, df[col], 'tbl_cid')
    
    return df
    
#%%
def prob(dt):
    #update the prob@tgt_dt and prob @exp date

    for index, row in dt.iterrows():
            p_mean=row['close']
            std_t=row['iv']*np.sqrt(row['days_to_tgt_dt']/252)
            std= row['iv']*np.sqrt(row['days_to_exp']/252)
            
            if row['bedn']==0: #less or equal
                dt.loc[index, 'prob_t']=scipy.stats.norm.cdf(row['beup'], p_mean, std_t*p_mean)
                dt.loc[index, 'prob']=scipy.stats.norm.cdf(row['beup'], p_mean, std*p_mean)
                
            elif row['beup']==0:  #greater or equal
                dt.loc[index, 'prob_t']=scipy.stats.norm.sf(row['bedn'], p_mean, std_t*p_mean) 
                dt.loc[index, 'prob']=scipy.stats.norm.sf(row['bedn'], p_mean, std* p_mean )
    
            elif (row['bedn']>0) & (row['beup']>0):  #range
                if row['play']=='LCP': #straddle/strangle
                    dt.loc[index, 'prob_t']=scipy.stats.norm.sf(row['beup'], p_mean, std_t*p_mean) + \
                            scipy.stats.norm.cdf(row['bedn'], p_mean, std_t*p_mean)        
                    dt.loc[index, 'prob']= scipy.stats.norm.sf(row['beup'], p_mean, std*p_mean) + \
                        scipy.stats.norm.cdf(row['bedn'], p_mean, std*p_mean)
                else:
                    dt.loc[index, 'prob_t']=scipy.stats.norm.cdf(row['beup'], p_mean, std_t*p_mean)- \
                            scipy.stats.norm.cdf(row['bedn'], p_mean, std_t*p_mean)        
                    dt.loc[index, 'prob']= scipy.stats.norm.cdf(row['beup'], p_mean, std*p_mean)- \
                        scipy.stats.norm.cdf(row['bedn'], p_mean, std*p_mean)
            else:
                dt.loc[index, 'prob_t']=-1
                dt.loc[index, 'prob']=-1
    return dt

#def prob_t(['close','iv','days_to_tgt_dt','days_to_exp','bedn','beup']):
def prob_t(close ,iv, days_to_tgt_dt, days_to_exp, bedn, beup):  
    std_t=iv*np.sqrt(days_to_tgt_dt/252)
    std=iv*np.sqrt(days_to_exp/252)
    p_mean=close
    if bedn==0:  #less or equal
        prob_t=scipy.stats.norm.cdf(beup, p_mean, std_t*p_mean)
        prob=scipy.stats.norm.cdf(beup, p_mean, std*p_mean)
        
    elif beup==0:#greater or equal
        prob_t=scipy.stats.norm.sf(bedn, p_mean, std_t*p_mean) 
        prob=scipy.stats.norm.sf(bedn, p_mean, std* p_mean )
        
    elif (bedn>0 & beup>0):
        prob_t=scipy.stats.norm.cdf(beup, p_mean, std_t*p_mean)- \
                  scipy.stats.norm.cdf(bedn, p_mean, std_t*p_mean)        
        prob= scipy.stats.norm.cdf(beup, p_mean, std*p_mean)- \
                  scipy.stats.norm.sf(bedn, p_mean, std*p_mean)
    else: 
        print("track_raw:  ln319: beup/bedn both 0")
        return
    return prob_t, prob

