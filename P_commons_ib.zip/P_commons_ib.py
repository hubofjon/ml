# -*- coding: utf-8 -*-
"""
Created on Sat Nov 16 21:49:48 2019
1.  get_cid_greeks_ib_sync
1.1 get_cid_greeks_ib_async
2.  get_oi_occ_sync
2.1 get_oi_occ_async
3   get_chain_ib_sync
3.1 get_chain_ib_async

@author: frebo
"""

#import logging
#import time
from datetime import datetime
import numpy as np
from timeit import default_timer as timer
from datetime import timedelta
import time, platform
#import requests
import pandas as pd
from P_commons import *
from ib_insync import *
import asyncio
import nest_asyncio
import random
import io


import warnings
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format

if platform.node()=='LAPTOP-P2MHIA9Q':  #X1
    api='TWS'
    port= 7496
elif platform.node()=='HP-Main15':
    api='GW'
    port= 4001
api='GW'
port= 4001

occ_oi_min=1500
occ_oi_min_pain=0
occ_oi_min_vix=1000*7
occ_oi_expiry_depth_days =120

chain_trd_depth=3
chain_vix_depth=12
chain_strike_pct=0.2

chain_vol_oi_min=1000
chain_oi_min=1500
chain_vol_oi_ratio_min=3
chain_o_vol_vols_ratio_min=0.1
chain_prem_pct_min=0.05
chain_prem_min=2000

chain_oi_depth_days= 120
chain_trd_margin_min=200
chain_trd_risk_min=200
chain_trd_margin_ignore_max=50
chain_trd_mand_plays=['SC','SP','SCP','LC','LP','LCP']

scan_count_saved_by_ticker=5
scan_depth=10

sleep_bf_fetch=0.1  #seconds
sleep_af_fetch=1
    
#%%    
def  get_cid_greeks_ib_sync(cids=[], t_class=''):
        nest_asyncio.apply()
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            df_greeks= loop.run_until_complete(get_cid_greeks_ib_async(cids, t_class=''))
        finally:
            loop.close()
        time.sleep(2)
        assert(not df_greeks.empty), "get_cid_greeks_ib_sync_'%s':_______ empty result"%t_class
        return df_greeks
    
#%%
async def get_cid_greeks_ib_async(cids=[], t_class=''):
# =============================================================================
#     ASYNC use: return dataframe for all cids
#    t_class ['UNOP_TRD','UNOP_SCAN'] apply strike_pct
#     todo: thread safe for sync section insides async function
# =============================================================================
    start = timer()
    chunk_count= 48
    client_id=1
    def chunks(cids, chunk_count):
        for i in range(0, len(cids), chunk_count):
             yield cids[i: i+chunk_count]
    list_of_cids=list(chunks(cids, chunk_count))  
    ib = IB()
# connection    
    try:  #1st
        ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
    except:
        try:    #2nd
            client_id= client_id + random.randint(1,10)
            ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
        except:
            try:    #3rd
                client_id= client_id + random.randint(1,10)
                ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
            except:
                return ("ib_greeks_async unable to connect after 3 try")
    ib.reqMarketDataType( 2 )  #frozen data (eod)
    ib.client.MaxRequests = 48  # max 50 - to pace throttling
    print("ib connected id: ", client_id)
    list_greeks=[]
    df_greeks=pd.DataFrame()
    list_ib_error=[]

# ?? with ib:??   
# filer by strike_pct for UNOP_TRD and UNOP_SCAN only, get stock price
    if t_class in ['UNOP_TRD','UNOP_SCAN']:
        symbols=[]
        for cid in cids:
            sym=cid.split("-")[0]
            symbols.append(sym)
#        list_of_symbols=list(chunks(symbols, chunk_count))
        t_conts=[Stock(e,'SMART','USD') for e in symbols]
        await ib.qualifyContractsAsync(*t_conts) 
        t_prices=await ib.reqTickersAsync(*t_conts)
        ib.sleep(sleep_af_fetch)
        v_prices=[n.last for n in t_prices]
        k_prices=[n.contract.symbol for n in t_prices]
        dict_prices=dict(zip(k_prices, v_prices))

    for x in list_of_cids: #iter thru all chunks
        list_g=[]
        CONTS=[]
#    with ib:
        for cid in x:    #inter each cid in chunk, 
            ticker=cid.split("-")[0]
            expiry= '20' + cid.split("-")[1][:6]
            type= cid.split("-")[1][6:7]
            if type=='C':
                type_ib='CALL'
            else:
                type_ib='PUT'
            strike=int(cid.split("-")[1][7:].lstrip("0"))/1000
# filter strike_pct 
            if t_class in ['UNOP_TRD','UNOP_SCAN']:
                t_last=dict_prices[ticker]
                strike_up= t_last * (1+ chain_strike_pct)
                strike_dn= t_last * (1- chain_strike_pct)
                if (strike_dn<=strike) & (strike <=strike_up):          
                    cont=Option(ticker, expiry, strike, type_ib, 'SMART',100, 'USD')
            else:
                cont=Option(ticker, expiry, strike, type_ib, 'SMART',100, 'USD')
            CONTS.append(cont)
            
        await ib.qualifyContractsAsync(*CONTS)
        ib.sleep(sleep_bf_fetch)
        mds= await ib.reqTickersAsync(*CONTS)
        ib.sleep(sleep_af_fetch)
        
        for md in mds:
            #if no market data, log it, then jskip this cid, jump to next cid loop
            if not md.hasBidAsk():
                print("______get_cid_greeks_ib_async _______: no mkt data:", cid)
                list_ib_error.append(cid)
                continue
            # reconstruct 'cid'
            cid='-'.join(md.contract.localSymbol.split())
            bid=md.bid
            ask=md.ask
            sale=md.last
            o_vol=md.volume
            if md.lastGreeks is not None: 
                delta=md.lastGreeks.delta
                gamma=md.lastGreeks.gamma
                theta=md.lastGreeks.theta
                vega=md.lastGreeks.vega
                civ=md.lastGreeks.impliedVol
                p=md.lastGreeks.undPrice
                
            elif md.modelGreeks is not None:
                delta=md.modelGreeks.delta
                gamma=md.modelGreeks.gamma
                theta=md.modelGreeks.theta
                vega=md.modelGreeks.vega
                civ=md.modelGreeks.impliedVol
                p=md.modelGreeks.undPrice

            else:
                print("_____get_cid_greeks_ib_async:________ no greeks: ", cid)
                list_ib_error.append(cid)
                continue #skip this cid, loop next
                
            sale_prev=0
            keys_g=['civ', 'cid', 'p', 'bid', 'ask', 'sale', 'sale_prev', 'o_vol', 'delta', 'theta', 'vega', 'gamma']
            vals_g=[civ, cid, p,  bid, ask, sale, sale_prev, o_vol, delta, theta, vega, gamma]
            dic_g=dict(zip(keys_g, vals_g))
            list_g.append(dic_g)
            
        list_greeks += list_g  
    df_greeks=pd.DataFrame(list_greeks)
#    assert(not df_greeks.empty), "get_cid_greeks empty result"
# data cleanup
    df_greeks.fillna(0, inplace=True)
    col_vals=['sale', 'bid', 'ask','o_vol']
    try:
        df_greeks[col_vals].apply(lambda x: x.replace('nan',0))
    except:
        print("_______get_cid_greeks__async error_______:", df_greeks)
        ib.disconnect()
    ib.sleep(1)
    ib.disconnect()
    end = timer()
    print("get_cid_greek_ib_async:", timedelta(seconds=end-start))
    
    return df_greeks

#%%    
def get_oi_occ_sync(t_class, symbol_type='', symbols=[]): #
#    can return either chain or singe_cid od
# =============================================================================
#     source: get_oi_main_async, get_oi_subf_async
#    ext.: occ.com
#     dest: get_cid_greeks_ib_occ_sync_mc
#   EXCEPTION_handling: YES in subf
    # ref https://stackoverflow.com/questions/58906301/python3-7-aiohttp-is-slow
# =============================================================================
    start = timer()
    nest_asyncio.apply()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    chunk_count= 40
    def chunks(long_list, chunk_count):
        for i in range(0, len(long_list), chunk_count):
             yield long_list[i: i+chunk_count]
        
    list_of_symbols=list(chunks(symbols, chunk_count))  
    list_of_txt_files=[]
    list_of_tickers=[]
    try:
        for syms_by_chunk in list_of_symbols:
            txt_files_by_chunk, tickers_by_chunk= loop.run_until_complete(get_oi_async_main(t_class, symbol_type, syms_by_chunk ))
            list_of_txt_files.extend(txt_files_by_chunk)
            list_of_tickers.extend(tickers_by_chunk)
            time.sleep(4)
    except:
        cprint("_____get_oi_new_sync_ERROR_____", 'white', 'on_red')
    finally:
        loop.close()
    time.sleep(0.1)
    
#    assert(not list_of_df.empty), "get_oi_occ_sync_'%s'_____: empty result"%t_class
# data process in sync mode
    df_oi=pd.DataFrame()
    df=pd.DataFrame()
    for string_x in list_of_txt_files:
        dx=pd.read_csv(io.StringIO(string_x), sep='\t', engine='python', skiprows=6)
        df=pd.concat([df, dx], axis=0)
     
#   clean up data columns from IO string
    col_names=['Product Symbol', 'Year', 'Month', 'Day', 'Integer', 'Dec', 'C/P',
       'Call', 'Put', 'Position Limit']
    df.drop('year',axis=1, inplace=True)
    df.columns=col_names
    df['Product Symbol']=df['Product Symbol'].str.strip()
    df['Strike'] = df['Integer'] + (df['Dec']*0.001)
    cols_of_interest=['Product Symbol', 'Year', 'Month', 'Day', 'Strike', 'Call', 'Put']
    con_tickers=df['Product Symbol'].isin(list_of_tickers)
    df=df[con_tickers][cols_of_interest]  
    df['Month']=df['Month'].astype('str').str.zfill(2)
    df['Day']=df['Day'].astype('str').str.zfill(2)
    df['expiry']=df['Year'].astype('str')+df['Month'].astype('str') +df['Day'].astype('str')
#    df['expiry']=df['expiry'].apply(lambda x : datetime.datetime.strptime(x,"%Y%m%d"))
#    df['expiry']=df['expiry'].astype('str').str.replace("-",'').str[2:]
    
    df['strike']=(df['Strike']*1000).astype('int').astype('str').str.rjust(8,'0')
    dc=df[['Product Symbol','expiry','strike','Call']]
    dc['cid']=dc['Product Symbol'] + '-' + df['expiry'] +'C'+ df['strike']
    dc['o_oi']=dc['Call']
    dc=dc[['cid','o_oi','expiry']]
    
    dp=df[['Product Symbol','expiry','strike','Put']]

    dp['cid']=dp['Product Symbol'] + '-' + dp['expiry'] +'P'+ dp['strike']
    dp['o_oi']=dp['Put']
    dp=dp[['cid','o_oi','expiry']]
    dcp=pd.concat([dc,dp], axis=0)
    df_oi=pd.concat([df_oi, dcp], axis=0)
    df_oi.sort_values('cid', inplace=True)
    

    if symbol_type.upper() in ['CID']:  #for live_trd or op_spec candy
        df_oi=df_oi[df_oi.cid.isin(symbols)]
    elif (t_class.upper() in ['UNOP_SCAN', 'UNOP_TRD','VIX','PAIN']) \
                             & (symbol_type.upper() in ['TICKER']):    
     # FILTER: o_oi_min_volume and month_depth, esp. for Ver==1 (ib first then occ)
        if t_class.upper() in ['UNOP_SCAN', 'UNOP_TRD','PAIN']:
             oi_depth_date=datetime.datetime.today()+timedelta(occ_oi_expiry_depth_days)
             oi_depth_year=str(oi_depth_date.year)
             oi_depth_month=str(oi_depth_date.month).rjust(2,'0')
             oi_depth_date_max= (oi_depth_year + oi_depth_month + '')
#             df_oi=df_oi[df_oi['expiry'].astype(str)<= oi_depth_date_max]    
             con_oi_depth= ( df_oi['expiry'].astype('str')) <=oi_depth_date_max
             con_oi_min= df_oi.o_oi>=occ_oi_min 
             if t_class.upper() in ['PAIN']:
                 con_oi_min= df_oi.o_oi>=occ_oi_min_pain
             df_oi=df_oi[con_oi_depth & con_oi_min]
        else:
             df_oi= df_oi[df_oi.o_oi>=occ_oi_min_vix]
    df_oi.drop('expiry', axis=1, inplace=True)  
    end=timer()
    print("get_oi_occ_sync'%s time________:"%t_class, timedelta(seconds=end-start))
    return df_oi

#%%
async def get_oi_async_subf(url, session):
    try:
         response= await session.get(url)
         await asyncio.sleep(0.1)
         rt=await response.text()
         await asyncio.sleep(0.1)
#         df=pd.read_html(rt)[0]
#         await asyncio.sleep(2)
         return rt
    except:
        cprint("___get_oi_occ_async_NO_reply__SKIP___" 'white', 'on_red')
 
#%%
async def get_oi_async_main(t_class, symbol_type, symbols):
    import aiohttp
    tcp_conn_max=50
    url_base='https://marketdata.theocc.com/series-search?symbolType=U&symbol='
#    connector = aiohttp.connector.TCPConnector(limit=tcp_conn_max, limit_per_host=tcp_conn_max)
    headers={"User-Agent": "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36"}
    if symbol_type.upper() in ['CID']:
        tickers= [x.split("-")[0] for x in symbols]
    elif symbol_type.upper() in ['TICKER']:
        tickers=symbols
#    payloads=[{'symbolType': 'U','symbolId': t} for t in tickers]

    connector = aiohttp.TCPConnector(limit=tcp_conn_max, limit_per_host=tcp_conn_max)
    session = aiohttp.ClientSession(connector=connector, headers=headers)
#        ClientSession(\
#        connector=connector, \
#        headers=headers,\
#        raise_for_status=True)
    urls=[url_base + t for t in tickers]

    list_of_txt_files = await asyncio.gather(*[get_oi_async_subf(url, session) for url  in urls])
    # waht is ret, a list of df tables?
    await session.close()
    return list_of_txt_files, tickers


# =============================================================================
# #%%    
# def get_oi_occ_sync(t_class, symbol_type='', symbols=[]): #
# #    can return either chain or singe_cid od
# # =============================================================================
# #     source: occ.com
# #     dest: get_cid_greeks_ib_occ_sync_mc
# #   EXCEPTION_handling: YES in subf
# # =============================================================================
# #    start = timer()
#     nest_asyncio.apply()
#     loop = asyncio.new_event_loop()
#     asyncio.set_event_loop(loop)
#     try:
#         doi= loop.run_until_complete(get_oi_occ_async(t_class, symbol_type, symbols ))
#     finally:
#         loop.close()
#     time.sleep(2)
#     assert(not doi.empty), "get_oi_occ_sync_'%s'_____: empty result"%t_class
#     return doi
# 
# #%%
# async def get_oi_occ_async(t_class, symbol_type, symbols): #or ['cid','ticker']
#     
# # =============================================================================
# #   use: symbol_type ['cid', 'ticker']
# #       purpose: t_class ['VIX','LIVE_TRD','UNOP_TRD','UNOP_SCAN']   
#     # EXCEPTION_handling: YES
#  #   FILTER: 'CID': no 
#  #   o_oi_min >1000, month_depth for UNOP_TRD, UNOP_SCAN
# #    working!
# #     ASYNC use: get_oi (whole chain fast)
# #     try-except-else: 'else' only when 'try' completed
# #     todo: threadsafe
# #     default max connections: 100
#     #Assuming occ_oi is post-trade number, thus only cares for oi>1000
# # =============================================================================
#     import aiohttp
#     from aiohttp import ClientSession
#     tcp_conn_max=48
# #    sema = asyncio.BoundedSemaphore(5)
#     start = timer()
#     url='https://www.theocc.com/webapps/series-search'
#     list_oi=[]
#     df_oi=pd.DataFrame()
#     connector = aiohttp.connector.TCPConnector(limit=tcp_conn_max, limit_per_host=tcp_conn_max)
#     headers={"User-Agent": "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36"}
#     async with ClientSession(\
#         connector=connector, \
#         headers=headers,\
#         raise_for_status=True) as session:
#         for sym in symbols:
#             if symbol_type.upper() in ['CID']:
#                 ticker=sym.split("-")[0]
#             elif symbol_type.upper() in ['TICKER']:
#                 ticker=sym
#             await asyncio.sleep(0.1)
#             try:
#                 r= await session.post(url,data={'symbolType': 'U','symbolId': ticker})
#                 await asyncio.sleep(0.1)
#                 rt=await r.text()
#                 await asyncio.sleep(0.1)
#  #               await asyncio.sleep(5)
#                 # if used in sync , r.content is STREAMINGAPI if in async,
#                 #  r = s.post(url,data={'symbolType': 'O','symbolId': symbol})
#                 # df = pd.read_html(r.content)[0] #read_html is NOT awaitable
#             except:
#                 cprint("___get_oi_occ_async_NO_reply__SKIP___'%s'"%sym, 'white', 'on_red')
#                 continue
#             else:
#         #sync section: will block whole process, OK only when execution is quick enough
#                 try:
#                     df=pd.read_html(rt)[0]
#                 except:
#                     cprint("___get_oi_occ_async_NO_table_Replied_SKIP____'%s'"%sym, 'white', 'on_red')
#                     continue
#                 df.columns = df.columns.droplevel()
#                 df['Strike'] = df['Integer'] + (df['Dec']*0.001)
#                 cols_of_interest=['Product Symbol', 'Year', 'Month', 'Day', 'Strike', 'Call', 'Put']
#                 df = df[cols_of_interest]    
#                 df['expiry']=df['Year'].astype(str)+df['Month']+df['Day'].astype(str)
#                 df['expiry']=df['expiry'].apply(lambda x : datetime.datetime.strptime(x,"%Y%b%d"))
#                 df['expiry']=df['expiry'].astype(str).str.replace("-",'').str[2:]
#                 
#                 df['strike']=(df['Strike']*1000).astype(int).astype(str).str.rjust(8,'0')
#                 dc=df[['Product Symbol','expiry','strike','Call']]
#                 dc['cid']=dc['Product Symbol'] + '-' + df['expiry'] +'C'+ df['strike']
#                 dc['o_oi']=dc['Call']
#                 dc=dc[['cid','o_oi','expiry']]
#                 
#                 dp=df[['Product Symbol','expiry','strike','Put']]
#                 dp['cid']=dp['Product Symbol'] + '-' + dp['expiry'] +'P'+ dp['strike']
#                 dp['o_oi']=dp['Put']
#                 dp=dp[['cid','o_oi','expiry']]
#                 dcp=pd.concat([dc,dp], axis=0)
#                 df_oi=pd.concat([df_oi, dcp], axis=0)
# #                o_oi=dcp[dcp.cid==cid].o_oi.values[0]
# #                keys_oi=['cid','o_oi']
# #                vals_oi=[cid, o_oi]
# #                dict_oi=dict(zip(keys_oi, vals_oi))
# #ALT- thread safeway
# #                executor = concurrent.futures.ThreadPoolExecutor(max_workers=3)
# #                loop_oi = asyncio.get_event_loop()   
# #                dict_oi= await loop_oi.run_in_executor(executor, thread_oi_occ, rt, cid)
# #                list_oi.append(dict_oi)
# #            df_oi=pd.DataFrame(list_oi)
#     await session.close() 
#     
#     if symbol_type.upper() in ['CID']:  #for live_trd or op_spec candy
#         df_oi=df_oi[df_oi.cid.isin(symbols)]
#     # oi_depth= 90 days
#     if (t_class.upper() in ['UNOP_SCAN', 'UNOP_TRD','VIX']) \
#                             & (symbol_type.upper() in ['TICKER']):
# # FILTER: o_oi_min_volume and month_depth, esp. for Ver==1 (ib first then occ)
#         df_oi=df_oi[df_oi.o_oi>= chain_vol_oi_min]    
#         if t_class.upper() in ['UNOP_SCAN', 'UNOP_TRD']:
#             oi_depth_date=datetime.datetime.today()+timedelta(chain_oi_depth_days)
#             oi_depth_year=str(oi_depth_date.year)
#             oi_depth_month=str(oi_depth_date.month).rjust(2,'0')
#             oi_depth_date_max= (oi_depth_year + oi_depth_month + '')
#             df_oi=df_oi[df_oi['expiry'].astype(str)<= oi_depth_date_max]    
#     df_oi.drop('expiry', axis=1, inplace=True)   
#     await asyncio.sleep(0.1)
#     end = timer()
# #    assert(not df_oi.empty), "get_oi_occ_async_'%s'_____: empty result"%t_class
#     print("get_oi_occ_'%s time________:"%t_class, timedelta(seconds=end-start))
#     return df_oi
# =============================================================================

#%%    
def get_chain_ib_sync(api, t_class, tickers):
    # EXCEPTION_hanlding: YES in subf
    start = timer()
#    logging.getLogger('ib_insync.wrapper').setLevel(logging.FATAL)
#    start = timer()
    nest_asyncio.apply()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        dg= loop.run_until_complete(get_chain_ib_async(api, t_class, tickers))
    finally:
        loop.close()
    time.sleep(2)
    end = timer()
    print("get_chain_ib_sync times_________:", timedelta(seconds=end-start))
    return dg

#%%
async def get_chain_ib_async(api, t_class, tickers):
    # EXCEPTION_handling: YES
    chunk_count= 48
    def chunks(long_list, chunk_count):
        for i in range(0, len(long_list), chunk_count):
             yield long_list[i: i+chunk_count]
# connection part
    client_id=1
    if api.upper() =='TWS':
        port = 7496
    elif api.upper() =='GW':
        port = 4001
    ib = IB()
# connection    
    try:  
        ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
    except:
        try:    #2nd
            client_id= client_id + random.randint(1,10)
            ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
        except:
            try:    #3rd
                client_id= client_id + random.randint(1,10)
                ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
            except:
                return ("ib_greeks_async unable to connect after 3 try")    
    ib.reqMarketDataType( 2 )  #frozen data (eod)
    ib.client.MaxRequests = 48  # max 50 - to pace throttling
    print(" ib connected id______: ", client_id)
    
    if t_class in ['STK', 'UNOP_TRD','UNOP_SCAN']:
        t_conts=[Stock(e,'SMART','USD') for e in tickers]
    elif t_class in ['IDX']:
        t_conts=[Index(e,'SMART','USD') for e in tickers]  
    elif t_class in ['VIX']:
        t_conts=[Index(e,'CBOE') for e in tickers] 
    await ib.qualifyContractsAsync(*t_conts)   
    ib.sleep(sleep_bf_fetch)
#    t_conts=[x in t_conts if x.ConId]
    k_conts=[m.symbol for m in t_conts]
    dict_conts=dict(zip(k_conts, t_conts))
    
    t_prices=await ib.reqTickersAsync(*t_conts)
    ib.sleep(0.1)
    v_prices=[n.last for n in t_prices]
    k_prices=[n.contract.symbol for n in t_prices]
    dict_prices=dict(zip(k_prices, v_prices))
    list_greeks_all_chains=[]
    list_ib_error=[]
    cid_got_cnt=0
    vol_nan_cnt=0
    for ticker in tickers:
        try:
            t=dict_conts[ticker]
            t_last=dict_prices[ticker]
            
            strike_up= t_last * (1+ chain_strike_pct)
            strike_dn= t_last * (1- chain_strike_pct)
            
            list_greeks_by_chain=[]
            chains=ib.reqSecDefOptParams(t.symbol, '', t.secType, t.conId)
            ib.sleep(1)
            chain = next (x for x in chains if x.tradingClass == t.symbol and x.exchange =='SMART')
                    
            if t_class in ['VIX']:
                expirations = sorted(exp for exp in chain.expirations)#[:chain_vix_depth]
                strikes = [strike for strike in chain.strikes ]
            else: 
                expirations = sorted(exp for exp in chain.expirations if exp<oi_depth_date_max) #[:chain_trd_depth]
                strikes = [strike for strike in chain.strikes \
                           if strike_dn <= strike <= strike_up]
    #                if strike % 5 == 0
            rights = ['P', 'C']
            contracts = [Option(t.symbol, expiration, strike, right, 'SMART', tradingClass=t.symbol)\
                         for right in rights\
                         for expiration in expirations \
                         for strike in strikes]
    #        contracts = ib.qualifyContracts(*contracts)
            contracts = await ib.qualifyContractsAsync(*contracts)
            ib.sleep(0.1)
            list_of_contracts=list(chunks(contracts, chunk_count))  
            mds=[]
            for c in list_of_contracts:
                mds_c= await ib.reqTickersAsync(*c)
                ib.sleep(0.2)
                mds.extend(mds_c)
            # construct dataframe for a chain of one ticker(all expiry/strikes)
            ib.sleep(0.1)
            for md in mds:
                if not md.hasBidAsk():
                    cprint("___get_cid_greeks_ib_reqTicker_no_BidAsk_skip_contract___: '%s'"%t, 'white', 'on_red')
                    list_ib_error.append(t)
                    continue
                # reconstruct 'cid'
                cid='-'.join(md.contract.localSymbol.split())
                bid=md.bid
                ask=md.ask
                sale=md.last
                o_vol=md.volume
                if md.lastGreeks is not None: 
                    delta=md.lastGreeks.delta
                    gamma=md.lastGreeks.gamma
                    theta=md.lastGreeks.theta
                    vega=md.lastGreeks.vega
                    civ=md.lastGreeks.impliedVol
                    p=md.lastGreeks.undPrice
                elif md.modelGreeks is not None:
                    delta=md.modelGreeks.delta
                    gamma=md.modelGreeks.gamma
                    theta=md.modelGreeks.theta
                    vega=md.modelGreeks.vega
                    civ=md.modelGreeks.impliedVol
                    p=md.modelGreeks.undPrice
                else:
                    list_ib_error.append(cid)
                    cprint("___get_cid_greeks_ib_no_greeks_skip____: '%s'"%t, 'white', 'on_red')
                    continue #skip this cid, loop next
                sale_prev=0
                keys_g=['civ', 'cid', 'p', 'bid', 'ask', 'sale', 'sale_prev', 'o_vol', 'delta', 'theta', 'vega', 'gamma']
                vals_g=[civ, cid, p,  bid, ask, sale, sale_prev, o_vol, delta, theta, vega, gamma]
                dic_greeks_by_option=dict(zip(keys_g, vals_g))
                list_greeks_by_chain.append(dic_greeks_by_option)
            list_greeks_all_chains += list_greeks_by_chain
        except:
            cprint("___get_cid_greeks_ib_Loop_Error_skip_ticker___: '%s'"%ticker, 'white', 'on_red')
            continue
            
    df=pd.DataFrame(list_greeks_all_chains)
    df['year']=df['cid'].str.split('-').str[1].str[:2]
    df['month']=df['cid'].str.split('-').str[1].str[2:4]
    df['day']=df['cid'].str.split('-').str[1].str[4:6]
    df['type']=df['cid'].str.split('-').str[1].str[6:7]
    df['strike']=df['cid'].str.split("-").str[1].str[7:].str.lstrip("0").astype(int)/1000
    df['ticker']=df['cid'].str.split('-').str[0]
    df.fillna(0, inplace=True)
    col_vals=['sale', 'bid', 'ask','o_vol']
    df[col_vals].apply(lambda x: x.replace('nan',0))
    ib.disconnect()
    return df

#%%
def get_timesale_sync(q_date, cids=[], mode=''):
# =============================================================================
#     use: label cid with 'bs_pct' and 'trds_block-top-3"
#     source: candy_intel
#     dest:
    # EXCEPTION_handling: 
# =============================================================================
    print("get_timesale_sync started")
    start = timer()
    nest_asyncio.apply()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    try:
        df_timesales= loop.run_until_complete(get_timesale_async(q_date, cids, mode))
    finally:
        loop.close()
    time.sleep(2)
    end = timer()
#    assert(not df_timesales.empty), "_____get_timesale_sync___: empty result"
    print("get_timesale_sync times spent:", timedelta(seconds=end-start))
    return df_timesales
    
#%%
async def get_timesale_async(q_date, cids, mode):
# =============================================================================
#     use: label cid 'ts_t_pct', 'ts_ba_pct','delta_n', 'trds_block'
    # mode ='entry" -> get pirior days block data for accurate 'BS' and 'delta_n'
    # enry key: 'block_time_start' = q_date@8am EST
    # block_time: 
#    source: 
    # EXCEPTION_handing: YES
    # TODO: resample-> better decide block_size.max() by 'second'
#      label logic
#  1. block_price vs. range_avg_price_trds
#  2. block_price vs. block_bid_ask
#  3. block_size vs. block_range_size_stk  (delta-neutral)
    # 
#    special condition
#     https://www.interactivebrokers.com/en/index.php?f=7235
#      https://www.elitetrader.com/et/threads/how-to-identify-a-call-put-sweeper-on-thinkorswim.318281/
#  for option contract, can get prev dates's option ticks!!
#     timezone https://howchoo.com/g/ywi5m2vkodk/working-with-datetime-objects-and-timezones-in-python
#     tm : numpy.datetime64('2019-11-15T15:53:02.000000000')# 
# =============================================================================
    df=pd.DataFrame()
# PARA_peformance
    
# PARA_Accuracy
    range_trd_seconds= 120
    range_bid_ask_seconds=120
    if mode =='entry':
        range_trd_seconds= 120*5
        range_bid_ask_seconds=120*5
    post_block_time_weight= 1
    stk_hour_offset= -5

    block_trds_top_num=1
    block_size_trd_min= 1 # sum of 30seconds around block_time, otherwise skip this cid
    last_price_range=4
    stk_duration_seconds= 240  # small bar (30sec or less) pace limiationhttps://interactivebrokers.github.io/tws-api/historical_limitations.html
    stk_barSizeSetting = '30 secs' # block_stk of 240s till blck_time+ 240 * 0.5s)
    stk_delta_neutral_pct=0.7
# connection    
    client_id=3
    ib = IB()
    try:  #1st
        ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
    except:
        try:    #2nd
            client_id= client_id + random.randint(1,10)
            ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
        except:
            try:    #3rd
                client_id= client_id + random.randint(1,10)
                ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
            except:
                return ("ib_greeks_async unable to connect after 3 try")
    ib.reqMarketDataType( 2 )  #frozen data (eod)
    ib.client.MaxRequests = 0  # max 50 - to pace throttling
    ib.client.setConnectOptions('+PACEAPI')
    print("ib connected id: ", client_id)
    
    if len(cids)>1:
        cids.sort()
    cnt_bar_trd_overtime=0
    cnt_bar_ba_overtime=0
    list_cont_stk=[]
    for cid in cids:
#    with ib:
        try:  # skip cid if exception
            ticker=cid.split("-")[0]
            expiry= '20' + cid.split("-")[1][:6]
            type= cid.split("-")[1][6:7]
            if type=='C':
                type_ib='CALL'
            else:
                type_ib='PUT'
            strike=int(cid.split("-")[1][7:].lstrip("0"))/1000
            cont=Option(ticker, expiry, strike, type_ib, 'SMART',100, 'USD')
            await ib.qualifyContractsAsync(cont)  
            ib.sleep(0.1)
        ## get cid ticks for the day
#            block_time_end = datetime.datetime.now()
            block_time_start = datetime.datetime(q_date.year, q_date.month, q_date.day, 8,0,0)
#            block_time_end=datetime.datetime.strptime(str(q_date), '%Y-%m-%d')
# ENTRY redefine block_time_end
            if mode =="entry":
                de=read_sql("SELECT * FROM tbl_candy_track WHERE cid='%s'"%cid)
                candy_dt=de.sort_values('candy_dt').candy_dt.iloc[0]
                block_time_start=datetime.datetime.strptime(candy_dt, '%Y-%m-%d')
#            print("step 1", cont)
            bars_trd = ib.reqHistoricalTicks(
                cont,
                startDateTime=block_time_start,  #[],
                endDateTime=[], #block_time_end,       
                numberOfTicks=1000,
                whatToShow='TRADES',
                useRth=1,
                ignoreSize=True,
                miscOptions=[])
            ib.sleep(2) 
#            if bars_trd == None:
#                cnt_bar_trd_overtime +=1
#                ib.sleep(3)
            trds=util.df(bars_trd)
            trds.sort_values('time', inplace=True)
            
            if len(bars_trd)>=990:
                block_time_start2=bars_trd[-1].time     #to check
                block_time_start2=str(trds.tail(1)['time'].iloc[0])
                block_time_start2=datetime.datetime.strptime(block_time_start2, '%Y-%m-%d %H:%M:%S+00:00') #string to datetime
                block_time_start2= block_time_start2 + datetime.timedelta(hours=stk_hour_offset)
                block_time_start2_str= block_time_start2.strftime('%Y%m%d %H:%M:%S')
                ib.sleep(0.1)
                bars_trd_2 = ib.reqHistoricalTicks(
                    cont,
                    startDateTime=block_time_start2_str, #[],
                    endDateTime=[],  #block_time_end2_str,       
                    numberOfTicks=1000,
                    whatToShow='TRADES',
                    useRth=1,
                    ignoreSize=True,
                    miscOptions=[])
                ib.sleep(1)  
                bars_trd.extend(bars_trd_2)
                
            trds=util.df(bars_trd)
#            print("step-2:  timesale_trds shape:", trds.shape)
            trds['time']=pd.to_datetime(trds['time'])
            last_price_trds=trds.sort_values('time').tail(last_price_range).price.mean()
            trds.sort_values('size', ascending=False, inplace=True)
            trds_block=trds.head(block_trds_top_num)[['size','time','price']].to_dict('list')
            block_size_trd_largest=trds['size'].max()  
            idx_trd= trds[trds['size']== block_size_trd_largest].head(1).index
            block_price_trd=trds.loc[idx_trd]['price'].iloc[0]
            block_price_trd=float(block_price_trd)
            block_time_trd= trds.loc[idx_trd]['time'].iloc[0]
            block_time_range_begin_trd=block_time_trd  -datetime.timedelta(seconds=range_trd_seconds)
            block_time_range_end_trd=block_time_trd + datetime.timedelta(seconds=range_trd_seconds * post_block_time_weight)
            range_trds=trds[(trds['time']>=block_time_range_begin_trd ) & \
                            (trds['time']<=block_time_range_end_trd)]
# sum of blocks during -10s ~ +10s , in case break down in small blocks
#            block_size_trd=trds['size'].max()    
            block_size_trd= range_trds['size'].sum()
            size_trds=trds['size'].sum()
            block_size_pct='{:2f}'.format(block_size_trd/ size_trds)
            block_price_trd='{:2f}'.format(block_price_trd)
            block_price_chg=float(last_price_trds) - float(block_price_trd)
            block_price_chg_pct=float(block_price_chg)/ float(block_price_trd)
            block_price_chg='{:1f}'.format(block_price_chg)
            block_price_chg_pct='{:3f}'.format(block_price_chg_pct)
# skip loop filter
            if block_size_trd <= block_size_trd_min:
                print("block_size_trd skip___:", block_size_trd, cid)
                continue   # retail trades only, - to skip
#            range_price_trds_min=  float(range_trds['price'].min())
#            range_price_trds_max=  float(range_trds['price'].max())
#            ts_t_pct=(block_price_trd-range_price_trds_min)/(range_price_trds_max - range_price_trds_min)
        # logic_2: block_price vs. block_time_range_bid_ask !! bid_asks have 1000+rows !!
            block_time_range_begin_bid_ask= block_time_trd  -datetime.timedelta(seconds= range_bid_ask_seconds)
            #input is EST in string format
            block_time_range_end_bid_ask= block_time_trd  + datetime.timedelta(hours=stk_hour_offset, seconds= range_bid_ask_seconds * post_block_time_weight)    
            block_time_range_end_bid_ask_str=block_time_range_end_bid_ask.strftime('%Y%m%d %H:%M:%S')
            ib.sleep(sleep_bf_fetch)
            bars_bid_ask = ib.reqHistoricalTicks(
                cont,
                startDateTime=[],
                endDateTime=block_time_range_end_bid_ask_str,       
                numberOfTicks=800,
                whatToShow='BID_ASK',
                useRth=1,
                ignoreSize=True,
                miscOptions=[])
            ib.sleep(sleep_af_fetch)
            if bars_bid_ask is None:
                bars_bid_ask = ib.reqHistoricalTicks(
                    cont,
                    startDateTime=[],
                    endDateTime=block_time_range_end_bid_ask_str,       
                    numberOfTicks=800,
                    whatToShow='BID_ASK',
                    useRth=1,
                    ignoreSize=True,
                    miscOptions=[])
                ib.sleep(4)

            bid_asks=util.df(bars_bid_ask)
#            print("step-3:  timesale_bid_ask shape", bid_asks.shape)
            bid_asks['time']=pd.to_datetime(bid_asks['time'])
            bid_asks_range=bid_asks[bid_asks['time']>=block_time_range_begin_bid_ask]
            range_price_bid_avg= bid_asks_range['priceBid'].mean()
            range_price_ask_avg= bid_asks_range['priceAsk'].mean()
            ts_ba_pct=(float(block_price_trd)-range_price_bid_avg)/(range_price_ask_avg - range_price_bid_avg)
            ts_ba_pct="{:.1f}".format(ts_ba_pct)
            
# ONLY when mode == 'entry:   logic_3:  block_size_opt vs. block_range_size_stk (delta_netural), adjust hour: -5
            if mode =='entry':
                cont_stk=Stock(ticker,'SMART','USD') 
                await ib.qualifyContractsAsync(cont_stk)  
                ib.sleep(sleep_bf_fetch)                
                block_time_range_end_stk=block_time_trd + datetime.timedelta(hours= stk_hour_offset, seconds= stk_duration_seconds)
                stk_durationStr=str(stk_duration_seconds) + ' S'
                block_time_range_end_stk_str=block_time_range_end_stk.strftime('%Y%m%d %H:%M:%S')
                bars_stk = ib.reqHistoricalData(
                    cont_stk,
                    endDateTime= block_time_end.strftime('%Y%m%d %H:%M:%S'),       
                    durationStr=stk_durationStr ,
                    barSizeSetting= stk_barSizeSetting,  #'1 secs',
                    whatToShow='TRADES',
                    useRTH=1,
                    formatDate=1, # use EST 
                    keepUpToDate=False,
                    chartOptions=[])  
                ib.sleep(sleep_af_fetch)
                trds_stk_range=util.df(bars_stk)
    #            print("step-4:  timesale_stock_range", trds_stk_range.shape) 
                block_duration_stk_sizes =trds_stk_range['volume'].sum()   
                delta_n_pct=block_duration_stk_sizes/ block_size_trd
                block_stk_price=trds_stk_range.average.mean()
                
# get_close_volumne for the day
                bars_stk_day = ib.reqHistoricalData(
                    cont_stk,
                    endDateTime=block_time_end.strftime('%Y%m%d %H:%M:%S'),       
                    durationStr='1 D' ,
                    barSizeSetting= '1 day',  #'1 secs',
                    whatToShow='TRADES',
                    useRTH=1,
                    formatDate=1, # use EST 
                    keepUpToDate=False,
                    chartOptions=[])  

                ib.sleep(sleep_af_fetch)
                stk_volume=bars_stk_day[0].volume
                stk_close=bars_stk_day[0].close
                block_size_pct_stk=block_duration_stk_sizes/stk_volume
                p_p_chg_pct=block_stk_price/stk_close-1
            else:
                ts_t_pct=None
                delta_n_pct=None
                block_stk_price=None
                block_size_pct_stk=None
                p_p_chg_pct=None
            
            data=[cid, ticker, ts_ba_pct, block_size_trd, block_size_pct,  block_price_trd, block_time_trd, block_price_chg, \
                   block_price_chg_pct, size_trds]
            data_entry=[ delta_n_pct, block_stk_price, block_size_pct_stk, p_p_chg_pct]
            
            columns=['cid','ticker','ts_ba_pct', 'block_size', 'block_size_pct','block_price','block_time', 'block_p_chg',\
                     'block_p_chg_pct', 'size_trds']
            columns_entry=[ 'delta_n_pct', 'block_stk_price', 'block_size_pct_stk', 'p_p_chg_pct']
            
            if mode=='entry':
                data=data + data_entry
                columns=columns + columns_entry
            data_list=[data]
                
            df_tmp=pd.DataFrame(data=data_list, columns=columns)
            df=pd.concat([df, df_tmp], axis=0)

            if mode=="entry":
                list_cont_stk.append(cont_stk)
        except:
            print("_____get_timesale_sync exception_skip____: ", cid)
            continue
# get the close price for tickers
# =============================================================================
#         if mode=="entry":
#             try:
#                 ib.sleep(0.1)
#                 t_prices=await ib.reqTickersAsync(*list_cont_stk)
#                 ib.sleep(0.1)
#                 v_prices=[n.last for n in t_prices]
#                 k_prices=[n.contract.symbol for n in t_prices]
#                 dict_prices=dict(zip(k_prices, v_prices))
#                 df_stk_prices=pd.DataFrame(data=dict_prices, columns=['ticker','stk_close', 'stk_volume'])
#     #merge      
#                 df=df.merge(df_stk_prices)        
#                 df['p_p_chg']=df['block_stk_price']/df['stk_close']-1
#             except:
#                 pass
# =============================================================================
    if not df.empty:
        df['block_time']=df['block_time'].astype(str).str.split('+').str[0]
        df['block_time']=pd.to_datetime(df['block_time'])-datetime.timedelta(hours=5)
        col=['block_size_pct', 'block_price','block_p_chg'  ]
        df=type_convert(df, col)
        ib.sleep(0.1)         
    print("cnt_bar_ba_overtime:__", cnt_bar_ba_overtime, "   cnt_bar_trd_overtime:__", cnt_bar_trd_overtime)
    ib.disconnect()        
    return df
    
# get earlier trade time
#    ib.reqHeadTimeStamp(
#        cont,
#        whatToShow='TRADES',
#        useRTH =1, # regular trading horu
#        formatDate =1)
#%%
def get_scan_sync():
# =============================================================================
#     use: get tickers by scan-> then get_chain
#     source: ibapi
#     dest: 
#    excepton_handle: YES
# =============================================================================
    client_id=2
    ib = IB()
# connection    
    try:  #1st
        ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
    except:
        try:    #2nd
            client_id= client_id + random.randint(1,10)
            ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
        except:
            try:    #3rd
                client_id= client_id + random.randint(1,10)
                ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
            except:
                return ("get_candy_scan_ib unable to connect after 3 try")
    ib.client.MaxRequests = 40  # max 50 - to pace throttling
    print("ib connected id: ", client_id)
    list_scanner=['HOT_BY_OPT_VOLUME']
#    list_scanner=[
#        "HOT_BY_OPT_VOLUME",  #over 10-day average
#        "TOP_OPT_IMP_VOLAT_GAIN",
#        "TOP_OPT_IMP_VOLAT_LOSE",
#        "HIGH_OPT_IMP_VOLAT_OVER_HIST",
#        "LOW_OPT_IMP_VOLAT_OVER_HIST",
#        "HIGH_OPT_VOLUME_PUT_CALL_RATIO",  #Put option volumes are divided by call option volumes
#        "LOW_OPT_VOLUME_PUT_CALL_RATIO",
#        "HIGH_OPT_OPEN_INTEREST_PUT_CALL_RATIO",
#        "LOW_OPT_OPEN_INTEREST_PUT_CALL_RATIO",
#        "TOP_PERC_LOSE",
#        "HOT_BY_VOLUME"]
    dict_all_scanners={}
    numberOfRows= scan_depth
    belowPrice='250'
    abovePrice='10'
    aboveVolume='2000000'
    averageOptionVolumeAbove='4000'
#    marketCapAbove=1
#    StockTypeFilter='ETF'
#    ScannerSettingPairs="Annual,true"
#https://groups.io/g/insync/topic/31264538#3358 (filter option)    
    for x in list_scanner:
        try:
            scanner= ScannerSubscription(instrument='STK',
                                       locationCode='STK.US.MAJOR',
                                       numberOfRows= numberOfRows,
                                       belowPrice= belowPrice,
                                       abovePrice= abovePrice, 
                                       aboveVolume=aboveVolume,
                                       averageOptionVolumeAbove=averageOptionVolumeAbove,
    #                                   StockTypeFilter= StockTypeFilter,
                                       scanCode=x)
            tagValues=[]
    #        tagValues=tagValues.append(TagValue("belowIvPercentiles52","30")) #no working
            scanner_result= ib.reqScannerData( scanner, [],\
                        scannerSubscriptionFilterOptions=tagValues)
            time.sleep(3)
            list_ticker_by_scanner=[]
            for s in scanner_result:
                ticker=s[1].contract.symbol
                list_ticker_by_scanner.append(ticker)
            dict_by_scanner= {x:list_ticker_by_scanner} 
    #        list_ticker_all_scanners.extend(list_ticker_by_scanner)   
            dict_all_scanners.update(dict_by_scanner)
        except: #skip scanner if error
            cprint("__get_scan_sync_exception: skip scanner:___'%s'"%x, 'white', 'on_red')
            pass
    print(dict_all_scanners)
    df=pd.DataFrame(dict_all_scanners)
    df['rank']=df.index
    ib.disconnect()
    return df


list_scanner=[
"HOT_BY_OPT_VOLUME",  #over 10-day average
"TOP_OPT_IMP_VOLAT_GAIN",
"TOP_OPT_IMP_VOLAT_LOSE",
"HIGH_OPT_IMP_VOLAT_OVER_HIST",
"LOW_OPT_IMP_VOLAT_OVER_HIST",
"HIGH_OPT_VOLUME_PUT_CALL_RATIO",  #Put option volumes are divided by call option volumes
"LOW_OPT_VOLUME_PUT_CALL_RATIO",
"HIGH_OPT_OPEN_INTEREST_PUT_CALL_RATIO",
"LOW_OPT_OPEN_INTEREST_PUT_CALL_RATIO",
"TOP_PERC_LOSE",
"HOT_BY_VOLUME"
]

#https://www.interactivebrokers.com/en/software/webtrader/webtrader/marketscanners/about%20market%20scanners.htm
scancodes=["LOW_OPT_VOL_PUT_CALL_RATIO",
"HIGH_OPT_IMP_VOLAT_OVER_HIST",
"LOW_OPT_IMP_VOLAT_OVER_HIST",
"HIGH_OPT_IMP_VOLAT",
"TOP_OPT_IMP_VOLAT_GAIN",
"TOP_OPT_IMP_VOLAT_LOSE",
"HIGH_OPT_VOLUME_PUT_CALL_RATIO",
"LOW_OPT_VOLUME_PUT_CALL_RATIO",
"OPT_VOLUME_MOST_ACTIVE",
"HOT_BY_OPT_VOLUME",  #
"HIGH_OPT_OPEN_INTEREST_PUT_CALL_RATIO",
"LOW_OPT_OPEN_INTEREST_PUT_CALL_RATIO",
"TOP_PERC_GAIN",
"MOST_ACTIVE",
"TOP_PERC_LOSE",
"HOT_BY_VOLUME",
"TOP_PERC_GAIN",
"HOT_BY_PRICE",
"TOP_TRADE_COUNT",
"TOP_TRADE_RATE",
"TOP_PRICE_RANGE",
"HOT_BY_PRICE_RANGE",
"TOP_VOLUME_RATE",
"LOW_OPT_IMP_VOLAT",
"OPT_OPEN_INTEREST_MOST_ACTIVE",
"NOT_OPEN",
"HALTED",
"TOP_OPEN_PERC_GAIN",
"TOP_OPEN_PERC_LOSE",
"HIGH_OPEN_GAP",
"LOW_OPEN_GAP",
"LOW_OPT_IMP_VOLAT",
"TOP_OPT_IMP_VOLAT_GAIN",
"TOP_OPT_IMP_VOLAT_LOSE",
"HIGH_VS_13W_HL",
"LOW_VS_13W_HL",
"HIGH_VS_26W_HL",
"LOW_VS_26W_HL",
"HIGH_VS_52W_HL",
"LOW_VS_52W_HL",
"HIGH_SYNTH_BID_REV_NAT_YIELD",
"LOW_SYNTH_BID_REV_NAT_YIELD"]

symbols_cboe=['VIX', 'VVIX', 'SKEW', 'KCJ', 'VIX9D', 'VIX3M', 'VIX6M', 'VIX1Y',\
         'VXN', 'RVX', 'VXD', 'OVX', 'GVZ', 'VXSLV', 'VXGDX', 'VXXLE', 'EVZ',\
         'VXEFA', 'VXEEM', 'VXFXI', 'VXEWZ']
#%%
def get_eod_sync(q_date, symbols, sym_type='IDX_CBOE', duration='1 D'):
# =============================================================================
#     use: get eod data from ib

# =============================================================================
    print("geteod_sync started")
    start = timer()
    nest_asyncio.apply()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    try:
        df_eod= loop.run_until_complete(get_eod_async(q_date, symbols, sym_type, duration))
    finally:
        loop.close()
    time.sleep(2)
    end = timer()
#    assert(not df_timesales.empty), "_____get_timesale_sync___: empty result"
    print("get_eod_sync times spent:", timedelta(seconds=end-start))
    return df_eod
    
#%%
async def get_eod_async(q_date, symbols, sym_type, duration):
#   use: get historical or EOD data for index or ticker:
#    VIX, VVIX, SKEW, KCJ, VIX9D, VIX3M, VIX6M, VIX1YVXN, RVX, VXD
    # VXEFA, VXEEM, VXFXI, VXEWZ
# OVX, GVZ, VXSLV, VXGDX, VXXLE, EVZ (euro)
#symbols=['VIX', 'VVIX', 'SKEW', 'KCJ', 'VIX9D', 'VIX3M', 'VIX6M', 'VIX1Y',\
#         'VXN', 'RVX', 'VXD', 'OVX', 'GVZ', 'VXSLV', 'VXGDX', 'VXXLE', 'EVZ',\
#         'VXEFA', 'VXEEM', 'VXFXI', 'VXEWZ']
# connection    
    client_id=10
    ib = IB()
    try:  #1st
        ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
    except:
        try:    #2nd
            client_id= client_id + random.randint(1,10)
            ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
        except:
            try:    #3rd
                client_id= client_id + random.randint(1,10)
                ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
            except:
                return ("ib_greeks_async unable to connect after 3 try")
    ib.reqMarketDataType( 2 )  #frozen data (eod)
    ib.client.MaxRequests = 0  # max 50 - to pace throttling
    ib.client.setConnectOptions('+PACEAPI')
    print("ib connected id: ", client_id)
    
# Contruct contract
    symbols=[x.upper() for x in symbols]
    sym_type= sym_type.upper()
    
    if sym_type=='IDX_OTHER':
        conts=[Index(e,'SMART','USD') for e in symbols]  
    elif sym_type=='IDX_CBOE':
        conts=[Index(e,'CBOE','USD') for e in symbols] 
    elif sym_type=='STK':
        conts= [Stock(e,'SMART','USD') for e in symbols]
        
    await ib.qualifyContractsAsync(*conts)     
    
    df=pd.DataFrame()
    for ct in conts:
        ticker=ct.symbol
        bar_eod = ib.reqHistoricalData(
            ct,
            endDateTime= '',       
            durationStr= duration ,
            barSizeSetting= '1 day',  #'1 secs',
            whatToShow='TRADES',
            useRTH=1,
            formatDate=1, # use EST 
            keepUpToDate=False,
            chartOptions=[]) 
        ib.sleep(0.2)
        df_eod=util.df(bar_eod)
        try:
            df_eod['ticker']=ticker
            df=pd.concat([df, df_eod], axis=0)
        except:
            print("get_eod_async error:  ", ticker)
            pass
        
    ib.sleep(1)

    ib.disconnect()        
    return df
# filter:    name>US Stocks</name>\n\t\t\t<type>STK</type>\n\t\t\t<filters>AFTERHRSCHANGEPERC,AVGOPTVOLUME,AVGPRICETARGET,AVGRATING,AVGTARGET2PRICERATIO,AVGVOLUME,AVGVOLUME_USD,CHANGEOPENPERC,CHANGEPERC,EMA_20,EMA_50,EMA_100,EMA_200,PRICE_VS_EMA_20,PRICE_VS_EMA_50,PRICE_VS_EMA_100,PRICE_VS_EMA_200,DAYSTOCOVER,DIVIB,DIVYIELD,DIVYIELDIB,FEERATE,FIRSTTRADEDATE,GROWTHRATE,HALTED,HASOPTIONS,HISTDIVIB,HISTDIVYIELDIB,IMBALANCE,IMBALANCEADVRATIOPERC,IMPVOLAT,IMPVOLATOVERHIST,INSIDEROFFLOATPERC,INSTITUTIONALOFFLOATPERC,MACD,MACD_SIGNAL,MACD_HISTOGRAM,MKTCAP,MKTCAP_USD,NEXTDIVAMOUNT,NEXTDIVDATE,NUMPRICETARGETS,NUMRATINGS,NUMSHARESINSIDER,NUMSHARESINSTITUTIONAL,NUMSHARESSHORT,OPENGAPPERC,OPTVOLUME,OPTVOLUMEPCRATIO,PERATIO,PPO,PPO_SIGNAL,PPO_HISTOGRAM,PRICE,PRICE2BK,PRICE2TANBK,PRICERANGE,PRICE_USD,QUICKRATIO,REBATERATE,REGIMBALANCE,REGIMBALANCEADVRATIOPERC,RETEQUITY,SHORTABLESHARES,SHORTOFFLOATPERC,SHORTSALERESTRICTED,SIC,ISSUER_COUNTRY_CODE,SOCSACT,SOCSNET,STKTYPE,STVOLUME_3MIN,STVOLUME_5MIN,STVOLUME_10MIN,TRADECOUNT,TRADERATE,UNSHORTABLE,VOLUME,VOLUMERATE,VOLUME_USD,RCGLTCLASS,RCGLTENDDATE,RCGLTIVALUE,RCGLTTRADE,RCGITCLASS,RCGITENDDATE,RCGITIVALUE,RCGITTRADE,RCGSTCLASS,RCGSTENDDATE,RCGSTIVALUE,RCGSTTRADE,ESG_SCORE,ESG_COMBINED_SCORE,ESG_CONTROVERSIES_SCORE,ESG_RESOURCE_USE_SCORE,ESG_EMISSIONS_SCORE,ESG_ENV_INNOVATION_SCORE,ESG_WORKFORCE_SCORE,ESG_HUMAN_RIGHTS_SCORE,ESG_COMMUNITY_SCORE,ESG_PRODUCT_RESPONSIBILITY_SCORE,ESG_MANAGEMENT_SCORE,ESG_SHAREHOLDERS_SCORE,ESG_CSR_STRATEGY_SCORE,ESG_ENV_PILLAR_SCORE,ESG_SOCIAL_PILLAR_SCORE,ESG_CORP_GOV_PILLAR_SCORE,IV_RANK13,IV_RANK26,IV_RANK52,IV_PERCENTILE13,IV_PERCENTILE26,IV_PERCENTILE52,HV_RANK13,HV_RANK26,HV_RANK52,HV_PERCENTILE13,HV_PERCENTILE26,HV_PERCENTILE52,PRICE_2_SALES,EQUITY_PER_SHARE,UTILIZATIO