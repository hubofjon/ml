
# -*- coding: utf-8 -*-

import datetime as datetime
from P_commons import read_sql, to_sql_append, to_sql_replace, type_convert, fmt_map,tbl_nodupe_append
from P_commons import get_profile
import pandas as pd
from P_getdata import get_RSI
import numpy as np
import scipy.stats as stats
pd.options.display.float_format = '{:,.2f}'.format
import warnings
warnings.filterwarnings("ignore")

def stat_VIEW(q_date, tick='topdown', profile_update=''): 
    '''
    use: 
        1."topdown": rank sec, and top/bottom ticker per sec
        2. ad_hoc: list of ad_hoc tickers
        3. profile_update: if 'UPDATE', ask for input for 'sec','beta'
    '''
    qry_sp="SELECT * FROM tbl_stat WHERE date='%s'"%q_date
    qry_etf="SELECT * FROM tbl_stat_sec WHERE date='%s'"%q_date
    ds_etf=read_sql(qry_etf, q_date)
    ds_sp=read_sql(qry_sp,q_date)
    
    ds_etf.rename(columns={'ticker': 'sec', 'sartn_22': 'abs_rtn_22','rtn_22_pct': 'srtn_22_pct', \
            'rtn_66_pct':'srtn_66_pct', 'rtn_22':'srtn_22',\
        'fm_hi':'sfm_hi', 'fm_lo': 'sfm_lo','fm_50': 'sfm_50', 'fm_200':'sfm_200',\
        'hv_22':'shv_22', 'hv_rank': 'shv_rank'}, inplace=True)
    show_etf=['sec', 'srtn_22','srtn_22_pct', 'srtn_66_pct',\
              'sfm_50','sfm_200','shv_22', 'shv_rank']
    show_sp= ['ticker', 'spike', 'hv_22', 'hv_rank', 'rtn_22','rtn_5_pct', \
              'rtn_22_pct','rtn_66_pct', \
              'fm_50', 'fm_200','fm_hi', 'fm_lo','close',\
              'atr_hd','atr_hv','spike_hv','rsi']  
    show_stat=show_etf+ show_sp
    
    if tick !='topdown':  #if ad-hoc ticker
            tick=[x.upper() for x in tick]
            da=pd.DataFrame(tick, columns=['ticker'], index=np.arange(len(tick)))
            da=get_profile(da)
            if profile_update.upper()=='UPDATE':
                for t in da[da.sec=='']['ticker']:
                        da.loc[da.ticker==t, 'sec']=input("input sector of %s:"%t).upper()
#                        da.loc[da.ticker==t, 'beta']=float( input("input beta of %s:"%t) )
            da_st=stat_run_base(q_date, 'ad_hoc', 'prod', da)
            #add back da profile filed incl. sec
            try: 
                da_st.drop(['sec', 'beta'], axis=1, inplace=True)
            except:
                pass
            show_pro=['ticker','sec','beta','mkt']
            da_st=pd.merge(da_st, da[show_pro], on='ticker',suffixes=('_ticker',''))
            da_st=da_st.merge(ds_etf[show_etf], on='sec',  how='left', suffixes=('_sec','')) 
            scm_t_pro=['beta','mkt']
            scm_v_stat=show_stat + scm_t_pro
            da_st=da_st[scm_v_stat]
            return da_st
            exit   
   # for overall view     
    df=ds_etf[show_etf].merge(ds_sp, on='sec') 
    df.sort_values(['srtn_22'],ascending=[False], inplace=True)

    lead=df[df.srtn_22>0].sort_values(['rtn_22_pct'], ascending=False).groupby(show_etf).head(3)
    lag=df[df.srtn_22<=0].sort_values(['rtn_22_pct'], ascending=False).groupby(show_etf).tail(3)
    df=pd.concat([lead,lag],axis=0)
    df=df[show_stat]
    df.sort_values(['srtn_22','rtn_22_pct'],ascending=[False, False], inplace=True)
    pd.set_option('display.expand_frame_repr', False)
    print(df)
    pd.set_option('display.expand_frame_repr', True)
    return df
   
def stat_run_base(q_date, underlying="sp500", env="prod", df_ah=''):
    '''
    use: 
        1. underlying: sp500/ sec/ etf_all/ ad_hoc
        2. df_ah: ad_hoc 
    source: tbl_pv_etf/sp500/all (since 2018 jun) <backup: tbl_price (since 2013)>
    dest: tbl_stat, tbl_stat_sec, tbl_stat_fx/macro/region/
    
    hv_22: annuallized of daily volaility(std) by * sqrt(252)
    '''
    p_date=q_date-datetime.timedelta(380)
    df_st=pd.DataFrame()
    if underlying=='sp500':
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_pv_sp500", p_date, q_date)
        df=read_sql(query, q_date)
    elif (underlying=='sec'):
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_pv_etf", p_date, q_date)
        df=read_sql(query, q_date) 
    elif (underlying=='etf_all'):
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_pv_all", p_date, q_date)
        df=read_sql(query, q_date)      
        pro_etf=read_sql("select * from profile_etf")
        list_etf=pro_etf.ticker.tolist()
        df=df[df.ticker.isin(list_etf)]
        
    elif (underlying=='ad_hoc') and  (~ df_ah.empty):
        qry="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_pv_all", p_date, q_date)
        df=read_sql(qry, q_date)
        df=df[df.ticker.isin(df_ah.ticker)]
    else:
        print("stat_run missing underlying")
        exit
    df_pivot=df.pivot_table(index='date', columns='ticker', values='close')
    df=pd.DataFrame(df_pivot.to_records())
    df.set_index('date', inplace=True) 
    df.sort_index(axis=0, ascending=True, inplace=True)
    if df.isnull().values.any():
        df.fillna(method='ffill',inplace=True)
    df0=pd.DataFrame()
    len=df.shape[1]  
    #if iterate thru rows then use below code
    # for index, row in df.iterrows():
        #   ....:     print row['c1'], row['c2']   
    #for columns in df (another way)
    for c in range (0,len):
        df0=df.iloc[:,c].describe()
        #df0['ticker']=df.iloc[0:,c].name
        df0['ticker']=df.columns[c]
        df0['close']=df.iloc[-1,c]  #last row is latest price
        df0['close_22b']=df.iloc[-22,c]
        df0['close_66b']=df.iloc[-66,c]
        df0['mean_20']=df.iloc[:,c].tail(20).mean()
        df0['mean_50']=df.iloc[:,c].tail(50).mean()
        df0['mean_200']=df.iloc[:,c].tail(200).mean()
        df0['hi_252']=df.iloc[:,c].tail(252).max()  
        df0['lo_252']=df.iloc[:,c].tail(252).min()  
        df0['rtn_5']=df.iloc[-1,c]/df.iloc[-5,c]-1 
        df0['rtn_22']=df.iloc[-1,c]/df.iloc[-22,c]-1 
        df0['rtn_66']=df.iloc[-1,c]/df.iloc[-66,c]-1 
        try:
            df0['rsi']=get_RSI(pd.Series(df.iloc[-15:,c].values),14).values[0]
        except:
            df0['rsi']=0
        df0['std_22']=(np.log(1+df.iloc[:,c].pct_change())).tail(22).std()
        df0['std_66']=(np.log(1+df.iloc[:,c].pct_change())).tail(66).std()
        df0['hv_22']=df0['std_22']*(252**0.5)  
        df0['hv_66']=df0['std_66']*(252**0.5) 
        df0['std_22_lastd']=(np.log(1+df.iloc[:-1,c].pct_change())).tail(22).std()
        df0['p_d']=df0['std_22_lastd']* df.iloc[-2,c] #expected p_move for last day
        df0['spike']=(df.iloc[-1,c] -df.iloc[-2,c])/df0['p_d']
        df0['atr_hd']=df0['std_22']*df0['close']
        #rolling hv_22, then get the std of last 22 hv_22
        log_rtn=np.log(1+df.iloc[:,c].pct_change())
        std_22=log_rtn.rolling(22).std()
        std_22.sort_index(inplace=True)
        std_22=std_22[:252]  #1 year range
        df0['std_hv_22']=std_22.tail(22).std()
        df0['hv_hv_22']=df0['std_hv_22']*(252**0.5)
        df0['atr_hv']=df0['hv_22']*df0['std_hv_22']
        hv_22=std_22*(252**0.5)
        df0['hv_rank']=hv_22.rank(pct=True).tail(1).values[0]
        std_hv_22_lastd=hv_22.tail(23).head(22).std()
        hv_22_lastd=hv_22.tail(2).head(1).values[0]
        df0['spike_hv']=(df0['hv_22']- hv_22_lastd)/std_hv_22_lastd
        
        log_rtn.dropna(inplace=True)
        try:
            df0['p_value']=stats.shapiro(log_rtn)[1]
        except:
            df0['p_value']=0
        df_st=df_st.append(df0)

    df_st['date']=q_date     
    df_st['fm_mean20']=(df_st['close']/ df_st['mean_20'])-1
    df_st['fm_50']=df_st['close']/ df_st['mean_50']-1     
    df_st['fm_200']=df_st['close']/ df_st['mean_200']-1
    df_st['fm_hi']=df_st['close']/ df_st['hi_252']-1
    df_st['fm_lo']=df_st['close']/ df_st['lo_252']-1
    df_st['p_22_sig']=df_st['close']*df_st['hv_22']
    df_st['p_66_sig']=df_st['close']*df_st['hv_66']
    
    try:
        df_st.drop(['25%', '50%', '75%','count','max','min','std','mean',\
            'std_22_lastd', 'p_d','std_22', 'std_66'], axis=1, inplace=True)
    except:
        pass
    col=df_st.columns
    col_drop=['25%', '50%', '75%','count','max','min','std','mean',\
            'std_22_lastd', 'p_d','std_22', 'std_66','std_hv_22']
    col=[x for x in col if x not in col_drop]
    df_st=df_st[col]
    
    if underlying=='sp500':
        df_st=get_beta_sec(df_st)  
        df_st.dropna(inplace=True)
        df_st=stat_rank(df_st)
        tbl_nodupe_append(q_date, df_st, "tbl_stat")
        
    elif underlying=='sec':
        secs=['IYR','IYT','XLI','XLY','XLK','XLV','XLP','XLU','XLF','XLB','XLE','SPY']
        df_st=df_st.loc[df_st['ticker'].isin(secs)]
        df_st['sartn_22']=df_st['rtn_22']
        df_st['chg_22_66']=df_st['rtn_22']-df_st['rtn_66']
        spy_rtn_22=df_st[df_st.ticker=='SPY']['rtn_22'].values[0]
        spy_rtn_66=df_st[df_st.ticker=='SPY']['rtn_66'].values[0]
        df_st['rtn_22']-= spy_rtn_22
        df_st['rtn_66']-= spy_rtn_66
        df_st=stat_rank(df_st)
        tbl_nodupe_append(q_date, df_st, "tbl_stat_sec")

    elif underlying=='ad_hoc':
        df_st_orig=df_st.sort_values('ticker')  #reserve original df_st
        df_sp=read_sql("SELECT * FROM tbl_stat")
        #get latest stat of sp500
        df_sp=df_sp[df_sp.date==df_sp.date.max()]
        #merge df_st with df_sp to get ad_hoc ticker rank with sp components
        df_st=pd.concat([df_sp, df_st], axis=0)
        #avoid dupe for sp ticker in ad_hoc, 
        df_st.sort_values(['ticker','spike_hv'], inplace=True)
        df_st.drop_duplicates(subset=['ticker'],keep='first', inplace=True)
        df_st=stat_rank(df_st)
        df_st=df_st[df_st.ticker.isin(df_st_orig.ticker)] 

    elif underlying=='etf_all':
        for col in ['fx', 'credit', 'como', 'factor',\
                    'region', 'macro']: #, 'risk', 'vol']:
            con=(pro_etf[col]==1)
            df=df_st[df_st.ticker.isin(pro_etf[con].ticker)]
            df=stat_rank(df)
            tbl_nodupe_append(q_date, df, "tbl_stat_%s"%col )

    return df_st

def stat_rank(df_st):
    df_st['rtn_5_pct']=df_st['rtn_5'].rank(pct=True)*10
    df_st['rtn_22_pct']=df_st['rtn_22'].rank(pct=True)*10
    df_st['rtn_66_pct']=df_st['rtn_66'].rank(pct=True)*10
    return df_st
    
def get_beta_sec(df):
    pro=read_sql("select * from profile_all")
    pro=pro[pro.mkt=='SPY']
    df=df.merge(pro[['ticker','beta', 'sec']], on='ticker', how='left')
    return df

def stat_PLOT(q_date, sec=[]):
    import matplotlib.pyplot as plt
    qry="SELECT * FROM tbl_stat_sec"
    df=read_sql(qry, q_date)
    try:
        df.drop(['index'], axis=1, inplace=True) 
    except:
        pass
    df.sort_values('ticker',ascending=False, inplace=True)
    if len(sec)>0:
        df=df[df.ticker.isin(sec)]
    pvt=df.pivot(index='date',columns='ticker',values='rtn_22')
    on=['IYR','IYT','XLB','XLE','XLF','XLI','XLK','XLY']
    color_on=['coral','indigo','khaki','green','lime','violet','red','purple']
    off=['SPY','XLP','XLU','XLV']
    color_off=['black','grey','blue','navy']
    ax=pvt[on].plot(kind='line', color=color_on, figsize=(16,8), rot=45, alpha=0.7)
    ax2 = ax.twinx()
#    ax2.plot(ax.get_xticks(), pvt[off]) #, kind='line',  color=color_off, rot=45)
    pvt[off].plot(kind='line', color=color_off, ax=ax2,  linestyle='--') 
    plt.legend(fontsize=15, loc='best')
    plt.show()

def tick_leadlag(q_date, ticks=['']):
    """
    use:  get single ticker rank among sp component
    sub_f: stat_VIEW, stat_sec_leadlag
    """
    pd.set_option('display.expand_frame_repr', False)
    dt=stat_VIEW(q_date, ticks)
    show=['ticker','close', 'rtn_22', 'rtn_5_pct','rtn_22_pct','rtn_66_pct',\
      'sec','srtn_22','srtn_22_pct','srtn_66_pct']
    con_sec= pd.notnull(dt['sec'])
    print(dt[con_sec][show])
    df=dt[ ~con_sec ]
    for t in df['ticker']:
#        df.loc[df.ticker==t, 'sec']=input("input sector of %s:"%t)
        sec=input("input sector of %s:  "%t)
        print(dt[dt.ticker==t][['ticker','rtn_22','rtn_22_pct', 'rtn_66_pct','close']], '\n')
        stat_sec_leadlag(q_date, [sec.upper()], 22, 1)
    pd.set_option('display.expand_frame_repr', True)
    
def etf_corr():
    bond=['BIL','SHV','SHY','IEF','TLT','GOVT','WYDE','HYG','FLAT','TIP']
    eqty=['SPY','EEM','EFA','PBP','SPLV', 'SPHB', 'FXI','ASHR']
    vol=['VXX']
    ccy=['UUP','FXY','FXA']
    com=['JJC','DBC','USO','GLD']
    etf=bond+eqty+vol+ccy+com
    df=read_sql("SELECT * FROM tbl_pv_etf")
    df=df[df.ticker.isin(etf)]
    dp=pd.pivot_table(df, index=['date'], columns=['ticker'],values=['close'])
    dp=dp.corr()
    c_plus=dp>0.8
    c_neg=dp < -0.8
    c_no= (dp <0.1)& (dp >-0.1)
    pd.set_option('display.expand_frame_repr', False)
    print(dp[c_plus].fillna(''))
    print(dp[c_neg].fillna(''))
    print(dp[c_no].fillna(''))

def sec_leadlag(q_date, sectors=['ALL'], period=22, num=3): # ['XLI','XLB']
    '''
    use:
        sec momentum persistency of lead/lag tickers by rtn_5 vs rtn_5_avg
    source: tbl_stat
    '''
    pd.set_option('display.expand_frame_repr', False)
    df=read_sql("SELECT * FROM tbl_stat")
    df['date']=pd.to_datetime(df['date']).dt.date
    p_date=q_date - datetime.timedelta(period)
    sec_orig=sectors
    if sectors[0]=='ALL':
        sectors=df['sec'].unique()
    data=list()   
    for sec in sectors:
        ds=df[df.sec==sec.upper()]
        ds.sort_values(['date','rtn_22_pct'], inplace=True)
        ds=ds[ds.date>=p_date]
        lead=ds[ds.date==q_date].tail(num)
        lead['momt']='lead'
        lag=ds[ds.date==q_date].head(num)
        lag['momt']='lag'
        tag=pd.concat([lead,lag], axis=0)
        tag.sort_values('rtn_22_pct', ascending=False, inplace=True)
        for t in tag['ticker']:
            ds.loc[ds.ticker==t,'rtn_5_pct_avg']=ds[ds.ticker==t]['rtn_5_pct'].mean()
        ds_avg=ds[['ticker','rtn_5_pct_avg']]    
        ds_avg.drop_duplicates(keep='first', inplace=True)
        dm=tag.merge(ds_avg, on='ticker', how='left')
        dm.loc[dm.momt=='lead', 'agree']=dm[dm.momt=='lead']['rtn_5_pct']>dm[dm.momt=='lead']['rtn_5_pct_avg']
        dm.loc[dm.momt=='lag', 'agree']=dm[dm.momt=='lag']['rtn_5_pct']<dm[dm.momt=='lag']['rtn_5_pct_avg']
        leading=dm[(dm.momt=='lead') & (dm.agree==True)].shape[0]/num
        lagging=dm[(dm.momt=='lag') & (dm.agree==True)].shape[0]/num
        rotate='{:1f}'.format(leading-lagging)
        data.append([sec, leading, lagging, rotate])
        if sec_orig[0] !='ALL':
#            print(sec, 'leading: ', leading, "lagging: ", lagging, "rotate: ", rotate)
            show=['sec','momt','ticker','rtn_22_pct','agree', 'rtn_5_pct','rtn_5_pct_avg','rtn_22','beta']
            de=dm.rtn_22.describe()
            pct_25='{:.3f}'.format(de.loc['25%'])
            pct_50='{:.3f}'.format(de.loc['50%'])
            pct_75='{:.3f}'.format(de.loc['75%'])
            print ("rtn_22 pct_25: %s,  pct_50: %s,  pct_75: %s"%(pct_25, pct_50, pct_75), '\n')
            print(dm[show])    
    cols=['sec','leading', 'lagging', 'rotate']
    data=np.asarray(data)
    data=data.transpose()
    df_sec=pd.DataFrame(dict(zip(cols, data)))
    df_sec.sort_values('rotate', ascending=False, inplace=True)
    df_sec=type_convert(df_sec,['rotate','leading','lagging'])
    df_sec[['rotate','leading','lagging']]=df_sec[['rotate','leading','lagging']]*100
    df_sec=fmt_map(df_sec, ['rotate','leading','lagging'], fmt='{:.0f}%')
    print("sec_leadlag: rtn_22 agree by rtn_5_pct: num: %s, period: %s"%(num, period) )
    print(df_sec[['sec','rotate','leading','lagging']])
    pd.set_option('display.expand_frame_repr', True)
#    return dm[show]
    
def sec_sharpe(lookback_period=22):
    """
    use: Sharpe ratio by sector in past 22 days
    source: tbl_stat_sec
    """
    ds=read_sql("SELECT * FROM tbl_stat_sec")
    #rtn_22: relative rtn to SPY, sartn_22: abs ret
    #get correlation
    ds.sort_values('date',inplace=True)
    ds_pvt=pd.pivot_table(ds, index=['date'], columns=['ticker'], values=['sartn_22'])
    ds_corr=ds_pvt.corr()
       
    dsg=ds.groupby('ticker')
    data=[]
    for n, g in dsg:
        g.sort_values('date', inplace=True)
        g=g.tail(lookback_period)
        std_22='{:.3f}'.format(g['sartn_22'].std())
        max_22_pct='{:.0f}'.format(g['rtn_22_pct'].max())
        min_22_pct=g['rtn_22_pct'].min()
        begin_22_pct=g['rtn_22_pct'].head(1).values[0].astype(float)
        end_22_pct=g['rtn_22_pct'].tail(1).values[0].astype(float)
        sartn_22=g['sartn_22'].tail(1).values[0].astype(float)
        avg_5_pct='{:.0f}'.format(g['rtn_5_pct'].mean())
 #       ratio=(float(end_22)-float(begin_22))/std_5
        data_tmp=[n,std_22, begin_22_pct, end_22_pct, max_22_pct, \
                  min_22_pct, avg_5_pct, sartn_22]
        data.append(data_tmp)
    data=np.asarray(data)
    data=data.transpose()
    cols=['ticker','std_22','begin_22_pct','end_22_pct', 'max_22_pct',\
          'min_22_pct', 'avg_5_pct','sartn_22']
    df=pd.DataFrame(dict(zip(cols, data)))
    df['abs_sharpe']=df['sartn_22'].astype(float)/df['std_22'].astype(float)
    df['sartn_22']=df['sartn_22'].astype(float)
    df['abs_sharpe']=df['abs_sharpe'].astype(float)
    df.sort_values(['abs_sharpe', 'end_22_pct'], ascending=(False, False), inplace=True)
    show=['ticker','sartn_22','abs_sharpe', 'end_22_pct','std_22', 'avg_5_pct',\
          'begin_22_pct','max_22_pct','min_22_pct']
    
    fmt_map={'sartn_22': '{:.2f}', 'abs_sharpe': '{:.1f}'}
    for key, value in fmt_map.items():
        df[key]=df[key].apply(value.format)
    pd.set_option('display.expand_frame_repr', False)
    print(df[show])
    print("sector correlation")
    print(ds_corr.iloc[:,0].sort_values())
    print(ds_corr[ds_corr<=0.5].fillna(''))
    pd.set_option('display.expand_frame_repr', True)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    '''
def sdev(q_date, underlying='sp500', env='prod',df_ah=''):
    
#    Run stat_run_base(etf) first then (sp)
#    In:tbl_price (since 2013), tbl_pv (since 2018 jun)
#    Update: tbl_stat, tbl_stat_sec
#    note:
#    tbl_stat_ep, etf is created for quicker access
#    ticker rtn_22_pct in 500 component, sec rtn_22_pct in 8 etfs
    
    import scipy.stats as stats
    p_date=q_date-datetime.timedelta(380)
    start_time=timer()
    
    #pick up price in the range only
#    if underlying=='sp500':
#        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price", p_date, q_date)
#        df=read_sql(query, q_date)
#    elif (underlying=='etf')|(underlying=='sec')|(underlying=='macro')|(underlying=='ccy'):
#        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price_etf", p_date, q_date)
#        df=read_sql(query, q_date)
    if underlying=='sp500':
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_pv_sp500", p_date, q_date)
        df=read_sql(query, q_date)
    elif (underlying=='etf'):
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_pv_etf", p_date, q_date)
        df=read_sql(query, q_date)        
    elif (underlying=='ad_hoc') and  (~ df_ah.empty):
        qry="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_pv_all", p_date, q_date)
        df=read_sql(qry, q_date)
        df=df[df.ticker.isin(df_ah.ticker)]
    else:
        print("stat_run missing underlying")
        exit
    ds=pd.DataFrame()
    dfg=df.groupby('ticker')
#daily, calc stat for past 1 year from q_date as the stat of q_date
    for n,g in dfg:  #new item: std_22, std_66, spike, p_value, fm_20
        g.sort_values('date',inplace=True)
        g['close_22b']=g['close'].shift(22)
        g['close_66b']=g['close'].shift(66)
        g['mean_20']=g['close'].tail(20).mean()
        g['mean_50']=g['close'].tail(50).mean()
        g['mean_200']=g['close'].tail(200).mean()
        g['hi_252']=g['close'].tail(252).max()
        g['lo_252']=g['close'].tail(252).min()
        g['rtn_5']=g['close']/g['close'].shift(5)-1
        g['rtn_22']=g['close']/g['close'].shift(22)-1
        g['rtn_66']=g['close']/g['close'].shift(66)-1
        g['std_22']=(np.log(1+g['close'].pct_change())).rolling(22).std()
        g['hv_22']=g['std_22']*(252**0.5)
        g['std_66']=(np.log(1+g['close'].pct_change())).rolling(66).std()
        g['hv_66']=g['std_66']*(252**0.5)
#        g['rsi']=get_RSI()
        g['spike']=(g['close']-g['close'].shift(1))/(g['std_22'].shift(1)*g['close'].shift(1))
        g['p_value']=stats.shapiro(np.log(1+g['close'].pct_change()))[1]
#       g['beta']=get_BETA()
        g['fm_20']=g['close']/g['mean_20']-1
        g['fm_50']=g['close']/g['mean_50']-1
        g['fm_200']=g['close']/g['mean_200']-1
        g['fm_hi']=g['close']/g['hi_252']-1
        g['fm_lo']=g['close']/g['lo_252']-1
        g['p_22_sig']=g['close']*g['hv_22']*np.sqrt(22/252)
        g['p_66_sig']=g['close']*g['hv_66']*np.sqrt(66/252)
        g['atr']=g['close']*g['std_22']
#        g['vwap']
#get the last row as stat as of q_date
        ds_qdate=g.tail(1)
        ds=pd.concat([ds, ds_qdate], axis=0)
      
    if underlying=='sp500':
        ds=stat_beta(ds)  #get sector
        ds.dropna(inplace=True)
    elif underlying=='etf':
    #rename columns, rtn_22 -> relative rtn to SPY
        secs=['XLI','XLY','XLK','XLV','XLP','XLU','XLF','XLB','XLE','SPY']  #defined in consituents list
        ds=ds.loc[ds['ticker'].isin(secs)]
        ds['sartn_22']=ds['rtn_22']
        ds['chg_22_66']=ds['rtn_22']-ds['rtn_66']
        spy_rtn_22=ds[ds.ticker=='SPY']['rtn_22'].values[0]
        spy_rtn_66=ds[ds.ticker=='SPY']['rtn_66'].values[0]
        ds['rtn_22']-= spy_rtn_22
        ds['rtn_66']-= spy_rtn_66
#    dsat=ds.set_index('ticker') #ticker is set to be index
    elif underlying=='ad_hoc':
        #only non_sp ticker go this route
        ds_orig=ds.sort_values('ticker')  #reserve original ds
        df_sp=read_sql("SELECT * FROM tbl_stat")
        df_sp.drop('index',axis=1, inplace=True)
        df_sp=df_sp[df_sp.date==df_sp.date.max()]
        #merge ds with df_sp to get ad_hoc ticker rank with sp components
        ds=pd.concat([df_sp, ds], axis=0)
    else:
        pass
# rank rtn_pct among sp components as of q_date    
    ds['rtn_5_pct']=ds['rtn_5'].rank(pct=True)*10
    ds['rtn_22_pct']=ds['rtn_22'].rank(pct=True)*10
    ds['rtn_66_pct']=ds['rtn_66'].rank(pct=True)*10

    if underlying=='ad_hoc': 
        #for non-sp ticker
        ds=ds[ds.ticker.isin(ds_orig.ticker)]
    
#    if env=='prod' and underlying=='sp500':
##        to_sql_append(ds, "tbl_stat")
#        tbl_nodupe_append(q_date, ds, "tbl_stat")
#    elif env=='prod' and underlying=='etf':
##        to_sql_append(ds, "tbl_stat_sec")    
#        tbl_nodupe_append(q_date, ds, "tbl_stat_sec")
    end_time=timer()
    print("time: ", end_time-start_time)
    return ds
    '''