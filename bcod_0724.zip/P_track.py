# -*- coding: utf-8 -*-
"""
arch:
    tbl_cid has aggregaged tbl_oc by lc/lp/comm (tbl_oc just record trans and as proof of live oc
    )
report_data()
report_data_process()
report_pid()

"""
import pandas as pd
import numpy as np 
import datetime as datetime
import sqlite3 as db
from timeit import default_timer as timer
from dateutil import parser
import scipy.stats
from termcolor import colored, cprint
import warnings
from P_commons import to_sql_append, to_sql_replace, read_sql, type_convert,to_sql_delete, get_conn, tbl_nodupe_append
from P_commons import * 
from P_stat import stat_VIEW
from R_plot import plot_base
from P_getdata import get_FUN, get_DIV, get_SI
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format

"""
    logic: risk control by delta (i_delta) and weigh( i_ip)
    var_id_max=cap * Max_loss_per_pos/ Buff_var_id
    delta_max=var_id_max/ var_id
    var_id= atr_hd * iv_hv
    ic_max_id= delta_max/ i_detla
    weigh_max= cap * weigh_per_pos
    ic_max_weigh= weigh_max/ i_ip
    i_ic@entry = min (ic_max_id, ic_max_weigh)
        Immediate control:
    0) daily update IBQ_cap
    1) con_weigh (risk_live/cap)>max_weigh_per_pos
    2) size_pct: max(var_id,var_hd)*BUFF_var_id )/(cap* MAX_loss_per_pos))
    3) spike>Buff_var_id(R multiple: 3* std)
    4) spike_etf>1  
"""
weigh_per_pos=0.05   
MAX_loss_per_pos=0.03
BUFF_var_id=3  # R: stop@ 3 std_daily
#    v_stk_vol_pct=2.5
key_level_pct=0.01    
exit_days_pct=0.5
event_days=5
itm_pct=0.015
itm_deep=0.85
spike_min=1
stop_spike=BUFF_var_id
stop_spike_etd=1.1
hiv_chg_pct=0.2
hv_rank_chg_min=0.1
loss_size_pct_max=0.2
gain_size_pct_min=0.9
size_chg_days_pct_max=0.3
vega_min= 15
days_pct_tgt_p=0.3
oi_chg_min=500
oi_chg_pct_min=0.3
o_vol_pct_min=2

oi_chg_min=500
oi_chg_pct_min=0.3
o_vol_pct_min=2


#%%
def tbl_cid_update(q_date):
    """
    use: tbl_cid: cacl mp, pl, risk_live, greek_i,greek_p, cid @q_date, mp=(mid, sale)
    source: op_c, cid_oc_by_cid
    pl attr: https://www.elitetrader.com/et/threads/explaining-options-p-l-by-greeks.321460/
    """
    df=read_sql("select * from op_c")
    df['o_dt']=pd.to_datetime(df['o_dt'])
    dict_list=[]
    for cid in df.cid.unique():
        dg=df[df.cid==cid]
        dg.sort_values('o_dt', inplace=True)
        i_delta=dg['delta'].head(1).values[0]
        delta_i_chg=dg['delta'].tail(1).values[0]-i_delta
        delta_p_chg=dg['delta'].tail(1).values[0]-dg['delta'].tail(2).head(1).values[0]
        i_vega=dg['vega'].head(1).values[0]
        vega_i_chg=dg['vega'].tail(1).values[0]-i_vega
        vega_p_chg=dg['vega'].tail(1).values[0]-dg['vega'].tail(2).head(1).values[0] 
        o_oi_chg=dg['o_oi'].tail(1).values[0]-dg['o_oi'].tail(2).head(1).values[0] 
#        o_oi_chg=dg['o_oi'].shift(-1)- dg['o_oi']
        o_oi_chg_pct=(dg['o_oi'].tail(1).values[0]/dg['o_oi'].tail(2).head(1).values[0])-1 
        o_oi_i_chg =dg['o_oi'].tail(1).values[0]-dg['o_oi'].head(2).tail(1).values[0] 
        o_oi_i_chg_pct =o_oi_i_chg /dg['o_oi'].head(2).tail(1).values[0]
        o_vol=dg['o_vol'].tail(1).values[0]
        delta=dg['delta'].tail(1).values[0]
        theta=dg['theta'].tail(1).values[0]
        gamma=dg['gamma'].tail(1).values[0]
        vega=dg['vega'].tail(1).values[0]
        bid=dg['bid'].tail(1).values[0]
        ask=dg['ask'].tail(1).values[0]
        sale=dg['sale'].tail(1).values[0]
        o_oi=dg['o_oi'].tail(1).values[0]
        delta_i=dg['delta'].head(1).values[0]
        theta_i=dg['theta'].head(1).values[0]
        gamma_i=dg['gamma'].head(1).values[0]
        vega_i=dg['vega'].head(1).values[0]
        delta_p=dg['delta'].tail(2).head(1).values[0]
        theta_p=dg['theta'].tail(2).head(1).values[0]
        gamma_p=dg['gamma'].tail(2).head(1).values[0]
        vega_p=dg['vega'].tail(2).head(1).values[0]
        keys=['cid', 'delta' ,'gamma', 'vega', 'theta',  'delta_i_chg', 'delta_p_chg', \
            'vega_i_chg', 'vega_p_chg', 'o_oi_chg', 'o_vol','bid','ask','sale','o_oi',\
            'o_oi_chg_pct', 'o_oi_i_chg', 'o_oi_i_chg_pct', \
            'delta_i','theta_i', 'gamma_i', 'vega_i', \
            'delta_p', 'theta_p', 'gamma_p', 'vega_p']
        vals=[cid, delta ,gamma, vega, theta, delta_i_chg, delta_p_chg, \
            vega_i_chg, vega_p_chg, o_oi_chg, o_vol, bid, ask, sale, o_oi,\
            o_oi_chg_pct, o_oi_i_chg, o_oi_i_chg_pct, \
            delta_i, theta_i, gamma_i, vega_i, 
            delta_p, theta_p, gamma_p, vega_p]     
        dic=dict(zip(keys, vals))
        dict_list.append(dic)
    dx=pd.DataFrame(dict_list)
    
    dp=calc_oc_by_cid()
    
    df=dx.merge(dp, on='cid',how='outer')
#    con_mp=(df['o_vol']>0) & (df['ask']>df['sale']) & (df['bid']<df['sale'])
    con_lc=df['lc']>0
    df.loc[con_lc, 'mp']=df['bid']
    df.loc[~con_lc, 'mp']=df['ask']
#    df.loc[con_mp & con_lc, 'mp']=df['bid']
#    df.loc[(~con_mp) & con_lc, 'mp']=df['bid']
#    df.loc[(~con_mp) & (~con_lc), 'mp']=df['ask']   
#pl, risk calculation
    df['pl_ur']=(df['mp']-df['lp'])*df['lc']*100
    df['pl']=df['pl_r']+df['pl_ur']-df['comm_c'].astype(float)
    #consider l or s
    df['pl_ur_pct']=(df['mp']/df['lp']-1)*(df['lc']/np.abs(df['lc']))  
    df['risk_live']=df['lc']*df['mp']*100
    df['delta_c']=df['delta']* df['lc']*100
    df['vega_c']=df['vega']* df['lc']*100
    df['theta_c']=df['theta']* df['lc']*100
    df['gamma_c']=df['gamma']* df['lc']*100
    df['date']=q_date
    col_val=['delta_p', 'theta_p', 'gamma_p', 'vega_p']
    df=type_convert(df, col_val, 'float')
    tbl_nodupe_append(q_date, df, 'tbl_cid')
    return df
# tbl_cid add below files
#['pl_p_vega', 'pl_p_delta', 'pl_p_exp', 'pl_p_theta', 'pl_p_exp_pct', 'pl_p', 'pl_p_gamma', 'mp_p_chg']
#col_val=['delta_p', 'theta_p', 'gamma_p', 'vega_p']
#%%        
def calc_oc_by_cid():
    """
    use:  cacl pl_r, lc, lp, comm_c@cid (sum)
    source: tbl_oc
    dest: update_tbl_cid()
    intel: pl_r change at each cacl, but key is pl_all. pl_r has no comm
    """
    dt=read_sql("select * from tbl_oc WHERE exit_dt =='N'")
    #trd only, combine U later
    con_unop= dt['pid'].str[:1]=='U'
    du=dt[con_unop]
    dc=dt[~ con_unop]
    dc.sort_values('uid',axis=0, inplace=True)
    dict_list=[]
    for cid in dc.cid.unique():
        df=dc[dc.cid==cid] #contain trde history per cid
        df_ic=df[df.ioc>0]
        if not df_ic.empty:
            sum_ic=df_ic.ioc.sum()
            prem_ic=(df_ic['ioc']*df_ic['iop']).sum()
            lp_avg_ic=prem_ic/ sum_ic  #average price for buy contracts
        else:
            sum_ic=0
            prem_ic=0
            lp_avg_ic=0
        
        df_oc=df[df.ioc<0]
        if not df_oc.empty:
            sum_oc=np.abs(df_oc.ioc.sum())
            prem_oc=(df_oc['ioc']*df_oc['iop']).sum()   
            lp_avg_oc=prem_oc/ sum_oc  #average price for sold contracts
        else:
            sum_oc=0
            prem_oc=0
            lp_avg_oc=0
        lc=df['ioc'].sum()
        comm=df['comm'].sum()
        if lc>0: # bought more than sold
            lp= lp_avg_ic
            pl_r=sum_oc *( lp_avg_oc - lp_avg_ic)*100
        else:
            lp= np.abs(lp_avg_oc) # as lp always positive
            pl_r=sum_ic *( lp_avg_ic - lp_avg_oc)*100
        keys=[ 'cid', 'lc', 'lp', 'pl_r','comm_c']
        vals=[ cid, lc, lp, pl_r, comm]
        dic=dict(zip(keys, vals))
        dict_list.append(dic)
    df=pd.DataFrame(dict_list)
    con_pl_r=pd.isnull(df['pl_r'])
    df.loc[con_pl_r, 'pl_r']=0
    return df
#%%
def reports(q_date): 
# tbl_oc & tbl_cid    
#    du=report_data(q_date, 'cid', 'U')
    
#    dz=report_data('ticker')
    rcid=report_by_cid(q_date)
    dy=report_data_get(q_date, ['ticker','pid'])
    dyp=report_data_process(dy, q_date)
    rpid=report_by_pid(dyp, q_date)
    
    #pid, or should be dt for live_oc only
#    dt['srtn_22_chg']=dt['srtn_22_pct']-dt['i_srtn_22_pct']
#    dt['rtn_22_chg']=dt['rtn_22_pct']-dt['i_rtn_22_pct']
#    dt['hv_22_chg_pct']=dt['hv_22']/dt['i_hv_22']-1
    #    dt['rsi_chg']=dt['rsi']<dt['i_rsi']
    #reporting            
#    dt['v_und']=dt['delta_c']*dt['close']
#    spy=read_sql("select close from tbl_pv_etf where ticker ='SPY'")
#    spy=spy.tail(1).iloc[0,0]
#    dt['beta']=dt['beta'].replace('',1).astype(float)
#    dt['v_spy']=dt['v_und']*dt['beta']/spy
#
## for proper risk calc, move dead to tbl_c_hist
#    scm_t_c=list(dict.fromkeys(dt.columns.tolist()))
#    scm_t_c=[x for x in scm_t_c if x not in ['index','index_x','index_y',\
#        'r_x', 'r_y','rx_x', 'rx_y', 'risky_x','risky_y']]
#    dt=dt[scm_t_c]
#    con_live=dt['exit_dt']=='N'
#    dt_dead=dt[~ con_live]
#    try:
#        z3_test=dt.groupby('act')['pl'].sum()
#    except:
#        print("track_raw: ln341:  Must produce aggregated value")
#    #validate dead trade
#    con_lc=dt['lc']==0  #no live contract
#    if (con_live & con_lc).any() | (~con_live & ~con_lc).any():
#        print("track_raw: ln337, con_live <>con_lc")
#    if ~ dt_dead.empty:
#        to_sql_append(dt_dead, 'tbl_track_hist')
#        print("track_raw: tbl_c_hist appended: %s"%dt_dead.ticker.tolist())
#    dt=dt[con_live]
#    if dt.empty:
#        print("track_raw: ln367, dt.empty")
#        return
#    else:
#        to_sql_replace(dt, 'tbl_track')
        #Track @ Act & asset level
#%%


def report_data_get(q_date, rpt_by='', unop=''): 
    """
    use: get report_by_pid/ ticker/ cid for live cid only
    source: tbl_oc, tbl_cid
    tip: groupby (,as_index=False).agg()
    """
    def pid_calc(dg):
#        calc lc, lp, mp for group_by_pid   
        g_lc=np.abs(dg['lc']).min()
        g_lp=(dg['lc']*dg['lp']).sum()/g_lc
        g_mp=(dg['lc']*dg['mp']).sum()/g_lc
        return g_lc, g_lp, g_mp
    # tbl_oc & tbl_cid    
    dt=read_sql("select * from tbl_oc where exit_dt ='N'")
    con_u= dt['pid'].str[:1]=='U'
    if unop.upper()=='U':
        dt=dt[con_u]
    else:
        dt=dt[~ con_u]
    
    dt.drop_duplicates('cid', keep='first', inplace=True)
    dt.drop('ticker', axis=1, inplace=True)
    #get the live unique oc ONLY
    dcid=read_sql("select * from tbl_cid")
    dcid['date']=pd.to_datetime(dcid['date'])
    dcid=dcid[dcid.date==q_date]
    
    df=dt.merge(dcid, on=['cid'],how='left')
    df.sort_values(['cid','entry_dt'], inplace=True)
    
    if unop=='U':
        return df
    elif rpt_by=='cid':
        return df
    
    col_g=['pl','pl_delta', 'pl_gamma','pl_theta','pl_vega', 'pl_exp',\
         'pl_p', 'pl_p_delta', 'pl_p_gamma','pl_p_theta','pl_p_vega', 'pl_p_exp', \
         'pl_ur', 'risk_live',\
         'delta', 'gamma', 'theta', 'vega',\
         'delta_p', 'gamma_p', 'theta_p', 'vega_p',\
         'delta_i', 'gamma_i', 'theta_i', 'vega_i',\
         'var_iv', 'var_delta', 'var_gamma', 'var_theta',\
         'delta_c',  'gamma_c', 'theta_c', 'vega_c', 'comm_c',\
         'lc', 'lp', 'mp']
    #common fields
    dt_g=['oexp_dt','entry_dt','play','sec','act','earn_dt']
    df=type_convert(df, col_g, 'float')
    dg=pd.DataFrame()
    #re_calc lp, mp, pl_ur_pct, pl_exp_pct, pl_p_exp_pct
    for x in col_g:
        dg[x]=df.groupby(rpt_by)[x].sum()
    for y in dt_g:
        dg[y]=df.groupby(rpt_by)[y].min()

    dg['pl_ur_pct']=dg['pl_ur']/(dg['risk_live']-dg['pl_ur'])
    dg['pl_exp_pct']=dg['pl_exp']/dg['pl_ur']
    dg['pl_p_exp_pct']=dg['pl_p_exp']/dg['pl_p']
    dg.reset_index(inplace=True)
    #re_cacl lc, lp, mp for pid only
    if rpt_by==['ticker','pid']:
        dc=df.groupby(['ticker','pid']).apply(pid_calc)
        dc=dc.to_frame()
        dc['lc']=dc[0].str[0]
        dc['lp']=dc[0].str[1]
        dc['mp']=dc[0].str[2]
#        dc['var_iv']=np.abs(df['var_delta'])+np.abs(df['var_gamma']+df['var_theta'])
        dc.reset_index(inplace=True)
        col_c=['ticker','pid','lc','lp','mp']
        dg.drop(['lc','lp','mp'], axis=1, inplace=True)
        dg=pd.merge(dg, dc[col_c], on=['ticker','pid'], how='left')
        #re-calc var_iv for 'pid' and 'ticker'
        dg['var_iv']=(np.abs(dg['var_delta'])+np.abs(dg['var_gamma']\
              +dg['var_theta'])) 
        dg['delta']=dg['delta_c']/np.abs(dg['lc'])
        dg['gamma']=dg['gamma_c']/np.abs(dg['lc'])
        dg['theta']=dg['theta_c']/np.abs(dg['lc'])
        dg['vega']=dg['vega_c']/np.abs(dg['lc'])
#    show=['ticker','pl', 'pl_ur_pct','lc', 'lp', 'mp','pl_exp', 'pl_exp_pct',\
#          'pl_delta', 'pl_gamma', 'pl_theta','pl_vega', 'pl_p', 'pl_p_exp_pct']   
    #merge back with other fields from tbl_cid, tbl_oc
    elif rpt_by==['cid']:
        col_share=list(set(df.columns.tolist()) - set(dg.columns.tolist()))
        col_add=col_share + list(rpt_by)
        dg=dg.merge(df[col_add], on=rpt_by, how='left')
    return dg

#%%
def report_data_process(df, q_date):
    """
    use: prep pid_rpt data
    source: tbl_act, tbl_risk, stat_VIEW
    """
    dt=df.sort_values('ticker')
#tbl_act
    dt_cap=read_sql("SELECT * FROM tbl_act", q_date)
    dt=dt.merge(dt_cap[['act','cap']], on='act',how='left')
#tbl_risk
    dr=read_sql("SELECT * FROM tbl_risk")
    dr=type_convert(dr, ['r','rx'], 'float')
    dt=pd.merge(dt, dr, on='play', how='left')  
#tbl_iv
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date'])
    div.sort_values('date', inplace=True)
    col_v=['oi','oi_c', 'iv_chg_pct','oi_p', 'vol_pct','iv','oi_p_pct']
    div=reg_convert(col_v, div, 'float')
    
    div['oi_i_chg_pct']=div.groupby('ticker')['oi'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    div['iv_i_chg']=div.groupby('ticker')['iv'].apply(lambda x:x-(x.iloc[0]))
    div['p_i_chg_pct']=div.groupby('ticker')['p'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    div['oi_p_pct_i_chg']=div.groupby('ticker')['oi_p_pct'].apply(lambda x:x-(x.iloc[0]))
    div['oi_c_i_chg_pct']=div.groupby('ticker')['oi_c'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    div['oi_p_i_chg_pct']=div.groupby('ticker')['oi_p'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    div['oi_c_chg_pct']=div.groupby('ticker')['oi_c'].apply(lambda x:x.div(x.shift(1)).subtract(1))
    div['oi_p_chg_pct']=div.groupby('ticker')['oi_p'].apply(lambda x:x.div(x.shift(1)).subtract(1))
    div['oi_c_chg']=div.groupby('ticker')['oi_c'].apply(lambda x:x-x.shift(1))
    div['oi_p_chg']=div.groupby('ticker')['oi_p'].apply(lambda x:x-x.shift(1))
    
    div_x=div[div.date==q_date]
    #only live ticker, as iloc[0] incl. non q_date ticker
    div_b=div[div.ticker.isin(div_x.ticker)].groupby('ticker')['iv_rank'].apply(lambda x:x.iloc[0])
    div_b=div_b.to_frame()
    div_b.reset_index(inplace=True)
    div_b.rename(columns={'iv_rank':'iv_i_rank'}, inplace=True)
    div=pd.merge(div_x, div_b, on='ticker', how='left')

    col_iv=['div', 'div_dt', 'earn_dt_mc', 'ind','iv', 'iv_1y',\
       'iv_chg_pct', 'iv_rank', 'mcap', 'oi', 'oi_c','oi_p','oi_p_pct', 'p', 'p_chg',
       'p_chg_pct', 'spike_iv', 'ticker', 'vol', 'vol_pct', 'vol_stk', 'yld']
    col_iv_new=['oi_i_chg_pct', 'iv_i_rank', 'iv_i_chg','p_i_chg_pct','oi_c_chg','oi_p_chg',\
        'oi_p_pct_i_chg', 'oi_c_i_chg_pct', 'oi_p_i_chg_pct', 'oi_c_chg_pct','oi_p_chg_pct']

    col_iv=col_iv + col_iv_new
    div=div[col_iv]
    dt=dt.merge(div, on='ticker', how='left')

# stat_VIEW
    dv=read_sql("select * from tbl_stat")
    dv['date']=pd.to_datetime(dv['date']).dt.date
    max_stat_dt=dv.date.max()
    
    ds=stat_VIEW(max_stat_dt, dt['ticker'].unique().tolist())
    ds.drop('sec', axis=1, inplace=True)
    col_share=list(set(dt.columns).intersection(set(ds.columns)))
    #preserve sec value from tbl_c for non-sp ticker
    col_drop=[x for x in col_share if x not in ['ticker', 'sec']]
    dt.drop(col_drop, axis=1, inplace=True)
    dt=dt.merge(ds, on='ticker', how='left')
#tbl_mc_raw, tbl_bc_raw
    dt_mc=read_sql("SELECT * FROM tbl_mc_raw ", q_date)
    dt_mc['date']=pd.to_datetime(dt_mc['date'])
    dt_mc=dt_mc[dt_mc.date==q_date]
    loc_mc=dt['ticker'].isin(dt_mc['ticker'])
    if loc_mc.any():
        dt.loc[loc_mc,'mc']=dt_mc['ticker'] +'|' + dt_mc['v_pct'].astype(str)\
            +'|'+dt_mc['pct_c'].astype(str)
    else:
        dt['mc']=np.NaN
    dt_bc=read_sql("SELECT * FROM tbl_obc_raw ", q_date)
    dt_bc['date']=pd.to_datetime(dt_bc['date'])
    dt_bc=dt_bc[dt_bc.date==q_date]
    loc_bc=dt['ticker'].isin(dt_bc['ticker'])
    if loc_bc.any():
        dt.loc[loc_bc,'bc']=dt_bc['ticker'] +'|' + dt_bc['v_oi'].astype(str)\
            +'|'+dt_bc['type'].astype(str)
    else:
        dt['bc']=np.NaN
#    for index, row in dt[con_new].iterrows():
#        try:
#            fun_col=['beta','pe','ta']
#            FUN=get_FUN(row.ticker)  
#            for k in fun_col:
#                dt.loc[index, k]=FUN[k]
#        except:
#            for k in fun_col:
#                dt.loc[index, k]=0
#        try:
#            si_col= ['si'] 
#            SI=get_SI(row.ticker)
#            for k in si_col:
#                dt.loc[index, k]=SI[k]
#        except:
#            for k in si_col:
#                dt.loc[index, k]=0
#Clean/convert data
    dt['date']=q_date
    dt.loc[pd.isnull(dt.earn_dt), 'earn_dt']=dt['earn_dt_mc']
    col_dt=['entry_dt', 'oexp_dt', 'earn_dt', 'div_dt','date']
    dt=type_convert(dt, col_dt, 'datetime')
#    for x in flask_val:
#        dt.loc[con_new, x]=dt.loc[con_new, x].replace('',0).replace('None',0).astype(float)
    col_float=['delta_c','vega_c','pl', 'pl_ur','theta_c', 'iv',\
               'pl_ur_pct']
    dt=type_convert(dt, col_float, 'float')

    dt['tgt_dt']=dt['entry_dt']+(dt['oexp_dt']-dt['entry_dt'])/2
    dt['days_to_exp']=dt['oexp_dt'].subtract(dt['date']).dt.days   
    dt['days_all']= dt['oexp_dt'].subtract(dt['entry_dt']).dt.days   
    dt['days_pct']=(1-dt['days_to_exp']/dt['days_all']).round(2)
    dt['days_to_div']=dt['div_dt'].subtract(dt['date']).dt.days
    dt['days_to_earn']=dt['earn_dt'].subtract(dt['date']).dt.days
    dt['days_to_tgt_dt']=dt['tgt_dt'].subtract(dt['entry_dt']).dt.days
#    dt['days_to_event']=dt['event_dt'].subtract(dt['date']).dt.days

# insert var_greeks cacl once from tbl_cid
    dt['var_delta_hv']=dt['delta_c']*dt['atr_hd']
    dt['var_vega_hv']=dt['vega_c']*dt['atr_hv']*100
    dt['var_hv']=np.abs(dt['var_delta_hv'])+np.abs(dt['var_vega_hv'])

    dt['iv_hv']=dt['iv']/dt['hv_22']  
    
    dt['weigh']=dt['risk_live']/dt['cap']
    dt['size_pct']=np.abs((dt[['var_iv','var_hv']].max(axis=1)*BUFF_var_id )/  \
              ( dt['cap']* MAX_loss_per_pos))
    dt['size_buff']=( dt['cap']*MAX_loss_per_pos)- \
            np.abs(dt[['var_iv','var_hv']].max(axis=1)* BUFF_var_id ) 
                #size_chg
    dt['delta_to_adj']=dt['delta_c']*(1-dt['size_pct'])
    dt['con_to_adj']=dt['delta_to_adj']/(dt['delta'])
    dt['weigh_to_adj']=(weigh_per_pos - dt['weigh'])*dt['cap']
    return dt

#%%
def report_by_pid(df, q_date):
    #avoid mute of orig df
    dt=df.sort_values('ticker')
    CON_stop= (dt['pl_ur_pct'].astype(float) <= dt['r'].astype(float))
    CON_out=(dt['tgt_dt']<q_date) | (dt['days_pct'].astype(float)>=exit_days_pct)
    CON_exit=dt['pl_ur_pct'].astype(float) > dt['rx'].astype(float)
    #a_event        
    con_earn_dt=dt['days_to_earn']>0
    con_div_dt=dt['days_to_div']>0
#    con_event_dt=dt['days_to_event']>0
    CON_event=(dt['days_to_div']<=event_days & con_div_dt)\
            |(dt['days_to_earn']<=event_days & con_earn_dt)
#              |(dt['days_to_event']<=event_days & con_event_dt )  
#a_key_level
    CON_key_level=(np.abs(dt['fm_50'])<= key_level_pct) \
          |(np.abs(dt['fm_200'])<= key_level_pct) \
          |(np.abs(dt['fm_hi'])<= key_level_pct) \
          |(np.abs(dt['fm_lo'])<= key_level_pct)  
#a_unop or oi_chg
    con_oi_c = (np.abs(dt['oi_c_chg'])> oi_chg_min) & (np.abs(dt['oi_c_chg_pct'])>oi_chg_pct_min)
    con_oi_p = (np.abs(dt['oi_p_chg'])> oi_chg_min) & (np.abs(dt['oi_p_chg_pct'])>oi_chg_pct_min)    
    con_oi = con_oi_c | con_oi_p
#    con_vol=dt['vol_pct']> o_vol_pct_min 
    
    con_bmc=pd.notnull(dt['mc']) |pd.notnull(dt['bc'])  
    CON_unop=con_bmc | con_oi          
#    CON_spike= (np.abs(dt['spike'])>spike_min) 
    CON_spike= (np.abs(dt['spike'])>spike_min) |(np.abs(dt['spike_iv'])>spike_min)          
    #a_size
    con_weigh=dt['weigh'] >=weigh_per_pos
    con_oversize=dt['size_pct']>=1
    con_add=(dt['pl_ur_pct']>0) & (dt['days_pct']<size_chg_days_pct_max) & (dt['size_pct']<gain_size_pct_min)
    con_cut=(dt['pl_ur_pct']<0) & (dt['days_pct']>=size_chg_days_pct_max) & (dt['size_pct']>=loss_size_pct_max)
    con_cut=con_cut | con_weigh | con_oversize
    CON_size=con_add | con_cut

    dt['a_out']=CON_out
    dt['a_stop']=CON_stop
    dt['a_exit']=CON_exit
    dt['a_size']=CON_size
    dt['a_spike']=CON_spike
    dt['a_event']=CON_event
    dt['a_key']=CON_key_level
    dt['a_unop']=CON_unop
    dt.loc[con_add, 'a_size']='+'
    dt.loc[con_cut, 'a_size']='-'  

#clean display
    dt.replace(False, "", inplace=True)
    dt.replace(np.nan, "", inplace=True)
#    dt.loc[~con_event_dt, 'event_dt']=np.nan
    dt.loc[~con_earn_dt, 'earn_dt']=np.nan    
    dt.loc[~con_div_dt, 'div_dt']=np.nan
    CON_event_show=pd.notnull(dt['div_dt'])|pd.notnull(dt['earn_dt'])
#        |pd.notnull(dt['event_dt'])
    show_alerts=['ticker','risk_live', 'pl_ur_pct', 'pl_ur','var_iv',\
                 'a_out', 'a_stop', 'a_exit','a_unop', 'a_size',  'a_spike', \
                'a_unop', 'a_key','theta_c','delta_c']
    
    show_base=['ticker','pid', 'risk_live', 'pl', 'pl_ur_pct','days_pct', 'close', 'iv_hv','iv_rank', 'hv_rank','spike_iv']
    show_action=['a_stop','a_exit','a_out']+ show_base
    show_size=['ticker','a_size','pl_ur_pct','size_pct', 'weigh','size_buff','delta_to_adj',\
               'con_to_adj','risk_live','weigh_to_adj', 'mp','days_pct','iv_hv', 'risky','play']
    show_unop=['ticker','mc','bc','p_chg', 'iv_rank', 'iv_i_rank', 'oi_p_pct_i_chg', 'p_i_chg_pct', \
               'oi_c_i_chg_pct','oi_p_i_chg_pct', 'oi_p_pct','iv_chg_pct']
    show_event= ['ticker','days_pct','close','div_dt','event_dt', 'earn_dt']
#display percentage
    col_pct=['hv_rank','pl_exp_pct', 'pl_p_exp_pct', 'pl_ur_pct','days_pct','size_pct','oi_c_chg_pct',\
             'oi_p_chg_pct', 'oi_p_pct', 'spike_iv','weigh', 'iv_chg_pct']
    
    for p in col_pct:
        dt[p]=dt[p].replace(np.inf,0).replace(-np.inf,0).replace(np.nan,0).replace('',0)
        dt[p] =dt[p].astype(float).apply(lambda x: "{0:.0f}%".format(x*100))
    dt.sort_values(['risk_live','pl_ur_pct','days_pct'], ascending=False, inplace=True)
    pd.set_option('display.expand_frame_repr', False)
    print(" \n---- ALERT_WARN  ---  \n ", dt[show_alerts].to_string(index=False))
    print("\n ---- STOP_EXIT_OUT ---   \n ", dt[CON_stop |CON_exit |CON_out][show_action])

    print("\n ---- SIZE ---   \n ", dt[CON_size][show_size].sort_values(['size_pct','weigh'], ascending=False))
    print("\n ---- UNOP ---    \n ", dt[CON_unop][show_unop])
#    print("\n ---- EVENT---   \n ", dt[CON_event & CON_event_show][show_event])
    return dt        

#%%
def report_by_cid(q_date):
    """
    use: risk_view@cid by sec/oexp_dt
    source: report_by('cid')
    """
    df=report_data(q_date, 'cid')
    """
#tbl_act        
    df_cap=read_sql("SELECT * FROM tbl_act")
    df=df.merge(df_cap[['act','cap']], on='act',how='left')
    df['weigh']=df['risk_live']/df['cap']
    risk_overview=df.groupby('act').agg({'risk_live':'sum', 'weigh':'sum', 'pl':'sum'})   
    print (" - --Overview ---- \n # of tickers: %s \n"%df.shape[0], risk_overview)   
    col_rpt=['var_iv', 'risk_live','weigh','pl_ur',  'pl', 'pl_p',\
             'delta_c','gamma_c','theta_c', 'vega_c'] 
    df[col_rpt]=df[col_rpt].replace('',0)      
    rpt_1=df.pivot_table(index=['sec', 'oexp_dt'], values= col_rpt, aggfunc= 'sum', \
            fill_value= 0, margins = True, margins_name= 'total')
    rpt_2=df.pivot_table(index=['oexp_dt', 'sec'], values= col_rpt, aggfunc= 'sum', \
            fill_value= 0, margins = True, margins_name= 'total')
    pd.set_option('display.expand_frame_repr', False)
    print(rpt_1)
    print(rpt_2)
    pd.set_option('display.expand_frame_repr', True)
    """
# prep for cid_alert
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date'])  
    col_iv=['ticker','date', 'iv', 'oi', 'oi_c', 'oi_p', 'vol','p','p_chg']
    
    df=df.merge(div[col_iv], on=['ticker','date'], how='left')
    
    df=prob_oc(df, q_date)
    
    con_itm_pct=np.abs(df['p']/df['strike'] -1)>itm_pct
    con_itm_sc=(df['lc']<0) & (df['type']=='C') & con_itm_pct & (df['p']>df['strike'])
    con_itm_sp=(df['lc']<0) & (df['type']=='P') & con_itm_pct & (df['p']<df['strike'])
    con_itm_deep=np.abs(df['delta'])>itm_deep
    CON_itm= con_itm_sc | con_itm_sp | con_itm_deep
    
    df['mp_i_chg']=df['mp'] - df['iop']
    con_neg_1=(df['p_chg']*df['mp_p_chg']<0) & (df['type']=='C')
    con_neg_2=(df['p_chg']*df['mp_p_chg']>0) &  (df['type']=='P')   
    con_neg_3=(df['p_i_chg']*df['mp_i_chg']<0) & (df['type']=='C')
    con_neg_4=(df['p_i_chg']*df['mp_i_chg']>0) &  (df['type']=='P')
    CON_neg=con_neg_1 | con_neg_2| con_neg_3 |con_neg_4
    
    
    df['a_itm']=CON_itm
    df['a_neg']=CON_neg
    show_itm=['ticker','type','oexp_dt','p', 'strike', 'delta','lc', 'lp','mp']
    show_neg=['cid', 'type','lc', 'mp','mp_p_chg', 'p_chg','mp_i_chg', 'p_i_chg', 'iv_i_chg']
    pd.set_option('display.expand_frame_repr', False)
    print("\n ---- ITM ---    \n ", df[CON_itm][show_itm])
    print("\n ---- NEG mp_chg vs. p_chg ---    \n ", df[CON_neg][show_neg])
    return df

#a_momt    
#    con_momt_l= con_l & (  (dt['srtn_22_pct']<dt['i_srtn_22_pct']) \
#                    | (dt['rtn_22_pct']<dt['i_rtn_22_pct']) )
#    con_momt_s= con_s & ( (dt['srtn_22_pct']>dt['i_srtn_22_pct']) \
#                   | (dt['rtn_22_pct']>dt['i_rtn_22_pct']) )
#    CON_momt= con_momt_l | con_momt_s

#    show_tgt_p=['ticker', 'days_pct','tgt_p','pl_pct', 'tgt_dt', 'prob_t', 'prob']

#    print("\n ---- TGT_P ---    \n ", dt[CON_tgt_p][show_tgt_p]) 
#    pd.set_option('display.expand_frame_repr', True)
#    return dt
    
#%%
def track_cid(q_date):
    """
    use: plot chg_mp, iv, vol, close@cid level
    raw source: tbl_oc, tbl_cid, tbl_iv, tbl_pv_all
    intel: i_chg in (o_oi, mp, iv, close, volume)
    alert: mp_i_chg_pct (add)
    
    2. risk_view_by_sec_exp
    """
    print("  cid_track started  ")
# aggr data@cid level, incl. 'U1' tid
    dt=read_sql("select * from tbl_oc where exit_dt ='N'")
#    dt['oexp_dt']=pd.to_datetime(dt['oexp_dt'])
#    dt['entry_dt']=pd.to_datetime(dt['entry_dt'])    
#    dt['days_to_exp']=dt['oexp_dt'].subtract(q_date).dt.days   
#    dt['days_all']= dt['oexp_dt'].subtract(dt['entry_dt']).dt.days   
#    dt['days_pct']=(1-dt['days_to_exp']/dt['days_all']).round(2)
    col_dt=['cid','days_pct', 'pid']
#    list_t=dt.ticker.unique().tolist()
    
    do=read_sql("select * from tbl_cid")
    do['date']=pd.to_datetime(do['date'])
    do['ticker']=do['cid'].str.split('-').str[0]
    col_cid=['cid', 'mp', 'pl', 'o_oi','o_vol','date', 'ticker']
    dot=do[col_cid].merge(dt[col_dt], on='cid', how='left')
#    do=do[do.ticker.isin(list_t)]
    
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date'])  
    col_iv=['ticker','date', 'iv', 'oi', 'oi_c', 'oi_p', 'vol','p_chg']
    
    dpv=read_sql("select * from tbl_pv_all")
    dpv['date']=pd.to_datetime(dpv['date'])      
    col_pv=['ticker','date','close','volume']
    
    df=dot.merge(div[col_iv], on=['ticker','date'], how='left')
    df=df.merge( dpv[col_pv], on=['ticker','date'], how='left' )
#rolling chg from i_date <tbl_iv> 
    df['o_oi_i_chg']=df.groupby('cid')['o_oi'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['mp_i_chg']=df.groupby('cid')['mp'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['iv_i_chg']=df.groupby('cid')['iv'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['close_i_chg']=df.groupby('cid')['close'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['volume_i_chg']=df.groupby('cid')['volume'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    con_u= df['pid'].str[:1]=='U'
    con_days_pct=df['days_pct']<0.5
    
    dft=df[(~con_u) & con_days_pct]
    dv_q=dft[dft.date==q_date][['cid','mp_i_chg', 'mp','days_pct']].sort_values('mp_i_chg')
    print(dv_q)
    dv_1=pd.pivot_table(dft, index='date', columns='cid', values='mp_i_chg')
# plot mp_chg for all cid    
    dv_1.sort_values(by=q_date, ascending=False, axis=1, inplace=True)
    dv_1.plot(kind='line',  figsize=(16,8), rot=45, alpha=0.7)    

    dfu=df[con_u & con_days_pct]  
    dv_u=dfu[dfu.date==q_date][['cid','mp_i_chg', 'mp','days_pct']].sort_values('mp_i_chg')
    print(dv_u)
    du_1=pd.pivot_table(dfu, index='date', columns='cid', values='mp_i_chg')
#    dv_2.plot(kind='line',  figsize=(16,8), rot=45, alpha=0.7)
    du_1.sort_values(by=q_date, ascending=False, axis=1, inplace=True)
    du_1.plot(kind='line',  figsize=(16,8), rot=45, alpha=0.7)
#plot mp_chg, close_chg, iv_chg for each cid
#    for c in df.cid.unique().tolist():
#        dg=df[df.cid==c]
#        dg.plot(x='date', y=['close_chg','mp_chg','iv_chg'])
 #%%    
def prob_oc(df, q_date):  
    import scipy.stats
    col_val=['lc','strike','iop','iv']
    df=type_convert(df, col_val)
    #lc: live contract, lp: live price
    con_lc= (df.lc >0) & (df.type == 'C')
    con_sc= (df.lc <0) & (df.type == 'C')
    con_lp= (df.lc >0) & (df.type == 'P')
    con_sp= (df.lc <0) & (df.type == 'P')
 
    df.loc[con_lc, 'bedn']=df.loc[con_lc, 'strike'] + df.loc[con_lc, 'iop']
    df.loc[con_sc, 'beup']=df.loc[con_sc, 'strike'] + df.loc[con_sc, 'iop']
    df.loc[con_lp, 'beup']=df.loc[con_lp, 'strike'] - df.loc[con_lp, 'iop']
    df.loc[con_sp, 'bedn']=df.loc[con_sp, 'strike'] - df.loc[con_sp, 'iop']
    
    df['oexp_dt']=pd.to_datetime(df['oexp_dt'])
    df['dte']=df['oexp_dt'].subtract(q_date).dt.days
    df['std']=df['iv']*np.sqrt(df['dte']/252)
    df=type_convert(df, ['p','std'])
    for index, row in df.iterrows():
        std_p=row['p']*row['std']
        if row['beup']>0:
            df.loc[index, 'prob']=scipy.stats.norm.cdf(row['beup'], row['p'], std_p)
        elif row.bedn>0:
            df.loc[index, 'prob']=scipy.stats.norm.sf(row['bedn'], row['p'], std_p)
        else:
            pass
    df['prob']=df['prob'].astype(float).apply(lambda x: "{0:.0f}%".format(x*100))
    return df


#%%    
def cid_calc_iv():  
    """
    use: cacl iv_i_chg, iv_i_rank, p_i_chg, iv_p ('i_date' depends on 'entry_dt'@tbl_oc
       , prep for cid_pl_attr()
    source: tbl_oc, tbl_iv, tbl_pv_all
    dest: cid_pl_attr()
    """
    div=read_sql("select * from tbl_iv")
    #tbl_oc: for entry_dt to decide i_date
    dt=read_sql("select * from tbl_oc where exit_dt ='N' ")  
    #tbl_pv_all: for p_i in case watchlist is added later
    dp=read_sql("select * from tbl_pv_all")
    dp['date']=pd.to_datetime(dp['date'])
    dtv=div.merge(dt[['ticker','entry_dt']], on ='ticker', how='right')
    dtv['date']=pd.to_datetime(dtv['date'])
    dtv['entry_dt']=pd.to_datetime(dtv['entry_dt'])
    df=pd.DataFrame()
    for t in dtv.ticker.unique().tolist():
        dg=dtv[dtv.ticker==t]
        dg.sort_values('date', inplace=True)
        #exclude tikcer from previous trade 
        dg=dg[dg.date>=dg.entry_dt]   
        dpt=dp[dp.ticker==t] 
        entry_dt=dg['entry_dt'].head(1).values[0]
        try:
            p_i=dpt[dpt.date==entry_dt]['close'].values[0]
            dg['iv_i_chg']=dg['iv'].tail(1).values[0]-dg['iv'].head(1).values[0] 
            dg['iv_chg']=dg['iv'].tail(1).values[0]-dg['iv'].tail(2).head(1).values[0]
            dg['iv_i_rank']=dg['iv_rank'].head(1).values[0]
            dg['p_i_chg']=dg['p'].tail(1).values[0]- p_i

        except:
            print(t)
            pass
        #get snapshot @q_date only
        dg=dg.tail(1)
        df=pd.concat([df, dg], axis=0)
    col=['date', 'div','div_dt', 'earn_dt_mc', 'entry_dt', 'ind', 'iv', 'iv_1y', 'iv_chg_pct',
       'iv_d', 'iv_i_chg_pct', 'iv_i_rank', 'iv_rank', 'mcap', 'oi', 'oi_c',
       'oi_p', 'oi_p_pct', 'p', 'p_chg', 'p_chg_pct', 'p_i_chg', 'sec',
       'spike_iv', 'ticker', 'vol', 'vol_pct', 'vol_stk', 'yld']
    return df

#%%
def cid_calc_var(df):
    """
    use: cacl var_greeks,
    source: tbl_cid, cid_calc_iv(need iv)
    dest: tbl_cid
    """
    df['atr_iv']=df['p']*df['iv']*np.sqrt(1/252)
    df['var_delta']=df['atr_iv']*df['delta'] *df['lc']*100
    df['var_gamma']=df['gamma']* 0.5 * 0.5* df['atr_iv']*df['lc']*100
    df['var_theta']=df['theta']*df['lc']*100
    df['var_iv']=np.abs(df['var_delta'])+np.abs(df['var_gamma']+df['var_theta'])
    return df
#    df['var_iv']=np.abs(df['var_delta'])+np.abs(df['var_gamma']+df['var_theta'])
    
 #%%    
def tbl_cid_pl_attr(q_date): 
    """
    use: append tbl_cid with pl_attr explained & outlier
    source: tbl_cid, cid_calc_iv() (from tbl_iv, tbl_oc)
    dest: tbl_cid
    alert: pl_ur_pct, 
    note: p_u_chg is accuare (based on entry_dt, tbl_pv_all)
    pl_greek (greek_i depends on tbl_iv avaibability - up to watchlist updated date), can be off
    #https://www.elitetrader.com/et/threads/explaining-options-p-l-by-greeks.321460/
    """
    print("cid_pl_attr started" )
    pl_exp_pct=0.7
    pl_ur_pct_min=0.3
#get iv data    
    div=cid_calc_iv()
    div['date']=pd.to_datetime(div['date'])
    div['entry_dt']=pd.to_datetime(div['entry_dt'])    
    
    #exclude unop trade, but might include exired cid as tbl_cid has not expir info
    #this will be updated by tbl_iv data
    did=read_sql("select * from tbl_cid WHERE comm_c IS NOT NULL")  
    did['date']=pd.to_datetime(did['date'])
# !! get mp_chg, pl_chg wiht new approach
    did['mp_p_chg']=did.sort_values('date').groupby('cid')['mp'].apply(lambda x:x-x.shift(1))
    did['pl_p']=did['mp_p_chg']*did['lc']*100
    
    did=did[did.date==q_date]
    did['ticker']=did['cid'].str.split('-').str[0]
    share_vd=['iv_d', 'iv_i_chg', 'iv_i_rank', 'p_i_chg']
    col_did=[x for x in did.columns.tolist() if not x in share_vd]
    #merge on live div only
    df=did[col_did].merge(div, on=['ticker','date'], how='right')
    col_val=['delta_p', 'theta_p', 'gamma_p', 'vega_p']
    df=type_convert(df, col_val, 'float')
    df['pl_delta']=df['delta_i']  *df['lc']*100* df['p_i_chg']
    df['pl_vega']=df['vega_i'] *df['lc']*100* df['iv_i_chg']*100  
    df['pl_gamma']= (df['gamma_i'] + df['gamma']) * 0.5 *df['lc']*100* 0.5* (df['p_i_chg'] **2 )
    df['theta_dt']=df['date'].subtract(df['entry_dt']).dt.days      
    df['pl_theta']=(df['theta'] + df['theta_i'])*0.5 * df['lc']*100* df['theta_dt']   
    df['pl_exp']=df['pl_delta']+df['pl_vega']+df['pl_theta']+df['pl_gamma']
    df['pl_exp_pct']=df['pl_exp']/df['pl'].astype(float)
   
# daily pl_attr
    df['pl_p_delta']=df['delta_p']*df['lc']*100* df['p_chg'] 
    df['pl_p_vega']=df['vega_p']*df['lc']*100* df['iv_chg']*100  
    df['pl_p_gamma']= df['gamma_p']*df['lc']*100* 0.5* (df['p_chg'] **2 )
    df['pl_p_theta']= df['theta_p'] * df['lc']*100
    df['pl_p_exp']= df['pl_p_delta'] +  df['pl_p_vega']+ df['pl_p_gamma']+ df['pl_p_theta']
    df['pl_p_exp_pct']=df['pl_p_exp']/df['pl_p'].astype(float)
   
    df=cid_calc_var(df)

    con_out=np.abs(df['pl_exp_pct']-1)> (1- pl_exp_pct)
    con_p_out_1=np.abs(df['pl_p_exp_pct']-1)> (1- pl_exp_pct)
    con_p_out_2= df['pl_p_exp_pct']< (pl_exp_pct-1)
    con_p_out= con_p_out_1 | con_p_out_2
    
    
    col=['cid','pl_ur_pct','pl', 'lp', 'mp', 'pl_exp_pct','pl_delta','pl_vega', 'pl_gamma', 'pl_theta',\
         'pl_p_exp_pct', 'pl_p', 'pl_p_delta','pl_p_vega', 'pl_p_gamma', 'pl_p_theta']

    df[['pl_exp_pct', 'pl_p_exp_pct']] =df[['pl_exp_pct', 'pl_p_exp_pct']].astype(float).applymap(lambda x: "{0:.0f}%".format(x*100))

    print("pl_outlier \n", df[con_out][col])
#    print("pl_explainable: \n", df[~con_out][col])
    print("pl_p_outlier: \n", df[con_p_out][col])
    
 # drop tbl_cid@q_date then add enriched back
    col_cid=did.columns.tolist()
    col_pl= ['pl_theta', 'pl_gamma', 'iv_i_rank', 'pl_exp', 'theta_dt', \
        'pl_delta', 'pl_vega', 'iv_i_chg', 'pl_exp_pct', 'p_i_chg', 'iv_d',\
        'pl_p_exp_pct', 'pl_p_exp','pl_p_delta','pl_p_vega', 'pl_p_gamma', 'pl_p_theta',\
        'pl_p', 'mp_p_chg']
    col_var=['atr_iv','var_delta','var_gamma','var_theta','var_iv']
    col_new=col_cid + col_pl+col_var
    col=list(set(col_new))  #drop duplicated 'var_delta'?
    if df.empty | (df.shape[0]==0) | (df.shape[0] !=did.shape[0]):
        print("cid_pl_attr: df empty")
        return
    conn=get_conn()
    cur=conn.cursor()
#    q_datetime=datetime.datetime(q_date.year, q_date.month, q_date.day)
    cur.execute("DELETE FROM tbl_cid WHERE date >='%s' "%q_date)
    conn.commit()
    cur.close()
    
    tbl_nodupe_append(q_date, df[col], 'tbl_cid')
    
    return df
    


