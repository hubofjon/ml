# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 12:18:13 2017

Purpose: genearte play_list
Functions:
    1. play_run_daily
    2. play_run  # save to DB
    3. play_view   #save to csv. not db
    4. feature_view
    5. get_column
    6. ml_apply  (apply algo for ETF ML trade)

Imported:
    1. stat_run
@author: jon
"""

import pandas as pd
import numpy as np 
import datetime as datetime
import scipy.stats as stats
import sqlite3 as db
import pandas_datareader.data as web
from pandas.tseries.offsets import BDay
from timeit import default_timer as timer
#Import functions
from P_commons import to_sql_append, to_sql_replace, read_sql
from P_stat import stat_run_new#, stat_run
from P_intel import get_earning_date, get_rsi, get_tsm
todate=datetime.date.today()
LBdate=(todate-BDay(1)).date()


def play_candy(q_date, ticks='', env="prod"): # generate play candidately by ad-hoc ['fl']
    from T_intel import get_earning_ec, get_DIV, get_si_sqz
    from R_options import get_option_simple
    from R_stat import stat_VIEW
    df=stat_VIEW(q_date,ticks)
    stat_schema=df.columns
    option_schema=['iv_30', 'iv_30_rank','iv_hv', 'hv_rank', 'v_opt_pct', 'pcr_v', 'pcr_oi']
    play_schema=['earn_date', 'ex_div', 'si']+ option_schema
    
    df.reset_index(inplace=True, drop=True)
    # enrich with si
    for index, row in df.iterrows():
        try:
            df.loc[index,play_schema[0]]=get_earning_ec(row.ticker)[0]
        except:  #ETF has no earning
            pass
        df.loc[index,play_schema[1]]=get_DIV(row.ticker)[0]
        df.loc[index,play_schema[2]]=get_si_sqz(row.ticker)[0]
        opt=get_option_simple(row.ticker)
        df.loc[index,play_schema[3]]=opt['iv_30'].values[0]
        df.loc[index,play_schema[4]]=float(opt['iv_30_rank'].values[0][:-1])
        df.loc[index,play_schema[5]]=opt['iv_hv'].values[0]
        df.loc[index,play_schema[6]]=opt['hv_rank'].values[0]        
        df.loc[index,play_schema[7]]=opt['v_opt_pct'].values[0]   
        df.loc[index,play_schema[8]]=opt['pcr_v'].values[0]    
        df.loc[index,play_schema[9]]=opt['pcr_oi'].values[0]            
#        df.loc[index,play_schema[7]]=opt['pe'].values[0]      
    
    entry_schema=['act','play','edge','entry_date','estike_1','estrike_2',\
        'exit_target','expire_date','be_up',\
        'be_down','exit_date','con_1', 'con_2','con_p1','con_p2', 'now_price'\
        ,'con_ex1','con_ex2','con_ex_p1','con_ex_p2' \
        ,'comm','delta']

    df_tbl_trade=df.append(pd.DataFrame(columns=entry_schema))  #df is df_play

    stat_view=['ticker','date', 'beta','close_qdate', 'fm_mean50', 'fm_mean200'\
              ,'fm_hi252','fm_lo252','hv_22', 'hv_66',  'mean_20','mean_50'\
              , 'mean_200', 'sec', 'srtn_22_pct','chg_22_66', 'rtn_5_pct', 'rtn_22_pct'\
              , 'rtn_66_pct', 'sartn_22', 'srtn_22', 'rsi']
    
    play_view=stat_view + play_schema
    entry_view= entry_schema
    entry_view.extend(play_view)
#pre-fill
    df_tbl_trade['exit_date']='N'
    df_tbl_trade['expire_date']=datetime.date(2017,1,1)
    df_tbl_trade['ex_div']=datetime.date(2017,1,1)
    df_tbl_trade['act']='IBQ'
    df_tbl_trade['play']='Z'
    df_tbl_trade[['con_1','con_2','con_p1','con_p2','con_ex1','con_ex2'\
                  ,'con_ex_p1', 'con_ex_p2']]=0
    
    
    df_play=df_tbl_trade[play_view]  #to show
    df_entry=df_tbl_trade[entry_view]  #to entry.csv
    pd.set_option('display.expand_frame_repr', False)
    print(df_play)
    pd.set_option('display.expand_frame_repr', True)

#    df_play.to_csv(r'c:\pycode\playlist\candy_%s.csv'%(q_date))
    tbl_trade_view=['date','act','ticker','play','edge','expire_date',\
        'entry_date','con_1','con_p1','estike_1','be_down','be_up',\
        'comm','exit_target','close_qdate','now_price','delta',\
        'sec','srtn_22_pct','srtn_22','rtn_22_pct',	'chg_22_66',\
        'rtn_5_pct',	'beta','iv_30','iv_30_rank','iv_hv','hv_rank',\
        'si',	'rsi','v_opt_pct','fm_mean20','fm_mean50','fm_mean200',\
        'earn_date',	'ex_div','estrike_2','exit_date','fm_hi252',\
        'fm_lo252','hv_22','hv_66','hi_252','lo_252','mean_20',\
       'mean_50','mean_200','rtn_5','rtn_22','rtn_66','rtn_66_pct',\
        'sartn_22','p_22_sig','p_66_sig',	'index','con_2','con_p2',\
        'close_22b',	'close_66b','con_ex1','con_ex2','con_ex_p1','con_ex_p2'\
        ,'pcr_v','pcr_oi']


    if env=='prod':
        df_tbl_trade[tbl_trade_view].round(2).to_csv(r'c:\pycode\playlist\tb_trade_%s.csv'%(q_date))
        to_sql_replace(df_play, "tb_play")
        print("candy list done for %s "%q_date)
    
    else:
        df_tbl_trade[tbl_trade_view].round(2).to_csv(r'c:\pycode\playlist\tb_trade_test_%s.csv'%(q_date))
        to_sql_replace(df_play, "tb_play_test")
        print("candy list_test done for %s "%q_date)
    return df_play
#    return df_tbl_trade, df_play, df_entry

#    entry_schema=['act','entry_price','entry_date','estike_1','estrike_2',\
#        'contracts','erisk','exit_target','expire_date','be_up',\
#        'be_down','exist_pct','alert_exit','alert_stop'\
#        ,'exit_date','exit_price','epnl_pct','epnl', 'days_left'\
#        ,'con_1', 'con_2','con_p1','con_p2','con_ex1','con_ex2',\
#        'con_ex_p1','con_ex_p2','comm','delta','play']  
    
def trade_ENTRY():
#    df_trade=pd.read_excel(open(r'c:\pycode\playlist\tb_trade.xlsx','rb'))
    df_trade=pd.read_csv(r'c:\pycode\playlist\tb_trade.csv')    
    to_sql_append(df_trade, 'tb_trade')  #log trades and track performance
    print ("trade is saved in tb_trade")
    