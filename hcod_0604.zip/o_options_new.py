# -*- coding: utf-8 -*-
"""
@author: jon
"""
import pandas as pd
import numpy as np
import datetime as datetime
import time
from P_commons import bdate, tbl_nodupe_append, get_profile, type_convert, reg_convert, read_sql, to_sql_replace
pd.options.display.float_format = '{:.2f}'.format
#from termcolor import colored
from timeit import default_timer as timer
from R_getdata import get_EARN, get_DIV, get_SI, get_RSI, get_FUN
#from R_plot import plot_base 
#from R_plot import plot_base
#from datetime import timedelta
from R_stat import stat_VIEW #stat_VIEW
from dateutil import parser
#from timeit import default_timer as timer
from termcolor import colored, cprint
import os

dir_eod='l:\\pycode\\eod'
path_driver="l:\\pycode\Github\chromedriver.exe"

#%%
def unop_omc(q_date): 
    """
    use:
    dest: tbl_mc_raw
    sub_f: get_unop_mc
    """
    print(" ------ chamerlain unop_mc starts ------")
    fm_last_earn_dt=60
    pages, mc_date=get_unop_mc()
    if mc_date !=q_date:
        print("mc_date not equal q_date")
        return
    #remove empty element
    pages=[x for x in pages if x]  
    df=pd.DataFrame(data=pages[1:], columns=pages[0], index=range(len(pages)-1))
    df.rename(columns={'Symbol':'ticker', 'Volume':'v_opt', 'Calls':'pct_c', \
           'Puts':'pct_p', 'Relative Volume':'v_pct', 'Price':'p',\
           '% Chg':'p_chg', 'Earnings':'earn_dt', 'Event':'event',\
           'IV':'iv', 'IV Chg':'iv_chg',
           '#Call Trades':'num_c', '#Put Trades':'num_p'}, inplace=True)
    df['v_pct']=df.v_pct.astype(float)
    df['p_chg_abs']=df.p_chg.str.replace("+","").str.replace("-","")\
        .str.replace("%","").astype(float)
    df['p_chg']=df.p_chg.str.replace("+","")\
        .str.replace("%","").astype(float)        
    df['iv_chg_abs']=  df.iv_chg.str.replace("+","").str.replace("-","")\
        .str.replace("%","").astype(float)
    df['iv_chg']=  df.iv_chg.str.replace("+","")\
        .str.replace("%","").astype(float)
    df['v_opt']=df['v_opt'].str.replace(",", "").astype(float)
    df['v_opt_avg']=df['v_opt']/df['v_pct']
    def rgx(val):
        import re
        evt=re.search('(\d{1,2}-\S{3}-\d{4})',val)
        if evt:
            return evt.group(0)
        else:
            return np.nan        
    df['event_dt']=df['event'].apply(rgx)
    #Filter outdated earn_dt from mc website   
    #deal with datetime type issue: earn_dt<q_date, but no more than 2mth old
    df['earn_dt']= pd.to_datetime(df['earn_dt'].str.split(' ').str[0])
    df['earn_dt'].fillna('2018-01-01', inplace=True)
    df['earn_dt']=pd.to_datetime(df['earn_dt'])
    try:
        con_earn_dt_1= df['earn_dt']<q_date
        con_earn_dt_2= (q_date -df['earn_dt'].dt.date)<datetime.timedelta(fm_last_earn_dt)
        con_earn_dt=con_earn_dt_1 & con_earn_dt_2 
        df.loc[con_earn_dt, 'earn_dt']=np.datetime64('NaT')    
    except:
        print(" --con_earn_dt type error --")
        pass
    df.sort_values(by=['v_pct','iv_chg_abs', 'p_chg_abs'], ascending=[False, True, True]
                ,axis=0, inplace=True)

    df['pct_c']=df['pct_c'].str.replace("%","").astype(float)
    df['date']=q_date
    df['iv']=df['iv'].astype(float) /100
    #datetime.datetime.strptime(mc_date, '%Y-%m-%d').date()
    df['date']=pd.to_datetime(df['date'])
    tbl_nodupe_append(q_date, df, 'tbl_mc_raw')    
    return df
#%%
def omc_intel(q_date):
    '''
    source: tbl_mc_raw, 
    dest: tbl_mc_candy
    criteria: dsize: size_per_trade, div: top n iv_chg, dpct: pct_c>90
    '''
    print("--- mc_intel started  --- ")
    qry="SELECT * FROM tbl_mc_raw"
    df=read_sql(qry, q_date)
    df['date']=pd.to_datetime(df['date'])
    df=df[df.date==q_date]
    df['num_p']=df['num_p'].str.replace(',','')
    df['num_c']=df['num_c'].str.replace(',','')
    df['pct_p']=df['pct_p'].str.replace('%','')
    df_val=['iv_chg','p_chg','pct_c','p','v_opt_avg','v_pct','v_opt','num_p','num_c']
    df=type_convert(df, df_val,'float')
    df['size_c']=(df['v_opt'].astype(float)*df['pct_c'].astype(float) \
                  *0.01)/df['num_c'].astype(float)
    df['size_p']=(df['v_opt'].astype(float)*df['pct_p'].astype(float) \
                  *0.01)/df['num_p'].astype(float)    
    #criteria
    v_pct_min=4
    v_opt_avg_min=1000  
    size_min=100
    p_chg_pct_top=3
    iv_chg_pct_top=5
    call_pct=85
    put_pct=15
    iv_chg_clip=40
    iv_p_chg_max=5
    iv_iv_chg_min=10

    p_max=250
    p_min=2

    con_p=(df.p< p_max) & (df.p> p_min)
    df=df[con_p]
# dsize: by size_c before downsizing   
    con_size=(df[['size_c','size_p']]>size_min).any(axis=1)
    dsize=df[con_size]

# div: by iv_chg
    div=df.reindex(df.iv_chg.abs().sort_values(ascending=False).index).head(iv_chg_clip)
    con_iv=(df.p_chg.abs()<=iv_p_chg_max) & (df.iv_chg.abs()>=iv_iv_chg_min)
    div=div[con_iv]
    div['play']='V'
    
#3. bc_interl criteria    
    con_liq=(df.v_opt_avg > v_opt_avg_min)
    con_v_pct=df.v_pct>v_pct_min
#dx: by pct_call only    
    dpct=df[(df.pct_c> call_pct)|(df.pct_c<(100-call_pct))]
    dpct=dpct[con_liq & con_v_pct]
    
# by internal criteria
    df=df[con_liq & con_p & con_v_pct]    
    con_iv_up_top=df['iv_chg']>iv_chg_pct_top
    con_iv_up_lo= (~con_iv_up_top) & (df['iv_chg']>0)
    con_iv_dn_top=df['iv_chg']< (0- iv_chg_pct_top)
    con_iv_dn_lo= (~ con_iv_dn_top) & (df['iv_chg']<0)
                
    con_p_up_top=df['p_chg']>p_chg_pct_top    
    con_p_up_lo= (~con_p_up_top) & (df['p_chg']>0)
    con_p_dn_top=df['p_chg']< (0-p_chg_pct_top)
    con_p_dn_lo= (~con_p_dn_top) & (df['p_chg']<0)
    
    con_c=df['pct_c']>call_pct
    con_p=(100-df['pct_c'])>put_pct
                 
    con_cat=pd.notnull(df['earn_dt'])|pd.notnull(df['event_dt'])

    CON_iv_up_top_p_up_top=con_iv_up_top & con_p_up_top #& (~con_cat)  #LC->SCV, BW)
    CON_iv_up_top_p_up_lo=con_iv_up_top & con_p_up_lo  & (con_c | con_p) #con_cat # !! Accumu ->LC, LCV
    CON_iv_up_top_p_dn_top=con_iv_up_top & con_p_dn_top & (con_c | con_p) #& (~con_cat) #LP -> BF, CAL
    CON_iv_up_top_p_dn_lo=con_iv_up_top & con_p_dn_lo & con_cat  # !! Acumu: LP or LC- up to iv rank
    
    CON_iv_dn_top_p_up_top_cp=con_iv_dn_top & con_p_up_top & (con_c |con_p) & (con_cat) #SC/SP-> LP wait)
    CON_iv_dn_top_p_up_lo= con_iv_dn_top & con_p_up_lo & con_c & ( con_cat) #SC-> wait to LP
    CON_iv_dn_top_p_dn_top=con_iv_dn_top & con_p_dn_top & (con_cat)  #more dn ?
    CON_iv_dn_top_p_dn_lo=con_iv_dn_top & con_p_dn_lo & (con_c |con_p) & con_cat #sc/sp->LC
    
    CON_iv_up_lo_dn_p_up_top=(con_iv_up_lo | con_iv_dn_lo) & con_p_up_top & (con_c |con_p) & (~ con_cat) #sc/sp->BW, Cal
    CON_iv_up_lo_dn_p_dn_top=(con_iv_up_lo | con_iv_dn_lo) & con_p_dn_top  & con_cat #sc/sp nohope-> l=LP, LPV, more down                                              

    df.loc[CON_iv_up_top_p_up_top,'play']='SCV, BW'
    df.loc[CON_iv_up_top_p_up_lo, 'play']='LCV'
    df.loc[CON_iv_up_top_p_dn_top, 'play']='BF/CAL'
    df.loc[CON_iv_up_top_p_dn_lo, 'play']='LCP'
    
    df.loc[CON_iv_dn_top_p_up_top_cp, 'play']='LP'
    df.loc[CON_iv_dn_top_p_up_lo, 'play']='LP'
    df.loc[CON_iv_dn_top_p_dn_top, 'play']='LP'
    df.loc[CON_iv_dn_top_p_dn_lo, 'play']='LC'
    
    df.loc[CON_iv_up_lo_dn_p_up_top, 'play']='BW,CAL'
    df.loc[CON_iv_up_lo_dn_p_dn_top, 'play']='LPV'
# stat_mc to evaluate 
    c1=df[CON_iv_up_top_p_up_top].shape[0]
    c2=df[CON_iv_up_top_p_up_lo].shape[0]   
    c3=df[CON_iv_up_top_p_dn_top].shape[0]
    c4=df[CON_iv_up_top_p_dn_lo].shape[0]   
    
    c5=df[CON_iv_dn_top_p_up_top_cp].shape[0]
    c6=df[CON_iv_dn_top_p_up_lo].shape[0]   
    c7=df[CON_iv_dn_top_p_dn_top].shape[0]
    c8=df[CON_iv_dn_top_p_dn_lo].shape[0]  

    c9=df[CON_iv_up_lo_dn_p_up_top].shape[0]
    c10=df[CON_iv_up_lo_dn_p_dn_top].shape[0]   
    print(" --- mc_intel stat: --  ")
    stat_mc={'date': q_date, 'c1':c1, 'c2':c2,'c3':c3, 'c4':c4, 'c5':c5, \
             'c6':c6, 'c7':c7, 'c8':c8, 'c9':c9, 'c10':c10} 
    df_stat=pd.DataFrame(stat_mc, index=np.arange(len(stat_mc)))
    tbl_nodupe_append(q_date, df_stat, "tbl_stat_mc")
    print("stat_mc: \n", stat_mc)
    
    du=df[pd.notnull(df.play)]
    du['earn_dt']=pd.to_datetime(du['earn_dt'])
    unop_show= ['ticker', 'play', 'v_pct', 'pct_c', 'iv_chg', 'iv', 'p_chg', 'p'\
                ,'earn_dt', 'event_dt', 'v_opt_avg']
    unop_show2=[x for x in unop_show if x not in ['play']]
    du=pd.concat([du[unop_show],du['event']], axis=1)
    pd.set_option('display.expand_frame_repr', False)

    dusw=du[unop_show]
#merge with results filtered by other criteria, dpct, dszie, div
    dpct=dpct[unop_show2]
    dsize=dsize[unop_show2]
    div=div[unop_show2]    

#ONLY 2
    mct=pd.concat([ dpct, dsize], axis=0)
    mct.drop_duplicates(['ticker'], keep='last', inplace=True)
#    mct.loc[(con_iv & pd.isnull(mct.play)),'play']='V'
    mct['earn_dt']=pd.to_datetime(mct['earn_dt'])
    mct.sort_values(by=['v_pct','pct_c'], ascending=[False,False], inplace=True)
    print(" ----- mc_candy list ---- ")
    mct['date']=q_date
    mct['date']=pd.to_datetime(mct['date'])
#    mct['play'].fillna('', inplace=True)
#    tbl_nodupe_append(q_date, mct, 'tbl_mc_candy') 
    return mct
#%%    
def unop_obc(q_date): 
    """
    use: update with bc.csv @q_date
    source: bc.csv, tbl_pv_all, 
    dest: tbl_bc_raw
    note:https://www.barchart.com/options/unusual-activity
    """
    print("  ---- unop_bc_dev starts -----  ")
    bid_ask_mark=0.5  #mark b or s, label for agreessivness, i.e. sweeping
    
    path_eod=dir_eod
    path_eod=r"%s"%path_eod
    files=os.listdir(path_eod)
    f_unop=[f for f in files if f[:7]=='unusual']
    if len(f_unop)!=1:
        print("bc eod file not available or more than one file")
        return
    f_unop=f_unop[0]
    unop_date=f_unop[-14:-4]
    unop_date=parser.parse(unop_date).date()
    if unop_date!=q_date:
        print("upon_bc: bc_unop_csv not euqal to q_date")
        return
    df=pd.read_csv(os.path.join(path_eod, f_unop))
    #last row is text useless
    df.drop(df.index[-1], inplace=True) 
    df.columns=df.columns.str.lower()
    df.rename(columns={'symbol':'ticker', 'exp date':'oexp_dt', 'open int':'oi'\
            ,'volume':'ioc', 'vol/oi':'v_oi', 'time':'date', 'iv':'civ',\
            'price':'p','last':'iop'}, inplace=True)
        #    date_fmt="{:%m/%d/%y}".format(q_date)) -not working as %s converted dt to str already!!
    df['civ']=df['civ'].str.replace('%','')
    df['civ']=df['civ'].astype(float)/100
    df['date']=pd.to_datetime(df['date'])
    df['ba_pct']= (df['iop']-df['bid'])/(df['ask']-df['bid'])
    df.loc[df['ba_pct']>bid_ask_mark, 'bs']='b'
    df.loc[df['ba_pct']<(1-bid_ask_mark), 'bs']='s'
    df.loc[df['ba_pct']==(1-bid_ask_mark), 'bs']='n'
    oexp_dt=pd.to_datetime(df['oexp_dt']).dt.strftime('%y%m%d')
    strike=df['strike'].apply(lambda x: str(int(x *1000)).rjust(8,'0'))
    df['cid']=df.ticker+ '-' + oexp_dt+df['type'].str[:1]+strike
    df['atm']=np.abs(df['strike']/df['p']-1)
    df['bet']=df['iop']*df['ioc']*100
    df['iop_p']=df['iop']/df['p']
    tbl_nodupe_append(q_date, df, 'tbl_obc_raw')
    return df 

#%%    
def candy_intel(q_date): 

    """
    use: rule-based filter candy@ q_date
    source: tbl_bc_raw, tbl_mc_raw, tbl_pv_all, stat_VIEW
    ext_source: get_EARN
    dest: tbl_candy, called by obmc_update_tbl_track()
    intel: 
        ? why- hikes
        ? 
    """
    print("candy_intel started")
    from datetime import timedelta
    #bc:
    vol_min=1500  #bc cvol min
    premium_min=0.2
    premium_max=4
    prem_short_max=1  #premium max for short term option
    dte_min=5
    dte_max=75
    dte_short=14
    p_max=250
    p_min=5
    atm_max=0.3
    bet_min=100000
    iop_p_ratio=0.01
    #mc_filter
    vol_avg_max=20000  #avoid high optios volume ticker
    v_oi_ratio=8
    volume_stk_max=7500000
    #"why" criteria
    spike_min=2
    key_level_pct=0.015
    hv_rank_min=0.1
    iv_hv_diff=0.3
    
    #bc data    
    dbc=read_sql("SELECT * FROM tbl_obc_raw", q_date)
    dbc['date']=pd.to_datetime(dbc['date'])
    dbc=dbc[dbc.date==q_date]
    dbc=type_convert(dbc, ['v_oi','dte','ioc','iop', 'p','atm'])
    con_vol=dbc['ioc']>vol_min
    con_dte= (dbc.dte>dte_min) & (dbc.dte<dte_max)  #ignore long dated
    con_prem=(dbc['iop']>premium_min) & (dbc['iop']<premium_max)
    con_price=(dbc['p']<p_max) & (dbc['p']>p_min)
    con_atm= (dbc['atm']<=atm_max)
    con_short=(dbc['dte']<dte_short) & (dbc['iop']>prem_short_max)
    con_bet=dbc.bet>bet_min
    dbc=dbc[con_vol & con_dte & con_prem & con_price & con_atm & con_bet & (~con_short)] 
    col_bc=['atm', 'bs', 'cid', 'civ', 'date', 'dte', 'ioc','bet','iop_p',
       'iop', 'oexp_dt', 'oi', 'p',  'strike', 'ticker', 'type', 'v_oi']
    dbc=dbc[col_bc]
    #mc data
    dmc=read_sql("SELECT * FROM tbl_mc_raw", q_date)
    dmc['date']=pd.to_datetime(dmc['date'])
    dmc=dmc[dmc.date==q_date]
    con_vol_max=dmc['v_opt_avg']<vol_avg_max
    dmc=dmc[con_vol_max]
    col_mc=['ticker','p_chg','v_pct', 'pct_c', 'iv', 'iv_chg','earn_dt','event_dt']
    dmc=dmc[col_mc]
   
    df_bmc=dbc.merge(dmc, on='ticker',how='left')  
    df=df_bmc[pd.notnull(df_bmc.iv) ] #overlap mc
    #process dn, with no overlap with mc
    dn=df_bmc[pd.isnull(df_bmc.iv)] 
    
    p_date=q_date-timedelta(1)
    dp=read_sql("SELECT * FROM tbl_pv_all")
    dp['date']=pd.to_datetime(dp['date'])
    dp=dp[dp.date==p_date]
    dn=dn.merge(dp[['ticker','volume']], on='ticker', how='left')
    con_v_oi=dn.v_oi> v_oi_ratio
    con_vol_stk=dn.volume< volume_stk_max
    dn=dn[ con_v_oi & con_vol_stk]
    dn.drop('volume', axis=1, inplace=True)
    
    dfn=pd.concat([df, dn], axis=0)
#   merge with stat_VIEW
    ds=stat_VIEW(q_date, dfn.ticker.unique().tolist())
    dt=dfn.merge(ds, on='ticker')
    con_earn_dt=pd.isnull(dt.earn_dt)
    list_tickers=dt[con_earn_dt].ticker.unique()
    for t in list_tickers:
        try:
            dt.loc[dt.ticker==t, 'earn_dt']= get_EARN(t)
        except:
            pass

    CON_key_level=(np.abs(dt['fm_50'])<= key_level_pct) \
      |(np.abs(dt['fm_200'])<= key_level_pct) \
      |(np.abs(dt['fm_hi'])<= key_level_pct) \
      |(np.abs(dt['fm_lo'])<= key_level_pct)
    
    con_iv=pd.isnull(dt.iv)
    dt.loc[con_iv, 'iv']=dt.loc[con_iv, 'civ']
    dt['iv_hv']=dt['iv']/dt['hv_22']
    CON_iv_hv= (dt['iv_hv']> (1+ iv_hv_diff)) & (dt['iv_hv']<(1-iv_hv_diff))
    
    CON_hv_rank=(dt['hv_rank']< hv_rank_min) & (dt['hv_rank']> (1-hv_rank_min))
    
    dt['earn_dt']=pd.to_datetime(dt['earn_dt'])
    dt['oexp_dt']=pd.to_datetime(dt['oexp_dt'])
    CON_earn=(dt['oexp_dt']>dt['earn_dt']) & (dt['earn_dt']>q_date)
    CON_spike=dt['spike']>spike_min
    
    dt['why']=''
    dt.loc[CON_hv_rank, 'why']='h'
    dt.loc[CON_iv_hv, 'why']=dt.loc[CON_iv_hv, 'why']+'i'
    dt.loc[CON_key_level, 'why']=dt.loc[CON_key_level, 'why'] + 'k'
    dt.loc[CON_earn, 'why']=dt.loc[CON_earn, 'why']+'e'
    dt.loc[CON_spike, 'why']=dt.loc[CON_spike, 'why']+'s'
    
    con_why=CON_key_level |CON_iv_hv |CON_hv_rank |CON_earn
    
    show_why=['ioc','iop','bet','dte','atm','cid','bs', 'why', 'hv_rank','iv_hv', 'fm_200', 'fm_50', \
          'fm_hi','fm_lo',  'earn_dt', 'spike', 'iv_chg','rtn_22_pct']
    print("candy_intel:  \n", dt[show_why].to_string(index=False))
#   manual check daily to update ioc/iop by stocktwist or mc_point of sales
#    tbl_nodupe_append(q_date, dfn, 'tbl_candy')
    return dt
#%%
def get_unop_mc():  # take max 5 pages from unop  url
    """
    use:
    source:
    dest: 
    #http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/
    """
    from lxml import html
    from selenium.webdriver.chrome.options import Options
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException
    from bs4 import BeautifulSoup
# parameters  
#    gecko="c:\\pycode\Github\chromedriver.exe"
#    path_driver="c:\\pycode\Github\chromedriver.exe"
#    path_user_data=r"C:\Users\jon\AppData\Local\Google\Chrome\User Data\Default"
#    path_plugin_overlay="c:\\pycode\Github\extension_1_0_7_overlay_remove.crx"
#    path_plugin_ad="c:\\pycode\Github\extension_1_13_8.crx"
#    page_max= 11
    u_name='freeofjon@gmail.com'
    u_pswd='kevin2008'
    url_login="https://marketchameleon.com/Account/Login"
    url_unop ="https://marketchameleon.com/Reports/UnusualOptionVolumeReport"
    
    chrome_options=Options()
    chrome_options.add_argument("--start-maximized")  #full screen
    driver=webdriver.Chrome(executable_path= path_driver, chrome_options=chrome_options)

#url_log_in
    driver.get(url_login)
    try:
        username=driver.find_element_by_xpath('//*[@id="UserName"]')
        password=driver.find_element_by_xpath('//*[@id="Password"]')
        username.send_keys(u_name)
        password.send_keys(u_pswd)
        submit=driver.find_element_by_xpath('//*[@id="site-body-inner"]/div/div[1]/form/div[3]/input')
        time.sleep(2) 
        submit.send_keys('\n')  
    except:
        return ("unop_mc login failed")
        pass  #if user login cache preserved    
        """
trying to get symov_history table
#    url='https://marketchameleon.com/Overview/wrk/DailyHistory/'
#    driver.get(url)
#    time.sleep(5)
#    html_pg=driver.page_source
#    soup=BeautifulSoup(html_pg, 'lxml')
#    aray=[]
#    lis=[]
#    table=soup.find("table",{"id":"symov_daily_history_tbl"})
#    for row in table.find_all('tr'):
#        for td_tags in row.find_all('td'):
#            x= td_tags.get_text()
#            lis.append(x)
#        aray.append(lis)
#        lis=[]
#    driver.close()
#    driver.quit()
#    return lis, aray
    """

#url_unop
    driver.get(url_unop)
    time.sleep(2)
    html_pg=driver.page_source
    soup=BeautifulSoup(html_pg, 'lxml')
    #find report date
    try:
        mc_date=soup.findAll("div",{"class":"report_as_of_time"})[0].text[13:]
    except: 
        mc_date=datetime.date.today().strftime("%Y-%m-%d")
    #find subtitle
    titles=[]
    subs=soup.find("tr",{"class":"sub_heading"})
    for th_tags in subs.find_all('th'):
        titles.append(th_tags.get_text())

    #find table contents
    table=soup.find("table",{"id":"opt_unusual_volume"})
    pages=[]
    pages.append(titles)   # APPEND whole list of subtile as first element
    aray=[]
    lis=[]
    for row in table.find_all('tr'):
        for td_tags in row.find_all('td'):
            x= td_tags.get_text()
            lis.append(x)
        aray.append(lis)
        lis=[]
    pages.extend(aray)
    nxt=driver.find_element_by_css_selector("a.paginate_button.next")
#    nxt_dis=driver.find_element_by_css_selector("a.paginate_button.next.disabled")
    page_num=0
    page_max=15
    nxt_dis=False
    while (nxt and page_num<page_max and (not nxt_dis)):
#        if page_num<10:
            try:
                nxt.send_keys(Keys.END)
            except:
                pass
    #        driver.execute_script("window.scrollTo(0,  document.body.scrollHeight);")
            time.sleep(2)
            try:
                nxt.click()
            except:
                driver.close()
                return pages, mc_date

            time.sleep(3)
            html=driver.page_source
            soup=BeautifulSoup(html, 'lxml')
            table=soup.find("table",{"id":"opt_unusual_volume"})
            aray=[]
            lis=[]
            for row in table.find_all('tr'):
                for td_tags in row.find_all('td'):
                    x= td_tags.get_text()
                    lis.append(x)
                aray.append(lis)
                lis=[]
            pages.extend(aray)
    #        next=driver.find_element_by_id("opt_unusual_volume_next")
            page_num+=1
            nxt=driver.find_element_by_css_selector("a.paginate_button.next")
            try:
                nxt_dis=driver.find_element_by_css_selector("a.paginate_button.next.disabled")
            except:
                pass
    driver.close()
    driver.quit()
    mc_date=parser.parse(mc_date).date()
    return pages, mc_date  
#%%
def get_option_simple(ticker=''):
#ref: http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/
    from lxml import html
    from selenium.webdriver.chrome.options import Options
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException

    chrome_options=Options()
    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_0_7_overlay_remove.crx")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
    x=r"C:\Users\jon\AppData\Local\Google\Chrome\User Data\Default"
    chrome_options.add_argument("user-data-dir=%s"%x)
    url_1="https://marketchameleon.com/Overview/"+ticker
    url_2=url_1+"/OptionSummary/"
    url_3=url_1+"/StockPosts/"
    url_4=url_1+"/SymbolReview/"
    gecko="c:\\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="c:\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
#LOG IN
    url_0="https://marketchameleon.com/Account/Login"
#    driver.get(url_0)
#    time.sleep(4)
#    try:
#        ol=driver.find_element_by_class_name("register-flyer-close")
#        ol=driver.find_element
#        ol.click()
#    except:
#        print("no find flyer close")
#        pass
#    username = driver.find_element_by_id("UserName")
#    password = driver.find_element_by_id("Password")
#    username.send_keys("freeofjon@gmail.com")
#    password.send_keys("kevin2008")
#    submit=driver.find_element_by_xpath('//input[@class="site-login-control btn"]')
#    time.sleep(2)
#    submit.send_keys('\n')

#go to url_1
    driver.get(url_1)
    time.sleep(1)
    try:
        ol=driver.find_element_by_class_name("register-flyer-close")
        ol=driver.find_element
        ol.click()
    except:
        pass
    iv_30_rank=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[6]/span[2]').get_attribute('textContent')
    iv_30s=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[5]/span[2]').get_attribute('textContent')
    hv_1y=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[4]/span[2]').get_attribute('textContent')
    hv_22=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[3]/span[2]').get_attribute('textContent')

    v_stk=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[2]/span[2]').get_attribute('textContent')
    v_stk_avg=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[3]/span[2]').get_attribute('textContent')
    v_opt=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[4]/span[2]').get_attribute('textContent')
    v_opt_avg=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[5]/span[2]').get_attribute('textContent')
    v_stk=v_stk.replace(",","")
    v_stk_avg=v_stk_avg.replace(",","")
    v_opt=v_opt.replace(",","")
    v_opt_avg=v_opt_avg.replace(",","")
    v_stk_pct='{:.1%}'.format(float(v_stk)/float( v_stk_avg))
    try:
        v_opt_pct='{:.1%}'.format(float(v_opt)/ float(v_opt_avg))
    except:  #v_op is zero
        pass
#    etf_o=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[1]/span/a').get_attribute('textContent')
#    corr_etf=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[4]').get_attribute('textContent')
#    p_chg_etf=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[7]/span').get_attribute('textContent')
#    p_chg=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[1]/div[2]/div[2]/p[3]').get_attribute('textContent')
#    p=driver.find_element_by_xpath('//*[@id="overview_last_price"]').get_attribute('textContent')
#    earn_date= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[4]/span[2]').get_attribute('textContent')
    ex_div= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[2]/span[2]').get_attribute('textContent')
    yld= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[3]/span[2]').get_attribute('textContent')
#    pe= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[5]/span[2]').get_attribute('textContent')
    iv_30=float(iv_30s.split(" ")[0])
    iv_30_chg=float(iv_30s.split(" ")[1])
    iv_30_chg='{:.1%}'.format(iv_30_chg/ iv_30)
    iv_30_rank=iv_30_rank.split(" ")[0]
    iv_hv=float(iv_30)/float(hv_22)
    hv_rank=float(hv_22)/float(hv_1y)

#go to url_2: option summary for call, put volume
    driver.get(url_2)
    time.sleep(1)
    try:
        ol=driver.find_element_by_class_name("register-flyer-close")
        ol=driver.find_element
        ol.click()
    except:
        pass
    v_c= driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[6]').get_attribute('textContent')
    v_p= driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[7]').get_attribute('textContent')
    oi_c= driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[8]').get_attribute('textContent')
    oi_p= driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[9]').get_attribute('textContent')
    v_c=float(v_c.replace(",", ""))
    v_p=float(v_p.replace(",", ""))
    oi_c=float(oi_c.replace(",", ""))
    oi_p=float(oi_p.replace(",", ""))
    pcr_v=v_p/ v_c
    pcr_oi=oi_p/ oi_c #avoid division by zero
    names=['iv_30', 'iv_30_rank', 'iv_hv', 'hv_1y', 'hv_22', 'hv_rank',   \
        'v_stk', 'v_stk_avg', 'v_opt', 'v_opt_avg', 'v_stk_pct','v_opt_pct', \
        'ex_div', 'yld', 'pcr_v', 'pcr_oi']
    values=[iv_30, iv_30_rank, iv_hv,  hv_1y, hv_22, hv_rank,\
            v_stk, v_stk_avg, v_opt, v_opt_avg, v_stk_pct, v_opt_pct, \
       ex_div, yld, pcr_v, pcr_oi]
    do=pd.DataFrame(data=[], columns=names)
    do.loc[0,names]=values
    do['ticker']=ticker
    driver.quit()
#    driver.close
    return do    

def download():
    import re
    import requests
    from bs4 import BeautifulSoup

    link = 'https://www.barchart.com/options/unusual-activity'

    r = requests.get(link)
    soup = BeautifulSoup(r.text, "html.parser")

    for i in soup.find_all('a', {'class': "toolbar-button download"}):
    #    print(re.search('http://.*\.apk', i.get('href')).group(0))
         print(i.get('href'))
         return i

def download_bc():
    from lxml import html
    from selenium.webdriver.chrome.options import Options
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException

    chrome_options=Options()
#    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_0_7_overlay_remove.crx")
#    chrome_options.add_extension(r"c:\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
    x=r"C:\Users\jon\AppData\Local\Google\Chrome\User Data\Default"
    chrome_options.add_argument("user-data-dir=%s"%x)
    url="https://www.barchart.com/options/unusual-activity"

    gecko="c:\\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="c:\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
#LOG IN
    url_0="https://www.barchart.com/login"
    driver.get(url_0)
    time.sleep(4)
    try:
        ol=driver.find_element_by_class_name("register-flyer-close")
        ol=driver.find_element
        ol.click()
    except:
#        print("no find flyer close")
        pass
#    username = driver.find_element_by_id("bc-login-form")
#    password = driver.find_element_by_id("login-form-password")

    try:
        username=driver.find_element_by_xpath('//*[@id="bc-main-content-wrapper"]/div/div[2]/div[2]/div/div/div/div[2]/form/div[1]/input')
        password=driver.find_element_by_xpath('//*[@id="login-page-form-password"]')
        username.send_keys("boxofjon@yahoo.com")
        password.send_keys("kevin2008")
        submit=driver.find_element_by_xpath('//*[@id="bc-main-content-wrapper"]/div/div[2]/div[2]/div/div/div/div[2]/form/div[4]/button')
        time.sleep(2)
        submit.send_keys('\n')
    except:
        pass  #if user login cache preserved

    driver.get(url)
    time.sleep(4)
    download=driver.find_element_by_xpath('//*[@id="main-content-column"]/div/div[3]/div[2]/div[2]/a[4]')
    download.click()
    time.sleep(10)
#    download.send_keys(Keys.ENTER)
#    download.send_keys('\n')
    print("i am waiting")
    driver.close()
    driver.quit()  
#%%
def get_IV(q_date):  
    """
    use: daily update tbl_iv for tbl_oc p&l
    source: mc watch list, get_iv_table()
    dest: tbl_iv
    #http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/
    """
    from lxml import html
    from selenium.webdriver.chrome.options import Options
    from selenium import webdriver
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException
    from selenium.webdriver.common.by import By
    from bs4 import BeautifulSoup
    import numpy as np
    import re
# parameters    
#    """
#    path_driver="c:\\pycode\Github\chromedriver.exe"
#    gecko="c:\\pycode\Github\chromedriver.exe"
#    path_user_data=r"C:\Users\jon\AppData\Local\Google\Chrome\User Data\Default"
#    path_plugin_overlay="c:\\pycode\Github\extension_1_0_7_overlay_remove.crx"
#    path_plugin_ad="c:\\pycode\Github\extension_1_13_8.crx"
#    page_max= 11
#    """
    u_name='freeofjon@gmail.com'
    u_pswd='kevin2008'
    url_login="https://marketchameleon.com/Account/Login"
    url_watchlist="https://marketchameleon.com/Account/Watchlists"
    chrome_options=Options()
    chrome_options.add_argument("--start-maximized")  #full screen
    driver=webdriver.Chrome(executable_path= path_driver, chrome_options=chrome_options)
    wait = WebDriverWait(driver, 10)
#url_log_in
    driver.get(url_login)
    try:
        username=driver.find_element_by_xpath('//*[@id="UserName"]')
        password=driver.find_element_by_xpath('//*[@id="Password"]')
        username.send_keys(u_name)
        password.send_keys(u_pswd)
        submit=driver.find_element_by_xpath('//*[@id="site-body-inner"]/div/div[1]/form/div[3]/input')
        time.sleep(2) 
        submit.send_keys('\n')  
    except:
        return ("unop_mc login failed")
        pass  #if user login cache preserved    
#url_unop
    driver.get(url_watchlist)
    ds=get_IV_table(driver)
    ds.rename(columns={'% Chg':'p_chg_pct','Chg':'p_chg', 'Div Amt':'div', 'Div Ex-Date':'div_dt',\
        'Div Yield': 'yld', 'Earnings':'earn_dt_mc', 'Industry':'ind', 'Last Price':'p',\
        'Market Cap':'mcap', 'Sector':'sec', 'Symbol':'ticker', 'Volume':'vol_stk'}, inplace=True)
    ds=ds[['p_chg_pct','p_chg', 'div', 'div_dt','yld', 'earn_dt_mc','ind', 'p',\
           'mcap', 'sec', 'ticker', 'vol_stk']]
    
    btn_option=driver.find_element_by_xpath('//*[@id="stockWatchlistMenu_Options"]')
    btn_option.click()
    do=get_IV_table(driver)
#    wait.until(EC.visibility_of_element_located_by_xpath("//*[contains(text(), 'Option Volume')]"))
    do.rename(columns={'1-Yr Volatility':'iv_1y', 'IV % Rank':'iv_rank', \
        'IV30 % Chg':'iv_chg_pct', 'IV30 Last':'iv',  'Open Interest':'oi',
       'Open Interest Put Pct':'oi_p_pct', 'Option Volume':'vol', 'Relative Volume':'vol_pct', \
       'Symbol':'ticker', '1-Day Volatility':'iv_d'}, inplace=True)
    df=ds.merge(do, on='ticker', how='outer')
    df['date']=q_date
# data processing
    col_dt=['earn_dt_mc','div_dt']
    pattern=r'\d{1,2}\-[A-Za-z]{3}'
    today=datetime.datetime.today()
    for c in col_dt:
        con_dt= ~(df[c]=='')
        for index, row in df[con_dt].iterrows():
            val=re.findall(pattern, row[c])
            val=datetime.datetime.strptime(val[0], '%d-%b' )
            if val.month < today.month:
                val_year=today.year+1
            else:
                val_year=today.year
            val=datetime.datetime(val_year, val.month, val.day).date()
            df.loc[index, c]=val
    
    col_val=['p', 'p_chg_pct', 'p_chg', 'vol_stk', 'iv_d', 'iv_1y', 'iv', 'iv_chg_pct',\
              'oi','oi_p_pct','vol']
    df=reg_convert(col_val, df)
    for x in [ 'iv_d', 'iv_1y', 'iv']:
        df[x]=df[x] * 0.01
    
    p_prev=df['p']-df['p_chg']
    iv_prev=df['iv']/(1+df['iv_chg_pct'])
    p_imp=p_prev *iv_prev*np.sqrt(1/252)
    df['spike_iv']=df['p_chg']/p_imp
    df['oi_p']=df['oi']*df['oi_p_pct']
    df['oi_c']=df['oi']* (1-df['oi_p_pct'])
    tbl_nodupe_append(q_date, df, 'tbl_iv')
    driver.close()
    driver.quit() 
    return df

def get_IV_table(driver):
    time.sleep(5)
    row_header=driver.find_element_by_xpath('''//*[@id="watchlist_tbl_wrapper"]/div/div[3]/div/div[1]/div/table''')
    header=[]
    for h in row_header.find_elements_by_tag_name("th"):
        val=h.text.replace('\n',' ')          
        header.append(val)
    tbl_op=driver.find_element_by_xpath('//*[@id="watchlist_tbl"]')
    rows=tbl_op.find_elements_by_tag_name("tr")
    arry=[]
    cell=[]
    for r in rows:
        for c in r.find_elements_by_tag_name("td"):
            val=c.text           
            cell.append(val)
        arry.append(cell)
        cell=[]
    #assemble data
    arry=np.asarray(arry[1:])
    arry=np.transpose(arry)
    df=pd.DataFrame(dict(zip(header, arry)))
    return df
#%%
def candy_combo(q_date, mode):
#    """
#    USE: combine mc_candy, bc_candy, bmc_candy into tbl_candies, enrich with get_SI, EARN,DIV
#    source: tbl_mc_candy, tbl_bc_candy, tbl_bmc_candy
#    dest:
#    sub_f: get_profile, stat_VIEW, get_DIV, get_SI, get_EARN
#    mode: 'EOD', or 'pre_EOD'
#    """
    dte=22 
    print("candy_combo started")
    start_time=timer()
    # consolidate mc_candy, bc_candy, bmc_candy into one table tbl_candies in past x days
    if mode=='EOD':
        dbct=read_sql("SELECT * FROM tbl_bc_candy", q_date)
        dbmct=read_sql("SELECT * FROM tbl_bmc_candy", q_date)
        
    elif mode=='pre_EOD':
        dbct=read_sql("SELECT * FROM tbl_bc_candy_pre", q_date)
        dbmct=read_sql("SELECT * FROM tbl_bmc_candy_pre", q_date)
    else:
        print("candy_combo: mode is wrong")
        return   
    dmct=read_sql("SELECT * FROM tbl_mc_candy", q_date)
    df=pd.concat([dmct, dbct, dbmct])
    df['date']=pd.to_datetime(df['date'])
    df=df[df.date==q_date]
    scm_t_bmct=dbmct.columns.tolist()
    df=df[scm_t_bmct]
    df.sort_values(['ticker','strike'], ascending=True, inplace=True)
#    df.drop_duplicates(['ticker','date'], keep='first', inplace=True)
    if 'sec' in df.columns:
        df.drop('sec', axis=1, inplace=True)
    df=get_profile(df)
    scm_t_pro=['ticker', 'mkt', 'beta', 'sec']
    ds=stat_VIEW(q_date, df['ticker'].tolist())
    scm_v_stat=ds.columns.tolist()
    df=pd.merge(df, ds, how='left',on=scm_t_pro)

    df['iv']=df['iv'].astype('str')
    df['iv']=df['iv'].str.replace("%",'')
    df['iv']=df['iv'].astype('float')
    df['p']=df['p'].astype('float')
    df['sig_dte']=df['p']*df['iv']*np.sqrt(dte/252)
    df['iv_hv']=df['iv']/df['hv_22']
#!! update only tickers from unop_bc to save time
#    for index, row in df[pd.notnull(df.strike)].iterrows():
    for index, row in df.iterrows():
        try:
            df.loc[index,'earn_dt']=get_EARN(row.ticker)
        except:
            pass
    """    
        try:
            FUN=get_FUN(row.ticker)  
            fun_col=[ 'beta', 'pe',   'ta', 'yld', 'sector']  #earn_dt
            for k in fun_col:
                df.loc[index, k]=FUN[k]
        except:
            for k in fun_col:
                df.loc[index, k]=0
        
#        try:
#            DIV=get_DIV(row.ticker)
#            div_col=['div_dt', 'yld', 'pe', 'pe_f', 'beta']
#            for k in div_col:
#                df.loc[index, k]=DIV[k]
#        except:
#            for k in div_col:
#                df.loc[index, k]=0
 
        try:
            SI=get_SI(row.ticker)
            si_col= ['si','si_chg'] #, 'si_dtc','m_cap','inst']
            for k in si_col:
                df.loc[index, k]=SI[k]
        except:
            for k in si_col:
                df.loc[index, k]=0
    col_extra1=['earn_dt', 'yld', 'pe',  'ta', 'sector','beta','si', 'si_chg']
    """
    col_extra1=['earn_dt']
    col_extra=['sig_dte', 'iv_hv']
    scm_t_candy=scm_t_bmct + scm_t_pro + scm_v_stat + col_extra + col_extra1
    #duplicate list
    scm_t_candy=list(set(scm_t_candy))
    scm_t_candy=[x for x in scm_t_candy if x not in ['index','level_0']]
    df=df[scm_t_candy]
#    if mode=='EOD':
#        tbl_nodupe_append(q_date, df, 'tbl_candies')
#    elif mode=='pre_EOD':
#        to_sql_replace(df, 'tbl_candies_pre')    
    pd.set_option('display.expand_frame_repr', False)
    df['atm']=np.abs(df['spike']/df['close']-1)
    df.sort_values(['v_oi','v_pct', 'atm'], ascending=[False, False, True], inplace=True)
    df['earn_dt']=pd.to_datetime(df['earn_dt']).dt.strftime('%m/%d')
#    df['event_dt']=pd.to_datetime(df['event_dt']).dt.strftime('%m/%d')
    
    show_candy=['ticker','type','bs', 'dte','spike','strike','oexp_dt','sig_dte',\
                 'earn_dt','ta','si','iv_chg', 'rtn_22_pct', 'iv_hv', \
                'hv_rank', 'beta', 'pe','yld', 'close',\
                'sector','fm_50']
    pd.options.display.float_format = '{:.1f}'.format
    print(df[show_candy].to_string(index=False))
    pd.set_option('display.expand_frame_repr', True)
    end_time=timer()
    print("time: ", end_time-start_time)
    pd.options.display.float_format = '{:.2f}'.format
    return df

"""
critical selenium source
1. selenium + ajax table
https://www.guru99.com/handling-dynamic-selenium-webdriver.html
2.youtubeWaits: Selenium and Python 3
https://www.youtube.com/watch?v=Ho7zzgfh4bQ&list=PLCDERj-IUIFA4nAWEsV0xAvGFEzqDpXrR&index=6&t=0s
3. barchart api simular header
https://stackoverflow.com/questions/55006553/scraping-an-ajax-web-page-using-python-and-requestshttps://stackoverflow.com/questions/55006553/scraping-an-ajax-web-page-using-python-and-requests
4. datatbale allinone
https://datatables.net/manual/tech-notes/1
"""