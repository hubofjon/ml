select AREA_CODE, area_date, PREV_BUSINESS_DAY, WSS_GDP_TIME 
from ORDMMAPP.ord_area where AREA_CODE in (select lead_area from ORDMMAPP.bns_coa_run_list);

