SELECT AREA, LEAD_AREA, COA_FROM_DATE, COA_TYPE,
DECODE(
COA_TYPE ,
'OH','History tables',
'OR','Rate Tables',
'OG','General Ledger',
'OP','Portfolio Accounts',
'OA','Areas',
'OY','Cities',
'OC','Credit',
'LE','Lead COA',
'MI','MIS COA',
'PA','Portfolio Accounting',
'PO','Positons COA',
'CR','Credit',
'GL','General Ledger',
'EC','Echelle',
'OS','Security Settlements',
'OF','Futures MTM',
'Unknown='||COA_TYPE
) AS COA_TYPE_IN_PROGRESS
FROM ORD_AS WHERE
LEAD_AREA in (select lead_area from bns_coa_run_list)
AND COA_STATUS IS NULL
AND COA_FROM_DATE >= sysdate - 12
order by LEAD_AREA, AREA, COA_TYPE
