# -*- coding: utf-8 -*-
"""
Created on Sat Apr 13 16:13:08 2019
@author: jon
"""
import pandas as pd
import numpy as np 
import datetime as datetime
from datetime import timedelta
import warnings
from P_commons import to_sql_append, to_sql_replace, read_sql, type_convert, get_conn, tbl_nodupe_append, reg_convert
from R_stat import stat_VIEW
from R_plot import plot_base
from R_getdata import get_greeks, get_SI, get_FUN
from dateutil import parser
from termcolor import colored, cprint
from timeit import default_timer as timer
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
"""
    logic: risk control by delta (i_delta) and weigh( i_ip)
    var_id_max=cap * Max_loss_per_pos/ Buff_var_id
    delta_max=var_id_max/ var_id
    var_id= atr_hd * iv_hv
    ic_max_id= delta_max/ i_detla
    weigh_max= cap * weigh_per_pos
    ic_max_weigh= weigh_max/ i_ip
    i_ic@entry = min (ic_max_id, ic_max_weigh)
    update_op_CID: get_greeks for op_c, op_spec
"""
weigh_per_pos=0.05   
MAX_loss_per_pos=0.025
BUFF_var_id=3 
look_back=7  #update_op_CID('op_spec') & obmc_update_tbl_track
 # R: stop@ 3 std_daily
#%%    
def update_op_CID(q_date, tbl=''):
    """
    use: update CID table
    source: get_greeks(), tbl_oc, tbl_candy
    dest: op_c, op_spec
    """
    from R_getdata import get_greeks
    from datetime import timedelta
#    look_back=5
    print("get_CID: %s started"%tbl)
    start_time=timer()
    dt=read_sql("select * from tbl_oc where exit_dt ='N' ") 
    if tbl=='op_spec':
        do=read_sql("select * from tbl_candy where watch IS NULL ")
        do.rename(columns={'date':'candy_dt'}, inplace=True)
        do['candy_dt']=pd.to_datetime(do['candy_dt'])
        p_date=q_date - timedelta(look_back)
        con_lookback=do.candy_dt > p_date
        con_t= do.ticker.isin(dt.ticker)
        do=do[con_lookback & (~con_t)]
        dt=do
    lis=[]
    fail=[]
    list_cid=dt.cid.unique()
    for cid in list_cid:       
        try:
            g=get_greeks(cid)  
            lis.append(g)
        except:
            fail.append(cid)
    if len(fail)>1:
        cprint("get_CID:%s,  get_greeks failed tickers: %s"%(tbl, fail),'red')
    df=pd.DataFrame(lis)
    df['o_dt']=pd.to_datetime(df['o_dt'])
    df['date']=q_date
    df['time']=datetime.datetime.now().strftime('%H:%M:%S')
    col_val=['p','bid','ask','sale','sale_prev', 'o_oi','o_vol','delta','theta','vega','gamma']
    df=reg_convert(col_val, df, 'float')
    if tbl=='op_spec':
        df['ticker']=df['cid'].str.split('-').str[0]
    tbl_nodupe_append(q_date, df, tbl)
    end_time=timer()
    print("time: ", end_time-start_time)
    return df
#%%
def candy_update(q_date):
    """
    use: update tbl_candy_update from op_spec: mp=mid_point, only 'watch' is NULL
    source: tbl_candy, op_spec, lookback <no new data>
    ext_source: no
    dest:tbl_obmc_track
    """
    print("candy_update started")
    from datetime import timedelta
    from R_getdata import get_EARN
#    look_back=5
    dc=read_sql("select * from tbl_candy where watch IS NULL")
#    dc.rename(columns={'date':'candy_dt'}, inplace=True)
    dc['candy_dt']=dc['date']
    dc['candy_dt']=pd.to_datetime(dc['candy_dt']).dt.date
    dc['oexp_dt']=pd.to_datetime(dc['oexp_dt']).dt.date
    p_date=q_date - timedelta(look_back)
    con_lookback=dc['candy_dt'] > p_date
    con_oexp= dc['oexp_dt'] > q_date
    dc=dc[con_lookback & con_oexp]
    do=read_sql("select * from op_spec")
    do['o_dt']=pd.to_datetime(do['o_dt'])
    do=do[do.o_dt==q_date]
    do['mp']=(do['bid']+do['ask'])*0.5
    # p from op_spec (for daily non-candy update p)
    dc.drop('p', axis=1, inplace=True)
    df=dc.merge(do[['cid','mp','o_oi','o_vol', 'p', 'o_dt']])
    tbl_nodupe_append(q_date, df, 'tbl_candy_update')
    return df
#%%    
def candy_track(q_date):
    """
    use: rule-based filter candy list on entry_signal (lcp, scp, covl, covp)
    source: tbl_candy_update, tbl_obc_raw, 
    dest:   
    """
    from datetime import timedelta
    from P_commons import type_convert
    from R_getdata import get_FUN, get_SI
    from P_commons import get_conn
#    look_back= 5
    # all tid from bc_raw
    o_oi_i_chg_min=1000  #min impact on oi_chg from vol>1500, or is wash if new trade
    bet_bc_raw_min=50000
    bargain_min= -0.55
    mp_max= 3
    dte_min= 10
    #filter 
    o_vol_min=300  #min o_vol
    o_vol_2_oi_chg_max =3  #min vol impact on oi_chg
    o_oi_i_chg_pct_add_min= 0.2
    o_oi_i_chg_pct_cut_min= -0.3 
    
    dt=read_sql("select * from tbl_candy_update")
    dt['candy_dt']=pd.to_datetime(dt['candy_dt']).dt.date
    dt['oexp_dt']=pd.to_datetime(dt['oexp_dt']).dt.date
    dt['o_dt']=pd.to_datetime(dt['o_dt']).dt.date
    lbk_date=q_date - timedelta(look_back)
    dt=dt[dt.candy_dt >lbk_date]
    dt['tid']=dt['cid']+ '-' + dt['candy_dt'].apply(lambda x: x.strftime('%y%m%d'))
    # prepare bc_raw for concat data 
    dbc=read_sql("select * from tbl_obc_raw")
    dbc['date']=pd.to_datetime(dbc['date'])
    dbc['oexp_dt']=pd.to_datetime(dbc['oexp_dt'])
    dbc['dte']=dbc['dte'].astype(float)
    dbc=dbc[dbc.date>lbk_date]
    dbc['tid']=dbc['cid']+ '-' +dbc['date'].apply(lambda x: x.strftime('%y%m%d'))
    con_bet=dbc.bet>bet_bc_raw_min
    con_oexp=dbc.oexp_dt>q_date
    dbc=dbc[con_bet & con_oexp & dbc.dte>dte_min]
    set_dt=set(dt.columns.tolist())
    set_bc=set(dbc.columns.tolist())    
    col_share=list(set_dt & set_bc)
#   update @cid level
    df=pd.DataFrame()
    list_cid=dt.cid.unique()
    for cid in list_cid:
    #candy_dt from tbl_candy, date for tbl_bc_raw, o_dt for greeks udpate timing
        dg=dt[dt.cid==cid]
        dg.sort_values('o_dt', inplace=True)
        #o_oi_i_chg: last day (not incl. impact from o_vol@q_date) vs, 2nd day o_oi (ie. o_oi after un_op)
        # if dg.shape=2 then oi_i_chg=0
        #'o_oi_i_chg' is used for beachmark thus enforced a fixe value into a columns
        o_oi_i_chg=dg['o_oi'].tail(1).values[0]-dg['o_oi'].head(1).values[0] 
        o_oi_i_chg_pct =o_oi_i_chg /dg['o_oi'].head(1).values[0]
        dg['o_oi_i_chg']=o_oi_i_chg
        dg['o_oi_i_chg_pct']=o_oi_i_chg_pct
        dg['o_oi_chg']=dg['o_oi'].shift(-1)- dg['o_oi']
        #assess vol to oi_chg percent
        dg['o_vol_2_oi_chg']=dg['o_vol']/dg['o_oi_chg']
        dg['mp_p_chg']=dg['mp']-dg['mp'].shift(1)
        mp_i_chg_pct=(dg['mp'].tail(1).values[0]-dg['mp'].head(1).values[0])/ \
                (dg['mp'].head(1).values[0]) 
        dg['mp_i_chg_pct']=mp_i_chg_pct
        dg['up_cnt']=dg[dg['mp_p_chg']>0].shape[0]
        dg['dn_cnt']=dg[dg['mp_p_chg']<0].shape[0]
        dg['cnt']=dg.shape[0]
        p_i_chg_pct=(dg['p'].tail(1).values[0]/dg['p'].head(1).values[0])-1
        dg['p_i_chg_pct']=p_i_chg_pct
        #when new trade has rsi
        dg['rsi_i_chg']=dg['rsi'].tail(1).values[0]-dg['rsi'].head(2).tail(1).values[0] 
        dg['hv_i_chg']=dg['hv_22'].tail(1).values[0]-dg['hv_22'].head(2).tail(1).values[0] 
        #exclude wash candy from y'day
        if (dg.shape[0]==2) & (o_oi_i_chg <o_oi_i_chg_min):
            dg['watch']='N'
        else:
            dg['watch']=np.NaN
        watch=dg['watch'].head(1).values[0]
        #merge dbc_raw on tid basis
        dbc_g=dbc[dbc.ticker.isin(dg.ticker) & ~(dbc.tid.isin(dg.tid))]
        dbc_g=dbc_g[col_share]
        dbc_g['o_oi_i_chg']= o_oi_i_chg
        dbc_g['o_oi_i_chg_pct']= o_oi_i_chg_pct
        dbc_g['mp_i_chg_pct']=mp_i_chg_pct
        dbc_g['p_i_chg_pct']=p_i_chg_pct
        dbc_g['watch']=watch
        df=pd.concat([df,dg, dbc_g], axis=0)
# FILTER: EXclude NO_WATCH tid   
    # exclude:  o_vol_min, impact on  o_oi or new trade
    con_o_vol=df['o_vol']> o_vol_min
    con_o_vol_2_oi_chg=np.abs(df['o_vol_2_oi_chg'])<o_vol_2_oi_chg_max  # vol has impact on oi_chg
    con_new= (df['o_dt']==df['candy_dt']) #not the q_date (as oi is missing)
    con_q_date=df['o_dt']==q_date
    CON_in=(con_o_vol & con_o_vol_2_oi_chg)| con_new | con_q_date
    df_0=df.sort_values('o_dt')
    df=df_0[CON_in]
    df_no_watch=df_0[~CON_in]
    df_no_watch['watch']='N'
# update tbl_candy with 'watch' filed
    watch_list=df_no_watch.tid.unique().tolist()
    if len(watch_list)>0:
        conn = get_conn()
        cursor = conn.cursor()
        for w in watch_list:
            cursor.execute("UPDATE tbl_candy SET watch='N' WHERE tid='%s' "%w )
        conn.commit()
        conn.close()    
    #no dupe 'uid'???
    df.drop_duplicates(['tid'], keep='first', inplace=True)
    col_sort=[ 'o_oi_i_chg_pct','mp_i_chg_pct', 'tid','o_dt']
    col_asc=[0, 0, 1,1]
    df.sort_values(col_sort, ascending=col_asc,  inplace=True)
    #Entry_singal_op: mp_up, oi_up
    con_oi_up=df.o_oi_i_chg>=0
    con_mp_up=df.mp_i_chg_pct>0
    #Entry_signal_ticker: 
    con_p_up=df.p_i_chg_pct>0
    con_rsi_up=df.rsi_i_chg>0
    con_hv_up =df.hv_i_chg>0    #hv expand
    con_c=df.type=='Call'
    con_p=df.type=='Put'

    con_cov_loss=(~ con_oi_up) & con_mp_up
    con_cov_prof= (~ con_oi_up) & (~ con_mp_up)
    con_lc=con_oi_up & con_mp_up & con_c & con_p_up #& con_rsi_up & con_hv_up
    con_lp=con_oi_up & con_mp_up & con_p & (~ con_p_up) #& (~ con_rsi_up) & con_hv_up
    con_sc= ( con_oi_up) & (~ con_mp_up) & con_c# & (~ con_rsi_up)
    con_sp= ( con_oi_up) & (~ con_mp_up) & con_p #& con_rsi_up
    df.loc[con_lc, 'e_sig']='lc'
    df.loc[con_lp, 'e_sig']='lp'
    df.loc[con_sc, 'e_sig']='sc'
    df.loc[con_sp, 'e_sig']='sp' 
    
    df['date']=q_date
    df=prob_o(df, q_date)
    
    df_orig=df.sort_values('cid')
    col=['cid','bs', 'dte', 'earn_dt', 'mp_i_chg_pct', 'o_dt', \
         'o_oi_i_chg_pct', 'o_oi_i_chg','o_vol_2_oi_chg', \
         'o_vol', 'o_oi_chg',  'bet', 'iv','atm', 'iop_p',\
         'p_i_chg_pct', 'iop','mp', 'why', 'e_sig','prob', 'sig_dte'] 
    col_why=['why', 'hv_rank','iv_hv', 'fm_200', 'fm_50', 'fm_hi','fm_lo']
    show_why=['ioc','iop','bet','dte','atm','cid','bs', 'why', 'hv_rank','iv_hv', 'fm_200', 'fm_50', \
          'fm_hi','fm_lo',  'earn_dt', 'spike', 'iv_chg','rtn_22_pct']
    df=df[col]
    con_why=pd.notnull(df.why)
    why=df[con_why]
    lcw=df[con_lc & con_why]
    lc=df[con_lc & (~con_why)]
    lpw=df[con_lp & con_why]
    lp=df[con_lp & (~con_why)]
    scw=df[con_sc & con_why]
    sc=df[con_sc & (~con_why)]
    spw=df[con_sp & con_why]
    sp=df[con_sp & (~con_why)] 
    cov_loss=df[con_cov_loss]
    cov_prof=df[con_cov_prof]
    #bargain
    con_barg=(df.dte> dte_min) & (df.mp_i_chg_pct < bargain_min) & (df.mp< mp_max)
    barg=df[con_barg]
    
    tbl_nodupe_append(q_date, df_orig, 'tbl_candy_track')    
    return why, lcw, lpw, scw, spw, lc, lp, sc, sp, cov_loss, cov_prof, barg, df_orig

#%%
def update_tbl_cid(q_date):
    """
    use: tbl_cid: cacl mp, then snapshot of pl, risk per cid @q_date, mp=(mid, sale)
    source: op_c, cacl_tbl_cid
    """
    df=read_sql("select * from op_c")
    df['o_dt']=pd.to_datetime(df['o_dt'])
    dict_list=[]
    for cid in df.cid.unique():
        dg=df[df.cid==cid]
        dg.sort_values('o_dt', inplace=True)
        i_delta=dg['delta'].head(1).values[0]
        delta_i_chg=dg['delta'].tail(1).values[0]-i_delta
        delta_p_chg=dg['delta'].tail(1).values[0]-dg['delta'].tail(2).head(1).values[0]
        i_vega=dg['vega'].head(1).values[0]
        vega_i_chg=dg['vega'].tail(1).values[0]-i_vega
        vega_p_chg=dg['vega'].tail(1).values[0]-dg['vega'].tail(2).head(1).values[0] 
        o_oi_chg=dg['o_oi'].tail(1).values[0]-dg['o_oi'].tail(2).head(1).values[0] 
#        o_oi_chg=dg['o_oi'].shift(-1)- dg['o_oi']
        o_oi_chg_pct=(dg['o_oi'].tail(1).values[0]/dg['o_oi'].tail(2).head(1).values[0])-1 
        o_oi_i_chg =dg['o_oi'].tail(1).values[0]-dg['o_oi'].head(2).tail(1).values[0] 
        o_oi_i_chg_pct =o_oi_i_chg /dg['o_oi'].head(2).tail(1).values[0]
        o_vol=dg['o_vol'].tail(1).values[0]
        delta=dg['delta'].tail(1).values[0]
        theta=dg['theta'].tail(1).values[0]
        gamma=dg['gamma'].tail(1).values[0]
        vega=dg['vega'].tail(1).values[0]
        bid=dg['bid'].tail(1).values[0]
        ask=dg['ask'].tail(1).values[0]
        sale=dg['sale'].tail(1).values[0]
        o_oi=dg['o_oi'].tail(1).values[0]
        keys=['cid', 'delta' ,'gamma', 'vega', 'theta',  'delta_i_chg', 'delta_p_chg', \
            'vega_i_chg', 'vega_p_chg', 'o_oi_chg', 'o_vol','bid','ask','sale','o_oi',\
            'o_oi_chg_pct', 'o_oi_i_chg', 'o_oi_i_chg_pct' ]
        vals=[cid, delta ,gamma, vega, theta, delta_i_chg, delta_p_chg, \
            vega_i_chg, vega_p_chg, o_oi_chg, o_vol, bid, ask, sale, o_oi,\
            o_oi_chg_pct, o_oi_i_chg, o_oi_i_chg_pct]     
        dic=dict(zip(keys, vals))
        dict_list.append(dic)
    dx=pd.DataFrame(dict_list)
    
    dp=calc_tbl_cid()
    df=dx.merge(dp, on='cid',how='outer')
#    con_mp=(df['o_vol']>0) & (df['ask']>df['sale']) & (df['bid']<df['sale'])
    con_lc=df['lc']>0
    df.loc[con_lc, 'mp']=df['bid']
    df.loc[~con_lc, 'mp']=df['ask']
#    df.loc[con_mp & con_lc, 'mp']=df['bid']
#    df.loc[(~con_mp) & con_lc, 'mp']=df['bid']
#    df.loc[(~con_mp) & (~con_lc), 'mp']=df['ask']   
    
#pl, risk calculation
    df['pl_ur']=(df['mp']-df['lp'])*df['lc']*100
    df['pl']=df['pl_r']+df['pl_ur']-df['comm_c'].astype(float)
    df['pl_ur_pct']=df['mp']/df['lp']-1
    df['pl_ur_pct']=(df['mp']/df['lp']-1)*(df['lc']/np.abs(df['lc']))
    df['risk_live']=df['lc']*df['mp']*100
    df['delta_c']=df['delta']* df['lc']*100
    df['vega_c']=df['vega']* df['lc']*100
    df['theta_c']=df['theta']* df['lc']*100
    df['date']=q_date
    tbl_nodupe_append(q_date, df, 'tbl_cid')
    return df
#%%        
def calc_tbl_cid():
    """
    use: called by update_tbl_cid() to cacl pl_r, lc, lp, comm_c
    intel: pl_r change at each cacl, but key is pl_all. pl_r has no comm
    """
    dt=read_sql("select * from tbl_oc")
    #trd only, combine U later
    con_unop= dt['pid'].str[:1]=='U'
    du=dt[con_unop]
    dc=dt[~ con_unop]
    dc.sort_values('uid',axis=0, inplace=True)
    dict_list=[]
    for cid in dc.cid.unique():
        df=dc[dc.cid==cid] #contain trde history per cid
        df_ic=df[df.ioc>0]
        if not df_ic.empty:
            sum_ic=df_ic.ioc.sum()
            prem_ic=(df_ic['ioc']*df_ic['iop']).sum()
            avg_ic=prem_ic/ sum_ic
        else:
            sum_ic=0
            prem_ic=0
            avg_ic=0
        
        df_oc=df[df.ioc<0]
        if not df_oc.empty:
            sum_oc=np.abs(df_oc.ioc.sum())
            prem_oc=(df_oc['ioc']*df_ic['iop']).sum()   
            avg_oc=prem_oc/ sum_oc
        else:
            sum_oc=0
            prem_oc=0
            avg_oc=0
        
        lc=df['ioc'].sum()
        comm=df['comm'].sum()
        if lc>0: # bought more than sold
            lp= avg_ic
            pl_r=sum_oc *( avg_oc - avg_ic)*100
        else:
            lp= avg_oc
            pl_r=sum_ic *( avg_ic - avg_oc)*100
        keys=[ 'cid', 'lc', 'lp', 'pl_r','comm_c']
        vals=[ cid, lc, lp, pl_r, comm]
        dic=dict(zip(keys, vals))
        dict_list.append(dic)
    df=pd.DataFrame(dict_list)
    con_pl_r=pd.isnull(df['pl_r'])
    df.loc[con_pl_r, 'pl_r']=0
    return df
#%%
def o_pre_spec(q_date, spec='[]'):
    """
    td: add plot_all, get_news etc.
    use: enrich cid ('why', 'e_sig') for q_date with FUN,SI to manual view
    source: tbl_candy_track
    dest: 
    """
    look_back=10
    vol_bc_min=1500
    prem_min=0.2
    prem_max=5
    
    df=read_sql("select * from tbl_candy_track")
    df['date']=pd.to_datetime(df['date'])
    # TRACK spec_why * e_sig
    ds=df[df.date == q_date]
    con_e_sig=pd.notnull(df.e_sig)
    #    con_why_sig=pd.notnull(df.why) 
    df=df[con_e_sig]
    df.sort_values(['cid', 'date'], inplace=True)
#    ds.drop_duplicates('cid', keep='first', inplace=True)
    list_spec=df.ticker.unique().tolist()
    
    if len(list_spec)>0:
        for t in list_spec:
            try:
                fun_col=['beta','pe','ta','eg']
                FUN=get_FUN(t)  
                for k in fun_col:
                    df.loc[df.ticker==t, k]=FUN[k]
            except:
                for k in fun_col:
                    df.loc[df.ticker==t, k]=0
            try:
                si_col=['si']
                SI=get_SI(t)  
                for k in si_col:
                    df.loc[df.ticker==t, k]=SI[k]
            except:
                for k in si_col:
                    df.loc[df.ticker==t, k]=0
    #SPEC e_sig & why
    con_why=pd.notnull(df.why)
    dsw=df[con_why]
    #TRACK e_sig & no_why
    ds=df[~ con_why]
    col=['cid','bs', 'dte', 'earn_dt', 'mp_i_chg_pct', 'o_dt', \
         'o_oi_i_chg_pct', 'o_oi_i_chg','o_vol_2_oi_chg', \
         'o_vol', 'o_oi_chg',  'bet', 'iv','atm', 'iop_p',\
         'p_i_chg_pct', 'iop','mp', 'ta', 'si','why', 'e_sig'] 
    return dsw, ds

#%%
def o_spec(q_date, spec_list=[]): 
    '''
    data_src: tbl_candy_track
    data_dest:tbl_spec_candy
    sub_func: stat_VIEW    
    '''
    lookback=10

    
    
    spec_list=[x.upper() for x in spec_list]
    p_date=q_date-datetime.timedelta(lookback)
    if len(spec_list)==0:
        print("empty spec_list")
        return
    df=read_sql("SELECT * FROM tbl_candies where date>='%s'"%p_date, q_date)
    df=df[df.ticker.isin(spec_list)]
    #if same ticker multi-occurence, keep the latest date
    df.sort_values(['ticker','date'], ascending=[True, False], inplace=True)
    df.drop_duplicates('ticker', keep='first',inplace=True)
   #update with lastest stat_VIEW 
    ds=stat_VIEW(q_date, spec_list, 'update') 
    col_ds=ds.columns.tolist()
    col_df=df.columns.tolist()
    col_nds=list(set(col_df)-set(col_ds))+['ticker']
    df_nds=df[col_nds]
    df=pd.merge(df_nds, ds, how='outer', on='ticker')
    #extra field for flask_candy input & 
    scm_t_spec=read_sql("select * from tbl_spec_candy").columns
    col_extra=list(set(scm_t_spec)-set(df.columns))
    for x in col_extra:
        df[x]=np.nan
    df.drop('index',axis=1, inplace=True)
    scm_t_spec=df.columns.tolist()
    df=df[scm_t_spec]
    df['date']=q_date
    df['i_delta']=0
    df['i_ic']=0
    df['i_ip']=0
    to_sql_append(df,"tbl_spec_candy")
    print("tbl_spec_cany appended  %s: %s "%(q_date, df.ticker.tolist()))
    pd.set_option('display.expand_frame_repr', False)
    pd.options.display.float_format = '{:.1f}'.format
    show_spec=['ticker','sec', 'type','dte','spike', 'iv_chg', 'rtn_22_pct', 'iv_hv', \
            'hv_rank', 'beta', 'pe','yld', 'si', 'close','strike','oexp_dt',\
            'earn_dt','div_dt','sig_dte', 'rsi','fm_50']
    print(df[show_spec].to_string(index=False))
    pd.set_option('display.expand_frame_repr', True)
    return df

def re_spec(q_date):
    '''
    use: calc i_ic_max after flask_spec
    source: tbl_spec_candy, tbl_act
    dest: tbl_spec_candy
    '''

    df_act=read_sql("select * from tbl_act")
    Cap_IBQ=df_act[df_act.act=='IBQ'].cap.values[0]
    df=read_sql("SELECT * FROM tbl_spec_candy where date>='%s'"%q_date)
    flask_val=['i_delta', 'i_ip', 'i_ic']
    for x in flask_val:
        df[x]=df[x].replace('',0).astype(float)
    #data validation & input as spec_track needs i_delt to track
    dr=read_sql("select * from tbl_risk")
    con_lsnv= df['lsnv'].isin(['L','S','N','V','LN','SN']).all()
    con_play= df['play'].isin(dr.play.tolist()).all()
    man_val=['i_delta','i_ip']
    if  not ( con_lsnv & con_play):
        print("trade_entry: lsnv or play not in list")
        return    
    elif (df[man_val]==0).any(axis=1).values[0]:
        print("trade_entry: mandtory input: %s"%man_val)
        return
    
    df_val=['iv_hv','atr_hd']
    df=type_convert(df, df_val)
    #solve previous data issue
    con_iv_hv=df['iv_hv']<0.03
    df.loc[pd.isnull(df['iv_hv']),'iv_hv']=1
    df.loc[con_iv_hv,'iv_hv']=df['iv_hv']*100
    df['iv_hv']=df['iv_hv'].clip(1,1)
    #end
    
    var_id_max=Cap_IBQ * MAX_loss_per_pos/BUFF_var_id
    var_id=df['iv_hv']*df['atr_hd']
    delta_max=var_id_max/var_id
    ic_max_id=delta_max/df['i_delta']
    weigh_max= Cap_IBQ* weigh_per_pos
    ic_max_weigh=weigh_max/ (df['i_ip']*100)
    df['i_ic']=np.minimum(ic_max_id, ic_max_weigh)
    df.loc[df.i_ic==np.inf, 'i_ic']=0
    conn=get_conn()
    cur=conn.cursor()
    for index, row in df[pd.notnull(df.i_ic)].iterrows():
        values=[ int(row['i_ic']), row['ticker'], q_date ]
        cur.execute("update tbl_spec_candy set i_ic=? where ticker=? and date=?", values)
        conn.commit()
        print("re_spec: i_ic updated for %s"%row['ticker'] )
    conn.close()
    return df
    
def spec_track(q_date):
    '''
    USE: entry signal of spec_candy in past 5 days
    source: tbl_spec_candy, tbl_oc, tbl_stat_sec
    sub_f: stat_VIEW
    use: entry_signal for spec candies in past 5 days
    intel: 
        direction: i_delta vs (rsi_chg, close_chg, rtn_5_chg, srtn_22_chg)
        spike > spike_min
        hv: i_play vs. hv_chg
        stk_vol?
    '''
    look_back=10
    spike_min=1
    hv_chg_min=0.25
    
    p_date=q_date - datetime.timedelta(look_back)
    df=read_sql("SELECT * FROM tbl_spec_candy", q_date)
    df['date']=pd.to_datetime(df['date'])
    df=df[df.date>p_date]
    #exclude live trade
    dt=read_sql("SELECT * FROM tbl_oc", q_date)
    list_track=list(set(df.ticker) - set(dt.ticker))
    df=df[df.ticker.isin(list_track)]
    df.sort_values('date', inplace=True)
    df.drop_duplicates('ticker', keep='last', inplace=True)
#entry_signal
    #delta vs. p_chg, rsi_chg
    col_spec=['i_delta','i_play','i_ic','i_ip','note','si','sig_dte','sec','pe','yld',\
              'earn_dt','div_dt','iv','i_lsnv','date']
    col_rn=['ticker', 'atr_hd', 'atr_hv', 'close', 'hv_22','rsi','rtn_5_pct', \
            'srtn_22_pct','spike']
    col_rnto=['ticker', 'i_atr_hd', 'i_atr_hv', 'i_close','i_hv_22', 'i_rsi',\
              'i_rtn_5_pct', 'i_srtn_22_pct','i_spike']
    df.rename(columns=dict(zip(col_rn, col_rnto)), inplace=True)
    df=df[col_rnto + col_spec]
    ds=stat_VIEW(q_date, df.ticker.tolist())
    dt=df.merge(ds[col_rn], on='ticker')
    #update srtn_22_pct for non-sp ticker
    ds_etf=read_sql("select * from tbl_stat_sec")
    ds_etf=ds_etf[ds_etf.date==ds_etf.date.max()]
    for index, row in dt[pd.isnull(dt.srtn_22_pct)].iterrows():
        dt.loc[index,'srtn_22_pct']=ds_etf.loc[ds_etf.ticker==row['sec'].upper(), 'rtn_22_pct'].values[0]
    
    vals=['i_delta','rsi','i_rsi','hv_22','i_hv_22', 'rtn_5_pct', 'i_rtn_5_pct',\
          'close','i_close','srtn_22_pct','i_srtn_22_pct', 'atr_hv', 'i_atr_hv']
    dt[vals].fillna(0, inplace=True)
    dt=type_convert(dt, vals, 'float')
    # direction
    dt['rsi_chg']=dt['rsi']- dt['i_rsi']
    dt['close_chg']=dt['close']-dt['i_close']
    dt['rtn_5_chg']=dt['rtn_5_pct']-dt['i_rtn_5_pct']
    dt['srtn_22_chg']=dt['srtn_22_pct']-dt['i_srtn_22_pct']
    dt['hv_chg']=dt['hv_22']/dt['i_hv_22']-1

    col_ls=['rsi_chg','close_chg','rtn_5_chg','srtn_22_chg']
    con_l=(dt[col_ls]>=0).all(axis=1)
    con_s=(dt[col_ls]<=0).all(axis=1)
    con_L=(dt['i_delta']>0) & (dt['rsi_chg']>=0) & (dt['close_chg']>=0) & (dt['rtn_5_chg']>=0)& (dt['srtn_22_chg']>=0)
    con_S=(dt['i_delta']<0) & (dt['rsi_chg']<=0) & (dt['close_chg']<=0) & (dt['rtn_5_chg']<=0)& (dt['srtn_22_chg']<=0)
    
    con_spike=dt['spike']>spike_min
    con_hv=( np.abs(dt['hv_chg'])> hv_chg_min) & (dt['i_lsnv']=='V')
# stk_vol chg    
    dt.loc[con_l,'alert']='l'
    dt.loc[con_s, 'alert']='s'
    dt.loc[con_L,'alert']='L'
    dt.loc[con_S, 'alert']='S'
    dt.loc[con_spike,'alert']='Spike'
    dt.loc[con_hv, 'alert']='vol'
    
    show=['ticker','alert', 'i_lsnv', 'date','spike', 'i_play','i_delta','close_chg','rsi_chg','rtn_5_chg','srtn_22_chg','hv_chg','earn_dt','div_dt','sec','note']
    dt=dt[show]
    pd.set_option('display.expand_frame_repr', False)
    print(dt)
    pd.set_option('display.expand_frame_repr', True)
    print("spec_track entry_signal:  %s days plot "%look_back)
    plot_base(q_date, dt.ticker.unique(),dt)
    return dt

def otrade_candy(q_date, trade_list=['']):
    '''
    USE: prep data for flask update (must be from tbl_spec_candy)
    source: tbl_spec_candy
    dest: tbl_otrade_candy (replace)
    sub_f: o_flask input (raw only)
    unique id: pid+cid
    @trd_flask: unique_id +date
    '''
    trade_list=[x.upper() for x in trade_list]
    df=read_sql("SELECT * FROM tbl_spec_candy", q_date)
    df=df[df.ticker.isin(trade_list)]
    df['date']=pd.to_datetime(df['date'])
    df.sort_values(['ticker','date'], ascending=True, inplace=True)
    #keep lastest ticker
    df.drop_duplicates('ticker', keep='last',inplace=True)
    df.drop('index', axis=1, inplace=True)
    # add schema_flask, only need 'ticker' from tbl_spec_candy
    #['act','pid','type','strike','exp_dt','strike','ioc','iop','play']
    #schema_greeks
    #[]
    
    df['type']='P'
    df['pid']='T1'
    df['act']='IBQ'
    df['exit_dt']='N'
    df['ioc']=0
    df['iop']=0
    df['comm']=0
    df['play']='CAL'
    df['cid']=0
    df['entry_dt']=q_date
    #construct unique id for flask eidt/delete
    #rebuld cid/uid

    df['uid']=df['ticker']+df['oexp_dt']+df['type']+df['strike'].astype(str)+df['pid']+df['entry_dt'].astype(str)
    if df.empty:
        print ("trade_candy: not in tbl_spec_candy")
        return
    
    to_sql_replace(df,"tbl_otrade_candy")
    return df
    """
    list_trade= df.ticker.tolist()
    ds=stat_VIEW(q_date, list_trade) 
    col_ds=ds.columns.tolist()
    col_df=df.columns.tolist()
    col_nds=list(set(col_df)-set(col_ds))+['ticker']
    df_nds=df[col_nds]
    df=pd.merge(df_nds, ds, how='left', on='ticker')   
    df['date']=q_date
    df.drop('index',axis=1, inplace=True)
    scm_t_spec=df.columns.tolist()
    col_rn=['close','iv','hv_22','rtn_22_pct','srtn_22_pct', 'strike','hv_rank','iv_hv']
    col_rnto=['entry_p','i_iv','i_hv_22','i_rtn_22_pct','i_srtn_22_pct',\
              'strik','i_hv_rank','i_iv_hv']              
    df.rename(columns=dict(zip(col_rn, col_rnto)), inplace=True)
    col_df=df.columns.tolist()
    df_trade=read_sql("SELECT * FROM tbl_oc")
    scm_t_trade=df_trade.columns.tolist()
    col_flask=list(set(scm_t_trade)- set(col_df))
    df_extra=pd.DataFrame(columns=col_flask, index=df.index)
    dc=pd.concat([df, df_extra], axis=1)
    scm_t_trade_candy=dc.columns.tolist()
    flask_val=['ic1','ip1','ic2','ip2','oc1','op1','oc2','op2',\
        'mp','comm','tgt_p','delta','vega','beup','bedn','strike']
    flask_dt=['entry_dt', 'tgt_dt']
    dc['act']='IBQ'
    dc[flask_val]=0
    dc[flask_dt]=q_date
    dc['exit_dt']='N'
    dc['tgt_p']=0
    """

def otrade_entry(q_date):
    """
    USE: after candy@flask update
    0. construct cid (CID unique for get_greeks, PID+CID unique for P&L)
    1. append to op_trd, and get_GREEK
    2. then validate input and append to tbl_oc with greeks, pre_filled 
    source:
    dest:
    sub_f:
    """
    df=read_sql("SELECT * FROM tbl_otrade_candy", q_date)
    #construct CID from entry@flask
    oexp_dt=pd.to_datetime(df['oexp_dt']).dt.strftime('%y%m%d')
    strike=strike=df['strike'].apply(lambda x: str(int(x *1000)).rjust(8,'0'))
    df['cid']=df.ticker+ '-' + oexp_dt+df.type+strike
    col_c=['act','ticker','type','strike','oexp_dt','cid', 'pid','date','entry_dt','ioc','iop',\
           'comm','play','exit_dt']
   
    dc=df[col_c]
    dc['exit_dt']='N'
    dc.rename(columns={'date':'s_dt'}, inplace=True)  #preserve spec_date for initial entry only
    dc['date']=q_date
    dc['uid']=dc['cid']+ dc['pid'] + dc['entry_dt']
    to_sql_append(dc, 'tbl_oc')
#    tbl_nodupe_append(q_date, dc, 'tbl_oc')
    return dc
 #%%   
def o_track_new(q_date):
    """
    after o_update_greek: append to op_c (after flask_trd update)
    1. update tbl_cid: greeks@cid
    2. update tbl_cid: pl, risk@cid (source: op_c)
    3. update tbl_track: pl, risk, alert, stat@ticker
    4. view_pid
    """
    update_op_c(q_date)
    update_tbl_cid(q_date)
#%%    
def prob_o(df, q_date):  
    import scipy.stats
    con_lc=(df.bs=='b') & (df.type=='Call')
    con_sc=(df.bs=='s') & (df.type=='Call')
    con_lp=(df.bs=='b') & (df.type=='Put')
    con_sp=(df.bs=='s') & (df.type=='Put') 
    df.loc[con_lc, 'bedn']=df.loc[con_lc, 'strike'] + df.loc[con_lc, 'iop']
    df.loc[con_sc, 'beup']=df.loc[con_sc, 'strike'] + df.loc[con_sc, 'iop']
    df.loc[con_lp, 'beup']=df.loc[con_lp, 'strike'] - df.loc[con_lp, 'iop']
    df.loc[con_sp, 'bedn']=df.loc[con_sp, 'strike'] - df.loc[con_sp, 'iop']
    
    con_iv=pd.isnull(df.iv)
    df.loc[con_iv, 'iv']=df.loc[con_iv, 'civ']
    df['oexp_dt']=pd.to_datetime(df['oexp_dt'])
    df['dte']=df['oexp_dt'].subtract(q_date).dt.days
    df['std']=df['iv']*np.sqrt(df['dte']/252)
    df=type_convert(df, ['p','std'])
    for index, row in df.iterrows():
        std_p=row['p']*row['std']
        if row['beup']>0:
            df.loc[index, 'prob']=scipy.stats.norm.cdf(row['beup'], row['p'], std_p)
        elif row.bedn>0:
            df.loc[index, 'prob']=scipy.stats.norm.sf(row['bedn'], row['p'], std_p)
        else:
            pass
    df['prob']=df['prob'].apply(lambda x: "{0:.0f}%".format(x*100))
    return df
