# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 12:18:13 2017

Purpose: genearte play_list
Functions:
    1. play_run_daily
    2. play_run  # save to DB
    3. play_view   #save to csv. not db
    4. feature_view
    5. get_column
    6. ml_apply  (apply algo for ETF ML trade)

Imported:
    1. stat_run
@author: jon
"""

import pandas as pd
import numpy as np 
import datetime as datetime
import scipy.stats as stats
import sqlite3 as db
import pandas_datareader.data as web
from pandas.tseries.offsets import BDay
from timeit import default_timer as timer
#Import functions
from P_commons import to_sql_append, to_sql_replace, read_sql
from P_stat import stat_run_new#, stat_run
from P_intel import get_earning_date, get_rsi, get_tsm
todate=datetime.date.today()
LBdate=(todate-BDay(1)).date()

capital=22000
DF_sp500=pd.read_csv('c:\\pycode\pyprod\constituents.csv')
df_etf=pd.read_csv('c:\\pycode\pyprod\etf.csv')
df_sp500=DF_sp500.ix[:,0] #serie
df_etf=df_etf.ix[:,0]

def play_run_daily(q_date, underlying, env='prod'):
    if env=='prod':
        stat_run_new(q_date,underlying, 'prod')
        df_play=play_run(q_date, underlying, 'prod')
        stime=timer()
        df_play=play_view(df_play)
        print("play_run minutes used :", (timer()-stime)/60)
        df_play.to_csv('c:\\pycode\playlist\playlist_%s_%s.csv'%(underlying, q_date))  
    elif env=='test':
        stat_run_new(q_date, underlying, 'test')
        df_play=play_run(q_date, underlying, 'test')
        df_play=play_view(df_play)
        df_play.to_csv('c:\\pycode\pytest\playlist_%s_test_%s.csv'%(underlying, q_date))  
    else:
       print("play_run_daily miss env or underlying")  
    print("----  %s %s---play_run_daily completed"%(underlying,env))
    return df_play
    
#in:tbl_stat_hist / out:tbl_play_hist
def play_run(q_date, underlying, env='prod'): #qdate - date of running this, latest date
    df_temp=pd.DataFrame()
    df=pd.DataFrame()
    df_prev=pd.DataFrame()  #store last df_play
    dd=pd.DataFrame()
    if env=='prod':
        
        if underlying=='sp500':
            df_playbook=pd.read_excel(open('c:\\pycode\pyprod\playbook.xlsx','rb'), sheetname='plays')
            qry="SELECT * FROM tbl_play"
            df_prev=read_sql(qry, todate)
            
        elif underlying=='etf':
            df_playbook=pd.read_excel(open('c:\\pycode\pyprod\playbook.xlsx','rb'), sheetname='plays_etf')
            qry="SELECT * FROM tbl_play_etf"
            df_prev=read_sql(qry, todate)
    elif env=='test':
        if underlying=='sp500':
            df_playbook=pd.read_excel(open('c:\\pycode\pytest\playbook_test.xlsx','rb'), sheetname='plays')
        elif underlying=='etf':
            df_playbook=pd.read_excel(open('c:\\pycode\pytest\playbook_test.xlsx','rb'), sheetname='plays_etf')
    else:
        print ("play_run() missing env or underlying")
        exit
    conn=db.connect('c:\\pycode\db_op.db')
   
    try:        
            df_temp=read_sql(query, conn) #because tbl_stat has only the latest stat, so only latest result
    except:
            print(row['play'])
    df_temp['play']=row['play']
    df=df.append(df_temp)
    df['date']=q_date
    df.reset_index(level=0, inplace=True, drop=True)    
    #append to tbl_play_hist, drop unneeded from df_stat
#    df=df.drop(['rtn_ma510', 'rtn_ma1022','rtn_ma2266', 'rtn_ma66252',\
#            'rtn_ma510_pct', 'rtn_ma1022_pct','rtn_ma2266_pct', 'rtn_ma66252_pct' ],1)
    if env=='prod':
        if underlying=='sp500':
             to_sql_replace(df, "tbl_play")
             to_sql_append(df, "tbl_play_hist")
        elif underlying=='etf':
             to_sql_replace(df, "tbl_play_etf")
             to_sql_append(df, "tbl_play_hist_etf")
# print new ticker by comparing with last df_play             
        df1=df[['ticker','play']]
        df2=df_prev[['ticker','play']]
        dff=df1.merge(df2, indicator=True, how='left')
        dff=dff[dff['_merge']=='left_only']
        print(dff)
        dff.to_csv(r'c:\pycode\playlist\new_play_list.csv')  
    else:
        if underlying=='sp500':
            to_sql_replace(df, "tbl_play_test")
        elif underlying=='etf':
             to_sql_replace(df, "tbl_play_etf_test")        
        pass
    print ("---play_run_%s completed and appended to tbl_play_hist"%env)
    
    return df

def play_view(df): 
    import pandas_datareader.data as web
    #enrich with si, earning, tsm
#if df_play is from legacy stat_run then drop, elif from stat_adhoc, then no drop
    if set(['25%']).issubset(df.columns): 
        df=df.drop(['25%', '50%', '75%', 'close_22b', 'close_66b','count', 'hv_10','hv_5', 'hv_66', 'max', 'mean',\
   'mean_10', 'mean_22', 'mean_252', 'mean_5', 'mean_66', 'min',   'p_22', 'p_252', 'rtn_22',\
            'rtn_5', 'rtn_66', 'std', 'sharpe_5', 'sharpe_22', 'sharpe_66',   'mean_510', \
        'sharpe_5_pct', 'rtn_5_pct', 'sharpe_22_pct', 'rtn_22_pct','sharpe_66_pct', 'rtn_66_pct', 'p_252_pct', \
            'p_22_pct','hv_5_pct', 'hv_22_pct', 'hv_66_pct', 'hv_252_pct','hv_m2y_pct',\
            'hi_5', 'lo_5','hi_66', 'lo_66', 'hi_252', 'lo_252',\
            'momt_50','p_44_sig', \
            'rtn_ma510', 'rtn_ma1022', 'rtn_ma2266', 'rtn_ma66252',\
        'rtn_ma510_pct', 'rtn_ma1022_pct', 'rtn_ma2266_pct', 'rtn_ma66252_pct'],1)
#        df=df.drop(['hi_10', 'hi_22', 'hi_252', 'hi_44', 'hi_5', 'hi_66', 'hv_22',\
#        'lo_10', 'lo_22', 'lo_252', 'lo_44', 'lo_5', 'lo_66'],1)
        df=df.drop(['mean_1022', 'mean_2266', 'mean_66252', 'p_66_sig', 'rtn_ma252', \
            'rtn_ma252_pct', 'rtn_ma66', 'rtn_ma66_pct'], 1)
        df=df.drop(['hv_10_50', 'hv_22_50', 'hv_252_50' ],1)
    #enrich fileds for trade input
    df_form=pd.DataFrame(columns=['entry_note','entry_price','entry_date','estike_1','estrike_2','contracts','erisk'\
                         ,'exit_target','expire_date','be_up','be_down','exist_pct','alert_exit','alert_stop'\
                         ,'exit_date','exit_price','epnl_pct','epnl','exit_note','close_last','date_last', 'days_left'\
                         ,'con_1', 'con_2','con_p1','con_p2','con_ex1','con_ex2','con_ex_p1','con_ex_p2','comm','delta','type'])
#pre-fill     
#    df_form['exit_date']='N' 
    df_form['entry_note']='behaved?'
    df_form['date_last']=LBdate
    df=df.append(df_form)
    df['exit_date']='N'
    df['expire_date']=datetime.date(2017,1,1)
    df['ex_div']=datetime.date(2017,1,1)
    df['estike_1']=1
    df['con_p1']=100
    df.reset_index(inplace=True, drop=True)
    # enrich with si
    for index, row in df.iterrows():
        df.loc[index,'earning_date']=get_earning_date(row['ticker']) 
        df.loc[index,'rsi']=get_rsi(row['ticker'])
#        get_info error on Jan10
#        df.loc[index,'div_yield'], df.loc[index,'ex_div'], df.loc[index,'pct_50_ma'], df.loc[index,'pct_200_ma'],\
#            df.loc[index,'pct_hi'], df.loc[index,'pct_lo'], df.loc[index,'pe'],\
#            df.loc[index,'peg'] =0,0,0,0,0,0,0,0
        try:
            df.loc[index,'si']=web.get_quote_yahoo(row['ticker'])['short_ratio'][0]
        except:
            df.loc[index,'si']=0
#        p_pct=web.get_quote_yahoo(ticker)['change_pct']
#        try:
#            df.loc[index,'div_yield'], df.loc[index,'ex_div'], df.loc[index,'pct_50_ma'], df.loc[index,'pct_200_ma'],\
#            df.loc[index,'pct_hi'], df.loc[index,'pct_lo'], df.loc[index,'pe'], df.loc[index,'peg'],\
#            df.loc[index,'si']=get_Share(row['ticker']) #, df.loc[index,'vol_ratio']
#        except:
#            print("get_info error")
#            pass
#enrich tsm
#        if underlying =='sp500':
        try:
            df.loc[index,'sec'], df.loc[index, 'rrtn_22_ts'], df.loc[index,'rrtn_22_sm']=get_tsm(row['ticker'])
        except:
            pass
#        elif underlying =='etf':
#            df.loc[index,'sec']=''
#            df.loc[index,'rrtn_22_ts']=''
#            df.loc[index,'rrtn_22_sm']=''
#        df.loc[index, 'beta']=DF_sp500[DF_sp500['SYMBOL']==row['ticker']].beta.values[0]
        try:        
            qry="SELECT *FROM tbl_play_hist WHERE ticker ='%s'" %row['ticker']
            dh=read_sql(qry, todate)
            df.loc[index, 'won_22']=dh[dh.win_22==1].shape[0]
        except:
            df.loc[index, 'won_22']=0
    df.sort_values(['play', 'won_22', 'momt', 'trend_n', 'hv_252', 'beta', 'close_qdate'],\
            ascending=[True, False, True, True, True, True, True], inplace=True)
    return df
    
def get_column():
    conn=db.connect('c:\\pycode\db_op.db')
    cur=conn.cursor()
    cur.execute("SELECT * FROM tbl_price")
    return [member[0] for member in cur.description]
 
def feature_view(df):
    df_view=df.drop(['max', 'mean',\
       'mean_10', 'mean_22', 'mean_5', 'mean_66', 'min','close_qdate',\
       'count','std',  'p_22_sig','p_44_sig','p_66_sig',
       'p_22_fwd',  '25%', '50%', '75%', 'close_22b', 'close_66b'],1)
    df_view.sort_index(axis=1)
    df_view.sort_values(['win_22'], ascending=[0])
    total=df_view.shape[0]
    true_22=df_view[df_view.win_22==True].shape[0]
    ratio_22=true_22/total
    print ("total: ", total)
    print ("true_22: ", true_22, ",  true_22 ratio: ", ratio_22)
    return df_view

def ml_apply(q_date):#df is df_stat (etf)
    from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
    import pickle
    import statsmodels.api as sm

    model_loaded=pickle.load(open(r'c:\pycode\pytest\ml_etf_lr_ZME1.sav',"rb"))
#get previous df_play list
    qry_prev="SELECT * FROM tbl_play_etf"
    df_prev=read_sql(qry_prev, q_date)    
    qry="SELECT * FROM tbl_stat_etf"
    df=read_sql(qry, todate)
    f=df[['hv_22','hv_66','hv_252','rtn_22']].values
    t= model_loaded.predict(f)
    t=t[:,None]  #convert to array[n,1]
    t=pd.DataFrame(t,columns=['rtn_22_pred'])
    # dc=pd.DataFrame([y_pred, y], columns=['y_pred','y'])
    #df_play_ml=np.concatenate((x, y_pred), axis=0)   
    dp=pd.concat([df,t], axis=1)
    con_L=dp['rtn_22_pred']>=(dp['p_22_sig']/dp['close_qdate'])*1   
    con_S=dp['rtn_22_pred']<=-(dp['p_22_sig']/dp['close_qdate'])*1    
    con_Z=np.abs(dp['rtn_22_pred'])<=0.005
    dp.loc[con_L, 'play']='LME1'
    dp.loc[con_S, 'play']='SME1'
    dp.loc[con_Z, 'play']='ZME1'
    print(dp.play.value_counts())
    dp=dp[['ticker','play','close_qdate', 'rtn_22_pred', 'p_22_sig','rtn_22', 'rtn_66','hv_22','hv_66','hv_252',\
      'mean_510', 'mean_1022', 'mean_2266','mean_66252','date']]
    dp.dropna(inplace=True)
    dp.to_csv('G:\\Trading\Trade_python\pycode\playlist_ml_etf_%s.csv'%q_date) 
    to_sql_replace(dp, "tbl_play_etf")
    to_sql_append(dp, "tbl_play_etf_hist")
    
    df1=dp[['ticker','play','earning_date']]
    df2=df_prev[['ticker','play','earning_date']]
    dff=df1.merge(df2, indicator=True, how='left')
    dff=dff[dff['_merge']=='left_only']
    print(dff)
    print ("ml_apply is completed")


    
    