# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 12:37:09 2017
Purpose:
Function:   fwd_test() in dailyrun as rolling fwd testing; 
            play_fwd_price() in back_test 
            fwd_date(), price_check()
Imported: 
@author: jon
"""
from pandas.tseries.offsets import BDay
import sqlite3 as db
import pandas as pd
import numpy as np
import datetime as datetime
from termcolor import colored

from P_commons import read_sql, to_sql_replace, to_sql_append

today=datetime.datetime.today()
todate=datetime.date.today()
ldate=todate

def fwd_test(underlying):  #daily update p_22_fwd to tbl_play_hist
#    from timeit import default_timer as timer
    print("fwd_test starts")
#    start_time=timer()
    if underlying=='sp500':
        query="SELECT * FROM tbl_play_hist"
        df=read_sql(query, todate)    
        df=df.drop(['level_0'],1)
        to_sql_replace(df, "tbl_play_hist_bkup")  #vback up before update
    elif underlying=='etf':
        query="SELECT * FROM tbl_play_etf_hist"
        df=read_sql(query, todate)    
        if set(['level_0']).issubset(df.columns):
            df=df.drop(['level_0'],1)
        to_sql_replace(df, "tbl_play_etf_hist_bkup")
    
    dh_play=play_fwd_price(df,5,underlying) 
    dh_play=play_fwd_price(df,10,underlying) #update fwd_10 price
    dh_play=play_fwd_price(df, 22, underlying) #update fwd_22 price
    dh_play=win_loss(dh_play,22)
# finnal write back to tbl_play_hist    
    if underlying=='sp500':
        to_sql_replace(dh_play, "tbl_play_hist") # with p_10_fwd, p_22_fwd, win_22, win_10
    elif underlying=='etf': 
        to_sql_replace(dh_play, "tbl_play_etf_hist")
#    end_time=timer()
#    test_time=end_time - start_time
#    print("fwd_test is done in seconds:  %s"%test_time)
    print(" -----  %s_fwd_test is done ------ "%underlying)
    
def play_fwd_price(df_play, lookfwd_period, underlying):#qdate for sql only, can be any
    today=datetime.datetime.today()
    todate=today.date()
    counter=0
    cnt_err=0
    list_err=[]
    periods=(5,10,22)
    if lookfwd_period not in periods:
        print ("lookfwd_period is wrong:", lookfwd_period)
        return
# exclude rows with data
    con_updated=pd.notnull(df_play.p_5_fwd) & pd.notnull(df_play.p_10_fwd) & pd.notnull(df_play.p_22_fwd)
    for index, row in df_play[~con_updated].iterrows():  #date is from df_play
        ticker=row['ticker']
        date=row['date']
#        date_fwd=fwd_date(pd.to_datetime(row['date']),lookfwd_period, underlying)
        bd_diff=pd.bdate_range(pd.to_datetime(date), pd.to_datetime(today)).size  #see if fwd_price avaiable in tbl_price
        con=(bd_diff>lookfwd_period) and pd.isnull(row['p_%s_fwd'%lookfwd_period])
#            con=(today.date()>=date_fwd.date()) and pd.isnull(row['p_22_fwd'])
        if con:
            if underlying=='sp500':
                qry="SELECT date, %s FROM tbl_price"%ticker
            elif underlying=='etf':
                qry="SELECT date, %s FROM tbl_price_etf"%ticker
            dp=read_sql(qry, todate) 
            try:
                t_loc=dp[pd.to_datetime(dp.date)==date]
                t_loc=t_loc.iloc[-1].name
                t_loc=dp.index.get_loc(t_loc)
                p_lookfwd_period=dp.loc[t_loc+lookfwd_period][1]
    
                df_play.loc[index, "p_%s_fwd"%lookfwd_period]=p_lookfwd_period
                counter =counter+1
            except:
                cnt_err+=1
                list_err.append(ticker + str(date))
            #print("yes", ticker, con, date, df_temp.iloc[0,1] )
            #print("no", ticker, con, date)
        else:
             pass
    print("number of update to fwd_%s:"%lookfwd_period, counter,\
        "cnt_err_%s:"%lookfwd_period, cnt_err)

    return df_play 

def win_loss(df, lookfwd_period):
    #lookfwd_priod=10: for trade_track() - stay or exit current trade
#   =22: for fwd_test(), testing current model in PROD
    #another way is use nested np.where or lambda
    fac_10=0.5  #range factor to range_22
    fac_5= fac_10*0.75

    #if p_22_fwd has data and win_22 is  null for whatever reson
    notnull_22=pd.notnull(df['p_22_fwd'])
    ttl_22=df[notnull_22].shape[0]
    notnull_10=pd.notnull(df['p_10_fwd']) &   pd.isnull(df['p_22_fwd'])     #p_22_fwd not available
    ttl_10=df[notnull_10].shape[0]
#p_5_fwd has data, and  p_10_fwd has no data   
    notnull_5=pd.notnull(df['p_5_fwd']) &   pd.isnull(df['p_10_fwd'])    
    ttl_5=df[notnull_5].shape[0]
#    for notnull_22:
    df.loc[(df['play'].str.strip().str[0]=='L') & (notnull_22), 'win_22']=(df['p_22_fwd']-df['close_qdate']).astype(float) >=df['p_22_sig'].astype(float)
    df.loc[df['play'].str.strip().str[0]=='S', 'win_22']=(df['close_qdate']-df['p_22_fwd']).astype(float) >=df['p_22_sig'].astype(float)
    df.loc[df['play'].str.strip().str[0]=='C', 'win_22']=np.abs(df['p_22_fwd']/df['close_qdate']-1).astype(float)<=0.02
    df.loc[df['play'].str.strip().str[0]=='Z', 'win_22']=np.abs(df['p_22_fwd']/df['close_qdate']-1).astype(float)<=0.02

    df.loc[df['play'].str.strip().str[0]=='L', 'win_10']=(df['p_10_fwd']-df['close_qdate']).astype(float) >=df['p_22_sig'].astype(float)*fac_10
    df.loc[df['play'].str.strip().str[0]=='S', 'win_10']=(df['close_qdate']-df['p_10_fwd']).astype(float) >=df['p_22_sig'].astype(float)*fac_10
    df.loc[df['play'].str.strip().str[0]=='C', 'win_10']=np.abs(df['p_10_fwd']/df['close_qdate']-1).astype(float)<=0.015
    df.loc[df['play'].str.strip().str[0]=='Z', 'win_10']=np.abs(df['p_10_fwd']/df['close_qdate']-1).astype(float)<=0.015

    df.loc[df['play'].str.strip().str[0]=='L', 'win_5']=(df['p_5_fwd']-df['close_qdate']).astype(float) >=df['p_22_sig'].astype(float)*fac_5
    df.loc[df['play'].str.strip().str[0]=='S', 'win_5']=(df['close_qdate']-df['p_5_fwd']).astype(float) >=df['p_22_sig'].astype(float)*fac_5
    df.loc[df['play'].str.strip().str[0]=='C', 'win_5']=np.abs(df['p_5_fwd']/df['close_qdate']-1).astype(float)<=0.015
    df.loc[df['play'].str.strip().str[0]=='Z', 'win_5']=np.abs(df['p_5_fwd']/df['close_qdate']-1).astype(float)<=0.015  
    
    if lookfwd_period==22:  # for fwd_test()
        c5 =df['win_5']==1
        c10=df['win_10']==1
        c22=df['win_22']==1
        w_5_22=df[c5 & c22].play.value_counts()
        w_5=df[c5 ].play.value_counts()
        r_5=w_5_22/w_5
        r_5.name='w22_w5'
        
        w_10_22=df[c10 & c22].play.value_counts()
        w_10=df[c10 ].play.value_counts()        
        r_10=w_10_22 /w_10
        r_10.name='w22_w10'
        
        w_22=df[c22].play.value_counts()
        w=df.play.value_counts()        
        r_22=w_22 / w
        r_22.name='w22_all'
        
        r_test=pd.concat([r_5, r_10, r_22], axis=1)
        r_test.sort_values('w22_all', ascending=False, inplace=True)
        print(colored("------  model predictability: ------", 'red', 'on_cyan'))
        print(colored(r_test, 'blue'))
        symbol_win_5=df[c5][['ticker','play', 'date', 'p_5_fwd']]
        symbol_win_5.sort_values('date', ascending=False, inplace=True)        
        symbol_win_5=symbol_win_5.groupby(['play','ticker']).first() 
        symbol_win_5.sort_values('date', ascending=True, inplace=True)
      #  symbol_win_5.to_csv('G:\\Trading\Trade_python\pycode\win5_true_candidate_%s.csv'%lday.date())          
        print(colored("win_5 is true, candidate trade:", 'red', 'on_green'))
        print(symbol_win_5.tail(16))      
        t5= pd.notnull(df['p_5_fwd']) & pd.isnull(df['win_5']) 
        t10= pd.notnull(df['p_10_fwd']) & pd.isnull(df['win_10'])         
        print("t5:  ", t5.shape)
        print("t10:  ", t10.shape)       
    else:  #lookfwd_period=10, then fro trade_track()
        pass
    
    return df

def fwd_test_model(n='6'):  #test accuracy of new models
    query="SELECT * FROM tbl_play_hist"
    df=read_sql(query, todate)    
    df=df.drop(['level_0'],1)
    con_5=df.win_5==1
    con_10= df.win_10==1
#    bd_diff=pd.bdate_range(pd.to_datetime(df.date), pd.to_datetime(today)).size
    df['x']=pd.to_datetime(df.date)
    df['y']=pd.to_datetime(today)
    diff=(df['y']-df['x']).dt.days
    elig_5= (diff>=5 ) 
    elig_10= (diff>=12)
    con_z= df.play=='Z%s'%n
    con_l= df.play=='L%s'%n
    con_s= df.play =='S%s'%n
    con_zls= con_z | con_l | con_z
    hit_5_l, hit_5_s, hit_5_z,hit_10_l, hit_10_s, hit_10_z =0,0,0,0,0,0
    if elig_5.any() :
        hit_5_l= df[elig_5 & con_5 & con_l].shape[0]/ df[elig_5 & con_l].shape[0]
        hit_5_s= df[elig_5 & con_5 & con_s].shape[0]/ df[elig_5 & con_s].shape[0]
        hit_5_z= df[elig_5 & con_5 & con_z].shape[0]/ df[elig_5 & con_z].shape[0]
        
    if elig_10.any():
        try:
            hit_10_l= df[elig_10 & con_10 & con_l].shape[0]/ df[elig_10 & con_l].shape[0]
            hit_10_s= df[elig_10 & con_10 & con_s].shape[0]/ df[elig_10 & con_s].shape[0]
            hit_10_z= df[elig_10 & con_10 & con_z].shape[0]/ df[elig_10 & con_z].shape[0]
        except:
            pass
    dic={'hit_5_l': hit_5_l,'hit_5_s': hit_5_s,'hit_5_z': hit_5_z,\
        'hit_10_l': hit_10_l,'hit_10_s': hit_10_s,'hit_10_z': hit_10_z}
    df_test=pd.DataFrame([dic], columns=dic.keys())
    print(colored("model_ZLS%s accuracy"%n, 'red', 'on_cyan'))
    print(colored(df_test, 'blue'))
    

    
def play_fwd_price_old(df_play, q_date, lookfwd_period, underlying):#qdate for sql only, can be any
    today=datetime.datetime.today()
    df_temp=pd.DataFrame()
    df_price_fwd=pd.DataFrame()
#    date_22_fwd=date_fwd(q_date, 2)
#    date_44_fwd=date_fwd(q_date, 44)
#    date_66_fwd=date_fwd(q_date, 66)
    counter=0
    for index, row in df_play.iterrows():  #date is from df_play
        ticker=row['ticker']
        date=row['date']
        date_fwd=fwd_date(pd.to_datetime(row['date']),lookfwd_period, underlying)
       
        if lookfwd_period==22:
            con=(today.date()>=date_fwd.date()) and pd.isnull(row['p_22_fwd'])
        elif lookfwd_period==10:
            con=(today.date()>=date_fwd.date()) and pd.isnull(row['p_10_fwd'])
        elif lookfwd_period==5:
            con=(today.date()>=date_fwd.date()) and pd.isnull(row['p_5_fwd'])
        if con:
        # and row['p_22_fwd'].isnull():
            #ticker=row['ticker']
            if underlying=='sp500':
                qry="SELECT date, %s FROM tbl_price WHERE date in ('%s')"%(ticker, date_fwd)
            elif underlying=='etf' and ticker !='^VIX':
                qry="SELECT date, %s FROM tbl_price_etf WHERE date in ('%s')"%(ticker, date_fwd)
            elif underlying=='etf' and ticker =='^VIX':
                x=date_fwd.date()                
                x='%s'%x               
                qry='SELECT date, "^VIX" FROM tbl_price_etf WHERE date in (%s)'%x
            else:
                print("play_fwd_price missing env")
            df_temp=read_sql(qry, q_date)
            if lookfwd_period==22:
                try:  # to skip VIX
                    df_play.loc[index, "p_22_fwd"]=df_temp.iloc[0,1]
                except:
                    pass
            elif lookfwd_period==10: 
                df_play.loc[index, "p_10_fwd"]=df_temp.iloc[0,1] 
            elif lookfwd_period==5: 
                df_play.loc[index, "p_5_fwd"]=df_temp.iloc[0,1]
            counter =counter+1
            #print("yes", ticker, con, date, df_temp.iloc[0,1] )
            #print("no", ticker, con, date)
        else:
             pass
    print("number of update to fwd_%s:"%lookfwd_period, counter)
    return df_play   



def pfp(df_play, lookfwd_period, underlying): #update p_22_fwd for data in DF 

    for index, row in df.iterrows():
        ticker=row['ticker']
        date=row['date']   #date: price for testing data date
        qry="SELECT date, %s FROM tbl_price"%ticker
        dp=read_sql(qry, todate) # extract all price
#        dp.date=pd.to_date(dp.date)  #convert date to datetime%m
        #date='{:%Y-%m-%d}'.format(date)  #convert datetime to string
#        p_tdate=dp[dp.date==t_date].iloc[-1]
        date=pd.to_datetime(date)
        t_loc=dp[pd.to_datetime(dp.date)==date]
        t_loc=t_loc.iloc[-1].name

        t_loc=dp.index.get_loc(t_loc)
        p_fwd=dp.loc[t_loc+lookfwd_period][1]
        df_play.loc[index, "p_%s_fwd"%lookfwd_period]=p_fwd
        
        print(p_22_fwd)
        
 #locate index position of a cell  x=d1[d1.date==x].iloc[-1].name       
 #get ordinal posistion of lael      d1.index.get_loc(x)  

def price_check(q_date):
    t_date=test_date+datetime.timedelta(28)
    z_date=test_date+datetime.timedelta(35)
    query="SELECT LMT FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price", t_date, z_date)
    df=read_sql(query, test_date)
    return df
  
def fwd_date(q_date, fwd_days, underlying):
    date_fwd=q_date+BDay(fwd_days)
    #date_fwd=q_date+BDay(fwd_days)
    if underlying=='sp500':
        query="SELECT * from tbl_price WHERE date= '%s'"%date_fwd
    elif underlying=='etf':
        query="SELECT * from tbl_price_etf WHERE date= '%s'"%date_fwd
    try:    
        df_price=read_sql(query,date_fwd)
        if df_price.empty:
           date_fwd=q_date+BDay(fwd_days+1)
        else:
            pass
#    df_price=read_sql(query,date_fwd)
#    try:
#        while df_price.empty and i<2:
#            date_fwd += BDay(1)
#            df_price=read_sql(query,date_fwd)
#            i+=1
    except:
        print("fwd_date exception: %s_%s"%(q_date,fwd_days))
        pass
    return date_fwd