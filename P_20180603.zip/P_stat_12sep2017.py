# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 11:50:54 2017
purpose:
Functions: 
    1. stat_run
    2. stat_rank

@author: jon
"""
import pandas as pd
import numpy as np 
import datetime as datetime
import scipy.stats as stats
import sqlite3 as db

from P_commons import to_sql_append, to_sql_replace, read_sql

DF_sp500=pd.read_csv('c:\\pycode\pyprod\constituents.csv')
df_etf=pd.read_csv('c:\\pycode\pyprod\etf.csv')
df_sp500=DF_sp500.ix[:,0] #serie
df_etf=df_etf.ix[:,0]

def stat_rank(df): #generic
    df['sharpe_5_pct']=df['sharpe_5'].rank(pct=True)  
    #this is abs rtn, as goal is to measure vol
    df['rtn_5_pct']=df['rtn_5'].rank(pct=True)    
    df['sharpe_22_pct']=df['sharpe_22'].rank(pct=True)    
    df['rtn_22_pct']=df['rtn_22'].rank(pct=True)
    df['sharpe_66_pct']=df['sharpe_66'].rank(pct=True)    
    df['rtn_66_pct']=df['rtn_66'].rank(pct=True)
    df['p_252_pct']=df['p_252'].rank(pct=True)
#    df['p_10_pct']=np.abs(df['p_10']).rank(pct=True)
    df['p_22_pct']=np.abs(df['p_22']).rank(pct=True)
#    df['p_66_pct']=np.abs(df['p_66']).rank(pct=True)
    df['hv_5_pct']=np.abs(df['hv_5']).rank(pct=True)
    df['hv_22_pct']=np.abs(df['hv_22']).rank(pct=True)
    df['hv_66_pct']=np.abs(df['hv_66']).rank(pct=True)
    df['hv_252_pct']=np.abs(df['hv_252']).rank(pct=True)
    df['hv_m2y_pct']=np.abs(df['hv_m2y']).rank(pct=True)
    df['rtn_ma66_pct']=df['rtn_ma66'].rank(pct=True)  
    df['rtn_ma252_pct']=df['rtn_ma252'].rank(pct=True)
    df.loc[pd.isnull(df.rtn_5_pct), 'rtn_5_pct']=0.5
    df.loc[pd.isnull(df.rtn_22_pct), 'rtn_22_pct']=0.5
    df.loc[pd.isnull(df.rtn_66_pct), 'rtn_66_pct']=0.5
    return df

# in: tbl_price /out:tbl_stat_hist
def stat_run(q_date, underlying, env='prod'): #underlying= sp500 or etf
#read_sql, to_sql_replace, stat_rank
    p_date=q_date-datetime.timedelta(380)
    #pick up price in the range only
    if underlying=='sp500':
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price", p_date, q_date)
    elif underlying=='etf':
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price_etf", p_date, q_date)
    else:
        print("stat_run missing underlying")
        exit
    #query="SELECT * FROM '%s' wHERE date >= '%s' " %("tbl_price", p_date)
    df=read_sql(query, q_date)
    df.sort_index(axis=0) #sort the price from old date to latest date
    df=df.fillna(0)
    df['date']=q_date
    # convert date column to index index
    df.set_index('date', inplace=True) 
#test corr() of 6month 
    df_corr=df.tail(132).corr().ix['SPY',:]   
    #get stat data
    df_stat=pd.DataFrame()
    df_st=pd.DataFrame()
    df0=pd.DataFrame()

    len=df.shape[1]  
    #iterate thru columns, each column is a ticker
    #if iterate thru rows then use below code
# for index, row in df.iterrows():
#   ....:     print row['c1'], row['c2']   
    
    #for columns in df (another way)
    for c in range (0,len):
        df0=df.iloc[:,c].describe()
        #df0['ticker']=df.iloc[0:,c].name
        df0['ticker']=df.columns[c]
#for PROD, always get the latest price
#for TEST, how?        
        df0['corr']=df_corr[df.columns[c]]      #read corr with SPY
        df0['close_qdate']=df.iloc[-1,c]  #last row is latest price
        df0['close_22b']=df.iloc[-22,c]
        df0['close_66b']=df.iloc[-66,c]
        df0['mean_5']=df.iloc[:,c].tail(5).mean()
        df0['mean_10']=df.iloc[:,c].tail(10).mean()
        df0['mean_22']=df.iloc[:,c].tail(22).mean()
        df0['mean_66']=df.iloc[:,c].tail(66).mean()
        df0['mean_252']=df.iloc[:,c].tail(252).mean()   
#        df0['hi_5']=df.iloc[:,c].tail(5).max()
#        df0['hi_10']=df.iloc[:,c].tail(10).max()
#        df0['hi_22']=df.iloc[:,c].tail(22).max()
#        df0['hi_44']=df.iloc[:,c].tail(22).max()
#        df0['hi_66']=df.iloc[:,c].tail(66).max()
#        df0['hi_252']=df.iloc[:,c].tail(252).max()  
#        df0['lo_5']=df.iloc[:,c].tail(5).min()
#        df0['lo_10']=df.iloc[:,c].tail(10).min()
#        df0['lo_22']=df.iloc[:,c].tail(22).min()
#        df0['lo_44']=df.iloc[:,c].tail(22).min()
#        df0['lo_66']=df.iloc[:,c].tail(66).min()
#        df0['lo_252']=df.iloc[:,c].tail(252).min()  
        df0['rtn_5']=df.iloc[-1,c]/df.iloc[-5,c]-1 
        df0['rtn_22']=df.iloc[-1,c]/df.iloc[-22,c]-1 
        df0['rtn_66']=df.iloc[-1,c]/df.iloc[-66,c]-1 
        #get hv_5
        #try:
            #x=(df.iloc[:,c]/df.iloc[:,c].shift(1))
            #print (x.dtype)
        log_rtn=np.log(df.iloc[:,c]/df.iloc[:,c].shift(1))
          #pass
        #df0['log_rtn']=np.log(df.columns[c]/df.columns[c].shift(1))
        #log_rtn=np.log(df.iloc[:,c]/df.iloc[:,c].shift(1))
        df0['hv_5']=np.sqrt(252*log_rtn.tail(5).var())
        df0['hv_10']=np.sqrt(252*log_rtn.tail(10).var())
        df0['hv_22']=np.sqrt(252*log_rtn.tail(22).var())
        df0['hv_66']=np.sqrt(252*log_rtn.tail(66).var())
        df0['hv_252']=np.sqrt(252*log_rtn.tail(252).var())
        #get normal testing
#        tp_10=stats.normaltest(log_rtn[-11:-1])
        tp_22=stats.normaltest(log_rtn[-23:-1])
#        tp_66=stats.normaltest(log_rtn[-67:-1])
        tp_252=stats.normaltest(log_rtn[-252:-1])
       
#        df0['p_10']=tp_10[1]
        df0['p_22']=tp_22[1]
#        df0['p_66']=tp_66[1]  
        df0['p_252']=tp_252[1]
#        df0['beta']=DF_sp500[DF_sp500['SYMBOL']==df0['ticker']].beta.values[0]
        
        df_st=df_st.append(df0)
    df_st=stat_beta(df_st)     
    
    df_stat=df_st.set_index('ticker') #ticker is set to be index
    df_stat['date']=q_date  
    df_stat['sharpe_5']=df_stat['rtn_5']/df_stat['hv_5']
    df_stat['sharpe_22']=df_stat['rtn_22']/df_stat['hv_22']
    df_stat['sharpe_66']=df_stat['rtn_66']/df_stat['hv_66']
    df_stat['hv_m2y']=df_stat['hv_22']/df_stat['hv_252']
    df_stat['mean_510']=df_stat['mean_5']>df_stat['mean_10']
    df_stat['mean_1022']=df_stat['mean_10']>df_stat['mean_22']
    df_stat['mean_2266']=df_stat['mean_22']>df_stat['mean_66']
    df_stat['mean_66252']=df_stat['mean_66']>df_stat['mean_252']
    #below added on Jan.2, 2017
    df_stat['rtn_ma66']=df_stat['mean_5']/df_stat['mean_66']-1
    df_stat['rtn_ma252']=df_stat['mean_5']/df_stat['mean_252']-1
    #enrich with 1sig forward expected price move    
    df_stat['p_22_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(22)/ np.sqrt(252)
    df_stat['p_44_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(44)/ np.sqrt(252)
    df_stat['p_66_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(66)/ np.sqrt(252)

    df_stat=stat_rank(df_stat)   
    df_stat=stat_ZLS_3(df_stat)

    con_price=(df_stat.close_qdate>25) & (df_stat.close_qdate<200)
    df_stat=df_stat[con_price]
        #overwrite tbl_stat_hist
    if env=='prod' and underlying=='sp500':
        to_sql_replace(df_stat, "tbl_stat")
    elif env=='prod' and underlying=='etf':
        to_sql_replace(df_stat, "tbl_stat_etf")    
    elif env=='test' and underlying=='sp500':
        to_sql_replace(df_stat, "tbl_stat_test")
    elif env=='test' and underlying=='etf':
        to_sql_replace(df_stat, "tbl_stat_etf_test")
   # print ("--- stat_run completed and replaced into tbl_stat_'%s'_'%s'---"%(underlying, env))
    return df_stat

#stat added on for model
def stat_ZLS_3(df):
#for L3, Z3, S3
    fac_5=2
    fac_10=3
    fac_22=4
    fac_66=1
    
    df['trend_n']=fac_22*df['mean_2266']+ fac_10*df['mean_1022']+ \
            fac_5*df['mean_510']+fac_66*df['mean_66252']
            
    df['trend']=(df['mean_510']).astype(str) + (df['mean_1022']).astype(str) \
        + (df['mean_2266']).astype(str) + (df['mean_66252']).astype(str)
    df.rtn_5_pctn=(10*df['rtn_5_pct']).astype(int) 
    df.rtn_22_pctn= (10*df['rtn_22_pct']).astype(int) 
    df.rtn_66_pctn=(10*df['rtn_66_pct']).astype(int)
    df['momt']=df.rtn_5_pctn.astype(str) + df.rtn_22_pctn.astype(str)\
        + df.rtn_66_pctn.astype(str)
    df['momt']=df['momt'].astype(float)
    df.loc[df.momt>999, 'momt']=999

    x=df.describe()
    loc_50=x.index.get_loc('50%')
    df['trend_n_50']= x.loc['50%', 'trend_n']
    df['momt_50']= x.loc['50%', 'momt']    
    df['hv_252_50']= x.loc['50%', 'hv_252'] 
    df['hv_22_50']= x.loc['50%', 'hv_22']     
    df['hv_10_50']= x.loc['50%', 'hv_10'] 
    return df

def stat_beta(df):
#add beta 

    d0=pd.DataFrame()
    d0[['ticker','beta']]=DF_sp500[['SYMBOL', 'beta']]
    
#    df['beta']=DF_sp500[DF_sp500['SYMBOL']==df['ticker']].beta.values[0]
    df=df.merge(d0, on='ticker', how='left')
    return df