# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 14:41:20 2017
Purpose: Back test SQL-based rules
@author: jon
"""
import numpy as np
import pandas as pd
import pandas.io.data as web
import datetime
import warnings
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.pyplot as plot
from sklearn import linear_model
from sklearn.cross_validation import train_test_split
from sklearn import preprocessing
import scipy as sp
import pickle
from sklearn import neighbors
import seaborn as sns
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
DF_sp500=pd.read_csv('G:\\Trading\Trade_python\pycode\pyprod\constituents.csv')
df_etf=pd.read_csv('G:\\Trading\Trade_python\pycode\pyprod\etf.csv')
df_sp500=DF_sp500.ix[:,0] #serie
df_etf=df_etf.ix[:,0]

def import_data(underlying):
    if underlying=='sp500':    
        dd=pd.read_csv(r'G:\Trading\Trade_python\pycode\pytest\playlist_sp500_test_2017-07-14.csv') 
    else:
        dd=pd.read_csv(r'G:\Trading\Trade_python\pycode\pytest\test_stat_etf_6.csv')
    #ddd=dd.dropna()
    dd.fillna(method='ffill', inplace=True)   
    dm=DF_sp500
    fac_5=2
    fac_10=3
    fac_22=4
    fac_66=1
    dm['ticker']=dm['SYMBOL']
    dd=dd.merge(dm, on='ticker', how='left')  
    dd['rtn_22_fwd']=(dd['p_22_fwd']/dd['close_qdate'])-1
    dd['rtn_22_fwd_pct']=dd['rtn_22_fwd'].rank(pct=True)
    dd['trend_n']=fac_22*dd['mean_2266']+ fac_10*dd['mean_1022']+ \
        fac_5*dd['mean_510']+fac_66*dd['mean_66252']
    dd['trend']=(dd['mean_510']).astype(str) + (dd['mean_1022']).astype(str) \
        + (dd['mean_2266']).astype(str) + (dd['mean_66252']).astype(str)
    dd.rtn_5_pctn=(10*dd['rtn_5_pct']).astype(int) 
    dd.rtn_22_pctn= (10*dd['rtn_22_pct']).astype(int) 
    dd.rtn_66_pctn=(10*dd['rtn_66_pct']).astype(int)
    dd['momt']=dd.rtn_5_pctn.astype(str) + dd.rtn_22_pctn.astype(str)\
        + dd.rtn_66_pctn.astype(str)
    dd['momt']=dd['momt'].astype(float)
    dd.loc[dd.momt>999, 'momt']=999
    return dd
    

def plot_prep():
    df=import_data('sp500')
    fac_hv=0.45  # outlier selection on hv_252 for z
    fac_z=0.02
    fac_l=0.8
    fac_s=0.2
    
    do=df
    df['hv_5m']=df['hv_5']/df['hv_22']    
    df1=df[['hv_5m', 'hv_252_pct','rtn_ma66_pct','p_10','p_22','hv_10','hv_66',\
    'hv_5', 'hv_22', 'hv_252','rtn_22_fwd', 'rtn_22', 'rtn_66',\
    'hv_66_pct','hv_22_pct','rtn_22_pct','rtn_22_fwd_pct']]
    df2=df[['hv_5m', 'hv_22', 'hv_252','p_252', 'rtn_ma66_pct',  'rtn_22_pct', 'rtn_5_pct', 'hv_5',\
        'rtn_22_fwd_pct','rtn_22_fwd', 'hv_m2y', 'hv_m2y_pct']]  
    df3=df[['hv_5', 'hv_10', 'hv_5m', 'hv_22', 'hv_252','p_252', 'p_66', 'sharpe_5', 'sharpe_22', \
    'sharpe_66', 'hv_m2y', 'sharpe_22_pct',
           'rtn_22_pct', 'sharpe_66_pct', 'rtn_66_pct', 'p_252_pct', 'p_10_pct',
           'p_22_pct', 'p_66_pct', 'hv_5_pct', 'hv_22_pct', 'hv_66_pct',
           'hv_252_pct', 'hv_m2y_pct', 'rtn_ma66_pct', 'rtn_ma252_pct',\
           'rtn_22_fwd', 'rtn_22_fwd_pct']]
    df4=df[['hv_252', 'hv_5', 'hv_10', 'hv_22', 'momt', 'trend_n', 'rtn_22_fwd', 'rtn_22_fwd_pct', 'rtn_ma66_pct', 'hv_22_pct']]      
           
    df=df4  #test first set of features
    outlier=((df.hv_252.astype(float)>fac_hv)|(df.hv_5.astype(float)>1.1)|(df.hv_10.astype(float)>1))
    dfz=df[~outlier]
    dfz.sort_index(axis=1)
    con_z=np.abs(dfz.rtn_22_fwd)<=fac_z
    df=dfz
#long or short no limited by outlier  
    con_l=df.rtn_22_fwd_pct>=fac_l
    con_s=df.rtn_22_fwd_pct<=fac_s
    dz=dfz[con_z]
    ds=df[con_s]
    dl=df[con_l]
    dnz=dfz[~con_z]
    dns=df[~con_s]
    dnl=df[~con_l]
    len_z=dz.shape[1]  #same for z,l, s

    lisa=[dz, dl, ds, df]
    lisa_name=['dz', 'dl', 'ds', 'df']
    ds_50=pd.DataFrame()
    ds_mean=pd.DataFrame()
    for i in range(len(lisa)):
        stat=lisa[i].describe()
        loc_50=stat.index.get_loc('50%')

        st_50=stat.iloc[loc_50,:]
        label_50=('%s_50')%lisa_name[i]
        d_50=pd.DataFrame({label_50: st_50})
        ds_50=pd.concat([ds_50, d_50], axis=1)
        
        loc_mean=stat.index.get_loc('mean')        
        st_mean=stat.iloc[loc_mean,:]
        label_mean=('%s_m')%lisa_name[i]
        d_mean=pd.DataFrame({label_mean: st_mean})
        ds_mean=pd.concat([ds_mean, d_mean], axis=1)
        
    x=df.describe()
    loc_50=x.index.get_loc('50%')
    con_z0=df.trend_n>= x.loc['50%', 'trend_n']
    con_z1=df.momt> 1.1 * x.loc['50%', 'momt']
    con_z2=df.hv_22 < 0.95 * x.loc['50%', 'hv_22']
    con_z3=df.hv_252 < 0.85*  x.loc['50%', 'hv_252']
    con_z4=df.hv_5 < 10 *  x.loc['50%', 'hv_5']
    con_z5=df.hv_10 < 10 *x.loc['50%', 'hv_10']
    con_CAL= (df.rtn_ma66_pct>0.7) & (df.hv_22_pct>0.4)
    
    con_z1= con_z0 & con_z1 & con_z2 & con_z3 & con_z4 & con_z5 
    dz_1=df[con_z1]
    cnt_z1=dz_1[np.abs(dz_1.rtn_22_fwd)<=0.02].shape[0]
    cnt_z=df[np.abs(df.rtn_22_fwd)<=0.02].shape[0]
    
    print("dz_1 ratio:", '{0:.1%}'.format(cnt_z1/dz_1.shape[0]))
    print("dz ratio:", '{0:.1%}'.format(cnt_z/df.shape[0]))
    print("cnt hit:",  '{0:.0%}'.format(cnt_z1/cnt_z), "cntz_1:  ", cnt_z1, cnt_z)
    
    con_l0=df.trend_n <= x.loc['50%', 'trend_n']
    con_l1=(df.momt<  0.95 * x.loc['50%', 'momt'])# & (df.momt>0.5 * x.loc['50%', 'momt'])
    con_l2=df.hv_22 >1 * x.loc['50%', 'hv_22']
    con_l3=df.hv_252 > 1.1*  x.loc['50%', 'hv_252']
    con_l4=df.hv_5 > 0.1 *  x.loc['50%', 'hv_5']
    con_l5=df.hv_10 >0.1 *x.loc['50%', 'hv_10']
    
    con_l1= con_l0 & con_l1 & con_l2 & con_l3 & con_l4 & con_l5
    dl_1=df[con_l1]
    cnt_l1=dl_1[(dl_1.rtn_22_fwd_pct>=0.8) & (dl_1.rtn_22_fwd>0)].shape[0]
    cnt_l= df[(df.rtn_22_fwd_pct>=0.8) & (df.rtn_22_fwd>0)].shape[0]    
    print("dl_1 ratio:", '{0:.1%}'.format(cnt_l1/dl_1.shape[0]))
    print("dl ratio:", '{0:.1%}'.format(cnt_l/df.shape[0]))
    print("cnt hit:",  '{0:.0%}'.format(cnt_l1/cnt_l), "cntl_1:  ", cnt_l1, cnt_l)
#  Short    
    con_s0=df.trend_n <= x.loc['50%', 'trend_n']
    con_s1=df.momt >1 * x.loc['50%', 'momt']
    con_s2=df.hv_22 >1.1* x.loc['50%', 'hv_22']
    con_s3=df.hv_252 > 1.1*  x.loc['50%', 'hv_252']
    con_s4=df.hv_5 > 0.1 *  x.loc['50%', 'hv_5']
    con_s5=df.hv_10 >1.1  *x.loc['50%', 'hv_10']

    con_s1= con_s0 & con_s1 & con_s2 & con_s3 & con_s4 & con_s5
    ds_1=df[con_s1]
    cnt_s1=ds_1[(ds_1.rtn_22_fwd_pct<=0.2) & (ds_1.rtn_22_fwd<0)].shape[0]
    cnt_s= df[(df.rtn_22_fwd_pct<=0.2) & (df.rtn_22_fwd<0)].shape[0]    
    print("ds_1 ratio:", '{0:.1%}'.format(cnt_s1/ds_1.shape[0]))
    print("ds ratio:", '{0:.1%}'.format(cnt_s/df.shape[0]))
    print("cnt hit:",  '{0:.0%}'.format(cnt_s1/cnt_s), "cnts_1:  ", cnt_s1, cnt_s)
    
    return ds_50, dz_1, dl_1, ds_1

#ds_50, dz_1, dl_1, ds_1=plot_prep()

def plot_zls(label=''):
    dl, ds, dz, dnl, dns, dnz, len_z, ds_50, ds_mean=plot_prep()
    if label =='z':
        print("z vs nz below")
        for i in range(len_z):
            sns.kdeplot(dz.iloc[:,i], label="z_%s"%dz.columns.values[i])
            sns.kdeplot(dnz.iloc[:,i], label="nz_%s"%dnz.columns.values[i])
            plt.figure()
#        
    elif label =='l':   
        print("l vs nl")        
        for i in range(len_z):
            sns.kdeplot(dl.iloc[:,i], label="l_%s"%dl.columns.values[i])
            sns.kdeplot(dnl.iloc[:,i], label="nl_%s"%dnl.columns.values[i]) 
            plt.figure()
    elif label == 's':
        print("s vs ns")
        for i in range(len_z):
            sns.kdeplot(ds.iloc[:,i], label="s_%s"%ds.columns.values[i])
            sns.kdeplot(dns.iloc[:,i], label="ns_%s"%dns.columns.values[i])
            plt.figure()  
            
    elif label == 'ls':
        print("l vs s")
        for i in range(len_z):
            sns.kdeplot(ds.iloc[:,i], label="s_%s"%ds.columns.values[i])
            sns.kdeplot(dl.iloc[:,i], label="l_%s"%dl.columns.values[i])
            plt.figure()  

        
    elif label =='all':
        print("z s l")
        for i in range(len_z):
            sns.kdeplot(dz.iloc[:,i], label="z_%s"%dz.columns.values[i])
            sns.kdeplot(dl.iloc[:,i], label="l_%s"%dl.columns.values[i])
            sns.kdeplot(ds.iloc[:,i], label="s_%s"%ds.columns.values[i])            
            plt.figure()         
        
#dd, dl, ds, dz, dnl, dns, dnz, len=plot_prep()

#kde_plot(len)
def feature_vet(df):
    
#    fl1=df.hv_252_pct>0.5
#    fl2=df.hv_66_pct<0.6
##    fl3=df.hv_22_pct>0
#    fl4=df.rtn_ma66_pct>0.8
##    fl5=df.hv_m2y_pct>0.5
##    fl6=df.rtn_22_pct<0.8
#    
#    fs1=df.hv_252_pct>0.8
##    fs2=df.hv_22_pct>0.8  #no tnecessary
#    fs3=df.rtn_ma66_pct>0.4
#    fs4=df.rtn_ma66_pct<0.7
#    fs5=df.hv_m2y_pct>0.5
#    
#    fz1=df.hv_252_pct<0.3
##    fz2=df.hv_66_pct>0.4
#    fz3=df.hv_22_pct>0.4
##    fz4=df.hv_252<0.225
##    fz5=df.hv_66_pct<0.4
#    fz6=df.rtn_ma66_pct>0.7
#    
##    fz6=df.sharpe_66_pct>0.5
##    fz7=df.p_252>0.001
##    fz8=df.sharpe_5_pct>=0.5
#    fz9=df.hv_5m<0.83
#     
#    dl=df[(fl1 &  fl4 &fl2 )]
#    ds=df[(fs1 &   fs3 & fs4 & fs5)]
#    dz=df[(fz1 & fz9 & fz3 )]
##    dz=df[(fz6 & fz7 & fz8 & fz9 &fz1)]
    
#etf
#    el1=df.rtn_ma252_pct<0.3  #diff from L
#    el2=df.hv_252_pct>0.5
#    el3=df.hv_66_pct>0.6
#    el4=df.hv_22_pct>0.6
#    el5=df.hv_m2y_pct<0.5
#    
#    es1=df.rtn_ma252_pct>0.8  #diff from L
#    es2=df.hv_252_pct>0.8
#    es3=df.hv_66_pct>0.7
#    es4=df.hv_22_pct>0.7
#    es5=df.hv_m2y_pct>0.5
    
    ez1=df.rtn_ma66_pct>0.4
    ez2=df.rtn_ma66_pct<0.7
    ez3=df.hv_252_pct>0.8
    ez4=df.hv_66_pct<0.6
    ez5=df.hv_22_pct<0.6
    ez6=df.rtn_22_pct>0.3
    ez7=df.rtn_22_pct<0.75
    ez8=df.hv_5m<0.83
    ez9=df.hv_252<0.25
    
    
#    el=df[el1 & el2 & el3 & el4 & el5]
#    es=df[es1 & es2 & es3 & es4 & es5]
    ez=df[ez8  & ez3 &  ez1 & ez2]
    #ez=df[(ez3) & ez8]
#    dl=el
#    ds=es
    dz=ez
    
    tl=dl[dl.rtn_22_fwd_pct>=0.8].shape[0]
    ts=ds[ds.rtn_22_fwd_pct<=0.2].shape[0]
    tz=dz[np.abs(dz.rtn_22_fwd_pct)<=0.2].shape[0]
    vet_l=tl/dl.shape[0]
    vet_s=ts/ds.shape[0]
    vet_z=tz/dz.shape[0]
    
#    print("L- true_l: %s  sum_l: %s  vet_l:%s"%(tl, dl.shape[0], vet_l))
#    print("S- true_s: %s  sum_s: %s  vet_s:%s"%(ts, ds.shape[0], vet_s))
    print("Z- true_z: %s  sum_z: %s  vet_z:%s"%(tz, dz.shape[0], vet_z))

#df=data_import('sp500')
#do, df, dx, dl, ds, dz, dnl, dns, dnz, len=plot_prep(df)
#feature_vet(df)
#kde_plot(len)
#feature_vet(df)
df=pd.read_csv(r'G:\Trading\Trade_python\pycode\pytest\playlist_etf_test_2017-02-16_100.csv')
dc=df
dc['rv_5']=dc['rtn_5']/dc['hv_5']
dc['rv_22']=dc['rtn_22']/dc['hv_22']
dc['rv_66']=dc['rtn_66']/dc['hv_66']
dc['ztn_5_fwd']=dc['p_5_fwd']/dc['close_qdate']-1
dc['ztn_10_fwd']=dc['p_10_fwd']/dc['close_qdate']-1
dc['ztn_22_fwd']=dc['p_22_fwd']/dc['close_qdate']-1
df1=dc[['hv_5', 'hv_66','hv_22', 'hv_252','p_252','rtn_22', 'rtn_5', 'rtn_66',\
    'mean_510', 'mean_1022','mean_2266', 'mean_66252','p_5_fwd', 'p_10_fwd', 'p_22_fwd',\
        'rv_5', 'rv_22', 'rv_66', 'ztn_5_fwd','ztn_10_fwd', 'ztn_22_fwd']]
df1['momt']=df1.mean_510.astype(str)+df1.mean_1022.astype(str)+df1.mean_2266.astype(str)+df1.mean_66252.astype(str)
df1['momt_rank']=df1['momt'].rank(pct=True)*0.01
df1=df1.drop(['mean_510', 'mean_1022','mean_2266', 'mean_66252','momt'], axis=1)
df1=df1.sort_index(axis=1)
df1.dropna(inplace=True)

x_22=df1.iloc[:,:15]
y_22=df1['ztn_22_fwd']
x_22a=x_22.drop(['hv_22', 'hv_252', 'hv_5', 'hv_66','p_10_fwd', 'p_22_fwd','p_5_fwd', 'rtn_22', 'rtn_5', 'rtn_66'],\
    axis=1)

def ml_importance(x,y):
    from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
    model_c=ExtraTreesClassifier()
    model_r=ExtraTreesRegressor()
    x=x.values
    y=y.values
    #model_c.fit(x,y)
    model_r.fit(x,y)
    print(model_r.feature_importances_)
