# -*- coding: utf-8 -*-
"""
Created on Mon Aug 21 10:46:42 2017
Purpose:  stat_option
Functions: get_option
@author: jon
"""
import pandas as pd
import numpy as np
import datetime as datetime
import time
pd.options.display.float_format = '{:.2f}'.format
from termcolor import colored

def get_option(ticker=''):
#ref: http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/ 
    from lxml import html
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException   
    from selenium.webdriver.chrome.options import Options
    chrome_options=Options()
    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_0_7_overlay_remove.crx")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
    url="https://marketchameleon.com/Overview/"
    url_1=url+"%s"%ticker
    url_2=url_1+"/OptionSummary/"
    url_3=url_1+"/StockPosts/"
    url_4=url_1+"/SymbolReview/"
    gecko="c:\\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="c:\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
#LOG IN
    url_0="https://marketchameleon.com/Account/Login"
    driver.get(url_0)
    time.sleep(1)   
    username = driver.find_element_by_id("UserName")
    password = driver.find_element_by_id("Password")
    username.send_keys("freeofjon@gmail.com")
    password.send_keys("kevin2008")
    submit=driver.find_element_by_xpath('//input[@class="site-login-control btn"]')
    time.sleep(2) 
    submit.send_keys('\n')         
        
#go to url_1
    driver.get(url_1)
    time.sleep(1)   
    try:
        ol=driver.find_element_by_class_name("register-flyer-close")
        ol=driver.find_element
        ol.click()
    except:
        pass
    iv_30_rank=driver.find_element_by_xpath(' //*[@id="sym_heading_top"]/div[2]/div[2]/div[1]/div[6]/span[2]').get_attribute('textContent')
    iv_30s=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[2]/div[2]/div[1]/div[5]/span[2] ').get_attribute('textContent')
    hv_1y=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[2]/div[2]/div[1]/div[4]/span[2]').get_attribute('textContent')
    hv_22=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[2]/div[2]/div[1]/div[3]/span[2]').get_attribute('textContent')  
    
    v_stk=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[2]/div[1]/div[2]/div[2]/span[2]').get_attribute('textContent')
    v_stk_avg=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[2]/div[1]/div[2]/div[3]/span[2]').get_attribute('textContent')
    v_opt=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[2]/div[1]/div[2]/div[4]/span[2]').get_attribute('textContent')
    v_opt_avg=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[2]/div[1]/div[2]/div[5]/span[2]').get_attribute('textContent')
    v_stk=v_stk.replace(",","")  
    v_stk_avg=v_stk_avg.replace(",","")    
    v_opt=v_opt.replace(",","")    
    v_opt_avg=v_opt_avg.replace(",","")    
    v_stk_pct='{:.1%}'.format(float(v_stk)/float( v_stk_avg))
    try:
        v_opt_pct='{:.1%}'.format(float(v_opt)/ float(v_opt_avg))
    except:  #v_op is zero
        pass
    etf_o=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[1]/span/a').get_attribute('textContent')
    corr_etf=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[4]').get_attribute('textContent')
    p_chg_etf=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[7]/span').get_attribute('textContent')
    p_chg=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[1]/div[2]/div[2]/p[3]').get_attribute('textContent')
    p=driver.find_element_by_xpath('//*[@id="overview_last_price"]').get_attribute('textContent')
    earn_date= driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[2]/div[2]/div[2]/div[3]/span[2]').get_attribute('textContent')    
    div= driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[2]/div[2]/div[2]/div[2]/span[2]').get_attribute('textContent')    
    time.sleep(2)
    
#go to page -OPTION SUMMARY
    driver.find_element_by_xpath('//*[@id="symnav_OptionSummary"]/a').click()
    time.sleep(2)
    iv_30_mean=driver.find_element_by_xpath(' //*[@id="option_summary_MainTotal"]/tbody/tr/td[3]').get_attribute('textContent')
    iv_30_lo=driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[4]').get_attribute('textContent')
    iv_30_hi=driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[5]').get_attribute('textContent')
    v_c=driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[6]').get_attribute('textContent')
    v_p=driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[7]').get_attribute('textContent')
    v_oi_c=driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[8]').get_attribute('textContent')
    v_oi_p=driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[9]').get_attribute('textContent')
    iv_30=float(iv_30s.split(" ")[0])   
    iv_30_chg=float(iv_30s.split(" ")[1])
    iv_30_chg='{:.1%}'.format(iv_30_chg/ iv_30)
    iv_30_rank=iv_30_rank.split(" ")[0]
    iv_hv=float(iv_30)/float(hv_22)
    hv_rank=float(hv_22)/float(hv_1y)
    v_oi_p=v_oi_p.replace(",","")
    v_oi_c=v_oi_c.replace(",","")
    v_c=float(v_c.replace(",",""))
    v_p=float(v_p.replace(",",""))
    try:
        v_c_pct='{:.1%}'.format(v_c/(v_c+v_p))
    except:
        pass
    pc_prev=float(v_oi_p)/ float(v_oi_c)
    pc=(float(v_oi_p) + float(v_p))/(float(v_oi_c) + float(v_c))
    pc_chg='{:.1%}'.format(pc/pc_prev-1)
    time.sleep(2)
    
#  go to page - POSTS
    driver.find_element_by_xpath('//*[@id="symnav_StockPosts"]/a').click()
    time.sleep(2)
    posts=driver.find_elements_by_class_name("homeContentItemInner")
    posts_time=driver.find_elements_by_class_name("homeContentItemTime")
    posts_list=' '
    length=min(3, len(posts))
    for i in range(length):
        x=posts_time[i].get_attribute('textContent') + ' ' + posts[i].get_attribute('textContent')
        posts_list = posts_list + x
        
#  go to page - SKEW
    driver.find_element_by_xpath( '//*[@id="symnav_VolatilitySkew"]/a').click()        
    time.sleep(2)  
    skew=driver.find_element_by_xpath('//*[@id="ivskew_25diff_curr_indicator"]/span/span').get_attribute('textContent')
    skew_pc=driver.find_element_by_xpath('//*[@id="ivskew_25diff_tbl_outer"]/table[1]/tbody/tr/td[4]').get_attribute('textContent')
    time.sleep(1)
#go to page -REVIEW REPORT
    driver.get(url_4)
#    driver.find_element_by_xpath( '//*[@id="symnav_SymbolReview"]/a').click()    
    time.sleep(2)
    note_raw=driver.find_elements_by_xpath("//*[text()='Price Performance:']/following-sibling::p")
    n=[]
    for i in note_raw:
        n.append(i.get_attribute('textContent').splitlines())
#    note=str(note)
    OHLC=n[6][1].strip() + n[6][2].strip()+n[6][3].strip()   
    put=n[13][1].strip() + n[13][2].strip()
    skew_v=n[16][1].strip() + n[16][2].strip() +n[16][3].strip()+n[16][4].strip()

    try:
        div_o=n[24][1].strip() + n[24][2].strip()        
    except:
        div_o=''
        pass
    note=OHLC + '\n' + put + '\n' + skew_v + '\n' + div_o
# summary    
    names=['iv_30', 'iv_30_chg',  'iv_30_rank', 'iv_hv', 'hv_1y', 'hv_22', 'hv_rank',   \
        'v_stk', 'v_stk_avg', 'v_opt', 'v_opt_avg', 'v_stk_pct','v_opt_pct', 'v_c_pct', \
        'etf_o', 'corr_etf', 'p_chg_etf', 'p_chg', 'p'\
        ,'earn_date', 'div', 'iv_30_mean', 'iv_30_lo', 'iv_30_hi', \
        'v_c', 'v_p', 'v_oi_c', 'v_oi_p', 'pc', 'pc_chg',  'posts_list',\
        'skew', 'skew_pc']
    values=[iv_30, iv_30_chg, iv_30_rank, iv_hv,  hv_1y, hv_22, \
    hv_rank,   v_stk, v_stk_avg, v_opt, v_opt_avg, v_stk_pct, v_opt_pct, v_c_pct, \
        etf_o, corr_etf, p_chg_etf, p_chg, p,earn_date, div, \
        iv_30_mean, iv_30_lo, iv_30_hi, \
        v_c, v_p, v_oi_c, v_oi_p,  pc, pc_chg,  posts_list,\
        skew, skew_pc]    
        
    do=pd.DataFrame(data=[], columns=names)    
    do.loc[0,names]=values
    do['ticker']=ticker
    driver.quit

    return do, posts_list, note 























def get_option_test(ticker=''):
#ref: http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/ 
    from lxml import html
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException   
    from selenium.webdriver.chrome.options import Options
    import pickle
    chrome_options=Options()
    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_0_7_overlay_remove.crx")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
#    chrome_options.add_argument("user-data-dir = r'C:\Users\jon\AppData\Local\Google\Chrome\User Data\Default'") 
    url_0="https://marketchameleon.com/Account/Login"
    url="https://marketchameleon.com/Overview/"
    url_1=url+"%s"%ticker
    url_2=url_1+"/OptionSummary/"
    url_3=url_1+"/StockPosts/"
    url_4=url_1+"/SymbolReview/"
    gecko="G:\\Trading\Trade_python\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="G:\Trading\Trade_python\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
    
#    cookie="C:\Users\jon\AppData\Local\Microsoft\Windows\INetCookies\Low\OLWO3KRW.cookie"
#    driver.add_cookie(cookie)

#LOG in page
    url_0="https://marketchameleon.com/Account/Login"
    driver.get(url_0)
    time.sleep(1)   
    username = driver.find_element_by_id("UserName")
    password = driver.find_element_by_id("Password")
    username.send_keys("boxofjon@yahoo.com")
    password.send_keys("Mima2008@")
    submit=driver.find_element_by_xpath('//input[@class="site-login-control btn"]')
    time.sleep(2) 
    submit.send_keys('\n') 

    driver.get(url_1)
    time.sleep(1) 
#<input type="submit" value="Log in" class="site-login-control btn">
# save cookie
#    pickle.dump(driver.get_cookies() , open(r"c:\pycode\Github\Marketchameleon.pkl","wb"))
#load cookie
#    for cookie in pickle.load(open(r"c:\pycode\Github\Marketchameleon.pkl", "rb")):
#        driver.add_cookie(cookie)
#    ol=driver.find_element_by_class_name("register-flyer-close")
#    ol=driver.find_element_by_name("div.register-flyer-close::before")
##go to page -REVIEW REPORT
#    driver.get(url_4)
#    driver.find_element_by_xpath('//*[@id="symnav_SymbolReview"]/a').click()    
#    time.sleep(1)
##    c_rtn=driver.find_elements_by_xpath("//*[text()='Price Performance:']/following-sibling::p")
##    n=[]
##    for i in c_rtn:
##        n.append(i.get_attribute('textContent').splitlines())
##    #driver.quit
##    OHLC=n[6][1].strip() + n[6][2].strip()+n[6][3].strip()   
##    put=n[13][1].strip() + n[13][2].strip()
##    skew_v=n[16][1].strip() + n[16][2].strip() +n[16][3].strip()+n[16][4].strip()
##    div_o=n[24][1].strip() + n[24][2].strip()
##    note=OHLC + '\n' + put + '\n' + skew_v + '\n' + div_o
##    strad=driver.find_elements_by_xpath('//*[@id="symov_main_content"]/div/div[1]/table/tbody/tr[5]/')
#    s1=driver.find_elements_by_xpath('//*[@id="symov_main_content"]/div/div[1]/table/tbody/tr[5]/td[1]')   
#    s1t= s1[0].get_attribute('textContent')
#    print (s1t)    
#    driver.quit
     #c_rtn, note#, c_hv, c_iv, c_div
def get_option_simple(ticker=''):
#ref: http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/ 
    from lxml import html
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException   
    from selenium.webdriver.chrome.options import Options
    chrome_options=Options()
    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_0_7_overlay_remove.crx")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
    url="https://marketchameleon.com/Overview/"
    url_1=url+"%s"%ticker
    url_2=url_1+"/OptionSummary/"
    url_3=url_1+"/StockPosts/"
    url_4=url_1+"/SymbolReview/"
    gecko="c:\\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="c:\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
#LOG IN
    url_0="https://marketchameleon.com/Account/Login"
    driver.get(url_0)
    time.sleep(1)   
    username = driver.find_element_by_id("UserName")
    password = driver.find_element_by_id("Password")
    username.send_keys("freeofjon@gmail.com")
    password.send_keys("kevin2008")
    submit=driver.find_element_by_xpath('//input[@class="site-login-control btn"]')
    time.sleep(2) 
    submit.send_keys('\n')         
        
#go to url_1
    driver.get(url_1)
    time.sleep(1)   
    try:
        ol=driver.find_element_by_class_name("register-flyer-close")
        ol=driver.find_element
        ol.click()
    except:
        pass
    iv_30_rank=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[6]/span[2]').get_attribute('textContent')
    iv_30s=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[5]/span[2]').get_attribute('textContent')
    hv_1y=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[4]/span[2]').get_attribute('textContent')
    hv_22=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[3]/span[2]').get_attribute('textContent')  

    v_stk=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[2]/span[2]').get_attribute('textContent')
    v_stk_avg=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[3]/span[2]').get_attribute('textContent')
    v_opt=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[4]/span[2]').get_attribute('textContent')
    v_opt_avg=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[5]/span[2]').get_attribute('textContent')
    v_stk=v_stk.replace(",","")  
    v_stk_avg=v_stk_avg.replace(",","")    
    v_opt=v_opt.replace(",","")    
    v_opt_avg=v_opt_avg.replace(",","")    
    v_stk_pct='{:.1%}'.format(float(v_stk)/float( v_stk_avg))
    try:
        v_opt_pct='{:.1%}'.format(float(v_opt)/ float(v_opt_avg))
    except:  #v_op is zero
        pass
#    etf_o=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[1]/span/a').get_attribute('textContent')
#    corr_etf=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[4]').get_attribute('textContent')
#    p_chg_etf=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[7]/span').get_attribute('textContent')
#    p_chg=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[1]/div[2]/div[2]/p[3]').get_attribute('textContent')
#    p=driver.find_element_by_xpath('//*[@id="overview_last_price"]').get_attribute('textContent')
    earn_date= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[4]/span[2]').get_attribute('textContent')    
    div= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[2]/span[2]').get_attribute('textContent')    
    yld= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[3]/span[2]').get_attribute('textContent')    
    pe= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[5]/span[2]').get_attribute('textContent')    


    iv_30=float(iv_30s.split(" ")[0])   
    iv_30_chg=float(iv_30s.split(" ")[1])
    iv_30_chg='{:.1%}'.format(iv_30_chg/ iv_30)
    iv_30_rank=iv_30_rank.split(" ")[0]
    iv_hv=float(iv_30)/float(hv_22)
    hv_rank=float(hv_22)/float(hv_1y)
    names=['iv_30', 'iv_30_rank', 'iv_hv', 'hv_1y', 'hv_22', 'hv_rank',   \
        'v_stk', 'v_stk_avg', 'v_opt', 'v_opt_avg', 'v_stk_pct','v_opt_pct', \
        'earn_date', 'div', 'yield','pe']
    values=[iv_30, iv_30_rank, iv_hv,  hv_1y, hv_22, hv_rank,\
            v_stk, v_stk_avg, v_opt, v_opt_avg, v_stk_pct, v_opt_pct, \
        earn_date, div, yld,pe]    
        
    do=pd.DataFrame(data=[], columns=names)    
    do.loc[0,names]=values
    do['ticker']=ticker
    driver.quit
    return do