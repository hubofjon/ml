# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 11:13:46 2017
Purpose: main program
Functions:  daily_run_eod
Imported:
    1. update_price_eod
    2. daily_run_eod
    3. entry_check

@author: jon
"""
import pandas as pd
import numpy as np
import datetime as datetime
from pandas import date_range
import pandas_datareader.data as web
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import sqlite3 as db
import sys, os
# %matplotlib inline
import time
import pandas.io.sql as pd_sql

#import pickle
#from pandas.tseries.offsets import BDay
#import bs4
#import requests
#import re
from timeit import default_timer as timer
from termcolor import colored, cprint
#from yahoo_finance import Share
import warnings
 
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
import statsmodels.api as sm
#from lxml import html
#from selenium import webdriver
#from selenium.webdriver.common.by import By
#from selenium.webdriver.support.ui import WebDriverWait
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.webdriver.common.keys import Keys
#from selenium.common.exceptions import TimeoutException
#from wallstreet import Stock, Call, Put
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
old_stdout=sys.stdout
#read stock from textfile or list


#Import functions
import P_commons
from P_commons import read_sql, to_sql_append, to_sql_replace
from P_update_price import update_price_eod
from P_play import play_run_daily
from P_track import trade_track, options_track, options_track_new
from P_intel import get_trades_marketbeat, view_unpv, marketbeat, get_ta, get_Share, \
        get_tsm, get_earning_date, get_share_nasdaq
from P_fwdtest import fwd_test, fwd_test_model
from P_options import get_option
from P_stat import stat_run_new, stat_view, stat_tm_plot
from P_update_price import update_pv_eod, trig_run, vpj_plot, trig_run_1

from pandas.tseries.offsets import BDay
today=datetime.datetime.today()
todate=today.date()
LBdate=(todate-BDay(1)).date()
#todate=datetime.date(2017,11,7)


capital=15000
DF_sp500=pd.read_csv('c:\\pycode\pyprod\constituents.csv')
df_etf=pd.read_csv('c:\\pycode\pyprod\etf.csv')
df_sp500=DF_sp500.ix[:,0] #serie
df_etf=df_etf.ix[:,0]

def daily_run_eod():
    update_price_eod('etf')
    df_play_etf=play_run_daily(todate, 'etf', 'prod')

    update_price_eod('sp500')
    df_play=play_run_daily(todate, 'sp500', 'prod')
#    dt=trade_track('sp500', todate)
#
#    dt['weigh']=dt['erisk']/(dt['erisk'].sum())
#    dt['weigh']=pd.Series(['{0:.0%}'.format(val) for val in (dt['weigh'])])
#    dt['allo']=pd.Series(['{0:.0%}'.format(val) for val in (dt['erisk']/capital)])
#    pd.set_option('display.expand_frame_repr', False)
#    print (colored('Trade Dashboard', 'magenta', 'on_cyan'))
#    print (dt[['ticker','play', 'erisk', 'weigh', 'allo', 'delta', 'epnl_pct', 'epnl', \
#        'days_left', 'pct_estrike_1','rsi_chg', 'p_pct', 'v_pct', 'ex_div']])
#    print (dt[[ 'ticker', 'si', 'beta', 'sec', 'rrtn_22_ts', 'rrtn_22_sm','win_5', 'win_10']])
#    pd.set_option('display.expand_frame_repr', True)
#    
#    print(colored("total risk:   %s" %dt['erisk'].sum(), 'red'))
#    print(colored("total epnl:   %s" %dt['epnl'].sum(), 'blue'))
#    print(colored("invested:  %s"% (dt['erisk'].sum()/capital), 'magenta'))
    do=options_track_new('sp500')
#    print (colored("option notes", 'magenta', 'on_green') )
#    for i in notes:
#        print(i, '\n')
#    print (colored("posts", 'magenta', 'on_green') )
#    for i in posts:
#        print(i, '\n')
#        print (colored("beat news", 'magenta', 'on_green') )    
 #   get_trades_marketbeat()
  #  view_unpv('etf', todate)
    fwd_test('sp500')  
    fwd_test_model(6)
    fwd_test_model(5)
    print("daily_run_eod completed")  
    print("watchlist:  psx")

    stat_view()
    

#    view_unpv('sp500', todate)
# --------0----EXECUTION ----------------------
#trade_entry('etf') 
#trade_entry('sp500') 
RUN_COUNT='n'
RUN_COUNT=input("todate? -- Run EOD?  yes/n:    ")
if RUN_COUNT=='yes':
#    daily_run_eod()
   #if today is not biz date 
#    todate=LBdate
#    todate=datetime.date(2018, 6, 1)
    update_pv_eod('etf')
    update_pv_eod('sp500')
    update_price_eod('etf')
    update_price_eod('sp500')
    trig_run_1('sp500')
    trig_run_1('etf')
    vpj_plot('sp500')
    vpj_plot('etf')
    ds_etf=stat_run_new(todate, 'etf', env='prod')
    pd.set_option('display.expand_frame_repr', False)
    stat_view()
    stat_tm_plot()
    pd.set_option('display.expand_frame_repr', True)
    RUN_COUNT='n'
    
def trade_entry(underlying):
    if underlying =='sp500':
        df_trade=pd.read_excel(open(r'c:\pycode\trade.xlsx','rb'))
    #df_trade=pd.read_csv('G:\Trading\Trade_python\pycode\\trade.xlsx')
        to_sql_append(df_trade, 'tbl_trade')  #log trades and track performance
        to_sql_append(df_trade, 'tbl_trade_bkup') #keep trde only
        print ("trade is saved in tbl_trade")
    elif underlying == 'etf':
        df_trade=pd.read_excel(open(r'c:\pycode\trade_etf.xlsx','rb'))
    #df_trade=pd.read_csv('G:\Trading\Trade_python\pycode\\trade.xlsx')
        to_sql_append(df_trade, 'tbl_trade_etf')  #log trades and track performance
        to_sql_append(df_trade, 'tbl_trade_etf_bkup') #keep trde only
        print ("trade is saved in tbl_trade_etf")   
    else:
        print ("trade_entry missing env")
        exit    
#dates = pd.date_range('1/1/2000', periods=8)
#df = pd.DataFrame(np.random.randn(8, 4), index=dates, columns=['A', 'B', 'C', 'D'])
        #eoddata, boxofjon@gmail.com, Mima2008@