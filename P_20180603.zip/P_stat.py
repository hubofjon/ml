# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 11:50:54 2017
purpose:
Functions: 
    1. stat_run
    2. stat_rank

@author: jon
"""
import pandas as pd
import numpy as np 
import datetime as datetime
import scipy.stats as stats
import sqlite3 as db
pd.options.display.float_format = '{:.2f}'.format
from P_commons import to_sql_append, to_sql_replace, read_sql

DF_sp500=pd.read_csv('c:\\pycode\pyprod\constituents.csv')
DF_etf=pd.read_csv('c:\\pycode\pyprod\etf.csv')
df_sp500=DF_sp500.ix[:,0] #serie
df_etf=DF_etf.ix[:,0]

from pandas.tseries.offsets import BDay
today=datetime.datetime.today()
todate=today.date()
LBdate=(todate-BDay(1)).date()


def stat_rank(df): #generic
    df['sharpe_5_pct']=df['sharpe_5'].rank(pct=True)  
    #this is abs rtn, as goal is to measure vol
    df['rtn_5_pct']=df['rtn_5'].rank(pct=True)    
    df['sharpe_22_pct']=df['sharpe_22'].rank(pct=True)    
    df['rtn_22_pct']=df['rtn_22'].rank(pct=True)
    df['sharpe_66_pct']=df['sharpe_66'].rank(pct=True)    
    df['rtn_66_pct']=df['rtn_66'].rank(pct=True)
    df['p_252_pct']=df['p_252'].rank(pct=True)
#    df['p_10_pct']=np.abs(df['p_10']).rank(pct=True)
    df['p_22_pct']=np.abs(df['p_22']).rank(pct=True)
#    df['p_66_pct']=np.abs(df['p_66']).rank(pct=True)
    df['hv_5_pct']=np.abs(df['hv_5']).rank(pct=True)
    df['hv_22_pct']=np.abs(df['hv_22']).rank(pct=True)
    df['hv_66_pct']=np.abs(df['hv_66']).rank(pct=True)
    df['hv_252_pct']=np.abs(df['hv_252']).rank(pct=True)
    df['hv_m2y_pct']=np.abs(df['hv_m2y']).rank(pct=True)
    df['rtn_ma66_pct']=df['rtn_ma66'].rank(pct=True)  
    df['rtn_ma252_pct']=df['rtn_ma252'].rank(pct=True)
    
    df.loc[pd.isnull(df.rtn_5_pct), 'rtn_5_pct']=0.5
    df.loc[pd.isnull(df.rtn_22_pct), 'rtn_22_pct']=0.5
    df.loc[pd.isnull(df.rtn_66_pct), 'rtn_66_pct']=0.5
    
    df['rtn_ma510_pct']=df['rtn_ma510'].rank(pct=True)
    df['rtn_ma1022_pct']=df['rtn_ma1022'].rank(pct=True)    
    df['rtn_ma2266_pct']=df['rtn_ma2266'].rank(pct=True)
    df['rtn_ma66252_pct']=df['rtn_ma66252'].rank(pct=True)
    
    df.loc[pd.isnull(df.rtn_ma510_pct), 'rtn_ma510_pct']=0.5
    df.loc[pd.isnull(df.rtn_ma1022_pct), 'rtn_ma1022_pct']=0.5
    df.loc[pd.isnull(df.rtn_ma2266_pct), 'rtn_ma2266_pct']=0.5
    df.loc[pd.isnull(df.rtn_ma66252_pct), 'rtn_ma66252_pct']=0.5
    
    return df

# in: tbl_price /out:tbl_stat_hist
def stat_run(q_date, underlying, env='prod'): #underlying= sp500 or etf
#read_sql, to_sql_replace, stat_rank
    p_date=q_date-datetime.timedelta(380)
    #pick up price in the range only
    if underlying=='sp500':
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price", p_date, q_date)
    elif underlying=='etf':
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price_etf", p_date, q_date)
    else:
        print("stat_run missing underlying")
        exit
    #query="SELECT * FROM '%s' wHERE date >= '%s' " %("tbl_price", p_date)
    df=read_sql(query, q_date)
    df.sort_index(axis=0) #sort the price from old date to latest date
    df=df.fillna(0)
    df['date']=q_date
    # convert date column to index index
    df.set_index('date', inplace=True) 
#test corr() of 6month 
    df_corr=df.tail(132).corr().ix['SPY',:]   
    #get stat data
    df_stat=pd.DataFrame()
    df_st=pd.DataFrame()
    df0=pd.DataFrame()

    len=df.shape[1]  
    #iterate thru columns, each column is a ticker
    #if iterate thru rows then use below code
# for index, row in df.iterrows():
#   ....:     print row['c1'], row['c2']   
    
    #for columns in df (another way)
    for c in range (0,len):
        df0=df.iloc[:,c].describe()
        #df0['ticker']=df.iloc[0:,c].name
        df0['ticker']=df.columns[c]
#for PROD, always get the latest price
#for TEST, how?        
        df0['corr']=df_corr[df.columns[c]]      #read corr with SPY
        df0['close_qdate']=df.iloc[-1,c]  #last row is latest price
        df0['close_22b']=df.iloc[-22,c]
        df0['close_66b']=df.iloc[-66,c]
        df0['mean_5']=df.iloc[:,c].tail(5).mean()
        df0['mean_10']=df.iloc[:,c].tail(10).mean()
        df0['mean_22']=df.iloc[:,c].tail(22).mean()
        df0['mean_66']=df.iloc[:,c].tail(66).mean()
        df0['mean_252']=df.iloc[:,c].tail(252).mean()   
        df0['hi_5']=df.iloc[:,c].tail(5).max()
#        df0['hi_10']=df.iloc[:,c].tail(10).max()
        df0['hi_22']=df.iloc[:,c].tail(22).max()
#        df0['hi_44']=df.iloc[:,c].tail(22).max()
        df0['hi_66']=df.iloc[:,c].tail(66).max()
        df0['hi_252']=df.iloc[:,c].tail(252).max()  
        df0['lo_5']=df.iloc[:,c].tail(5).min()
#        df0['lo_10']=df.iloc[:,c].tail(10).min()
        df0['lo_22']=df.iloc[:,c].tail(22).min()
#        df0['lo_44']=df.iloc[:,c].tail(22).min()
        df0['lo_66']=df.iloc[:,c].tail(66).min()
        df0['lo_252']=df.iloc[:,c].tail(252).min()  
        df0['rtn_5']=df.iloc[-1,c]/df.iloc[-5,c]-1 
        df0['rtn_22']=df.iloc[-1,c]/df.iloc[-22,c]-1 
        df0['rtn_66']=df.iloc[-1,c]/df.iloc[-66,c]-1 
        #get hv_5
        #try:
            #x=(df.iloc[:,c]/df.iloc[:,c].shift(1))
            #print (x.dtype)
        log_rtn=np.log(df.iloc[:,c]/df.iloc[:,c].shift(1))
          #pass
        #df0['log_rtn']=np.log(df.columns[c]/df.columns[c].shift(1))
        #log_rtn=np.log(df.iloc[:,c]/df.iloc[:,c].shift(1))
        df0['hv_5']=np.sqrt(252*log_rtn.tail(5).var())
        df0['hv_10']=np.sqrt(252*log_rtn.tail(10).var())
        df0['hv_22']=np.sqrt(252*log_rtn.tail(22).var())
        df0['hv_66']=np.sqrt(252*log_rtn.tail(66).var())
        df0['hv_252']=np.sqrt(252*log_rtn.tail(252).var())
        #get normal testing
#        tp_10=stats.normaltest(log_rtn[-11:-1])
        tp_22=stats.normaltest(log_rtn[-23:-1])
#        tp_66=stats.normaltest(log_rtn[-67:-1])
        tp_252=stats.normaltest(log_rtn[-252:-1])
#        df0['p_10']=tp_10[1]
        df0['p_22']=tp_22[1]
#        df0['p_66']=tp_66[1]  
        df0['p_252']=tp_252[1]
#        df0['beta']=DF_sp500[DF_sp500['SYMBOL']==df0['ticker']].beta.values[0]
#hi_new, lo_new
        if df0['close_qdate']==df0['hi_252']:
            df0['hi_new']='hi_252'
        elif df0['close_qdate']==df0['hi_66']:
            df0['hi_new']='hi_66'
        elif df0['close_qdate']==df0['hi_22']:
            df0['hi_new']='hi_22'
        else:
            df0['hi_new']=np.nan
    
        if df0['close_qdate']==df0['lo_252']:
            df0['lo_new']='lo_252'
        elif df0['close_qdate']==df0['lo_66']:
            df0['lo_new']='lo_66'
        elif df0['close_qdate']==df0['lo_22']:
            df0['lo_new']='lo_22'
        else:
            df0['lo_new']=np.nan        
        
        df_st=df_st.append(df0)
    df_st=stat_beta(df_st)     
    df_stat=df_st.set_index('ticker') #ticker is set to be index
    df_stat['date']=q_date  
    df_stat['sharpe_5']=df_stat['rtn_5']/df_stat['hv_5']
    df_stat['sharpe_22']=df_stat['rtn_22']/df_stat['hv_22']
    df_stat['sharpe_66']=df_stat['rtn_66']/df_stat['hv_66']
    df_stat['hv_m2y']=df_stat['hv_22']/df_stat['hv_252']
    df_stat['mean_510']=df_stat['mean_5']>df_stat['mean_10']
    df_stat['mean_1022']=df_stat['mean_10']>df_stat['mean_22']
    df_stat['mean_2266']=df_stat['mean_22']>df_stat['mean_66']
    df_stat['mean_66252']=df_stat['mean_66']>df_stat['mean_252']
    #below added on Jan.2, 2017
    df_stat['rtn_ma66']=df_stat['mean_5']/df_stat['mean_66']-1
    df_stat['rtn_ma252']=df_stat['mean_5']/df_stat['mean_252']-1
    
    df_stat['rtn_ma510']=df_stat['mean_5']/df_stat['mean_10']-1
    df_stat['rtn_ma1022']=df_stat['mean_10']/df_stat['mean_22']-1   
    df_stat['rtn_ma2266']=df_stat['mean_22']/df_stat['mean_66']-1
    df_stat['rtn_ma66252']=df_stat['mean_66']/df_stat['mean_252']-1     
    
    #enrich with 1sig forward expected price move    
    df_stat['p_22_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(22)/ np.sqrt(252)
    df_stat['p_44_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(44)/ np.sqrt(252)
    df_stat['p_66_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(66)/ np.sqrt(252)

    df_stat=stat_rank(df_stat)  
    df_stat=stat_trend(df_stat)
    df_stat=stat_stage(df_stat)

    con_price=(df_stat.close_qdate>25) & (df_stat.close_qdate<200)
    df_stat=df_stat[con_price]
        #overwrite tbl_stat_hist
    if env=='prod' and underlying=='sp500':
        to_sql_replace(df_stat, "tbl_stat")
    elif env=='prod' and underlying=='etf':
        to_sql_replace(df_stat, "tbl_stat_etf")    
    elif env=='test' and underlying=='sp500':
        to_sql_replace(df_stat, "tbl_stat_test")
    elif env=='test' and underlying=='etf':
        to_sql_replace(df_stat, "tbl_stat_etf_test")
   # print ("--- stat_run completed and replaced into tbl_stat_'%s'_'%s'---"%(underlying, env))
    return df_stat

#stat added on for model

def stat_trend(df):
#for update momt, trend_n and trend
    fac_5=1
    fac_10=2
    fac_22=3
    fac_66=4
    df.fillna(0, inplace=True)
    df['trend_n']=fac_22*df['mean_2266']+ fac_10*df['mean_1022']+ \
            fac_5*df['mean_510']+fac_66*df['mean_66252']
    df['trend_n']=df['trend_n'].astype(int)        
    df['trend']=(df['mean_510']*1).astype(str) + (df['mean_1022']*1).astype(str) \
        + (df['mean_2266']*1).astype(str) + (df['mean_66252']*1).astype(str)
#    df['trend']=df['mean_510']+df['mean_1022']+df['mean_2266']+df['mean_66252']    
    df['rtn_ma510_pctn']=(fac_5*10*df['rtn_ma510_pct'])
    df['rtn_ma1022_pctn']= (fac_10*10*df['rtn_ma1022_pct'])#.astype(int) 
    df['rtn_ma2266_pctn']=(fac_22*10*df['rtn_ma2266_pct'])
    df['rtn_ma66252_pctn']=(fac_66*10*df['rtn_ma66252_pct'])  
    
    df['momt']=(df['rtn_ma510_pctn'] + df['rtn_ma1022_pctn'] + \
    df['rtn_ma2266_pctn'] + df['rtn_ma66252_pctn']).astype(int)
    df.loc[df.momt>99, 'momt']=99    

    x=df.describe()
    loc_50=x.index.get_loc('50%')
    df['trend_n_50']= x.loc['50%', 'trend_n']
    df['momt_50']= x.loc['50%', 'momt']    
    df['hv_252_50']= x.loc['50%', 'hv_252'] 
    df['hv_22_50']= x.loc['50%', 'hv_22']     
    df['hv_10_50']= x.loc['50%', 'hv_10'] 
#    
    df=df.drop(['rtn_ma510_pctn','rtn_ma1022_pctn','rtn_ma2266_pctn', 'rtn_ma66252_pctn'], axis=1)
    return df
    
def stat_beta(df):
#add beta 
    DF_sp500=pd.read_csv('c:\\pycode\pyprod\constituents.csv')
    df_etf=pd.read_csv('c:\\pycode\pyprod\etf.csv')
    d0=pd.DataFrame()
    d0[['ticker','beta']]=DF_sp500[['SYMBOL', 'beta']]
    
#    df['beta']=DF_sp500[DF_sp500['SYMBOL']==df['ticker']].beta.values[0]
    df=df.merge(d0, on='ticker', how='left')
    return df

def stat_stage(df): #df- df_stat, before update to tbl_stat
# 1. calculate df_stat stage and con_move
# 2. merge with dh (from previous df_stat)
# 3. apply rules to update ds_stage and stage_date
    df['ticker']=df.index #df_stat index is ticker series
    fac_z=0.02
    
    qry_h="SELECT * FROM tbl_stat"
    dh=read_sql(qry_h, todate)
    dh=dh[['ticker', 'stage', 'stage_date', 'momt', 'trend_n', 'hv_22', 'hv_66', 'hv_252', \
    'rtn_5', 'rtn_22', 'rtn_66', 'mean_5', 'mean_22', 'mean_66', 'hi_5', 'lo_5', 'hi_22', 'lo_22']]    
#merge with dh
    dh.columns=['ticker', 'stage_h', 'stage_date_h', 'momt_h', 'trend_n_h', 'hv_22_h', 'hv_66_h', 'hv_252_h', \
        'rtn_5_h', 'rtn_22_h', 'rtn_66_h', 'mean_5_h', 'mean_22_h', 'mean_66_h',\
        'hi_5_h', 'lo_5_h', 'hi_22_h', 'lo_22_h']
    df=df.merge(dh, on='ticker', how='left') 

    df.rtn_ma522=df.mean_5/df.mean_22-1
    
    con_nap_h= (df.stage_h=='nap')
    con_up_h= (df.stage_h=='up')
    con_dn_h= (df.stage_h =='dn')
    con_null_h=pd.isnull(df.stage_h)
    
    con_stayquiet=(df.hv_22<0.17) & (df.hi_5<df.hi_22) & (df.lo_5> df.lo_22)
    con_hi=df.mean_5>df.hi_22
    con_lo=df.mean_5<df.lo_22
    
    con_nap=(np.abs(df.rtn_ma522)<= fac_z) & con_stayquiet 
    con_up=(df.rtn_ma510> fac_z)  & con_nap_h & con_hi
    con_dn=(df.rtn_ma510< (-fac_z)) & con_nap_h & con_lo
    con_move= con_up | con_dn

# calculate current stage
    df.loc[con_up, 'stage']='up'  #premise is nap identified
    df.loc[con_dn, 'stage']='dn'
    df.loc[con_nap, 'stage']='nap'

#rules , con2, 6, pass
    df.loc[con_nap & con_nap_h, 'stage_date']=df.stage_date_h #con1
    df.loc[con_nap & con_nap_h, 'stage_date']=df['date']  #con2
    df.loc[(~con_nap) & (~con_move) & con_nap_h, 'stage']=np.nan #con3
    df.loc[(~con_nap) & (~con_move) & con_nap_h, 'stage_date']=df['date']
    df.loc[(~con_nap) & (~con_move) & (con_up_h | con_dn_h), 'stage']=df['stage_h']  #con5a, b
    df.loc[(~con_nap) & (~con_move) & (con_up_h | con_dn_h), 'stage_date']=df['stage_date_h']   
    df.loc[(~con_nap) & (con_move) & (con_nap_h), 'stage']=df['stage']  #con7
    df.loc[(~con_nap) & (con_move) & (con_nap_h), 'stage_date']=df['stage_date']
    df.loc[(~con_nap) & ((con_up_h & con_up_h)|(con_dn_h & con_dn_h)), 'stage']=df['stage_h']  #con8, 11
    df.loc[(~con_nap) & ((con_up_h & con_up_h)|(con_dn_h & con_dn_h)), 'stage_date']=df['stage_date_h'] 
    df.loc[(~con_nap) & ((con_up_h & con_dn_h) | (con_dn_h & con_up)), 'stage']=np.nan  #con9, 10
    df.loc[(~con_nap) & ((con_up_h & con_dn_h) | (con_dn_h & con_up)), 'stage_date']=df['date']
    
#save to tbl_stage    
    ds=df[['ticker', 'stage', 'stage_date', 'momt', 'trend_n', 'hv_22', 'hv_66', 'hv_252', \
    'rtn_5', 'rtn_22', 'rtn_66', 'mean_5', 'mean_22', 'mean_66', 'hi_5', 'lo_5', 'hi_22', 'lo_22',\
        'stage_h', 'stage_date_h', 'momt_h', 'trend_n_h', 'hv_22_h', 'hv_66_h', 'hv_252_h', \
        'rtn_5_h', 'rtn_22_h', 'rtn_66_h', 'mean_5_h', 'mean_22_h', 'mean_66_h',\
        'hi_5_h', 'lo_5_h', 'hi_22_h', 'lo_22_h']]              
    to_sql_replace(ds, "tbl_stage")
#    to_sql_append(ds, "tbl_stage_hist")
#drop for save in tbl_play    
    df=df.drop(['stage_h','stage_date_h', 'momt_h', 'trend_n_h', 'hv_22_h', 'hv_66_h', 'hv_252_h', \
        'rtn_5_h', 'rtn_22_h', 'rtn_66_h', 'mean_5_h', 'mean_22_h', 'mean_66_h',\
        'hi_5_h', 'lo_5_h', 'hi_22_h', 'lo_22_h'],1)    
    df=df.set_index(['ticker'])
    return df


def stat_run_new(q_date, underlying, env='prod'): #underlying= sp500 or etf
#read_sql, to_sql_qplace, stat_rank
#stat_trend_new_test use rtn_ma510_avg thus also absolute value, nothing to do with ranking
    
    p_date=q_date-datetime.timedelta(380)
    #pick up price in the range only
    if underlying=='sp500':
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price", p_date, q_date)
    elif (underlying=='etf')|(underlying=='sec')|(underlying=='macro')|(underlying=='ccy'):
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price_etf", p_date, q_date)
    else:
        print("stat_run missing underlying")
        exit
        
    #query="SELECT * FROM '%s' wHERE date >= '%s' " %("tbl_price", p_date)
    df=read_sql(query, q_date)
    df.sort_index(axis=0) #sort the price from old date to latest date
    df=df.fillna(0)
#    df['date']=q_date  #overwrite date as when run the stat_run
    # convert date column to index index
    df.set_index('date', inplace=True) 
#test corr() of 6month 
#    df_corr=df.tail(132).corr().ix['SPY',:]   
    #get stat data
    df_stat=pd.DataFrame()
    df_st=pd.DataFrame()
    df0=pd.DataFrame()

    len=df.shape[1]  
    #iterate thru columns, each column is a ticker
    #if iterate thru rows then use below code
# for index, row in df.iterrows():
#   ....:     print row['c1'], row['c2']   
    
    #for columns in df (another way)
    for c in range (0,len):
        df0=df.iloc[:,c].describe()
        #df0['ticker']=df.iloc[0:,c].name
        df0['ticker']=df.columns[c]
#for PROD, always get the latest price
#for TEST, how?        
#        df0['corr']=df_corr[df.columns[c]]      #read corr with SPY
        df0['close_qdate']=df.iloc[-1,c]  #last row is latest price
        df0['close_22b']=df.iloc[-22,c]
        df0['close_66b']=df.iloc[-66,c]
        df0['mean_5']=df.iloc[:,c].tail(5).mean()
        df0['mean_10']=df.iloc[:,c].tail(10).mean()
        df0['mean_22']=df.iloc[:,c].tail(22).mean()
        df0['mean_66']=df.iloc[:,c].tail(66).mean()
        df0['mean_252']=df.iloc[:,c].tail(252).mean()   
        df0['hi_5']=df.iloc[:,c].tail(5).max()
#        df0['hi_10']=df.iloc[:,c].tail(10).max()
        df0['hi_22']=df.iloc[:,c].tail(22).max()
#        df0['hi_44']=df.iloc[:,c].tail(22).max()
        df0['hi_66']=df.iloc[:,c].tail(66).max()
        df0['hi_252']=df.iloc[:,c].tail(252).max()  
        df0['lo_5']=df.iloc[:,c].tail(5).min()
#        df0['lo_10']=df.iloc[:,c].tail(10).min()
        df0['lo_22']=df.iloc[:,c].tail(22).min()
#        df0['lo_44']=df.iloc[:,c].tail(22).min()
        df0['lo_66']=df.iloc[:,c].tail(66).min()
        df0['lo_252']=df.iloc[:,c].tail(252).min()  
        df0['rtn_5']=df.iloc[-1,c]/df.iloc[-5,c]-1 
        df0['rtn_22']=df.iloc[-1,c]/df.iloc[-22,c]-1 
        df0['rtn_66']=df.iloc[-1,c]/df.iloc[-66,c]-1 
        #get hv_5
        #try:
            #x=(df.iloc[:,c]/df.iloc[:,c].shift(1))
            #print (x.dtype)
        log_rtn=np.log(df.iloc[:,c]/df.iloc[:,c].shift(1))
          #pass
        #df0['log_rtn']=np.log(df.columns[c]/df.columns[c].shift(1))
        #log_rtn=np.log(df.iloc[:,c]/df.iloc[:,c].shift(1))
        df0['hv_5']=np.sqrt(252*log_rtn.tail(5).var())
        df0['hv_10']=np.sqrt(252*log_rtn.tail(10).var())
        df0['hv_22']=np.sqrt(252*log_rtn.tail(22).var())
        df0['hv_66']=np.sqrt(252*log_rtn.tail(66).var())
        df0['hv_252']=np.sqrt(252*log_rtn.tail(252).var())
        #get normal testing
#        tp_10=stats.normaltest(log_rtn[-11:-1])
        tp_22=stats.normaltest(log_rtn[-23:-1])
#        tp_66=stats.normaltest(log_rtn[-67:-1])
        tp_252=stats.normaltest(log_rtn[-252:-1])
#        df0['p_10']=tp_10[1]
        df0['p_22']=tp_22[1]
#        df0['p_66']=tp_66[1]  
        df0['p_252']=tp_252[1]
#        df0['beta']=DF_sp500[DF_sp500['SYMBOL']==df0['ticker']].beta.values[0]
        #hi_new, lo_new
        if df0['close_qdate']==df0['hi_252']:
            df0['hi_new']='hi_252'
        elif df0['close_qdate']==df0['hi_66']:
            df0['hi_new']='hi_66'
        elif df0['close_qdate']==df0['hi_22']:
            df0['hi_new']='hi_22'
        else:
            df0['hi_new']=np.nan
    
        if df0['close_qdate']==df0['lo_252']:
            df0['lo_new']='lo_252'
        elif df0['close_qdate']==df0['lo_66']:
            df0['lo_new']='lo_66'
        elif df0['close_qdate']==df0['lo_22']:
            df0['lo_new']='lo_22'
        else:
            df0['lo_new']=np.nan
#hi_252_days, #lo_252_days
        hi_252=df.iloc[:,c].tail(252).max()
        hi_252_date=(df.iloc[:,c].tail(252)==hi_252).argmax()
#        df0['hi_252_days']=(q_date-pd.to_datetime(hi_252_date).date()).days
        df0['hi_252_days']=pd.bdate_range(pd.to_datetime(q_date), pd.to_datetime(hi_252_date)).size 
        lo_252=df.iloc[:,c].tail(252).max()
        lo_252_date=(df.iloc[:,c].tail(252)==lo_252).argmax()
        df0['lo_252_days']=pd.bdate_range(pd.to_datetime(q_date), pd.to_datetime(lo_252_date)).size 

        df_st=df_st.append(df0)
    df_st=stat_beta(df_st)     
    
    df_stat=df_st.set_index('ticker') #ticker is set to be index
    df_stat['date']=q_date  
    df_stat['sharpe_5']=df_stat['rtn_5']/df_stat['hv_5']
    df_stat['sharpe_22']=df_stat['rtn_22']/df_stat['hv_22']
    df_stat['sharpe_66']=df_stat['rtn_66']/df_stat['hv_66']
    df_stat['hv_m2y']=df_stat['hv_22']/df_stat['hv_252']
    df_stat['mean_510']=df_stat['mean_5']>df_stat['mean_10']
    df_stat['mean_1022']=df_stat['mean_10']>df_stat['mean_22']
    df_stat['mean_2266']=df_stat['mean_22']>df_stat['mean_66']
    df_stat['mean_66252']=df_stat['mean_66']>df_stat['mean_252']
    #below added on Jan.2, 2017
    df_stat['rtn_ma66']=df_stat['mean_5']/df_stat['mean_66']-1
    df_stat['rtn_ma252']=df_stat['mean_5']/df_stat['mean_252']-1
    
    df_stat['rtn_ma510']=df_stat['mean_5']/df_stat['mean_10']-1
    df_stat['rtn_ma1022']=df_stat['mean_10']/df_stat['mean_22']-1   
    df_stat['rtn_ma2266']=df_stat['mean_22']/df_stat['mean_66']-1
    df_stat['rtn_ma66252']=df_stat['mean_66']/df_stat['mean_252']-1     
    
    #enrich with 1sig forward expected price move    
    df_stat['p_22_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(22)/ np.sqrt(252)
    df_stat['p_44_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(44)/ np.sqrt(252)
    df_stat['p_66_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(66)/ np.sqrt(252)
    


    list_sec=['SPY','XLY','XLE','XLF','XLV','XLI','XLB','XLK','XLU','XLP','XRT', 'XHB']
    list_macro=['SPY','EEM', 'GLD','JJC', 'USO','WYDE','HYG', 'JNK', 'TLT',\
        'UUP', 'DBC', 'FLAT', 'VXX', 'SPLV', 'PBP', 'SPHB', 'EMB', 'FXI', 'GDX']
     
    list_ccy=['UUP', 'FXY', 'FXE', 'FXC', 'FXA', 'GLD']
# ranking list only
    if underlying=='sec':    
        df_stat=df_stat.loc[list_sec]
    elif underlying =='macro':
        df_stat=df_stat.loc[list_macro]
    elif underlying=='ccy':
        df_stat=df_stat.loc[list_ccy]
    else:
        pass
    
    df_stat=stat_rank(df_stat)  
    df_stat=stat_trend_new_test(df_stat)
    df_stat=stat_stage_new(df_stat, underlying, env)
    try:
        df_stat=df_stat.drop('^VIX', axis=0)
    except:
        pass
#    con_price=(df_stat.close_qdate>20) & (df_stat.close_qdate<250)
#    df_stat=df_stat[con_price]
        #overwrite tbl_stat_hist
        
#    df_stat.sort_index(inplace=Ture)
    if env=='prod' and underlying=='sp500':
        to_sql_replace(df_stat, "tbl_stat")
    elif env=='prod' and underlying=='etf':
#        df_stat=df_stat.drop('^VIX', axis=0)
        to_sql_replace(df_stat, "tbl_stat_etf")    
        to_sql_append(df_stat, "tbl_stat_etf_hist")
    elif env=='test' and underlying=='sp500':
        to_sql_replace(df_stat, "tbl_stat_test")
    elif env=='test' and underlying=='etf':
#        df_stat=df_stat.drop('^VIX', axis=0)
        to_sql_replace(df_stat, "tbl_stat_etf_test")

    print ("--- stat_run completed and replaced into tbl_stat_'%s'_'%s'---"%(underlying, env))
 
    return df_stat

def stat_stage_new(df, underlying, env): #df- df_stat, before update to tbl_stat
# 1. calculate df_stat stage and con_move
# 2. merge with dh (from previous df_stat)
# 3. apply rules to update ds_stage and stage_date
    df['ticker']=df.index #df_stat index is ticker series
    fac_z=0.02
    if env=='test':
        if underlying=='sp500':    
            qry_h="SELECT * FROM tbl_stat_test"
        elif underlying =='etf':
            qry_h="SELECT * FROM tbl_stat_etf_test"
    elif env=='prod':
        if underlying=='sp500':    
            qry_h="SELECT * FROM tbl_stat"
        elif underlying =='etf':
            qry_h="SELECT * FROM tbl_stat_etf"        
        elif underlying =='sec':
            qry_h="SELECT * FROM tbl_stat_sec"            
        elif underlying =='macro':
            qry_h="SELECT * FROM tbl_stat_macro"      
        elif underlying =='ccy':
            qry_h="SELECT * FROM tbl_stat_ccy"  
        else:
            pass
    dh=read_sql(qry_h, todate)
    dh=dh[['ticker', 'stage', 'stage_date', 'momt', 'momt_n', 'trend_n', 'hv_22', 'hv_66', 'hv_252', \
    'rtn_5', 'rtn_22', 'rtn_66', 'mean_5', 'mean_22', 'mean_66', 'hi_5', 'lo_5', 'hi_22', 'lo_22']]    
# rename previous dh columns
    dh.columns=['ticker', 'stage_h', 'stage_date_h', 'momt_h', 'momt_n_h', 'trend_n_h', 'hv_22_h', 'hv_66_h', 'hv_252_h', \
        'rtn_5_h', 'rtn_22_h', 'rtn_66_h', 'mean_5_h', 'mean_22_h', 'mean_66_h',\
        'hi_5_h', 'lo_5_h', 'hi_22_h', 'lo_22_h']
#merge with current df_stat
    df=df.merge(dh, on='ticker', how='left') 

    df.rtn_ma522=df.mean_5/df.mean_22-1
    
    con_nap_h= (df.stage_h=='nap')
    con_up_h= (df.stage_h=='up')
    con_dn_h= (df.stage_h =='dn')
    con_null_h=pd.isnull(df.stage_h)
    
    con_stayquiet=(df.hv_22<0.17) & (df.hi_5<df.hi_22) & (df.lo_5> df.lo_22)
    con_hi=df.mean_5>df.hi_22
    con_lo=df.mean_5<df.lo_22
    
    con_nap=(np.abs(df.rtn_ma522)<= fac_z) & con_stayquiet 
    con_up=(df.rtn_ma510> fac_z)  & con_nap_h & con_hi
    con_dn=(df.rtn_ma510< (-fac_z)) & con_nap_h & con_lo
    con_move= con_up | con_dn
 
# calculate current stage
    df.loc[con_up, 'stage']='up'  #premise is nap identified
    df.loc[con_dn, 'stage']='dn'
    df.loc[con_nap, 'stage']='nap'

#rules , con2, 6, pass
    df.loc[con_nap & con_nap_h, 'stage_date']=df.stage_date_h #con1
    df.loc[con_nap & con_nap_h, 'stage_date']=df['date']  #con2
    df.loc[(~con_nap) & (~con_move) & con_nap_h, 'stage']=np.nan #con3
    df.loc[(~con_nap) & (~con_move) & con_nap_h, 'stage_date']=df['date']
    df.loc[(~con_nap) & (~con_move) & (con_up_h | con_dn_h), 'stage']=df['stage_h']  #con5a, b
    try:
        df.loc[(~con_nap) & (~con_move) & (con_up_h | con_dn_h), 'stage_date']=df['stage_date_h']  
    except:
        pass
    df.loc[(~con_nap) & (con_move) & (con_nap_h), 'stage']=df['stage']  #con7
    df.loc[(~con_nap) & (con_move) & (con_nap_h), 'stage_date']=df['stage_date']
    df.loc[(~con_nap) & ((con_up_h & con_up_h)|(con_dn_h & con_dn_h)), 'stage']=df['stage_h']  #con8, 11
    try:    
        df.loc[(~con_nap) & ((con_up_h & con_up_h)|(con_dn_h & con_dn_h)), 'stage_date']=df['stage_date_h'] 
    except:
        pass
    df.loc[(~con_nap) & ((con_up_h & con_dn_h) | (con_dn_h & con_up)), 'stage']=np.nan  #con9, 10
    df.loc[(~con_nap) & ((con_up_h & con_dn_h) | (con_dn_h & con_up)), 'stage_date']=df['date']
    
#save to tbl_stage    
    ds=df[['ticker', 'stage', 'stage_date', 'momt', 'momt_n', 'trend_n', 'hv_22', 'hv_66', 'hv_252', \
    'rtn_5', 'rtn_22', 'rtn_66', 'mean_5', 'mean_22', 'mean_66', 'hi_5', 'lo_5', 'hi_22', 'lo_22',\
        'stage_h', 'stage_date_h', 'momt_h','momt_n_h',  'trend_n_h', 'hv_22_h', 'hv_66_h', 'hv_252_h', \
        'rtn_5_h', 'rtn_22_h', 'rtn_66_h', 'mean_5_h', 'mean_22_h', 'mean_66_h',\
        'hi_5_h', 'lo_5_h', 'hi_22_h', 'lo_22_h', 'hi_new', 'lo_new']]     
    
    if underlying=='sp500':    
        to_sql_replace(ds, "tbl_stage")
    elif underlying =='etf':
        to_sql_replace(ds, "tbl_stage_etf")        
    elif underlying =='sec':
        to_sql_replace(ds, "tbl_stage_sec")             
    elif underlying =='macro':
        to_sql_replace(ds, "tbl_stage_macro")      
    elif underlying =='ccy':
        to_sql_replace(ds, "tbl_stage_ccy")   
#    to_sql_append(ds, "tbl_stage_hist")
#drop for save in tbl_play    
    df=df.drop(['stage_h','stage_date_h', 'momt_h', 'momt_n_h', 'trend_n_h', 'hv_22_h', 'hv_66_h', 'hv_252_h', \
        'rtn_5_h', 'rtn_22_h', 'rtn_66_h', 'mean_5_h', 'mean_22_h', 'mean_66_h',\
        'hi_5_h', 'lo_5_h', 'hi_22_h', 'lo_22_h'],1)    
    df=df.set_index(['ticker'])
    names_sm=['trend_n','trend','momt','momt_n',  'stage','stage_date', 'hi_new', 'hi_252_days',\
        'lo_new', 'lo_252_days','hv_252','rtn_22']
    if (underlying =='sec') |(underlying =='macro') | (underlying =='ccy') :      
        df=df[names_sm]
    df=df.fillna('')
    df=df.sort_values(['trend_n', 'momt'], ascending=[True, True])
    return df

def stat_trend_new(df):
#for update momt, trend_n and trend
#mont_n and trend_n is absolute value, nothong to do with ranking
    fac_5=4
    fac_10=3
    fac_22=2
    fac_66=1
    df.fillna(0, inplace=True)
    df['trend_n']=fac_22*df['mean_2266']+ fac_10*df['mean_1022']+ \
            fac_5*df['mean_510']+fac_66*df['mean_66252']
    df['trend_n']=df['trend_n'].astype(int)        
    df['trend']=(df['mean_510']*1).astype(str) + (df['mean_1022']*1).astype(str) \
        + (df['mean_2266']*1).astype(str) + (df['mean_66252']*1).astype(str)
#    df['trend']=df['mean_510']+df['mean_1022']+df['mean_2266']+df['mean_66252']    
    df['rtn_ma510_pctn']=(fac_5*10*df['rtn_ma510_pct'])
    df['rtn_ma1022_pctn']= (fac_10*10*df['rtn_ma1022_pct'])#.astype(int) 
    df['rtn_ma2266_pctn']=(fac_22*10*df['rtn_ma2266_pct'])
    df['rtn_ma66252_pctn']=(fac_66*10*df['rtn_ma66252_pct'])  
    
    df['momt']=(df['rtn_ma510_pctn'] + df['rtn_ma1022_pctn'] + \
    df['rtn_ma2266_pctn'] + df['rtn_ma66252_pctn']).astype(int)
    df.loc[df.momt>99, 'momt']=99    

    x=df.describe()
    loc_50=x.index.get_loc('50%')
    df['trend_n_50']= x.loc['50%', 'trend_n']
    df['momt_50']= x.loc['50%', 'momt']    
    df['hv_252_50']= x.loc['50%', 'hv_252'] 
    df['hv_22_50']= x.loc['50%', 'hv_22']     
    df['hv_10_50']= x.loc['50%', 'hv_10'] 
#    
#    df=df.drop(['rtn_ma510_pctn','rtn_ma1022_pctn','rtn_ma2266_pctn', 'rtn_ma66252_pctn'], axis=1)
    return df
    
def stat_trend_new_test(df):
#for update momt, trend_n and trend
#new2: momt to itself using pure price, not relative ranking
    fac_5=1
    fac_10=2
    fac_22=3
    fac_66=4
    df.fillna(0, inplace=True)
    df['trend_n']=fac_22*df['mean_2266']+ fac_10*df['mean_1022']+ \
            fac_5*df['mean_510']+fac_66*df['mean_66252']
    df['trend_n']=df['trend_n'].astype(int)        
    df['trend']=(df['mean_510']*1).astype(str) + (df['mean_1022']*1).astype(str) \
        + (df['mean_2266']*1).astype(str) + (df['mean_66252']*1).astype(str)
#    df['trend']=df['mean_510']+df['mean_1022']+df['mean_2266']+df['mean_66252']  
        
#    df['rtn_ma510_pctn']=(fac_5*10*df['rtn_ma510_pct'])
#    df['rtn_ma1022_pctn']= (fac_10*10*df['rtn_ma1022_pct'])#.astype(int) 
#    df['rtn_ma2266_pctn']=(fac_22*10*df['rtn_ma2266_pct'])
#    df['rtn_ma66252_pctn']=(fac_66*10*df['rtn_ma66252_pct'])  
#    
#    df['momt']=(df['rtn_ma510_pctn'] + df['rtn_ma1022_pctn'] + \
#    df['rtn_ma2266_pctn'] + df['rtn_ma66252_pctn']).astype(int)
    df['rtn_ma510_avg']=(df['rtn_ma510']*100/5)
    df['rtn_ma1022_avg']=df['rtn_ma1022']*100/10
    df['rtn_ma2266_avg']=df['rtn_ma2266']*100/22
    df['rtn_ma66252_avg']=df['rtn_ma66252']*100/93
#reset base
#    df['rtn_ma510_avg']= df['rtn_ma510_avg']+df['rtn_ma66252_avg']
#    df['rtn_ma1022_avg']=df['rtn_ma1022']+df['rtn_ma66252_avg']
#    df['rtn_ma2266_avg']=df['rtn_ma2266']+df['rtn_ma66252_avg']
#    df['rtn_ma66252_avg']=0
      
    df['rtn_ma510_avg']=df['rtn_ma510_avg'].map('{:,.2f}'.format)
    df['rtn_ma1022_avg']=df['rtn_ma1022_avg'].map('{:,.2f}'.format)
    df['rtn_ma2266_avg']=df['rtn_ma2266_avg'].map('{:,.2f}'.format)
    df['rtn_ma66252_avg']=df['rtn_ma66252_avg'].map('{:,.2f}'.format)
    
    df['momt_n']=df['rtn_ma510_avg'].astype(float)*fac_5 + df['rtn_ma1022_avg'].astype(float)*fac_10 \
        + df['rtn_ma2266_avg'].astype(float)*fac_22 + df['rtn_ma66252_avg'].astype(float)*fac_66  
    df['momt']=df['rtn_ma510_avg'].astype(str) + '|'+ df['rtn_ma1022_avg'].astype(str)\
        + '|' + df['rtn_ma2266_avg'].astype(str)+ '|' + df['rtn_ma66252_avg'].astype(str)
  
    df.loc[df.momt_n>99, 'momt_n']=99    

    x=df.describe()
    loc_50=x.index.get_loc('50%')
    df['trend_n_50']= x.loc['50%', 'trend_n']
    df['momt_50']= x.loc['50%', 'momt_n']    
    df['hv_252_50']= x.loc['50%', 'hv_252'] 
    df['hv_22_50']= x.loc['50%', 'hv_22']     
    df['hv_10_50']= x.loc['50%', 'hv_10'] 
    df.drop(['rtn_ma510_avg', 'rtn_ma1022_avg','rtn_ma2266_avg','rtn_ma66252_avg'], axis=1, inplace=True)
#    df=df.drop(['rtn_ma510_pctn','rtn_ma1022_pctn','rtn_ma2266_pctn', 'rtn_ma66252_pctn'], axis=1)
    return df

def stat_view(): #macro, sec, ccy, 
    print("stat_view started")
    qry="SELECT * FROM tbl_stat_etf" 
#ok for ccy,macro as stat is based on abs values
    df=read_sql(qry, todate)
      #, 'hi_252_days', 'lo_252_days']
    list_macro=['SPY','EEM', 'GLD','WYDE','HYG', 'TLT', 'UUP', 'DBC', 'FLAT', 'VXX', 'SPHB']
 
    list_sec=['SPY','XLY','XLE','XLF','XLV','XLI','XLB','XLK','XLU','XLP','XRT', 'XHB']

    list_ccy=['UUP', 'FXY', 'FXE', 'FXC', 'FXA']

    de=DF_etf.ix[:,:2]
    de.columns=['ticker', 'type']
#    if "%s"%mode in ['sec', 'macro', 'ccy']:
#        lst="list_%s"%mode
#        df_tmp=de.loc[de['ticker'].isin(lst)]
#        ds="df_$s"%mode
#        ds=df.merge(df_tmp, on='ticker', how='right')
#        ds=ds[show]
    delta=0
    df_macro=de.loc[de.ticker.isin(list_macro)]
 #   df_macro=stat_delta(df_macro, delta)
    df_macro=df.merge(df_macro, on='ticker', how='right')
    
    df_sec=de.loc[de.ticker.isin(list_sec)]
#    df_sec=stat_delta(df_sec, delta)
    df_sec=df.merge(df_sec, on='ticker', how='right')
    
    df_ccy=de.loc[de.ticker.isin(list_ccy)]
    df_ccy=df.merge(df_ccy, on='ticker', how='right')    
    show=['ticker', 'trend_n', 'momt_n', 'trend', 'momt', 'type', 'hv_252', 'hv_22',\
          'stage','hi_new', 'lo_new'] 
    print(df_macro[show])
    print(df_sec[show])
    print(df_ccy[show])



def stat_delta(df, delta):
        df.sort_values(['date','ticker'], ascending=[False,True])
        df_delta=pd.DataFrame()
        for tk in df['ticker']:
            dtk=df[df.ticker==tk]
            dtk.sort_values(['date','ticker'], ascending=[False,True])
            if dtk.shape[0]<(1+delta):
                print("not enough data in stat_delta: %s"%tk)
                pass
            dtk['momt_n_chg']=dtk['momt_n']-dtk['momt_n'].shift(delta)
            dtk['trend_n_chg']=dtk['trend_n']-dtk['trend_n'].  shift(delta)
            df_delta=df_delta.append(dtk)
        df_delta[df_delta.momt_n_chg==0]['momt_n_chg']  =''
        return df_delta

def stat_tm_plot():
    qry="SELECT * FROM tbl_stat_etf_hist"
    df=read_sql(qry, todate)
    list_macro=['SPY', 'GLD','HYG', 'TLT', 'SPHB']
    list_global=['EEM', 'SPY','ASHR']
    list_sec=['XLF','XLI','XLK','XLU', 'XLE']
    list_ccy=['UUP', 'FXY', 'FXE', 'FXC', 'FXA']       

    list_all=[list_macro, list_global, list_sec, list_ccy]

    for i in range(len(list_all)):
        di=df[df.ticker.isin(list_all[i])]
        di.fillna(method='ffill', inplace=True)  #fpr missing value/date
 #       print(list(set(di['ticker'])))
        tm_plot(di)


def tm_plot(df):  #plot trend_n and momt_n delta change
    import matplotlib.pyplot as plt
    df=df[['date','ticker','trend_n','momt_n']]
    tickers=df['ticker'].values
    tickers=list(set(tickers))    
#    for t in tickers:
#        fig,ax=plt.subplots(figsize=(16,3))
#        dt=df
#        df=df[df.ticker==t]
#        df['momt_chg']=df['momt_n']-df['momt_n'].shift(1)
#        df['trend_chg']=df['trend_n']-df['trend_n'].shift(1)
#        x=df['date']
#        y=df['trend_chg']
#        x_pos=[i for i, _ in enumerate(x)]
#        plt.bar(x_pos,y)
#        plt.show()
#        
#        df=dt
    N=len(set(df['date']))
    ind=np.arange(N)
    ind=np.sort(ind)
    width=0.2
    n=0
    x_label=list(set(df['date']))
    x_label.sort()
    fig=plt.figure(figsize=(16,7))
    ax1=fig.add_subplot(111)
    plt.ylabel('trend_chg')
    plt.xticks(ind+width/2, x_label, rotation=90)   
    ax2=ax1.twinx()
    plt.ylabel('momt_chg')
    plt.xticks(ind+width/2, x_label, rotation=90)      
    header=[]
    for t in tickers:
        dt=df[df.ticker==t]
        dt=dt.sort_values(['date'], ascending=True)
        dt['momt_chg']=dt['momt_n']-dt['momt_n'].shift(1)
        dt['trend_chg']=dt['trend_n']-dt['trend_n'].shift(1)
        ax1.bar(ind+n*width, dt['trend_chg'], width, label=t)
        ax1.legend(loc="upper right")
        ax2.plot(ind+n*width, dt['momt_chg'], label=t)
        ax1.grid(True)
        n+=1
        header.append(t)
        header.append(dt.tail(1)['trend_n'].values[0])
    plt.title(header)
    plt.show()
    