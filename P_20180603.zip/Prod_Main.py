# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 11:13:46 2017
Purpose: main program
Functions:  daily_run_eod
Imported:
    1. update_price_eod
    2. daily_run_eod
    3. entry_check

@author: jon
"""
import pandas as pd
import numpy as np
import datetime as datetime
from pandas import date_range
import pandas_datareader.data as web
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import sqlite3 as db
import sys, os
# %matplotlib inline
import time
import pandas.io.sql as pd_sql
#import pickle
#from pandas.tseries.offsets import BDay
#import bs4
#import requests
#import re
from timeit import default_timer as timer
from termcolor import colored, cprint
#from yahoo_finance import Share
import warnings
 
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
import statsmodels.api as sm
#from lxml import html
#from selenium import webdriver
#from selenium.webdriver.common.by import By
#from selenium.webdriver.support.ui import WebDriverWait
#from selenium.webdriver.support import expected_conditions as EC
#from selenium.webdriver.common.keys import Keys
#from selenium.common.exceptions import TimeoutException
#from wallstreet import Stock, Call, Put
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
old_stdout=sys.stdout
#read stock from textfile or list


#Import functions
import PROD_commons
from PROD_commons import read_sql, to_sql_append, to_sql_replace
import PROD_update_price
from PROD_update_price import update_price_eod
import PROD_play
from PROD_play import play_run_daily
from PROD_track import trade_track, options_track
from PROD_intel import get_trades_marketbeat, view_unpv, marketbeat, get_ta, get_Share, \
        get_tsm, get_earning_date, get_share_nasdaq
from PROD_fwdtest import fwd_test
from PROD_options import get_option

capital=22000
DF_sp500=pd.read_csv('G:\\Trading\Trade_python\pycode\pyprod\constituents.csv')
df_etf=pd.read_csv('G:\\Trading\Trade_python\pycode\pyprod\etf.csv')
df_sp500=DF_sp500.ix[:,0] #serie
df_etf=df_etf.ix[:,0]


def daily_run_eod():
#    update_price_eod('sp500')
#    df_play=play_run_daily(todate, 'sp500', 'prod')
    dt=trade_track('sp500', todate)
    update_price_eod('etf')
#    dt_etf=trade_track('etf', todate)
#    do_etf, posts_etf=options_track('etf')
#    dt=dt.append(dt_etf)
    dt['weigh']=dt['erisk']/(dt['erisk'].sum())
    #pd.set_option('display.expand_frame_repr', False)
    print (colored('track stat', 'magenta', 'on_blue'))
    print (dt[['ticker','erisk', 'weigh', 'delta', 'epnl_pct', 'epnl', \
        'alert_stop','alert_sig', 'alert_exit','alert_div']])
    print (dt[['ticker', 'days_left', 'pct_estrike_1','rsi_chg', 'p_pct', 'v_pct', 'ex_div']])
    print (dt[[ 'ticker', 'si', 'beta', 'corr_new', 'sec', 'rrtn_22_ts', 'rrtn_22_sm','win_5', 'win_10']])
   # print (dt[[  'win_5', 'win_10']])
    pd.set_option('display.expand_frame_repr', True)
    
    print(colored("total risk:   %s" %dt['erisk'].sum(), 'red', 'on_cyan'))
    print(colored("total epnl:   %s" %dt['epnl'].sum(), 'red', 'on_green'))
    print(colored("invested:  %s"% (dt['erisk'].sum()/capital), 'magenta'))
    do, posts, notes=options_track('sp500')
    print (colored("option notes", 'magenta', 'on_green') )
    print (notes)
    print (colored("posts", 'magenta', 'on_green') )
    print(posts)
    get_trades_marketbeat()
         
    view_unpv('sp500', todate)
  #  view_unpv('etf', todate)
    fwd_test('sp500')  
    print("daily_run_eod completed")  
    

# --------0----EXECUTION ----------------------
#trade_entry('etf') 
#trade_entry('sp500') 
today=datetime.datetime.today()
todate=today.date()
ldate=todate

RUN_COUNT='n'
RUN_COUNT=input("commented? update EOD, exit_target, delta, new trades? -- Run EOD?  yes/n:    ")
if RUN_COUNT=='yes':
    print (colored('Hedged Sure Profit by Expiry', 'red', 'on_cyan'))
    print (colored('>>>>> Reset RUN_COUNT  <<<<<', 'red'))
#    daily_run()
    daily_run_eod()
    RUN_COUNT='n'


def entry_check(ticker=''):
    todate=datetime.date.today()
    ticker=ticker.upper()
    
    qry_h="SELECT * FROM tbl_play_hist WHERE ticker='%s' "%ticker
    df=read_sql(qry_h,todate)
    df.sort('date', ascending =False, inplace=True)
    df['rtn_22_fwd']=df['p_22_fwd']/df['close_qdate']-1
    df['p_22_sig']=df['p_22_sig'].astype(float)
    df['hv_m2y']=df['hv_m2y'].astype(float)
    dh=df[[ 'date','play', 'close_qdate', 'p_22_sig', 'rtn_22_fwd', \
    'p_22_fwd', 'hv_m2y', 'win_22', 'sec', 'rrtn_22_ts', 'rrtn_22_sm']]
    print (ticker, "play history")
    pd.set_option('display.expand_frame_repr', False)
    print(dh)
    dp=df.head(1)
    try:
        rating, p_target, rating_1, rating_2, news_1, news_2, news_3,\
            ins, ins_1, ins_2=marketbeat(ticker)
    except:
        print("error marketbeat:  ", ticker)
        rating, p_target, rating_1, rating_2, news_1, news_2, news_3,\
            ins, ins_1, ins_2=('',)*10
    try:
        ta=get_ta(ticker)
    except:
        ta=0
        pass
    dp['momt']=dp['mean_510']+dp['mean_1022']+dp['mean_2266']+dp['mean_66252']
    dp['earning']=get_earning_date(ticker)
    dp['rating']=rating
    dp['p_target']=p_target
    dp['ta']=ta
    ticker_l=list()
    ticker_l.append(ticker)  #convert string to list
    dp['beta']=DF_sp500[DF_sp500['SYMBOL']==ticker].beta.values[0]
    #div_dummy, dp['beta']=get_share_nasdaq(ticker_l) 
    dp['sec'], dp['rrtn_22_ts'], dp['rrtn_22_sm']=get_tsm(ticker)
#    dp['div_yield'], dp['ex_div'], dp['pct_50_ma'], dp['pct_200_ma'],\
#            dp['pct_hi'], dp['pct_lo'], dp['pe'], dp['peg']=1,1,1,1,1,1,1,1
    dp['si']=web.get_quote_yahoo(ticker)['short_ratio']
#    dp['div_yield'], dp['ex_div'], dp['pct_50_ma'], dp['pct_200_ma'],\
#            dp['pct_hi'], dp['pct_lo'], dp['pe'], dp['peg'],\
#            dp['si']=get_Share(ticker) 
    do, posts, note=get_option(ticker)
    do_vol=do[['ticker', 'iv_hv',  'iv_30_rank', 'hv_rank', 'pc', 'iv_30', 'iv_30_mean', 'skew', 'skew_pc']]
    do_entry_timing=do[['p_chg', 'v_stk_pct', 'v_opt_pct', \
    'iv_30_chg','pc_chg', 'v_c_pct']]
    print (colored("Vol -B/S", 'magenta', 'on_cyan') )
    print(colored(do_vol, 'blue'))
    print (note)
    
    print (colored("Trend -L/S/Z", 'magenta', 'on_cyan') )
    print(dp[['momt', 'trend_n', 'trend', 'rating', 'p_target',  'sec','rrtn_22_ts', 'rrtn_22_sm','ta']])
    
    print(colored("Sure profit?", 'red', 'on_cyan'))    
    print(dp[['ticker', 'p_22_sig', 'p_44_sig', 'beta', 'pe', 'si' , 'ex_div', 'earning']])
    print(do[['earn_date', 'div']])
    
    print(colored("p_22_fwd forcast?", 'red', 'on_cyan')) 
#VWOP, ML, maxpain, straddle, IV-> range
    print(colored("Entry Timing?", 'red', 'on_cyan'))     
    print(do_entry_timing)
    
    print(colored("Unknown decide result", 'red', 'on_cyan')) 
    print (posts.strip())
    print (rating_1, rating)
    print ( ins_1)
    print(news_1.strip()) 
    print(news_2.strip() )
#    print (news_3)
    pd.set_option('display.expand_frame_repr', True)
    
def trade_entry(underlying):
    if underlying =='sp500':
        df_trade=pd.read_excel(open(r'G:\Trading\Trade_python\pycode\trade.xlsx','rb'))
    #df_trade=pd.read_csv('G:\Trading\Trade_python\pycode\\trade.xlsx')
        to_sql_append(df_trade, 'tbl_trade')  #log trades and track performance
        to_sql_append(df_trade, 'tbl_trade_bkup') #keep trde only
        print ("trade is saved in tbl_trade")
    elif underlying == 'etf':
        df_trade=pd.read_excel(open(r'G:\Trading\Trade_python\pycode\trade_etf.xlsx','rb'))
    #df_trade=pd.read_csv('G:\Trading\Trade_python\pycode\\trade.xlsx')
        to_sql_append(df_trade, 'tbl_trade_etf')  #log trades and track performance
        to_sql_append(df_trade, 'tbl_trade_etf_bkup') #keep trde only
        print ("trade is saved in tbl_trade_etf")   
    else:
        print ("trade_entry missing env")
        exit    
#dates = pd.date_range('1/1/2000', periods=8)
#df = pd.DataFrame(np.random.randn(8, 4), index=dates, columns=['A', 'B', 'C', 'D'])