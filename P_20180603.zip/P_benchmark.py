# -*- coding: utf-8 -*-
"""
Created on Wed Aug  9 14:49:01 2017

@author: jon
"""

import pandas as pd
import numpy as np
import datetime as datetime
from pandas import date_range
import pandas_datareader.data as web
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import sqlite3 as db
import sys, os
# %matplotlib inline
import time
import pandas.io.sql as pd_sql
import pickle
from pandas.tseries.offsets import BDay
import bs4
import requests
import re
from timeit import default_timer as timer
from yahoo_finance import Share
import warnings
from termcolor import colored
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
import statsmodels.api as sm
from lxml import html
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException

#from wallstreet import Stock, Call, Put
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
old_stdout=sys.stdout
today=datetime.datetime.today()
todate=today.date()
def read_sql(query, q_date):
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
    df=pd_sql.read_sql(query, conn)
    return df
    
def get_news():
    q_trade="SELECT * FROM tbl_trade WHERE exit_date ='N'"
    dt=read_sql(q_trade, todate)
    dt=dt.fillna(0)
    dn=pd.DataFrame(data=[], index=dt.index, columns=[['ticker','date','rating', 'p_target',\
        'rating_1', 'rating_2','news_1', 'news_2', 'news_3','ins', 'ins_1', 'ins_2']])
    dn['ticker']=dt['ticker']
    dn['date']=dt['date']
#    dn=dn.head(2)

    for index, row in dn.iterrows():
        ticker=row['ticker']
        dn.loc[index, ['rating', 'p_target', 'rating_1', 'rating_2', \
        'news_1', 'news_2', 'news_3','ins', 'ins_1', 'ins_2']]=get_analyst(ticker)
#        except:
#            print("get_analyst error : ", ticker)
#            pass
        time.sleep(2)
    return dn    

def get_analyst(ticker=''):
#ref: http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/    
    from selenium.webdriver.chrome.options import Options
    chrome_options=Options()
    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_1_0_7_overlay_remove.crx")
    chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
    url="https://www.marketbeat.com/"
    gecko="G:\\Trading\Trade_python\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="G:\Trading\Trade_python\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
    driver.get(url)
#    driver.execute_script("window.open(url);")
    try:
        ol_close=driver.find_element_by_class_name("overlay-close")
        ol.click()
    except:
        pass
    time.sleep(2)
    symbol=driver.find_element_by_xpath('//input[@class="main-searchbox autocomplete ui-autocomplete-input"]')
    symbol.send_keys(ticker)
    submit=driver.find_element_by_xpath('//a[@class="main-search-button"]')
    submit.click()
    
    time.sleep(2)   #get_attribute('innerHTML')
    rating=driver.find_elements_by_xpath('//*[@id="AnalystRatings"]/div[2]/table/tbody/tr[2]/td[2]')[0].get_attribute('textContent')
    p_target= driver.find_elements_by_xpath('//*[@id="AnalystRatings"]/div[2]/table/tbody/tr[3]/td[2]')[0].get_attribute('textContent')   
    rating_1=driver.find_elements_by_xpath('//*[@id="DataTables_Table_0"]/tbody/tr[1]')[0].get_attribute('textContent')
    rating_2=driver.find_elements_by_xpath('//*[@id="DataTables_Table_0"]/tbody/tr[2]')[0].get_attribute('textContent')
   
    news_1=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[1]/td[2]')[0].get_attribute('textContent')
    news_2=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[2]/td[2]')[0].get_attribute('textContent')
    news_3=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[3]/td[2]')[0].get_attribute('textContent')

    ins=driver.find_elements_by_xpath('//*[@id="InsiderTrades"]/div[1]')[0].get_attribute('textContent')
    ins_1=driver.find_elements_by_xpath('//*[@id="DataTables_Table_3"]/tbody/tr[1]')[0].get_attribute('textContent')
    ins_2=driver.find_elements_by_xpath('//*[@id="DataTables_Table_3"]/tbody/tr[2]')[0].get_attribute('textContent')
    return rating, p_target, rating_1, rating_2, news_1, news_2, news_3,ins, ins_1, ins_2
   
    #return news_1, news_2, news_3
def get_benchmark(ticker=''): #df_adhoc has column "ticker", ad hoc run on stock
# join ETF to get corr
    ticker=ticker.upper()
    qry="SELECT * FROM tbl_price x JOIN tbl_price_etf y ON x.date=y.date"
    df_price=read_sql(qry,lday)  
    df_price = df_price.loc[:,~df_price.columns.duplicated()] #drop duplicated columns -date
    df_price=df_price.set_index('date')
    df_tmp=pd.DataFrame(data=[], index=df_price.index)
    ds_tmp=pd.DataFrame()
    ds=pd.DataFrame()
    sec=DF_sp500[DF_sp500['SYMBOL'] == ticker].ETF  #series value
    df_tmp['ticker']=ticker
    df_tmp['close_t']=df_price[ticker]
    df_tmp['sec']=sec.values[0]
    df_tmp['close_s']=df_price[sec]
    df_tmp['spy']=df_price['SPY']
    df_tsm=df_tmp.tail(504)#historical data 1 year
    ds_tmp=benchmark(df_tsm)
    ds=ds.append(ds_tmp)
    ds=ds.dropna()
    
    return ds['sec'], ds['rrtn_22_ts'], ds['rrtn_22_sm']
        
def benchmark(df_tsm): # ticker/sector/market   ad hoc process beta, alpha, 
# one month return difference btn ticker,sec,mkt
    df=pd.DataFrame()  
    ds=pd.DataFrame()
# rtn_t: ticker, s: sector, m: market
    df_tsm[['rtn_t','rtn_s','rtn_m']]=df_tsm[['close_t', 'close_s','spy']]/df_tsm[['close_t', 'close_s','spy']].shift(1)-1
    df_tsm=df_tsm.dropna()
    covmat = np.cov(df_tsm['rtn_t'],df_tsm['rtn_m'])    
    beta = covmat[0,1]/covmat[1,1]  
          
    df['ticker']=df_tsm['ticker']
    df['beta']=beta
    #calc rtn_22 diff btn stock and mkt in past 22 days
    df['rrtn_22_sm'] = df_tsm['close_s'].tail(0)/df_tsm['close_s'].tail(0).shift(22) - \
        df_tsm['spy'].tail(0)/df_tsm['spy'].tail(0).shift(22)
    df['rrtn_22_ts'] = df_tsm['close_t'].tail(0)/df_tsm['close_t'].tail(0).shift(22) - \
        df_tsm['close_s'].tail(0)/df_tsm['close_s'].tail(0).shift(22)
    ds['rtn_22']=df_tsm['close_t'].tail(0)/df_tsm['close_t'].tail(0).shift(22)-1
    df=df.dropna()    
# plot relatvie rtn as personality change
  # return stat by ticker
    ds['ticker']=df['ticker'].tail(1)
    ds['sec']=df_tsm['sec'].tail(1)
    ds['beta']=df['beta'].tail(1)
    ds['rrtn_22_ts']=df['rrtn_22_ts'].tail(1)
    ds['rrtn_22_sm']=df['rrtn_22_sm'].tail(1)
    ds=ds.dropna()
    return ds    