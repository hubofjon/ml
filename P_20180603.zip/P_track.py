import pandas as pd
import numpy as np 
import datetime as datetime
import scipy.stats as stats
import sqlite3 as db
from timeit import default_timer as timer
#from yahoo_finance import Share
import pandas_datareader.data as web
from termcolor import colored, cprint
import warnings
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format

#Import functions
from P_commons import to_sql_append, to_sql_replace, read_sql
from P_intel import get_rsi, get_share_nasdaq, get_tsm
from P_fwdtest import win_loss
from P_options import get_option
from P_intel import marketbeat, get_ta, get_earning_date

capital=20000
DF_sp500=pd.read_csv('c:\\pycode\pyprod\constituents.csv')
DF_etf=pd.read_csv('c:\\pycode\pyprod\etf.csv')
df_sp500=DF_sp500.ix[:,0] #serie
df_etf=DF_etf.ix[:,0]
todate=datetime.date.today()

def trade_track(underlying, reval_date):
# 1. tbl_trade is to record entry of new trades
# 2. query and append historical trade from tbl_trade to tbl_trade_hist
# 3. for live trade, get price from tbl_price; update to tbl_trade_track and tbl_trade
#4.  so tbl_trade only keep live trade, 
#get tickers for live trades from tbl_trade
#save historical trade to tbl_trade_hist
    start_time=timer()
    do=pd.DataFrame()
    if underlying=='sp500':
        q_trade_hist="SELECT * FROM tbl_trade WHERE exit_date<>'N'" #get ride of non-live trade
        q_trade="SELECT * FROM tbl_trade WHERE exit_date ='N'"   #get live trade
    elif underlying=='etf':
        q_trade_hist="SELECT * FROM tbl_trade_etf WHERE exit_date<>'N'" 
        q_trade="SELECT * FROM tbl_trade_etf WHERE exit_date ='N'"
    else:
        print ("trade_track() missing underlying")
        exit
# save historical trades
    dh=read_sql(q_trade_hist, reval_date)
    if set(['level_0']).issubset(dh.columns):    
        dh=dh.drop(['level_0'],1)
    if underlying =='sp500':
        to_sql_append(dh, 'tbl_trade_hist')
    elif underlying == 'etf':
        to_sql_append(dh, 'tbl_trade_hist_etf')
 #   q_trade="SELECT * FROM tbl_trade WHERE exit_date ='N'" #get only live trade
    dt=read_sql(q_trade, reval_date)
    dt=dt.fillna(0)  #fill Nan with 0 for calc
    #get late price for above tickers from tbl_price
    #get previous price pct
#get win_10 to alert for exit
    con_nullticker=pd.isnull(dt.ticker)
    i_nullticker=dt[con_nullticker].index
    dt=dt.drop(i_nullticker)
    dt['pct_estrike_prev']=dt['close_last']/dt['estike_1']-1
    dt['rsi_prev']=dt['rsi']
   #update latest price from tbl_price and rsi
# update lastest corr from tbl_stat which has latest corr
    for index, row in dt.iterrows():
        ticker=row['ticker']
        if underlying=='sp500':
            q_price="SELECT date, %s FROM tbl_price WHERE instr(date,'%s')>0"%(ticker, reval_date)
            q_stat="SELECT * FROM tbl_stat WHERE ticker ='%s'"%ticker
        else: 
            q_price="SELECT date, %s FROM tbl_price_etf WHERE instr(date,'%s')>0"%(ticker, reval_date)
            q_stat="SELECT corr FROM tbl_stat_etf WHERE ticker ='%s'"%ticker
        dp=read_sql(q_price, reval_date)
        dc=read_sql(q_stat, reval_date)
        if not dp.empty:
            close=dp.iloc[0,1]
        else:
            print("no latest price:", ticker)
#            close=dt.loc[index, 'close_last']  #copy from last price
            pass           
        dt.loc[index, 'close_last']= close #update close_last price
        dt.loc[index,'rsi']=float(get_rsi(ticker)) ## Convert to Flaat from Object
#        dt.loc[index,'corr_new']=dc['corr'][0] #dc.iloc[0,0]  ## update latest corr
        dt.loc[index, 'momt_n_last']=dc['momt_n'][0]
        dt.loc[index, 'trend_n_last']=dc['trend_n'][0]
        if ticker =='TLT':
            dt.loc[index, 'beta']=-0.27
        else:    
            dt.loc[index, 'beta']=DF_sp500[DF_sp500['SYMBOL']==ticker].beta.values[0] #series   
#        #x=Share(ticker)._fetch()
#        x_si=''#=x['ShortRatio']
#        x_p_pct='' #=x['ChangeinPercent']
#        x_vol=''#x['Volume']
#        x_vol_avg=''#x['AverageDailyVolume']
#        x_ex_div=''#x['ExDividendDate']  # ex_div from Share yahoo source
        try:
            x_si=web.get_quote_yahoo(ticker)['short_ratio'].values
            x_p_pct=web.get_quote_yahoo(ticker)['change_pct'].values
        except:
            x_si=[0]
            x_p_pct=[0]
        t=[]
        t.append(ticker)
        x_vol, x_vol_avg, x_ex_div, x_beta=1,1,1,1    
        try:
            x_vol, x_vol_avg, x_ex_div, x_beta= get_share_nasdaq(t)
        except:
#            print('get_share_nasdaq error:', ticker)
            pass
#        try:
#            y_ex_div, dummy_beta=get_share_nasdaq(ticker)  #ex_div from Nasdaq source
#            if len(y_ex_div)>0 and (y_ex_div[0] != 'N/A') and (y_ex_div[0] >= x_ex_div):
#                dt.loc[index, 'ex_div']=y_ex_div[0] #Nasdq
#            else:
#                dt.loc[index, 'ex_div']=x_ex_div  #yahoo
#        except:
#            pass
        dt.loc[index, 'si']=x_si[0]
        dt.loc[index, 'p_pct']=x_p_pct[0]
        dt.loc[index, 'v_pct']=float(x_vol)/float(x_vol_avg) #string to float
        dt.loc[index, 'ta']=''        
#        try:
#            dt.loc[index, 'ta']=get_ta(ticker)
#        except:
#            pass
# add bechmark       
        if underlying =='sp500':
           try:
               x,y,z=get_tsm(ticker)
           except:
               print(colored("tsm error:  %s"%ticker, 'red', 'on_cyan'))
               x,y,z=0,0,0
           dt.loc[index,'sec']=x
           dt.loc[index, 'rrtn_22_ts']=y
           dt.loc[index,'rrtn_22_sm'] = z
#                print("benchmark error:   ", row['ticker'])
#                pass
        elif underlying =='etf':
            dt.loc[index,'sec']=''
            dt.loc[index,'rrtn_22_ts']=''
            dt.loc[index,'rrtn_22_sm']=''
#        try:
#            do_tmp,  posts=get_option(ticker)
#            do=do.append(do_tmp)
#
#        except:
#            pass
   # dt calc risk
    dt.date_last=reval_date  
    dt['contracts']=dt['con_1']+dt['con_2']-dt['con_ex1']-dt['con_ex2']
    dt['entry_price']=(dt['con_1']*dt['con_p1']+dt['con_2']*dt['con_p2'])/(dt['con_1']+dt['con_2'])
    dt['exit_price']=(dt['con_ex1']*dt['con_ex_p1']+dt['con_ex2']*dt['con_ex_p2'])/(dt['con_ex1']+dt['con_ex2'])
    con_m2m=pd.notnull(dt.exit_target)
    dt.loc[con_m2m,'erisk']= dt['contracts']*dt['exit_target']*100
    dt.loc[~con_m2m, 'erisk']=dt['contracts']*dt['entry_price']*100  #update exited trade before removal

#    dt['epnl']=(dt['con_ex1']+dt['con_ex2'])*(dt['exit_price']-dt['entry_price'])*100-dt['comm']
#    dt['epnl_pct']=0.01*dt['epnl']/((dt['con_1']+dt['con_2'])*dt['entry_price'])
    dt['epnl']=dt['contracts']*(dt['exit_target']-dt['entry_price'])*100-dt['comm']  #unrealized pnl
    dt['epnl_pct']=(dt['exit_target']/dt['entry_price']-1)
    dt['days_to_expire']=pd.to_datetime(dt['expire_date'])-pd.to_datetime(dt['date_last']) 
    dt['days_all_life']= pd.to_datetime(dt['expire_date'])-pd.to_datetime(dt['entry_date'])
# evaluate p_fwd_10 early sign    
    dt['days_from_entry']=dt['days_all_life'] - dt['days_to_expire']
    
# early indicator to stay or exit trade  !!
    dt.loc[dt['days_from_entry']=='5 days','p_5_fwd']=dt['close_last']
    dt.loc[dt['days_from_entry']=='10 days','p_10_fwd']=dt['close_last']
#        dt['p_fwd_10']=dt['close_last']
    dt=win_loss(dt, 10)  #
#    return dt
#    exit
    if underlying=='sp500': 
        con_datetime=(type(dt['ex_div'])==datetime.datetime)
        dt.loc[~con_datetime, 'ex_div']=datetime.datetime(2016,1,1) #day of month out of range error
    else: 
        dt['ex_div']=datetime.datetime(2016,1,1)
    dt['days_to_exdiv']=pd.to_datetime(dt['ex_div']) - pd.to_datetime(dt['date_last'])
    dt['exist_pct']=1-dt['days_to_expire']/dt['days_all_life']
    dt['exist_pct']=dt['exist_pct'].round(2)
    dt['days_left']=dt['days_to_expire']
    dt['days_to_exdiv']=dt['days_to_exdiv']
    #dt calculated fields
    dt['weigh']=dt['erisk']/(dt['erisk'].sum())
    #dt['pct_estrike_1']="{:.1%}".format(dt['close_last'])/dt['estike_1']-1)
    dt['pct_estrike_1']=(dt['close_last']/dt['estike_1']-1).round(2)
    dt['momt_n_chg']=dt['momt_n_last']-dt['momt_n']
    dt['trend_n_chg']=dt['trend_n_last']-dt['trend_n']
    # exit profit trade in time
    con_exit=(dt['play'].str.strip().str[0]=='Z')& (dt.pct_estrike_1 <=0.02) &(dt.exist_pct>=0.5)
# alert on margin of safety  
    con_sig=(dt.close_last > dt.be_up) | (dt.close_last< dt.be_down) | (np.abs(dt.close_last - dt.close_qdate) >=dt.p_22_sig)
#stop loss    
    con_too_late=(dt.exist_pct>=0.5) & (dt['exit_target']/dt['entry_price']<=1.1)
    con_stop_loss=dt.epnl_pct<= -0.35 # loss of 30%
    #con_lastweek=dt.days_left<=4
    con_stop=con_too_late| con_stop_loss# | con_lastweek
    con_div=(dt.days_to_exdiv<='5 days') & (dt.days_to_exdiv>='0 days')
    con_risk_allo=(dt.erisk/capital >0.15) | (dt.weigh > 0.35)
    con_prexit=pd.isnull(dt.alert_prexit) & dt.exist_pct>0.5  # pre-exit order
    
    dt['alert_exit']=con_exit
    dt['alert_sig']=con_sig
    dt['alert_stop']=con_stop
    dt['alert_div']=con_div
    
    dt['move_sig']=(dt['close_last']-dt['close_qdate'])/dt['p_22_sig']    
    
    risk_allo=dt[con_risk_allo][['ticker', 'weigh', 'erisk']]
    risk_sig=dt[con_sig][['ticker','p_22_sig', 'move_sig','close_last', 'close_qdate','estike_1', 'be_up', 'be_down']]    
    risk_stop=dt[con_stop][['ticker', 'epnl_pct', 'exist_pct']]
    risk_exit=dt[con_exit][['ticker','epnl_pct', 'pct_estrike_1','exist_pct']]
    risk_div=dt[con_div][['ticker','ex_div']]
    risk_prexit=dt[con_prexit][['ticker','epnl_pct', 'exist_pct', 'days_to_expire']]

    dt.alert_stop[dt.alert_stop==False]=""
    dt.alert_exit[dt.alert_exit==False]=""
    dt.alert_div[dt.alert_div==False]=""  
    dt.alert_sig[dt.alert_sig==False]=""  
    dt.win_5[dt.win_5==False]="" 
    dt.win_10[dt.win_10==False]="" 
   # dt.wrong[dt.wrong==False]="" 
    #multiple conditional alert
    dt.loc[((dt['play']=='L')|(dt['play']=='LL')), 'alert_direction']=dt['rsi']<dt['rsi_prev'] #less momentum
    dt.loc[((dt['play']=='S')|(dt['play']=='SS')), 'alert_direction']=dt['rsi']>dt['rsi_prev']
    dt.loc[((dt['play']=='CAL')|(dt['play']=='ZZ')|(dt['play']=='Z0')|(dt['play']=='Z4')), 'alert_direction']=\
            np.abs(dt['pct_estrike_1'])>np.abs(dt['pct_estrike_prev'])
    dt.loc[dt['play']=='E', 'alert_direction']=np.abs(dt['pct_estrike_1'])<np.abs(dt['pct_estrike_prev'])
   #counter
#    if underlying=='sp500':
#        dt.loc[dt['alert_stop']==True, 'counter']=dt['counter'].astype(float)+1
#    else:
#        dt['counter']=10
    dt.loc[dt['alert_stop']==True, 'counter']=dt['counter'].astype(float)+1
    dt.alert_direction[dt.alert_direction==False]="" 
    #dt.counter[dt.counter==0]="" 
#    if underlying=='sp500':    
#        dt=dt.drop(['level_0'],1)
#    else:
#        pass
    dt=dt.drop(['level_0'],1)
    if underlying=='sp500':
        to_sql_replace(dt, 'tbl_trade_track')
        to_sql_replace(dt, 'tbl_trade')
    else:
        to_sql_replace(dt, 'tbl_trade_etf')
    #pd.set_option('display.max_columns', None)
    dt['rsi_chg']=dt['rsi']-dt['rsi_prev']
  #  print (colored('>>>>>>>>>     NO exit order!!!    <<<<<<<<', 'red', attrs=['bold', 'reverse','blink']))
    print (colored('allocation risk', 'magenta', 'on_cyan'))    
    print(colored(risk_allo,'magenta'))
    print(" ------ ")
    print (colored('std deviation risk', 'red', 'on_cyan'))    
    print(colored(risk_sig,'blue'))
    print(" -------")
    print (colored('stop loss: HEDGED SURE PROFIT BY EXPIRE???', 'red','on_cyan'))    
    print(colored(risk_stop,'red'))
    print(" ------")
    print (colored('profit exit', 'red', 'on_green'))    
    print(colored(risk_exit,'green'))
    print("  -----    ")
    print (colored('need prexit order', 'red', 'on_cyan'))    
    print(colored(risk_prexit,'blue'))
    print("  -----    ")
    print (colored('event risk', 'magenta', 'on_cyan'))    
    print(colored(risk_div,'magenta'))
    print("")
    #print (colored('>>>>>>>>>     ALERT!!!    <<<<<<<<', 'red'))
    #print (df_alert[['ticker', 'alert_stop', 'alert_exit','erisk']])
    dtt=dt[['ticker','erisk', 'play', 'weigh', 'delta','beta', 'epnl', 'epnl_pct', 'alert_stop','alert_sig', 'alert_exit', 'alert_div', 'days_left',\
    #'alert_direction',\
    'pct_estrike_1','rsi_chg', 'p_pct', 'v_pct', 'si', 'ex_div', 'ta',  \
    'momt_n_chg', 'trend_n_chg', 'win_5', 'win_10', 'sec', 'rrtn_22_ts', 'rrtn_22_sm']]
    dtt.sort_values(['erisk', 'play'], ascending=[False, True], inplace=True)
    try:
        SPY=web.get_quote_yahoo('SPY')['last']
    except:
        print("web.get_quote_yahoo error@line 289")
        SPY=1000
    print (colored('>>>> SPY equivalent number of share in movement <<<<<<<<', 'red'))
    print("SPY equivalent share in movement:", (dt['beta']*dt['delta']*dt['close_last']).sum()/SPY)
    
    end_time=timer()
    test_time=end_time - start_time
    print("trade_track is done in seconds:  %s"%test_time)
    
    return dtt

def options_track(underlying):
    do=pd.DataFrame()
    posts=[]
    notes=[]
    if underlying=='sp500':
        q_trade="SELECT * FROM tbl_trade WHERE exit_date ='N'"   #get live trade
    elif underlying=='etf':
        q_trade="SELECT * FROM tbl_trade_etf WHERE exit_date ='N'"
    dt=read_sql(q_trade, todate)
    for index, row in dt.iterrows():
        ticker=row['ticker']
        try:
            do_tmp, posts_tmp, note_tmp=get_option(ticker)
            do=do.append(do_tmp)
            posts.append(posts_tmp)
            notes.append(note_tmp)
            
        except:
            pass    
#    do.style.set_properties(**{'text-align': 'left'})
    pd.set_option('display.expand_frame_repr', False)
    print (colored("Opt dashboard", 'magenta', 'on_green') )
    try:
        do_view=do[['ticker', 'iv_hv',  'iv_30_rank', 'hv_rank', 'pc', 'iv_30', 'iv_30_mean',\
        'p_chg', 'v_stk_pct', 'v_opt_pct', 'iv_30_chg',\
        'pc_chg', 'v_c_pct','skew', 'skew_pc']]
        print(colored(do_view, 'blue'))
    except:
        pass
#    print (colored("option notes", 'magenta', 'on_green') )
#    print (do['note'])
#    print (colored("posts", 'magenta', 'on_green') )
#    print (posts)
    pd.set_option('display.expand_frame_repr', True)
    return do, posts, notes

def trade_review():
    qry="SELECT * FROM tbl_trade_hist"
    dh=read_sql(qry, todate)
    dh=dh.drop_duplicates()
    dt=dh
    dt['entry_price']=(dt['con_1']*dt['con_p1']+dt['con_2']*dt['con_p2'])/(dt['con_1']+dt['con_2'])
    dt['exit_price']=(dt['con_ex1']*dt['con_ex_p1']+dt['con_ex2']*dt['con_ex_p2'])/(dt['con_ex1']+dt['con_ex2'])
    dt['pnl_pct']=dt['exit_price']/dt['entry_price']-1
    dt['pnl']=(dt['con_1']+dt['con_2'])*dt['entry_price']*100*dt['pnl_pct']
    names=['ticker', 'close_qdate', 'close_last', 'date','entry_date','estike_1', \
    'con_1', 'con_2', 'con_p1', 'con_p2', 'con_ex1', 'con_ex2', 'play', \
    'con_ex_p1', 'con_ex_p2', 'mean_1022', 'mean_2266', 'mean_66252', \
    'p_22_sig', 'play', 'si', 'pct_50_ma', 'pct_200_ma', 'be_up', 'be_down', 'pnl_pct', 'exit_date', 'hv_22', 'hv_m2y']    

    dt['skew_in']=dt['estike_1']/dt['close_qdate']-1
    dt['skew_out']=dt['estike_1']/dt['close_last']-1
    dt['momt']=dt['mean_1022'].astype(str)+dt['mean_2266'].astype(str)+dt['mean_66252'].astype(str)
    dt['ma_pct']=dt['pct_50_ma'].astype(float)+ dt['pct_200_ma'].astype(float)
    name_1=['ticker','play','pnl_pct','skew_in', 'pnl', 'skew_out', 'hv_22','hv_m2y', 'pct_50_ma', 'pct_200_ma', 'ma_pct', 'momt' ]
    df=dt[name_1]
    df=df.sort_values('pnl_pct', ascending=False)
    pd.set_option('display.expand_frame_repr', False)
    pd.options.display.float_format = '{:.2f}'.format
    print(df)
    pd.set_option('display.expand_frame_repr', True)
    return df
    
def check(ticker='', mode =''):
    todate=datetime.date.today()
    ticker=ticker.upper()
    qry_h="SELECT * FROM tbl_play_hist WHERE ticker='%s' "%ticker
    df=read_sql(qry_h,todate)
    df.sort_values('date', ascending =False, inplace=True)
    df['rtn_22_fwd']=df['p_22_fwd']/df['close_qdate']-1
    df['p_22_sig']=df['p_22_sig'].astype(float)
    df['hv_m2y']=df['hv_m2y'].astype(float)
    dh=df[[ 'date','play', 'close_qdate', 'p_22_sig', 'rtn_22_fwd', \
    'p_22_fwd', 'hv_m2y', 'win_22', 'sec', 'rrtn_22_ts', 'rrtn_22_sm']]
    print (ticker, "won_22:  ", dh[dh.win_22==1].shape[0])
    pd.set_option('display.expand_frame_repr', False)
    print(dh)
    dp=df.head(1)
    
#    dp['momt']=dp['mean_510']+dp['mean_1022']+dp['mean_2266']+dp['mean_66252']
    dp['earning']=get_earning_date(ticker)
    
    ticker_l=list()
    ticker_l.append(ticker)  #convert string to list
    dp['beta']=DF_sp500[DF_sp500['SYMBOL']==ticker].beta.values[0]
    #div_dummy, dp['beta']=get_share_nasdaq(ticker_l) 
    dp['sec'], dp['rrtn_22_ts'], dp['rrtn_22_sm']=get_tsm(ticker)
#    dp['div_yield'], dp['ex_div'], dp['pct_50_ma'], dp['pct_200_ma'],\
#            dp['pct_hi'], dp['pct_lo'], dp['pe'], dp['peg']=1,1,1,1,1,1,1,1
    dp['si']=web.get_quote_yahoo(ticker)['short_ratio']
#    dp['div_yield'], dp['ex_div'], dp['pct_50_ma'], dp['pct_200_ma'],\
#            dp['pct_hi'], dp['pct_lo'], dp['pe'], dp['peg'],\
#            dp['si']=get_Share(ticker) 
    print (colored("Trend -L/S/Z", 'magenta', 'on_cyan') )
    print(dp[['momt_n', 'momt', 'trend_n', 'trend', 'sec','rrtn_22_ts', 'rrtn_22_sm']])
    print(colored("Sure profit?", 'red', 'on_cyan'))    
#    print(dp[['ticker', 'p_22_sig', 'p_44_sig', 'beta', 'pe', 'si' , 'ex_div', 'earning']])
    print(dp[['ticker', 'p_22_sig', 'p_44_sig', 'beta',  'si' , 'earning']])
    
    if mode=='':
        pass
    else:
        try:
            rating, p_target, rating_1, rating_2, news_1, news_2, news_3,\
                ins, ins_1, ins_2=marketbeat(ticker)
        except:
            print("error marketbeat:  ", ticker)
            rating, p_target, rating_1, rating_2, news_1, news_2, news_3,\
                ins, ins_1, ins_2=('',)*10
        try:
            ta=get_ta(ticker)
        except:
            ta=0
            pass
        dp['rating']=rating
        dp['p_target']=p_target
        dp['ta']=ta
        print(colored(dp[['rating', 'p_target', 'ta']], 'blue'))
        
        do, posts, note=get_option(ticker)
        do_vol=do[['ticker', 'iv_hv',  'iv_30_rank', 'hv_rank', 'pc', 'iv_30', 'iv_30_mean', 'skew', 'skew_pc', 'earn_date', 'div']]
        do_entry_timing=do[['p_chg', 'v_stk_pct', 'v_opt_pct', \
        'iv_30_chg','pc_chg', 'v_c_pct']]
        print (colored("Vol -B/S", 'magenta', 'on_cyan') )
        print(colored(do_vol, 'blue'))
        print (note)
        
        print(do[['earn_date', 'div']])
        
        print(colored("p_22_fwd forcast?", 'red', 'on_cyan')) 
    #VWOP, ML, maxpain, straddle, IV-> range
        print(colored("Entry Timing?", 'red', 'on_cyan'))     
        print(do_entry_timing)
        
        print(colored("Unknown decide result", 'red', 'on_cyan')) 
        print (posts.strip())
        print (rating_1, rating)
        print ( ins_1)
        print(news_1.strip()) 
        print(news_2.strip() )
    #    print (news_3)
        pd.set_option('display.expand_frame_repr', True)
        
def options_track_new(underlying):
    do=pd.DataFrame()
    posts=[]
    notes=[]
    if underlying=='sp500':
        q_trade="SELECT * FROM tbl_trade WHERE exit_date ='N'"   #get live trade
    elif underlying=='etf':
        q_trade="SELECT * FROM tbl_trade_etf WHERE exit_date ='N'"
    dt=read_sql(q_trade, todate)
    for index, row in dt.iterrows():
        ticker=row['ticker']
        try:
            do_tmp=get_option(ticker)
            do=do.append(do_tmp)

            
        except:
            pass    
#    do.style.set_properties(**{'text-align': 'left'})
    pd.set_option('display.expand_frame_repr', False)
    print (colored("Opt dashboard", 'magenta', 'on_green') )
    try:
#        do_view=do[['ticker', 'iv_hv',  'iv_30_rank', 'hv_rank', 'pc', 'iv_30', 'iv_30_mean',\
#        'p_chg', 'v_stk_pct', 'v_opt_pct', 'iv_30_chg',\
#        'pc_chg', 'v_c_pct','skew', 'skew_pc']]
        print(colored(do, 'blue'))
    except:
        pass
#    print (colored("option notes", 'magenta', 'on_green') )
#    print (do['note'])
#    print (colored("posts", 'magenta', 'on_green') )
#    print (posts)
    pd.set_option('display.expand_frame_repr', True)
    return do