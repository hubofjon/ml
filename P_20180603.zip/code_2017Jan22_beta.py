#SELECT * FROM tbl_stat_hist WHERE p_252>0.0001 AND sharpe_66_pct>=0.5 AND sharpe_5_pct>=0.45 AND hv_22_pct>=0.23 AND hv_5_pct>0.1 AND hv_5_pct<0.6 AND p_22_pct<0.75

import pandas as pd
import numpy as np
import datetime as datetime
from pandas import date_range
import pandas_datareader.data as web
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import sqlite3 as db
import sys, os
# %matplotlib inline
import time
import pandas.io.sql as pd_sql
import pickle
from pandas.tseries.offsets import BDay
import bs4
import requests
import re
from timeit import default_timer as timer
from yahoo_finance import Share
import warnings
from termcolor import colored
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
import statsmodels.api as sm
from lxml import html
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException
#from wallstreet import Stock, Call, Put
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
old_stdout=sys.stdout
#read stock from textfile or list
capital=20000
DF_sp500=pd.read_csv('G:\\Trading\Trade_python\pycode\pyprod\constituents.csv')
df_etf=pd.read_csv('G:\\Trading\Trade_python\pycode\pyprod\etf.csv')
df_sp500=DF_sp500.ix[:,0] #serie
df_etf=df_etf.ix[:,0]

def update_price(underlying, start_date, end_date): #generic 
    df_close=pd.DataFrame()
    if underlying =='sp500':
        df_symbol=df_sp500
    elif underlying =='etf':
        df_symbol=df_etf
    for each in df_symbol:
        try:
#            df=web.DataReader(each,"yahoo", start_date, end_date)
            df=web.DataReader(each,"google", start_date, end_date)
        # returndf_close
            df[each]=df['Close']
            df_close=df_close.append(df[each])
            df_close.index.name='date'
        #convert index- date into column
        #df_close.reset_index(level=0, inplace=True) 
        except:
            print ("cannot retrieve yahoo data", each)
    return df_close.transpose()
    
def update_price_today_yahoo(underlying): #generic 

    df_close=pd.DataFrame()
    if underlying =='sp500':
        df_symbol=df_sp500
    elif underlying =='etf':
        df_symbol=df_etf
    try:     
        data=web.get_quote_yahoo(df_symbol)
        dt=data.T
        today=datetime.date.today()
        dt['date']=today
        dt['date']=pd.to_datetime(dt['date'])
#        dt.set_index('date',inplace=True)
        df_close=dt.iloc[2].to_frame().transpose()
    except:
        print("cannot retrieve data_yahoo")
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
    pd_sql.to_sql(df_close, "tbl_price", conn, if_exists='append', index=False)
    print("toda: %s yahoo data appended"%today.date())
    
#update_price_google(underlying):
#    from googlefinance import getQuotes
#    import json
    
    
def update_price_daily(from_date, to_date):#update both sp500 and etf
    #today=datetime.date.today
    #from_last=last_update_date+ datetime.timedelta(1)
    df_price=update_price('sp500', from_date, to_date)
    df_price.index.name='date'
    to_sql_append(df_price, "tbl_price")
    print (" '%s' price appended to tbl_price"%today)
    df_price_etf=update_price('etf', from_date, to_date)
    df_price_etf.index.name='date'
    to_sql_append(df_price_etf, "tbl_price_etf")
    print (" '%s' price appended to tbl_price_etf"%today)
    #one time load historical price
def update_price_historical(underlying, days_back):
    print ("--update_price_historical of %s in progress ---"%underlying)
    end_date=today # datetime.datetime(2016,9,16)
    start_date=end_date - datetime.timedelta(days_back)  #last 1500 days
    if underlying =='sp500':
        df_symbol=df_sp500
    elif underlying =='etf':
        df_symbol=df_etf    
    df_price=update_price(underlying, start_date, end_date)
    df_price.index.name='date'
    df_price.sort_index(axis=0, ascending=True, inplace=True)
    if underlying=='sp500':
        to_sql_replace(df_price, "tbl_price")
    elif underlying=='etf':
        to_sql_replace(df_price, "tbl_price_etf")
    print("--historical price updated to tbl_price of %s"%underlying)  
  
def to_sql_append(df, tbl_name):
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
    pd_sql.to_sql(df, tbl_name, conn, if_exists='append')

def to_sql_replace(df, tbl_name):
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
    pd_sql.to_sql(df, tbl_name, conn, if_exists='replace')  
    
#tbl_name is defined in query    
def read_sql(query, q_date):
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
    df=pd_sql.read_sql(query, conn)
    return df
    
def stat_rank(df): #generic
    df['sharpe_5_pct']=df['sharpe_5'].rank(pct=True)  
    #this is abs rtn, as goal is to measure vol
    df['rtn_5_pct']=df['rtn_5'].rank(pct=True)    
    df['sharpe_22_pct']=df['sharpe_22'].rank(pct=True)    
    df['rtn_22_pct']=df['rtn_22'].rank(pct=True)
    df['sharpe_66_pct']=df['sharpe_66'].rank(pct=True)    
    df['rtn_66_pct']=df['rtn_66'].rank(pct=True)
    df['p_252_pct']=df['p_252'].rank(pct=True)
    df['p_10_pct']=np.abs(df['p_10']).rank(pct=True)
    df['p_22_pct']=np.abs(df['p_22']).rank(pct=True)
    df['p_66_pct']=np.abs(df['p_66']).rank(pct=True)
    df['hv_5_pct']=np.abs(df['hv_5']).rank(pct=True)
    df['hv_22_pct']=np.abs(df['hv_22']).rank(pct=True)
    df['hv_66_pct']=np.abs(df['hv_66']).rank(pct=True)
    df['hv_252_pct']=np.abs(df['hv_252']).rank(pct=True)
    df['hv_m2y_pct']=np.abs(df['hv_m2y']).rank(pct=True)
    df['rtn_ma66_pct']=df['rtn_ma66'].rank(pct=True)  
    df['rtn_ma252_pct']=df['rtn_ma252'].rank(pct=True)
    return df

# in: tbl_price /out:tbl_stat_hist
def stat_run(q_date, underlying, env='prod'): #underlying= sp500 or etf
    #retrieve data from tbl_price
    p_date=q_date-datetime.timedelta(380)
    #pick up price in the range only
    if underlying=='sp500':
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price", p_date, q_date)
    elif underlying=='etf':
        query="SELECT * FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price_etf", p_date, q_date)
    else:
        print("stat_run missing underlying")
        exit
    #query="SELECT * FROM '%s' wHERE date >= '%s' " %("tbl_price", p_date)
    df=read_sql(query, q_date)
    df.sort_index(axis=0) #sort the price from old date to latest date
    df=df.fillna(0)
    df['date']=q_date
    # convert date column to index index
    df.set_index('date', inplace=True) 
#test corr() of 6month 
    df_corr=df.tail(132).corr().ix['SPY',:]   
    #get stat data
    df_stat=pd.DataFrame()
    df_st=pd.DataFrame()
    df0=pd.DataFrame()
    len=df.shape[1]  
    #iterate thru columns, each column is a ticker
    #if iterate thru rows then use below code
# for index, row in df.iterrows():
#   ....:     print row['c1'], row['c2']   
    
    #for columns in df (another way)
    for c in range (0,len):
        df0=df.iloc[:,c].describe()
        #df0['ticker']=df.iloc[0:,c].name
        df0['ticker']=df.columns[c]
#for PROD, always get the latest price
#for TEST, how?        
        df0['corr']=df_corr[df.columns[c]]      #read corr with SPY
        df0['close_qdate']=df.iloc[-1,c]  #last row is latest price
        df0['close_22b']=df.iloc[-22,c]
        df0['close_66b']=df.iloc[-66,c]
        df0['mean_5']=df.iloc[:,c].tail(5).mean()
        df0['mean_10']=df.iloc[:,c].tail(10).mean()
        df0['mean_22']=df.iloc[:,c].tail(22).mean()
        df0['mean_66']=df.iloc[:,c].tail(66).mean()
        df0['mean_252']=df.iloc[:,c].tail(252).mean()   
        df0['hi_5']=df.iloc[:,c].tail(5).max()
        df0['hi_10']=df.iloc[:,c].tail(10).max()
        df0['hi_22']=df.iloc[:,c].tail(22).max()
        df0['hi_44']=df.iloc[:,c].tail(22).max()
        df0['hi_66']=df.iloc[:,c].tail(66).max()
        df0['hi_252']=df.iloc[:,c].tail(252).max()  
        df0['lo_5']=df.iloc[:,c].tail(5).min()
        df0['lo_10']=df.iloc[:,c].tail(10).min()
        df0['lo_22']=df.iloc[:,c].tail(22).min()
        df0['lo_44']=df.iloc[:,c].tail(22).min()
        df0['lo_66']=df.iloc[:,c].tail(66).min()
        df0['lo_252']=df.iloc[:,c].tail(252).min()  
        df0['rtn_5']=df.iloc[-1,c]/df.iloc[-5,c]-1 
     
        df0['rtn_22']=df.iloc[-1,c]/df.iloc[-22,c]-1 
        df0['rtn_66']=df.iloc[-1,c]/df.iloc[-66,c]-1 
        #get hv_5
        #try:
            #x=(df.iloc[:,c]/df.iloc[:,c].shift(1))
            #print (x.dtype)
        log_rtn=np.log(df.iloc[:,c]/df.iloc[:,c].shift(1))
          #pass
        #df0['log_rtn']=np.log(df.columns[c]/df.columns[c].shift(1))
        #log_rtn=np.log(df.iloc[:,c]/df.iloc[:,c].shift(1))
        df0['hv_5']=np.sqrt(252*log_rtn.tail(5).var())
        df0['hv_10']=np.sqrt(252*log_rtn.tail(10).var())
        df0['hv_22']=np.sqrt(252*log_rtn.tail(22).var())
        df0['hv_66']=np.sqrt(252*log_rtn.tail(66).var())
        df0['hv_252']=np.sqrt(252*log_rtn.tail(252).var())
        #get normal testing
        tp_10=stats.normaltest(log_rtn[-11:-1])
        tp_22=stats.normaltest(log_rtn[-23:-1])
        tp_66=stats.normaltest(log_rtn[-67:-1])
        tp_252=stats.normaltest(log_rtn[-252:-1])
       
        df0['p_10']=tp_10[1]
        df0['p_22']=tp_22[1]
        df0['p_66']=tp_66[1]  
        df0['p_252']=tp_252[1]
        
        df_st=df_st.append(df0)
        df_stat=df_st.set_index('ticker') #ticker is set to be index
        df_stat['date']=q_date  
        df_stat['sharpe_5']=df_stat['rtn_5']/df_stat['hv_5']
        df_stat['sharpe_22']=df_stat['rtn_22']/df_stat['hv_22']
        df_stat['sharpe_66']=df_stat['rtn_66']/df_stat['hv_66']
        df_stat['hv_m2y']=df_stat['hv_22']/df_stat['hv_252']
        df_stat['mean_510']=df_stat['mean_5']>df_stat['mean_10']
        df_stat['mean_1022']=df_stat['mean_10']>df_stat['mean_22']
        df_stat['mean_2266']=df_stat['mean_22']>df_stat['mean_66']
        df_stat['mean_66252']=df_stat['mean_66']>df_stat['mean_252']
        #below added on Jan.2, 2017
        df_stat['rtn_ma66']=df_stat['mean_5']/df_stat['mean_66']-1
        df_stat['rtn_ma252']=df_stat['mean_5']/df_stat['mean_252']-1
        #enrich with 1sig forward expected price move    
        df_stat['p_22_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(22)/ np.sqrt(252)
        df_stat['p_44_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(44)/ np.sqrt(252)
        df_stat['p_66_sig']=df_stat['close_qdate']*df_stat['hv_252']*np.sqrt(66)/ np.sqrt(252)
        #call rank() to enrich df_stat
    df_stat_rank=stat_rank(df_stat)
        #overwrite tbl_stat_hist
    if env=='prod' and underlying=='sp500':
        to_sql_replace(df_stat, "tbl_stat")
    elif env=='prod' and underlying=='etf':
        to_sql_replace(df_stat, "tbl_stat_etf")    
    elif env=='test' and underlying=='sp500':
        to_sql_replace(df_stat, "tbl_stat_test")
    elif env=='test' and underlying=='etf':
        to_sql_replace(df_stat, "tbl_stat_etf_test")
   # print ("--- stat_run completed and replaced into tbl_stat_'%s'_'%s'---"%(underlying, env))
    return df_stat

#in:tbl_stat_hist / out:tbl_play_hist
def play_run(q_date, underlying, env='prod'): #qdate - date of running this, latest date
    df_temp=pd.DataFrame()
    df=pd.DataFrame()
    df_prev=pd.DataFrame()  #store last df_play
    dd=pd.DataFrame()
    if env=='prod':
        if underlying=='sp500':
            df_playbook=pd.read_excel(open('G:\\Trading\Trade_python\pycode\pyprod\playbook.xlsx','rb'), sheetname='plays')
            qry="SELECT * FROM tbl_play"
            df_prev=read_sql(qry, lday)
            
        elif underlying=='etf':
            df_playbook=pd.read_excel(open('G:\\Trading\Trade_python\pycode\pyprod\playbook.xlsx','rb'), sheetname='plays_etf')
            qry="SELECT * FROM tbl_play_etf"
            df_prev=read_sql(qry, lday)
            
    elif env=='test':
        if underlying=='sp500':
            df_playbook=pd.read_excel(open('G:\\Trading\Trade_python\pycode\pytest\playbook_test.xlsx','rb'), sheetname='plays')
        elif underlying=='etf':
            df_playbook=pd.read_excel(open('G:\\Trading\Trade_python\pycode\pytest\playbook_test.xlsx','rb'), sheetname='plays_etf')
    else:
        print ("play_run() missing env or underlying")
        exit
        
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
    for index, row in df_playbook.iterrows():
        query=row['script']    
        df_temp=read_sql(query, conn) #because tbl_stat has only the latest stat, so only latest result
        df_temp['play']=row['play']
        df=df.append(df_temp)
        df['date']=q_date
    df.reset_index(level=0, inplace=True, drop=True)    
    #append to tbl_play_hist
    if env=='prod':
        if underlying=='sp500':
             to_sql_replace(df, "tbl_play")
             to_sql_append(df, "tbl_play_hist")
        elif underlying=='etf':
             to_sql_replace(df, "tbl_play_etf")
             to_sql_append(df, "tbl_play_hist_etf")
# print new ticker by comparing with last df_play             
        df1=df[['ticker','play']]
        df2=df_prev[['ticker','play']]
        dff=df1.merge(df2, indicator=True, how='left')
        dff=dff[dff['_merge']=='left_only']
        print(dff)
        dff.to_csv(r'G:\Trading\Trade_python\pycode\new_play_list.csv')  
    else:
        if underlying=='sp500':
            to_sql_replace(df, "tbl_play_test")
        elif underlying=='etf':
             to_sql_replace(df, "tbl_play_etf_test")        
        pass
    print ("---play_run completed and appended to tbl_play_hist")
    
    return df
    
def get_column():
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
    cur=conn.cursor()
    cur.execute("SELECT * FROM tbl_price")
    return [member[0] for member in cur.description]
 
def feature_view(df):
    df_view=df.drop(['max', 'mean',\
       'mean_10', 'mean_22', 'mean_5', 'mean_66', 'min','close_qdate',\
       'count','std',  'p_22_sig','p_44_sig','p_66_sig',
       'p_22_fwd',  '25%', '50%', '75%', 'close_22b', 'close_66b'],1)
    df_view.sort_index(axis=1)
    df_view.sort(['win_22'], ascending=[0])
    total=df_view.shape[0]
    true_22=df_view[df_view.win_22==True].shape[0]
    ratio_22=true_22/total
    print ("total: ", total)
    print ("true_22: ", true_22, ",  true_22 ratio: ", ratio_22)
    return df_view

def play_run_daily(q_date, underlying, env='prod'):
    if env=='prod':
        stat_run(q_date,underlying, 'prod')
        df_play=play_run(q_date, underlying, 'prod')
        df_play=play_view(df_play)
        df_play['exit_date']='N'
        df_play.to_csv('G:\\Trading\Trade_python\pycode\playlist_%s_%s.csv'%(underlying, q_date))  
    elif env=='test':
        stat_run(q_date, underlying, 'test')
        df_play=play_run(q_date, underlying, 'test')
        df_play=play_view(df_play)
        df_play['exit_date']='N'        
        df_play.to_csv('G:\\Trading\Trade_python\pycode\pytest\playlist_%s_test_%s.csv'%(underlying, q_date))  
    else:
       print("play_run_daily miss env or underlying")  
    print("----  %s %s---play_run_daily completed"%(underlying,env))
    return df_play

def play_view(df): #generic
#if df_play is from legacy stat_run then drop, elif from stat_adhoc, then no drop
    if set(['25%']).issubset(df.columns): 
        df=df.drop(['25%', '50%', '75%', 'close_22b', 'close_66b','count', 'hv_10','hv_5', 'hv_66', 'max', 'mean',\
   'mean_10', 'mean_22', 'mean_252', 'mean_5', 'mean_66', 'min', 'p_10',   'p_22', 'p_252', 'p_66', 'rtn_22',\
            'rtn_5', 'rtn_66', 'std', 'sharpe_5', 'sharpe_22', 'sharpe_66',   'mean_510', \
        'sharpe_5_pct', 'rtn_5_pct', 'sharpe_22_pct', 'rtn_22_pct','sharpe_66_pct', 'rtn_66_pct', 'p_252_pct', \
           'p_10_pct', 'p_22_pct','p_66_pct', 'hv_5_pct', 'hv_22_pct', 'hv_66_pct', 'hv_252_pct','hv_m2y_pct'],1)
    
        df=df.drop(['hi_10', 'hi_22', 'hi_252', 'hi_44', 'hi_5', 'hi_66', 'hv_22',\
        'lo_10', 'lo_22', 'lo_252', 'lo_44', 'lo_5', 'lo_66'],1)
    #enrich fileds for trade input
    df_form=pd.DataFrame(columns=['entry_note','entry_price','entry_date','estike_1','estrike_2','contracts','erisk'\
                         ,'exit_target','expire_date','be_up','be_down','exist_pct','alert_exit','alert_stop'\
                         ,'exit_date','exit_price','epnl_pct','epnl','exit_note','close_last','date_last', 'days_left'\
                         ,'con_1', 'con_2','con_p1','con_p2','con_ex1','con_ex2','con_ex_p1','con_ex_p2','comm','delta'])
    df=df.append(df_form)
    df.reset_index(inplace=True, drop=True)
    # enrich with earning dates
    for index, row in df.iterrows():
        df.loc[index,'earning_date']=get_earning_date(row['ticker']) 
        df.loc[index,'rsi']=get_rsi(row['ticker'])
#        get_info error on Jan10
        try:
            df.loc[index,'div_yield'], df.loc[index,'ex_div'], df.loc[index,'pct_50_ma'], df.loc[index,'pct_200_ma'],\
            df.loc[index,'pct_hi'], df.loc[index,'pct_lo'], df.loc[index,'pe'], df.loc[index,'peg'],\
            df.loc[index,'si']=get_Share(row['ticker']) #, df.loc[index,'vol_ratio']
        except:
            print("get_Share error")
    return df

def get_Share(ticker=''):
    ticker=Share(ticker)
    x=ticker._fetch()
    div_yield=x['DividendYield']
    ex_div=x['ExDividendDate']
    pct_50_ma=x['PercentChangeFromFiftydayMovingAverage']
    pct_200_ma=x['PercentChangeFromTwoHundreddayMovingAverage']
    pct_hi=x['PercebtChangeFromYearHigh']
    pct_lo=x['PercentChangeFromYearLow']
    pe=x['PERatio']
    peg=x['PEGRatio']
    si=x['ShortRatio']
#    try:
#        vol_ratio=float(x['Volume'])/float(x['AverageDailyVolume'])
#    except TypeError:
#        print(ticker)
    return div_yield, ex_div, pct_50_ma, pct_200_ma, pct_hi, pct_lo, pe, peg, si#, vol_ratio
   
def get_earning_date(ticker=''):
    """
    https://github.com/sgerhardt/TakeStock/blob/master/src/QuarterlyReport.py
    """
    try:
        earnings_url = 'http://www.nasdaq.com/earnings/report/' + ticker.lower()
        request = requests.get(earnings_url)
        soup = bs4.BeautifulSoup(request.text, 'html.parser')
        tag = soup.find(text=re.compile('Earnings announcement*'))
        return tag[tag.index(':') + 1:].strip()
    except:
        return 'No Data Found'   
        
def get_si(ticker=''):
    import urllib3
    http=urllib3.PoolManager()
    url = "http://www.nasdaq.com/symbol/" + ticker + "/short-interest"
#    res = urllib3.urlopen(url)
#    res = res.read()
    res=http.request('GET', url)
    html=res.read()
    soup =bs4.BeautifulSoup(html)
    si = soup.find("div", {"id": "quotes_content_left_ShortInterest1_ContentPanel"})
    si = si.find("div", {"class": "genTable floatL"})
    df = pd.read_html(str(si.find("table")))[0]
    df.index = pd.to_datetime(df['Settlement Date'])
    del df['Settlement Date']
    df.columns = ['ShortInterest', 'ADV', 'D2C']
    return df.sort()

def get_rsi(ticker=''):
    """
    This function gets the rsi for the given ticker symbol. It performs a request to the
    nasdaq url and parses the response to find the rsi.
    :param ticker: The stock symbol/ticker to use for the lookup
    :return: String containing the rsi
    """
    try:
        rsi_url = 'http://charting.nasdaq.com/ext/charts.dll?2-1-14-0-0-512-03NA000000' + ticker.upper() \
                  + '-&SF:1|27-SH:27=10-BG=FFFFFF-BT=0-WD=635-HT=395--XTBL-'
        request = requests.get(rsi_url)
        soup = bs4.BeautifulSoup(request.text, 'html.parser')
        return soup.find_all('td', class_="DrillDownData")[1].text
    except:
        return 'No Data Found'
        
def trade_track(underlying, reval_date):
# 1. tbl_trade is to record entry of new trades
# 2. query and append historical trade from tbl_trade to tbl_trade_hist
# 3. for live trade, get price from tbl_price; update to tbl_trade_track and tbl_trade
#4.  so tbl_trade only keep live trade, 
#get tickers for live trades from tbl_trade
#save historical trade to tbl_trade_hist
    start_time=timer()
    if underlying=='sp500':
        q_trade_hist="SELECT * FROM tbl_trade WHERE exit_date<>'N'" #get ride of non-live trade
        q_trade="SELECT * FROM tbl_trade WHERE exit_date ='N'"   #get live trade
    elif underlying=='etf':
        q_trade_hist="SELECT * FROM tbl_trade_etf WHERE exit_date<>'N'" 
        q_trade="SELECT * FROM tbl_trade_etf WHERE exit_date ='N'"
    else:
        print ("trade_track() missing underlying")
        exit
# save historical trades
    dh=read_sql(q_trade_hist, reval_date)
    if set(['level_0']).issubset(dh.columns):    
        dh=dh.drop(['level_0'],1)
    if underlying =='sp500':
        to_sql_append(dh, 'tbl_trade_hist')
    elif underlying == 'etf':
        to_sql_append(dh, 'tbl_trade_hist_etf')
 #   q_trade="SELECT * FROM tbl_trade WHERE exit_date ='N'" #get only live trade
    dt=read_sql(q_trade, reval_date)
    dt=dt.fillna(0)  #fill Nan with 0 for calc
    #get late price for above tickers from tbl_price
    #get previous price pct
#get win_10 to alert for exit
    dt['pct_estrike_prev']=dt['close_last']/dt['estike_1']-1
    dt['rsi_prev']=dt['rsi']
   #update latest price from tbl_price and rsi
# update lastest corr from tbl_stat which has latest corr
    for index, row in dt.iterrows():
        ticker=row['ticker']
        if underlying=='sp500':
            q_price="SELECT date, %s FROM tbl_price WHERE instr(date,'%s')>0"%(ticker, reval_date)
            q_stat="SELECT corr FROM tbl_stat WHERE ticker ='%s'"%ticker
        else: 
            q_price="SELECT date, %s FROM tbl_price_etf WHERE instr(date,'%s')>0"%(ticker, reval_date)
            q_stat="SELECT corr FROM tbl_stat_etf WHERE ticker ='%s'"%ticker
        dp=read_sql(q_price, reval_date)
        dc=read_sql(q_stat, reval_date)
        if not dp.empty:
            close=dp.iloc[0,1]
        else:
            print("no latest price:", ticker)
            exit            
        dt.loc[index, 'close_last']= close #update close_last price
        dt.loc[index,'rsi']=float(get_rsi(ticker)) ## Convert to Flaat from Object
        dt.loc[index,'corr_new']=dc.iloc[0,0]  ## update latest corr
        
        if ticker =='TLT':
            dt.loc[index, 'beta']=-0.27
        else:    
            dt.loc[index, 'beta']=DF_sp500[DF_sp500['SYMBOL']==ticker].beta.values[0] #series   
        x=Share(ticker)._fetch()
        x_si=x['ShortRatio']
        x_p_pct=x['ChangeinPercent']
        x_vol=x['Volume']
        x_vol_avg=x['AverageDailyVolume']
        x_ex_div=x['ExDividendDate']  # ex_div from Share yahoo source
        try:
            y_ex_div=get_share_nasdaq(ticker)  #ex_div from Nasdaq source
            if len(y_ex_div)>0 and (y_ex_div[0] != 'N/A') and (y_ex_div[0] >= x_ex_div):
                dt.loc[index, 'ex_div']=y_ex_div[0] #Nasdq
            else:
                dt.loc[index, 'ex_div']=x_ex_div  #yahoo
        except:
            pass
        dt.loc[index, 'si']=x_si
        dt.loc[index, 'p_pct']=x_p_pct
        
        dt.loc[index, 'v_pct']=float(x_vol)/float(x_vol_avg) #string to float
        dt.loc[index, 'ta']=''        
#        try:
#            dt.loc[index, 'ta']=get_ta(ticker)
#        except:
#            pass
# add bechmark       
        if underlying =='sp500':
           x,y,z=get_benchmark(ticker)
           dt.loc[index,'sec']=x
           dt.loc[index, 'rrtn_22_ts']=y
           dt.loc[index,'rrtn_22_sm'] = z
#                print("benchmark error:   ", row['ticker'])
#                pass
        elif underlying =='etf':
            dt.loc[index,'sec']=''
            dt.loc[index,'rrtn_22_ts']=''
            dt.loc[index,'rrtn_22_sm']=''

   # dt calc risk
    dt.date_last=reval_date  
    dt['contracts']=dt['con_1']+dt['con_2']-dt['con_ex1']-dt['con_ex2']
    dt['entry_price']=(dt['con_1']*dt['con_p1']+dt['con_2']*dt['con_p2'])/(dt['con_1']+dt['con_2'])
    dt['exit_price']=(dt['con_ex1']*dt['con_ex_p1']+dt['con_ex2']*dt['con_ex_p2'])/(dt['con_ex1']+dt['con_ex2'])
    dt['erisk']=dt['contracts']*dt['entry_price']*100
    dt['epnl']=(dt['con_ex1']+dt['con_ex2'])*(dt['exit_price']-dt['entry_price'])*100-dt['comm']
    dt['epnl_pct']=0.01*dt['epnl']/((dt['con_1']+dt['con_2'])*dt['entry_price'])
    dt['days_to_expire']=pd.to_datetime(dt['expire_date'])-pd.to_datetime(dt['date_last']) 
    dt['days_all_life']= pd.to_datetime(dt['expire_date'])-pd.to_datetime(dt['entry_date'])
# evaluate p_fwd_10 early sign    
    dt['days_from_entry']=dt['days_all_life'] - dt['days_to_expire']
    
# early indicator to stay or exit trade  !!
    dt.loc[dt['days_from_entry']=='5 days','p_5_fwd']=dt['close_last']
    dt.loc[dt['days_from_entry']=='10 days','p_10_fwd']=dt['close_last']
#        dt['p_fwd_10']=dt['close_last']
    dt=win_loss(dt, 10)  #
#    return dt
#    exit
    if underlying=='sp500':    
        dt.loc[dt.ex_div=='0', 'ex_div']=datetime.datetime(2016,1,1) #day of month out of range error
    else: 
        dt['ex_div']=datetime.datetime(2016,1,1)
    dt['days_to_exdiv']=pd.to_datetime(dt['ex_div']) - pd.to_datetime(dt['date_last'])
    dt['exist_pct']=1-dt['days_to_expire']/dt['days_all_life']
    dt['exist_pct']=dt['exist_pct'].round(2)
    dt['days_left']=dt['days_to_expire']
    dt['days_to_exdiv']=dt['days_to_exdiv']
    #dt calculated fields
    dt['weigh']=dt['erisk']/(dt['erisk'].sum())
    #dt['pct_estrike_1']="{:.1%}".format(dt['close_last'])/dt['estike_1']-1)
    dt['pct_estrike_1']=(dt['close_last']/dt['estike_1']-1).round(2)
    dt.alert_stop= (dt.close_last > dt.be_up) | (dt.close_last< dt.be_down)
    dt['alert_sig']= np.abs(dt.close_last - dt.close_qdate) >=dt.p_22_sig
    dt.alert_exit= (dt.play=='BF_CAL') & (dt.pct_estrike_1 <=0.02) &(dt.exist_pct>=0.5)
    dt['alert_div']=(dt.days_to_exdiv<='4 days') & (dt.days_to_exdiv>='0 days')
    dt['alert_prexit']=(dt.days_to_expire<='8 days') & (pd.isnull(dt.exit_target))
    #export alerted trades
    #df_alert=dt[(dt.alert_stop ==True)|(dt.alert_exit==True)]
    dt.alert_stop[dt.alert_stop==False]=""
    dt.alert_exit[dt.alert_exit==False]=""
    dt.alert_div[dt.alert_div==False]=""  
    dt.alert_sig[dt.alert_sig==False]=""  
    dt.win_5[dt.win_5==False]="" 
    dt.win_10[dt.win_10==False]="" 
    #multiple conditional alert
    dt.loc[((dt['play']=='L')|(dt['play']=='LL')), 'alert_direction']=dt['rsi']<dt['rsi_prev'] #less momentum
    dt.loc[((dt['play']=='S')|(dt['play']=='SS')), 'alert_direction']=dt['rsi']>dt['rsi_prev']
    dt.loc[((dt['play']=='CAL')|(dt['play']=='ZZ')|(dt['play']=='Z0')), 'alert_direction']=\
            np.abs(dt['pct_estrike_1'])>np.abs(dt['pct_estrike_prev'])
    dt.loc[dt['play']=='E', 'alert_direction']=np.abs(dt['pct_estrike_1'])<np.abs(dt['pct_estrike_prev'])
   #counter
#    if underlying=='sp500':
#        dt.loc[dt['alert_stop']==True, 'counter']=dt['counter'].astype(float)+1
#    else:
#        dt['counter']=10
    dt.loc[dt['alert_stop']==True, 'counter']=dt['counter'].astype(float)+1
    dt.alert_direction[dt.alert_direction==False]="" 
    #dt.counter[dt.counter==0]="" 
#    if underlying=='sp500':    
#        dt=dt.drop(['level_0'],1)
#    else:
#        pass
    dt=dt.drop(['level_0'],1)
    if underlying=='sp500':
        to_sql_replace(dt, 'tbl_trade_track')
        to_sql_replace(dt, 'tbl_trade')
    else:
        to_sql_replace(dt, 'tbl_trade_etf')
    #pd.set_option('display.max_columns', None)
    dt['rsi_chg']=dt['rsi']-dt['rsi_prev']
  #  print (colored('>>>>>>>>>     NO exit order!!!    <<<<<<<<', 'red', attrs=['bold', 'reverse','blink']))
    print(dt[dt.alert_prexit==True]['ticker'])
  #  print (colored('>>>>>>>>>     NO exit order!!!    <<<<<<<<', 'red', attrs=['bold','reverse','blink']))
    print("")
    print (colored('>>>>>>>>>     ALERT!!!    <<<<<<<<', 'red'))
    #print (df_alert[['ticker', 'alert_stop', 'alert_exit','erisk']])
    dtt=dt[['ticker','erisk', 'weigh', 'delta','beta', 'alert_stop','counter','alert_div', 'days_left',\
    #'alert_direction',\
    'pct_estrike_1','rsi_chg', 'p_pct', 'v_pct', 'si', 'ex_div', 'ta', 'corr_new', \
    'win_5', 'win_10', 'sec', 'rrtn_22_ts', 'rrtn_22_sm']]
    print("total risk:", dt['erisk'].sum())
    print("invested:", dt['erisk'].sum()/capital)
#    SPY=web.get_data_yahoo('SPY',today, today).Close[0]
    SPY=web.get_quote_yahoo('SPY')['last']
    print (colored('>>>> SPY equivalent number of share in movement <<<<<<<<', 'red'))
    print("SPY equivalent share in movement:", (dt['beta']*dt['delta']*dt['close_last']).sum()/SPY)
    
    end_time=timer()
    test_time=end_time - start_time
    print("trade_track is done in seconds:  %s"%test_time)
    
    return dtt
# one month return benchmark with sector and SPY
def get_benchmark(ticker=''): #df_adhoc has column "ticker", ad hoc run on stock
# join ETF to get corr
    ticker=ticker.upper()
    qry="SELECT * FROM tbl_price x JOIN tbl_price_etf y ON x.date=y.date"
    df_price=read_sql(qry,lday)  
    df_price = df_price.loc[:,~df_price.columns.duplicated()] #drop duplicated columns -date
    df_price=df_price.set_index('date')
    df_tmp=pd.DataFrame(data=[], index=df_price.index)
    ds_tmp=pd.DataFrame()
    ds=pd.DataFrame()
    sec=DF_sp500[DF_sp500['SYMBOL'] == ticker].ETF  #series value
    df_tmp['ticker']=ticker
    df_tmp['close_t']=df_price[ticker]
    df_tmp['sec']=sec.values[0]
    df_tmp['close_s']=df_price[sec]
    df_tmp['spy']=df_price['SPY']
    df_tsm=df_tmp.tail(504)#historical data 1 year
    ds_tmp=benchmark(df_tsm)
    ds=ds.append(ds_tmp)
    ds=ds.dropna()
    
    return ds['sec'].values[0], ds['rrtn_22_ts'].values[0], ds['rrtn_22_sm'].values[0]
        
def benchmark(df_tsm): # ticker/sector/market   ad hoc process beta, alpha, 
# one month return difference btn ticker,sec,mkt
    df=pd.DataFrame()  
    ds=pd.DataFrame()
# rtn_t: ticker, s: sector, m: market
    df_tsm[['rtn_t','rtn_s','rtn_m']]=df_tsm[['close_t', 'close_s','spy']]/df_tsm[['close_t', 'close_s','spy']].shift(1)-1
    df_tsm=df_tsm.dropna()
    covmat = np.cov(df_tsm['rtn_t'],df_tsm['rtn_m'])    
    beta = covmat[0,1]/covmat[1,1]  
          
    df['ticker']=df_tsm['ticker']
    df['beta']=beta
    #calc rtn_22 diff btn stock and mkt in past 22 days
    df['rrtn_22_sm'] = df_tsm['close_s'].tail(0)/df_tsm['close_s'].tail(0).shift(22) - \
        df_tsm['spy'].tail(0)/df_tsm['spy'].tail(0).shift(22)
    df['rrtn_22_ts'] = df_tsm['close_t'].tail(0)/df_tsm['close_t'].tail(0).shift(22) - \
        df_tsm['close_s'].tail(0)/df_tsm['close_s'].tail(0).shift(22)
    ds['rtn_22']=df_tsm['close_t'].tail(0)/df_tsm['close_t'].tail(0).shift(22)-1
    df=df.dropna()    
# plot relatvie rtn as personality change
  # return stat by ticker
    ds['ticker']=df['ticker'].tail(1)
    ds['sec']=df_tsm['sec'].tail(1)
    ds['beta']=df['beta'].tail(1)
    ds['rrtn_22_ts']=df['rrtn_22_ts'].tail(1)
    ds['rrtn_22_sm']=df['rrtn_22_sm'].tail(1)
    ds=ds.dropna()
    return ds    
        
def trade_entry(underlying):
    if underlying =='sp500':
        df_trade=pd.read_excel(open(r'G:\Trading\Trade_python\pycode\trade.xlsx','rb'))
    #df_trade=pd.read_csv('G:\Trading\Trade_python\pycode\\trade.xlsx')
        to_sql_append(df_trade, 'tbl_trade')  #log trades and track performance
        to_sql_append(df_trade, 'tbl_trade_bkup') #keep trde only
        print ("trade is saved in tbl_trade")
    elif underlying == 'etf':
        df_trade=pd.read_excel(open(r'G:\Trading\Trade_python\pycode\trade_etf.xlsx','rb'))
    #df_trade=pd.read_csv('G:\Trading\Trade_python\pycode\\trade.xlsx')
        to_sql_append(df_trade, 'tbl_trade_etf')  #log trades and track performance
        to_sql_append(df_trade, 'tbl_trade_etf_bkup') #keep trde only
        print ("trade is saved in tbl_trade_etf")   
    else:
        print ("trade_entry missing env")
        exit

def view_map():
    qry="SELECT * FROM tbl_price_etf"
    df=read_sql(qry, lday)
    df=df.set_index('date')
    df_risk=df[['SPY','GLD','JJC','WYDE','HYG',\
        'TLT', 'UUP']]
    risk_base=df_risk.corr().ix['SPY',:]
    dr=df_risk.tail(180)
    drp=pd.rolling_corr(dr['SPY'], dr, window=66, pairwise=True)
    drp=drp.drop(['SPY'],1)
    #plot chart
 # forex
    df_fx=df[['UUP','FXC','FXY','FXA','FXE','GLD','TLT']]
    dx=df_fx.tail(180)
    dxp=pd.rolling_corr(dr['UUP'], dx, window=66, pairwise=True)
    dxp=dxp.drop(['UUP'],1)    
    print ("180 day correlation to SPY")
    plot(drp)
    plot(dxp)
def view_csv():  #sp500 component correlation, sector, volatility
    duration=200    
    lookback=22
    #get sp500 componetn correaltion
    qry="SELECT * FROM tbl_price"
    df=read_sql(qry, lday)
    df=df.set_index('date')
    df.sort_index(axis=0)  # 
    df_cosp=df.tail(duration)
    
    df_cs=pd.rolling_corr(df_cosp['SPY'], df_cosp, window=lookback, pairwise=True)
    df_cs=df_cs.tail(duration-lookback)
    df_cs.fillna(0, inplace=True)
    dc=df_cs.mean(axis=1)  #series, correlation of sp500 component
#clean data value and duplicated index
    dc.replace(np.inf, np.nan, inplace=True)
    dc.replace(-np.inf, np.nan, inplace=True)    
    dc.fillna(method='ffill', inplace=True)
    dc=dc[~dc.index.duplicated(keep='first')]
    #get sector corr
    query="SELECT * FROM tbl_price_etf"
    de=read_sql(query,lday)
    de=de.set_index('date')
    de.sort_index(axis=0)
   #get secto etf corr
    df_sec=de[['SPY','XLY','XLE','XLF','XLV','XLI','XLB','XLK','XLU','XLP']]
    df_s=pd.rolling_corr(df_sec['SPY'], df_sec, window=lookback, pairwise=True)
    df_s=df_s.tail(duration-lookback)
    df_s.fillna(0, inplace=True)
    ds=df_s.mean(axis=1) #sector ETF with SPY
    ds=ds[~ds.index.duplicated(keep='first')]
    #get vix
#    dv=de['^VIX']
    dv=de['VXX']
    dv=dv.tail(duration)
    dv=dv[~dv.index.duplicated(keep='first')]
    #get secto etf corr
    df_csv=pd.DataFrame({'cosp':dc, 'sec':ds, 'vxx':dv})   
   #plot on two axis
    fig=plt.figure()  #general figure
    plt.xticks(rotation=45) 
    plt.grid(b=True, which='major', color='black')
    ax1=fig.add_subplot(111)
    df_csv['cosp'].plot(color='b')
    #ax1.plot(df_cv['cosp'])
    df_csv['sec'].plot(color='y')
    ax2=ax1.twinx()
    #ax2.plot(df_cv['vix'])
    df_csv['vxx'].plot(color='r')
    plt.legend(loc='best')
#    plt.grid(b=True, which='minor', color='black')
    print("correlation - Blue: Sector, Brown: sp500 component")
    plt.show()

def view_macro():
    qry="SELECT * FROM tbl_stat_etf"
    df=read_sql(qry, lday)
    df=df[['ticker', 'rtn_5','rtn_22','rtn_66', 'corr','hv_22', 'hv_252','hv_m2y', \
    'mean_510', 'mean_1022', 'mean_2266','mean_66252']]
    df['momt']=df.mean_510.astype(str)+df.mean_1022.astype(str)+df.mean_2266.astype(str)+df.mean_66252.astype(str)
    df=df.drop(['mean_510', 'mean_1022', 'mean_2266','mean_66252'], axis=1)
    sector=['SPY','XLY','XLE','XLF','XLV','XLI','XLB','XLK','XLU','XLP']
    con_sec=df['ticker'].isin(sector)  #is in a list
    ds=df[con_sec]
    ds=ds.sort(['momt','rtn_5','rtn_22'], ascending=[False,True, True])
    print("sector view:")
    return ds

def plot(df):  
    columns=df.shape[1]
    num_plots=df.shape[1]
    colormap=plt.cm.gist_ncar
    plt.gca().set_color_cycle([colormap(i) for i in np.linspace(0, 0.9, num_plots)])
    for i in range(columns):
        datarow=df.iloc[:,i]
        datarow.plot(alpha=0.8)
#        plt.plot(datarow)
#    locs, labels = plt.xticks()   
#    plt.xlabel("date")
#    #plt.ylabel("win_lose")
#    labels=df.columns
#    locs=np.arange(labels.shape[0])
#   plt.xticks( locs, labels, rotation=45 )
    plt.xticks(rotation=45 )    
    plt.legend(loc='best')
    #ax.set_xticks(labels, minor=True)
    #print (locs)
    plt.grid(b=True, which='major', color='black')
    plt.show()    
    
def unpv(underlying,lday):  #scan unusal volume or price change
    v_fac=2.5 # avg. volume times
    p_fac=4/100  #price percent change
    list_all=[]
    list_tmp=[]
    da=pd.DataFrame()
    df=pd.DataFrame()
    dpv=pd.DataFrame()
    if underlying== 'sp500':
        df_symbol= df_sp500
    elif underlying == 'etf':
        df_symbol= df_etf
    len= df_symbol.shape[0]
    i=0
    while (i<=len):
        df_symbol=df_symbol[i:i+50]
        for ticker in df_symbol:
    #ticker, avg_vol, volume, DaysHigh, DaysLow, div_yield, ex_div,pe, si, peg,p_pct,p_1y, ma_50,\
    #ma_200,pct_50_ma, pct_200_ma, pct_hi, pct_lo
            x=Share(ticker)._fetch()
            list_tmp=[ticker,x['LastTradePriceOnly'],x['DaysRange'] ,\
            x['DividendYield'],x['ExDividendDate'],x['PERatio'],x['ShortRatio'],\
            x['PEGRatio'], x['OneyrTargetPrice'],x['FiftydayMovingAverage'],\
            x['TwoHundreddayMovingAverage'], x['PercentChangeFromFiftydayMovingAverage'],\
            x['PercentChangeFromTwoHundreddayMovingAverage'],  x['PercebtChangeFromYearHigh'],\
            x['PercentChangeFromYearLow'],x['AverageDailyVolume'],x['Volume'], x['ChangeinPercent']
            ]
            list_all.append(list_tmp)
        names=['ticker', 'close','range', 'div_yield', 'ex_div','pe', 'si', \
            'peg','p_1y', 'ma_50', 'ma_200','pct_50_ma', 'pct_200_ma', 'pct_hi',\
            'pct_lo', 'avg_vol','volume','p_pct']
        data=list_all
        da=pd.DataFrame(data, columns=names)
        df=df.append(da)
        i+=51
        
    df['v_pct']=df['volume'].astype(float)/df['avg_vol'].astype(float)
    df['date']=lday
    df.set_index('date', inplace=True) 
    con_v=np.abs(df['v_pct'])>=v_fac
    con_p=np.abs(df['p_pct'].str.strip('+-%').astype(float))>=p_fac*100
    dpv=df[con_v | con_p]
    dpv=dpv[~dpv.index.duplicated(keep='first')] 
    dpv=dpv.drop(['ma_50', 'ma_200','avg_vol','volume'],1)
    print(dpv)
    print("unpv() is done")

def update_price_eod(underlying):
    if underlying =='sp500':
        df_symbol=df_sp500
    elif underlying =='etf':
        df_symbol=df_etf
    
    path='G:\Trading\Trade_python\eod'
    path=r"%s"%path
    files=os.listdir(path)
    #list csv files
    files_csv=[f for f in files if f[-3:]=='csv']
    if len(files_csv)==0:
        print("eod file not available")
        exit
        
    df_price=pd.DataFrame()
    for f in files_csv:
        df=pd.read_csv(r'G:\Trading\Trade_python\eod\%s'%f)#, index_col=0)
# filter df with series df_sp500
        df=df[df['A'].isin(df_symbol)]
        df=df.iloc[:,[0,1,5]] #ticker, date, close
        df=df.T
        df=df.rename(columns=df.iloc[0]) #convert row to columns name
        df['date']=df.iloc[1,1]
        df['date']=pd.to_datetime(df['date'])  #convert string to datetime
#        df.set_index('date', inplace=True)
#        df.index.name='date'
        df=df.iloc[2,:] #keep close only
        df_price=df_price.append(df)
    df_price.reset_index(drop=True, inplace=True)
    df_price.sort('date', ascending=True, inplace=True) 
    eod_to_sql_append(df_price, underlying)
    return df_price

def eod_to_sql_append(df, underlying):
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
       
    if underlying =='sp500':
        pd_sql.to_sql(df, "tbl_price", conn, if_exists='append', index=False)
    elif underlying =='etf':
        pd_sql.to_sql(df, "tbl_price_etf", conn, if_exists='append', index=False)
    print("%s eod: %s appended to tbl_price"%(underlying, ldate))
    
def beta(underlying, tickers=''):
    if underlying =='sp500':
        query="SELECT * FROM tbl_price"
    elif underlying == 'etf':
        query="SELECT * FROM tbl_price_etf"
    df=read_sql(query,ldate)
    df=df.fillna(0)
    df['date']=ldate
# convert date column to index index
    df.set_index('date', inplace=True)
    df_corr=df.tail(132).corr().ix['SPY',:]
    for ticker in tickers:
#        x=df[ticker]
#        y=df['SPY']
#        cov=np.cov(x,y)[0][1]
#        var=np.var(y)
#        beta=cov/var
        a=df[[ticker,'SPY']]
#        a[['t_rtn','m_rtn']]=(a[[ticker,'SPY']]/a[[ticker,'SPY']].shift(1)-1)
        a[['t_rtn', 'm_rtn']]=np.log(a[[ticker, 'SPY']].diff())    
        a.replace(np.inf, np.nan, inplace=True)
        a.replace(-np.inf, np.nan, inplace=True)
        a=a.dropna()
        r=sm.OLS(a['t_rtn'],a['m_rtn']).fit()
        
        bt=r.params["m_rtn"]
        cm=np.cov(a['t_rtn'],a['m_rtn'])
        beta=cm[0,1]/cm[1,1]
        print ("%s beta is: %s"%(ticker, beta))
        print ("%s bt is: %s"%(ticker, bt))

today=datetime.datetime.today()  #get price of lday for trade_track
todate=today.date() 
lday=datetime.datetime(2017,7,10)
ldate=lday.date()
#lday='2017-07-05'

def daily_run():
#    today=lday    #if today is non-biz day
    print("daily_run begin")
#    time.sleep(2)
    try:
#        DF=web.get_data_yahoo('ZTS',today, today)
        DF=web.get_data_google('ZTS',today, today)
    except:
        print ("exception")
        exit
    if DF.empty==True:
        print("ZTS empty data")
        exit
    else:
        update_price_daily(today, today) #both sp500 and etf
        df_play=play_run_daily(today, 'sp500', 'prod')
        dt=trade_track('sp500', today)
        fwd_test('sp500')
        #df_play_etf=play_run_daily(today.date(), 'etf', 'prod')
#        dt_etf=trade_track('etf', lday)
#        dt=dt.append(dt_etf)
#        dt['weigh']=dt['erisk']/(dt['erisk'].sum())
#        print (dt)
#        print("total risk:", dt['erisk'].sum())
        df_stat_etf= stat_run(lday, 'etf', env='prod')
        ml_apply(lday.date())
       # fwd_test('etf')
    print("daily_run completed")  

def daily_run_eod():
    update_price_eod('sp500')
    df_play=play_run_daily(todate, 'sp500', 'prod')
    
    dt=trade_track('sp500', todate)

    update_price_eod('etf')
    dt_etf=trade_track('etf', todate)
    dt=dt.append(dt_etf)
    dt['weigh']=dt['erisk']/(dt['erisk'].sum())
    #pd.set_option('display.expand_frame_repr', False)
#    print (dt)
    print (dt[['ticker','erisk', 'weigh', 'delta','beta', 'alert_stop','counter','alert_div']])
    print (dt[['ticker', 'days_left', 'pct_estrike_1','rsi_chg', 'p_pct', 'v_pct', 'ex_div']])
    print (dt[[ 'ticker', 'si', 'beta', 'corr_new', 'sec', 'rrtn_22_ts', 'rrtn_22_sm','win_5', 'win_10']])
   # print (dt[[  'win_5', 'win_10']])
    pd.set_option('display.expand_frame_repr', True)
    print("total risk:", dt['erisk'].sum())
    get_news()
         
    unpv('sp500', todate)
    unpv('etf', todate)
    fwd_test('sp500')  
    print("daily_run_eod completed")  
# --------0----EXECUTION ----------------------
ldate=todate
RUN_COUNT='n'
RUN_COUNT=input("EOD, delta, trade, Diversified? -- Run EOD?  yes/n:    ")
if RUN_COUNT=='yes':
    print (colored('>>>>> Reset RUN_COUNT  <<<<<', 'red'))
#    daily_run()
    daily_run_eod()
    RUN_COUNT='n'
#print ("hello")        
#trade_entry('etf') 
#trade_entry('sp500')    
#view_map()
#view_csv()
###update_price_historical()
#__________________UTILITY ZONE _______________________
def tbl_change():
    #add one column each time
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
    cur=conn.cursor()
#add new column
#    cur.execute("ALTER TABLE tbl_trade_hist_etf add column rrtn_22_sm REAL")
#create index
    #cur.execute("CREATE UNIQUE INDEX date_index on tbl_price(date)")
#delete record
    #cur.execute("DELETE FROM tbl_play_etf")    
    #drop one column
    #cur.execute("ALTER TABLE tbl_price_20161104 drop 'ALL'")
#COPY TABLE
#    cur.execute("CREATE TABLE tbl_price_etf1 AS SELECT * FROM tbl_price_etf")
    #change table columns type
#    cur.execute("CREATE TABLE tbl_TD ('index' INTEGER, alert_exit REAL,  alert_stop REAL,  be_down REAL,\
#    be_up REAL,  \
#    close_last REAL,\
#    close_qdate REAL,  contracts INTEGER,  date TIMESTAMP,  date_last TIMESTAMP,  entry_date TIMESTAMP,\
#    entry_note TEXT,  entry_price REAL,  epnl REAL,  epnl_pct REAL,  erisk REAL,  estike_1 REAL,  estrike_2 REAL,\
#    exist_pct REAL,  exit_date REAL,  exit_note REAL,  exit_price REAL,  exit_target REAL,  \
#    expire_date TIMESTAMP,\
#    hv_22 REAL, hv_252 REAL,  hv_m2y REAL,  mean_1022 REAL,  mean_2266 REAL, mean_66252 REAL,  \
#    p_22_sig REAL, p_44_sig REAL,  p_66_sig REAL,  play TEXT,  ticker TEXT,, earning_date TIMESTAMP, con_1 INTEGER, con_2 INTEGER, con_ex1 INTEGER, con_ex2 INTEGER, con_p1 REAL, con_p2 REAL, con_ex_p1 REAL, con_ex_p2 REAL, comm REAL)")
    #cur.execute("CREATE TABLE tbl_t1 (d1 INTEGER, d2 INTEGER, n1 REAL, n2 REAL, n3 INTEGER, d3 TIMESTAMP, d4 TIMESTAMP)")
    conn.commit()
    print ("tbl changed")
    cur.close()

def drop_table(tbl_name):
    conn=db.connect('G:\\Trading\Trade_python\pycode\db_op.db')
    cur=conn.cursor()
    cur.execute("DROP TABLE if exists '%s'"%tbl_name)
    conn.commit()
    cur.close()
    print("table: '%s' is dropped"%tbl_name)
#__________________COMMAND ZONE_________________________________
#drop_table('tbl_trade_hist')
#tbl_change()
# test_stat_prep: get df_stat for past date range, call stat_run, play_run, play_fwd_price, win_loss

# ----- test stratey thought as of Jan, 1, 2017
# 1. test_stat_prep() to get the df_stat (playbook_test is blank)
# 2. tbl_stat_test, 
# 3. plot_feature to visualize data first

def test_stat_prep(lookfwd_period, underlying): #lookfwd_period option: 22/44/66
    print("test_stat_prep begins")
    sdate=datetime.datetime(2016,10,7)
    edate=sdate+datetime.timedelta(90)
    df=pd.DataFrame()
    df_tmp=pd.DataFrame()
    date_range = pd.date_range(sdate, edate)
    counter=0
    for eachdate in date_range:
        try:
            df_tmp=stat_run(eachdate, underlying, 'test') #saved in tbl_stat_test
        except:
            pass
        try:        
            df_tmp=play_run(eachdate,underlying, 'test') #select * , saved to tbl_play_test
#        df_tmp['p_22_sig']=df_tmp['close_qdate']*df_tmp['hv_252']*np.sqrt(22)/ np.sqrt(252)
#        df_tmp['p_44_sig']=df_tmp['close_qdate']*df_tmp['hv_252']*np.sqrt(44)/ np.sqrt(252)
#        df_tmp['p_66_sig']=df_tmp['close_qdate']*df_tmp['hv_252']*np.sqrt(66)/ np.sqrt(252)
            df_play=play_fwd_price(df_tmp, eachdate, lookfwd_period, underlying)
        except:
            pass
        df=df.append(df_play)
        counter+=1
        print("counter:  %s"%counter)
    #df=win_loss(df, lookfwd_period)
    #to_sql_replace(df, 'tbl_play_test')
    try:    
        df.to_csv(r'G:\\Trading\Trade_python\pycode\pytest\test_stat_%s_6.csv'%underlying)
    except:
        print("test_stat_prep cannnot save")
        return df
    print("stat_test csv is saved")  
    return df
    
#KEY: playbook need to be 0 so to select all df_stat (just in df_play format)
t_date=datetime.datetime(2017,2,15)
def back_test(t_date, test_period, underlying, lookfwd_period='22'):
    print("back test started")
    start_time=timer()
    counter=0
    df_temp=pd.DataFrame()
    df=pd.DataFrame()
    test_start_date=t_date- datetime.timedelta(test_period)
    date_range = pd.date_range(test_start_date, t_date)
  
    for eachdate in date_range:
        stat_run(eachdate, underlying, 'test')
        df_play=play_run(eachdate, underlying, 'test')
        df=df.append(df_play)
        counter+=1
        print(counter, end =", ")
        #df=df.drop_duplicates()
        #df=df[~df.index.duplicated(keep='first')]  
    df.reset_index(inplace=True, drop=True)
    df['p_5_fwd']=np.nan
    df['p_10_fwd']=np.nan
    df['p_22_fwd']=np.nan
    df=play_fwd_price(df,t_date, 22, underlying)    
    df.to_csv('G:\\Trading\Trade_python\pycode\pytest\playlist_%s_test_%s.csv'%(underlying, t_date.date()))
#    df=win_loss(df, lookfwd_period)
#    enable_print()
    #df.loc[df['play']=='BF', 'win_22']=np.abs(df['p_22_fwd']-df['close_qdate'])<=df['p_22_sig']
    #print("win_22 done")
#    df_view=feature_view(df)
    end_time=timer()
    test_time=end_time - start_time
    print("back_test is done in seconds:  %s"%test_time)
    #return df, df_view

def price_check(q_date):
    t_date=test_date+datetime.timedelta(28)
    z_date=test_date+datetime.timedelta(35)
    query="SELECT LMT FROM '%s' wHERE date BETWEEN '%s' AND '%s'" %("tbl_price", t_date, z_date)
    df=read_sql(query, test_date)
    return df
  
def fwd_date(q_date, fwd_days, underlying):
    date_fwd=q_date+BDay(fwd_days)
    #date_fwd=q_date+BDay(fwd_days)
   
    if underlying=='sp500':
        query="SELECT * from tbl_price WHERE date= '%s'"%date_fwd
    elif underlying=='etf':
        query="SELECT * from tbl_price_etf WHERE date= '%s'"%date_fwd
    try:    
        df_price=read_sql(query,date_fwd)
        if df_price.empty:
           date_fwd=q_date+BDay(fwd_days+1)
        else:
            pass
#    df_price=read_sql(query,date_fwd)
#    try:
#        while df_price.empty and i<2:
#            date_fwd += BDay(1)
#            df_price=read_sql(query,date_fwd)
#            i+=1
    except:
        print("fwd_date exception: %s_%s"%(q_date,fwd_days))
    return date_fwd

def fwd_test(underlying):
    print("fwd_test starts")
    if underlying=='sp500':
        query="SELECT * FROM tbl_play_hist"
        df=read_sql(query, lday)    
        df=df.drop(['level_0'],1)
        to_sql_replace(df, "tbl_play_hist_bkup")  #vback up before update
    elif underlying=='etf':
        query="SELECT * FROM tbl_play_etf_hist"
        df=read_sql(query, lday)    
        if set(['level_0']).issubset(df.columns):
            df=df.drop(['level_0'],1)
        to_sql_replace(df, "tbl_play_etf_hist_bkup")
    
    df_play=play_fwd_price(df,lday,5,underlying) 
    df_play=play_fwd_price(df,lday,10,underlying) #update fwd_10 price
    df_play=play_fwd_price(df_play,lday, 22, underlying) #update fwd_22 price
    #con_22=pd.notnull(df_play['p_10_fwd']) & pd.notnull(df_play['p_22_fwd'])#evaluate 22 and 10
    #df_play=df_play[~null_10]
    #print(underlying, "win_loss p_22_fwd is :")
    #win_loss(df_play[con_22],22)
    df_play=win_loss(df_play,22)
#    df_play=play_fwd_price(df,lday,22,underlying)
#    con=pd.isnull(df_play['p_22_fwd'])
#    df_play=df_play[~con]
    #con_10=pd.notnull(df_play['p_10_fwd']) & pd.isnull(df_play['p_22_fwd'])#evaluate only 10    
    #print(underlying, "win_loss p_10_fwd is :")
    #win_loss(df_play[con_10],10)
    
# finnal write back to tbl_play_hist    
    if underlying=='sp500':
        to_sql_replace(df_play, "tbl_play_hist") # with p_10_fwd, p_22_fwd, win_22, win_10
    elif underlying=='etf': 
        to_sql_replace(df_play, "tbl_play_etf_hist")
    print(" -----  %s_fwd_test is done ------ "%underlying)
    
    
def play_fwd_price(df_play, q_date, lookfwd_period, underlying):#qdate can be any
    df_temp=pd.DataFrame()
    df_price_fwd=pd.DataFrame()
#    date_22_fwd=date_fwd(q_date, 2)
#    date_44_fwd=date_fwd(q_date, 44)
#    date_66_fwd=date_fwd(q_date, 66)
    counter=0
    for index, row in df_play.iterrows():  
        ticker=row['ticker']
        date=row['date']
        date_fwd=fwd_date(pd.to_datetime(row['date']),lookfwd_period, underlying)
       
        if lookfwd_period==22:
            con=(today.date()>=date_fwd.date()) and pd.isnull(row['p_22_fwd'])
        elif lookfwd_period==10:
            con=(today.date()>=date_fwd.date()) and pd.isnull(row['p_10_fwd'])
        elif lookfwd_period==5:
            con=(today.date()>=date_fwd.date()) and pd.isnull(row['p_5_fwd'])
        if con:
        # and row['p_22_fwd'].isnull():
            #ticker=row['ticker']
            if underlying=='sp500':
                qry="SELECT date, %s FROM tbl_price WHERE date in ('%s')"%(ticker, date_fwd)
            elif underlying=='etf' and ticker !='^VIX':
                qry="SELECT date, %s FROM tbl_price_etf WHERE date in ('%s')"%(ticker, date_fwd)
            elif underlying=='etf' and ticker =='^VIX':
                x=date_fwd.date()                
                x='%s'%x               
                qry='SELECT date, "^VIX" FROM tbl_price_etf WHERE date in (%s)'%x
            else:
                print("play_fwd_price missing env")
            df_temp=read_sql(qry, q_date)
            if lookfwd_period==22:
                try:  # to skip VIX
                    df_play.loc[index, "p_22_fwd"]=df_temp.iloc[0,1]
                except:
                    pass
            elif lookfwd_period==10: 
                df_play.loc[index, "p_10_fwd"]=df_temp.iloc[0,1] 
            elif lookfwd_period==5: 
                df_play.loc[index, "p_5_fwd"]=df_temp.iloc[0,1]
            counter =counter+1
            #print("yes", ticker, con, date, df_temp.iloc[0,1] )
            #print("no", ticker, con, date)
        else:
             pass
    print("number of update to fwd_%s:"%lookfwd_period, counter)
    return df_play   
def win_loss(df, lookfwd_period):
    #lookfwd_priod=10: for trade_track() - stay or exit current trade
#   =22: for fwd_test(), testing current model in PROD
    #another way is use nested np.where or lambda
    s10=0.5
    s5=s10*0.5
    #if p_22_fwd has data and win_22 is  null for whatever reson
    notnull_22=pd.notnull(df['p_22_fwd'])
    ttl_22=df[notnull_22].shape[0]
    notnull_10=pd.notnull(df['p_10_fwd']) &   pd.isnull(df['p_22_fwd'])     #p_22_fwd not available
    ttl_10=df[notnull_10].shape[0]
#p_5_fwd has data, and  p_10_fwd has no data   
    notnull_5=pd.notnull(df['p_5_fwd']) &   pd.isnull(df['p_10_fwd'])    
    ttl_5=df[notnull_5].shape[0]
#    for notnull_22:
    df.loc[(df['play'].str.strip().str[0]=='L') & (notnull_22), 'win_22']=(df['p_22_fwd']-df['close_qdate']).astype(float) >=df['p_22_sig'].astype(float)
    df.loc[df['play'].str.strip().str[0]=='S', 'win_22']=(df['close_qdate']-df['p_22_fwd']).astype(float) >=df['p_22_sig'].astype(float)
    df.loc[df['play'].str.strip().str[0]=='C', 'win_22']=np.abs(df['p_22_fwd']/df['close_qdate']-1).astype(float)<=0.02
    df.loc[df['play'].str.strip().str[0]=='Z', 'win_22']=np.abs(df['p_22_fwd']/df['close_qdate']-1).astype(float)<=0.02

    df.loc[df['play'].str.strip().str[0]=='L', 'win_10']=(df['p_10_fwd']-df['close_qdate']).astype(float) >=df['p_22_sig'].astype(float)*s10
    df.loc[df['play'].str.strip().str[0]=='S', 'win_10']=(df['close_qdate']-df['p_10_fwd']).astype(float) >=df['p_22_sig'].astype(float)*s10
    df.loc[df['play'].str.strip().str[0]=='C', 'win_10']=np.abs(df['p_10_fwd']/df['close_qdate']-1).astype(float)<=0.015
    df.loc[df['play'].str.strip().str[0]=='Z', 'win_10']=np.abs(df['p_10_fwd']/df['close_qdate']-1).astype(float)<=0.015

    df.loc[df['play'].str.strip().str[0]=='L', 'win_5']=(df['p_5_fwd']-df['close_qdate']).astype(float) >=df['p_22_sig'].astype(float)*s5
    df.loc[df['play'].str.strip().str[0]=='S', 'win_5']=(df['close_qdate']-df['p_5_fwd']).astype(float) >=df['p_22_sig'].astype(float)*s5
    df.loc[df['play'].str.strip().str[0]=='C', 'win_5']=np.abs(df['p_5_fwd']/df['close_qdate']-1).astype(float)<=0.01
    df.loc[df['play'].str.strip().str[0]=='Z', 'win_5']=np.abs(df['p_5_fwd']/df['close_qdate']-1).astype(float)<=0.01    
    
    if lookfwd_period==22:  # for fwd_test()
        c5 =df['win_5']==1
        c10=df['win_10']==1
        c22=df['win_22']==1
        w_5_22=df[c5 & c22].play.value_counts()
        w_5=df[c5 ].play.value_counts()
        r_5=w_5_22/w_5
        r_5.name='w22_w5'
        
        w_10_22=df[c10 & c22].play.value_counts()
        w_10=df[c10 ].play.value_counts()        
        r_10=w_10_22 /w_10
        r_10.name='w22_w10'
        
        w_22=df[c22].play.value_counts()
        w=df.play.value_counts()        
        r_22=w_22 / w
        r_22.name='w22_all'
        
        r_test=pd.concat([r_5, r_10, r_22], axis=1)
        print("------  model predictability: ------")
        print(r_test)
        symbol_win_5=df[c5][['ticker','play', 'date', 'p_5_fwd']]
        symbol_win_5.sort('date', ascending=False, inplace=True)
        symbol_win_5=symbol_win_5.groupby(['play','ticker']).first() 

      #  symbol_win_5.to_csv('G:\\Trading\Trade_python\pycode\win5_true_candidate_%s.csv'%lday.date())          
        print("win_5 is true, candidate trade:")
        print(symbol_win_5.tail(12))      
        t5= pd.notnull(df['p_5_fwd']) & pd.isnull(df['win_5']) 
        t10= pd.notnull(df['p_10_fwd']) & pd.isnull(df['win_10'])         
        print("t5:  ", t5.shape)
        print("t10:  ", t10.shape)       
    else:  #lookfwd_period=10, then fro trade_track()
        pass
    
    return df

def ml_apply(q_date):#df is df_stat (etf)
    model_loaded=pickle.load(open(r'G:\Trading\Trade_python\pycode\pytest\ml_etf_lr_ZME1.sav',"rb"))
#get previous df_play list
    qry_prev="SELECT * FROM tbl_play_etf"
    df_prev=read_sql(qry_prev, q_date)    
    qry="SELECT * FROM tbl_stat_etf"
    df=read_sql(qry, lday)
    f=df[['hv_22','hv_66','hv_252','rtn_22']].values
    t= model_loaded.predict(f)
    t=t[:,None]  #convert to array[n,1]
    t=pd.DataFrame(t,columns=['rtn_22_pred'])
    # dc=pd.DataFrame([y_pred, y], columns=['y_pred','y'])
    #df_play_ml=np.concatenate((x, y_pred), axis=0)   
    dp=pd.concat([df,t], axis=1)
    con_L=dp['rtn_22_pred']>=(dp['p_22_sig']/dp['close_qdate'])*1   
    con_S=dp['rtn_22_pred']<=-(dp['p_22_sig']/dp['close_qdate'])*1    
    con_Z=np.abs(dp['rtn_22_pred'])<=0.005
    dp.loc[con_L, 'play']='LME1'
    dp.loc[con_S, 'play']='SME1'
    dp.loc[con_Z, 'play']='ZME1'
    print(dp.play.value_counts())
    dp=dp[['ticker','play','close_qdate', 'rtn_22_pred', 'p_22_sig','rtn_22', 'rtn_66','hv_22','hv_66','hv_252',\
      'mean_510', 'mean_1022', 'mean_2266','mean_66252','date']]
    dp.dropna(inplace=True)
    dp.to_csv('G:\\Trading\Trade_python\pycode\playlist_ml_etf_%s.csv'%q_date) 
    to_sql_replace(dp, "tbl_play_etf")
    to_sql_append(dp, "tbl_play_etf_hist")
    
    df1=dp[['ticker','play','earning_date']]
    df2=df_prev[['ticker','play','earning_date']]
    dff=df1.merge(df2, indicator=True, how='left')
    dff=dff[dff['_merge']=='left_only']
    print(dff)
    print ("ml_apply is completed")

def block_print():
    sys.stdout=open(os.devnull, 'w')

def enable_print():
   
    sys.stdout = old_stdout
    
def email():
    import smtplib
    from email.MIMEMultipart import MIMEMultipart
    from email.MIMEText import MIMEText
    from email.MIMEBase import MIMEBase
    from email import encoders
     
    fromaddr = ""
    toaddr = "EMAIL ADDRESS YOU SEND TO"
    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "SUBJECT OF THE EMAIL"
    body = "TEXT YOU WANT TO SEND"
     
    msg.attach(MIMEText(body, 'plain'))
     
    filename = "NAME OF THE FILE WITH ITS EXTENSION"
    attachment = open("PATH OF THE FILE", "rb")
     
    part = MIMEBase('application', 'octet-stream')
    part.set_payload((attachment).read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', "attachment; filename= %s" % filename)
     
    msg.attach(part)
     
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(fromaddr, "YOUR PASSWORD")
    text = msg.as_string()
    server.sendmail(fromaddr, toaddr, text)
    server.quit()
# --- TO DO LIST ---
# Auto run, send email
#https://github.com/sgerhardt/TakeStock/blob/master/src/TakeStock_Reporter.py
#https://ntguardian.wordpress.com/2016/09/19/introduction-stock-market-data-python-1/

  #_____________________ TESTING ZONE  ___________________________-   
#test_stat_prep(22)
#sdate=datetime.datetime(2016,8,10)
#test_stat_prep(66)
#sdate=datetime.datetime(2016,1,4)

#df_tmp=stat_run(sdate,'test')
#df_play=play_runly(sdate.date(),'test')
#df=play_run(eachdate,'test')

# ———————   TEST COMMAND LINE _________________________- 
#test_stat_prep(66)
#_______________ MACHINE LEARING ZONE _________________


#__________RESOURCE ZONE  ____________________________________
    
#https://pypi.python.org/pypi/googlefinance
#https://pypi.python.org/pypi/yahoo-finance/1.1.4
#http://www.sqlite.org/lang_datefunc.html
#df.loc[<row selection>, <column selection>]
#w.loc[w.female != 'female', 'female'] = 0
#  http://machinelearningmastery.com/feature-selection-machine-learning-python/  
#dy=pd.rolling_corr(dx['SPY'], dx, window=66, pairwise=True)
#dy.mean()
#dy.mean(axis=1)
#Python-Financial-Tools/capm.py  *capm model
#https://github.com/jealous/stockstats    
#http://ahmedbesbes.com/how-to-mine-newsfeed-data-and-extract-interactive-insights-in-python.html    
def get_share_nasdaq(ticker=''):
    """
    This function gets the share price for the given ticker symbol. It performs a request to the
    nasdaq url and parses the response to find the share price.
    :param ticker: The stock symbol/ticker to use for the lookup
    :return: String containing the earnings date
    """
    try:
        earnings_url = 'http://www.nasdaq.com/symbol/' + ticker[0]#.lower()
        request = requests.get(earnings_url)
#        soup = bs4.BeautifulSoup(request.text, 'html.parser')
#        price=soup.find('div', class_="qwidget-dollar").text
        #beta=soup.find(text=re.compile('beta')).findNext('td').text
        tree = html.fromstring(request.content)
        tbl="""//div[@class="genTable thin"]/table/tbody/"""
        ex_div=tree.xpath(tbl+'/tr[12]/td[2]/text()')
        #beta=tree.xpath(tbl+'/tr[15]/td[2]/text()')
        return ex_div#, beta#, vol_chg, p_chg
    except:
        return 'No Data Found'
        
def get_beta():
# have stock beta list 
# alternative
    y=[]
    z=[]
    df_s=df_sp500
    for ticker in df_s:
        beta=get_share_nasdaq(ticker)
#        data=np.asarray([ticker,beta]).T
#        y=pd.DataFrame(data, columns=['ticker','beta'], index=np.arange(i))
        y=[ticker,beta]
        z.append(y)
    z=pd.DataFrame(z,columns=['ticker','beta'])    
    return z
def get_ta(ticker=''):
    url = 'http://www.stocktrendcharts.com/'
#    payload = {'Stock Symbol:':'ibm'}
#    r = requests.get(url, params=payload)
#    tree=html.fromstring(r.content)
#    ta=tree.xpath('//h3[@class="block-title"]/text()')
    gecko="G:\\Trading\Trade_python\pycode\Github\geckodriver.exe"
    driver=webdriver.Firefox(executable_path="G:\Trading\Trade_python\pycode\Github\geckodriver.exe")
    driver.get(url)
    # fill in form and submit
    symbol=driver.find_element_by_id("edit-1")
    symbol.send_keys(ticker)
    submit=driver.find_element_by_id("edit-submit")
    submit.click()
    #wait.until(EC.visibility_of_element_located(By.CLASS_NAME("block-content-inner")))
#        WebDriverWait(driver, timeout).until(EC.visibility_of_all_elements_located(By.CLASS_NAME("block-title")))
    time.sleep(10)
    driver.implicitly_wait(3)
    x=driver.find_elements_by_class_name("block-title")[0].text
    ta=driver.find_elements_by_class_name("views-field-field-risk-d-value")[0].text
    loc1=x.index("been") 
    t1=x[loc1+5:loc1+19].split(" ")
    s1=t1[0]+t1[2]
    loc2=x.index("is")
    t2=x[loc2+3:len(x)].split(" ")
    s2=t2[-1]
    ta= ta + " " + s1 + " " + s2
#    driver.close()
#    driver.quit()
    return ta
    #tb=driver.find_elements_by_xpath('//*[text()[contains(., "Daily.png")]') 
 #   driver.find_element_by_xpath('//input[@id="edit-submit"]').click()
   #    wait=ui.WebDriverWait(driver,3)
#    wait.until(driver.find_element_by_tag_name("body")!=None)  
#    imgs=driver.find_elements_by_tag_name("img")
#    #save a screen shot   driver.save_screenshot("sr.png")
#    for i in imgs:
#        src=i.get_attribute('src')

#def get_news():
#    url="https://www.marketbeat.com/"
#    gecko="G:\\Trading\Trade_python\pycode\Github\geckodriver.exe"
#    driver=webdriver.Firefox(executable_path="G:\Trading\Trade_python\pycode\Github\geckodriver.exe")
#    driver.get(url)
#    # fill in form and submit
#    symbol=driver.find_element_by_name("query")
#    symbol.send_keys(ticker)
#    submit=driver.find_element_by_class("btn btn-default")
#    submit.click()
#    time.sleep(10)
#    driver.implicitly_wait(3)
#    x=driver.find_elements_by_class_name("block-title")[0].text

def get_news():
    q_trade="SELECT * FROM tbl_trade WHERE exit_date ='N'"
    dt=read_sql(q_trade, todate)
    dt=dt.fillna(0)
    dn=pd.DataFrame(data=[], index=dt.index, columns=[['ticker','date','rating', 'p_target',\
        'rating_1', 'rating_2','news_1', 'news_2', 'news_3','ins', 'ins_1', 'ins_2']])
    dn['ticker']=dt['ticker']
    dn['date']=dt['date']
#    dn=dn.head(2)

    for index, row in dn.iterrows():
        ticker=row['ticker']
        dn.loc[index, ['rating', 'p_target', 'rating_1', 'rating_2', \
        'news_1', 'news_2', 'news_3','ins', 'ins_1', 'ins_2']]=get_marketbeat(ticker)
#        except:
#            print("get_analyst error : ", ticker)
#            pass
        time.sleep(2)
    du=dn.transpose()    
    len=du.shape[1]
    pd.options.display.max_colwidth = 200
    du.style.set_properties(**{'text-align': 'left'})
    for c in range(0,len):
        print(du.loc[:,c])    
        print ("   ")

def get_marketbeat(ticker=''):
#ref: http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/    
    from selenium.webdriver.chrome.options import Options
    chrome_options=Options()
    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_1_0_7_overlay_remove.crx")
    chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
    url="https://www.marketbeat.com/"
    gecko="G:\\Trading\Trade_python\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="G:\Trading\Trade_python\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
    driver.get(url)
#    driver.execute_script("window.open(url);")
    try:
        ol_close=driver.find_element_by_class_name("overlay-close")
        ol.click()
    except:
        pass
    time.sleep(2)
    symbol=driver.find_element_by_xpath('//input[@class="main-searchbox autocomplete ui-autocomplete-input"]')
    symbol.send_keys(ticker)
    submit=driver.find_element_by_xpath('//a[@class="main-search-button"]')
    submit.click()
    
    time.sleep(2)   #get_attribute('innerHTML')
    rating=driver.find_elements_by_xpath('//*[@id="AnalystRatings"]/div[2]/table/tbody/tr[2]/td[2]')[0].get_attribute('textContent')
    p_target= driver.find_elements_by_xpath('//*[@id="AnalystRatings"]/div[2]/table/tbody/tr[3]/td[2]')[0].get_attribute('textContent')   
    rating_1=driver.find_elements_by_xpath('//*[@id="DataTables_Table_0"]/tbody/tr[1]')[0].get_attribute('textContent')
    rating_2=driver.find_elements_by_xpath('//*[@id="DataTables_Table_0"]/tbody/tr[2]')[0].get_attribute('textContent')
   
    news_1=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[1]/td[2]')[0].get_attribute('textContent')
    news_2=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[2]/td[2]')[0].get_attribute('textContent')
    news_3=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[3]/td[2]')[0].get_attribute('textContent')

    ins=driver.find_elements_by_xpath('//*[@id="InsiderTrades"]/div[1]')[0].get_attribute('textContent')
    ins_1=driver.find_elements_by_xpath('//*[@id="DataTables_Table_3"]/tbody/tr[1]')[0].get_attribute('textContent')
    ins_2=driver.find_elements_by_xpath('//*[@id="DataTables_Table_3"]/tbody/tr[2]')[0].get_attribute('textContent')
    return rating, p_target, rating_1, rating_2, news_1, news_2, news_3,ins, ins_1, ins_2
