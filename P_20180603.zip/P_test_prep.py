# -*- coding: utf-8 -*-
"""
Created on Fri Aug 11 11:50:54 2017
Purpose:
Functions: back_test()
imported: stat_run, play_run, play_fwd_price
@author: jon
"""
import pandas as pd
import numpy as np 
import datetime as datetime
from pandas import date_range
import pandas_datareader.data as web
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as stats
import sqlite3 as db
import sys, os
# %matplotlib inline
import time
import pandas.io.sql as pd_sql
import pickle
from pandas.tseries.offsets import BDay
import bs4
import requests
import re
from timeit import default_timer as timer
#from yahoo_finance import Share
import warnings
from termcolor import colored
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
import statsmodels.api as sm
from lxml import html
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import TimeoutException
#from wallstreet import Stock, Call, Put
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
old_stdout=sys.stdout

capital=20000
DF_sp500=pd.read_csv('G:\\Trading\Trade_python\pycode\pyprod\constituents.csv')
df_etf=pd.read_csv('G:\\Trading\Trade_python\pycode\pyprod\etf.csv')
df_sp500=DF_sp500.ix[:,0] #serie
df_etf=df_etf.ix[:,0]

import P_commons
#from PROD_stat_1 import stat_run
#from PROD_stat2 import stat_run2
from P_play import play_run
from P_fwdtest import play_fwd_price
from P_stat import stat_run_new

#testing parameters
t_date=datetime.date(2017,8,3) #at least 22 days ago
test_period=1
underlying='sp500'

def test_prep(t_date, test_period, underlying, lookfwd_period='22'):
    print(" test_prep started")
    start_time=timer()
    counter=0
    df_temp=pd.DataFrame()
    df=pd.DataFrame()
    test_start_date=t_date- datetime.timedelta(test_period)
    date_range = pd.date_range(test_start_date, t_date)
  
    for eachdate in date_range:
        stat_run_new(eachdate, underlying, 'test')
        df_play=play_run(eachdate, underlying, 'test')
        df=df.append(df_play)
        counter+=1
        print(counter, end =", ")
        #df=df.drop_duplicates()
        #df=df[~df.index.duplicated(keep='first')]  
    df.reset_index(inplace=True, drop=True)
    df['p_5_fwd']=np.nan
    df['p_10_fwd']=np.nan
    df['p_22_fwd']=np.nan
    print("play_fwd_price starts")
    df=play_fwd_price(df, 22, underlying)    
    df.to_csv('c:\\pycode\pytest\playlist_%s_test_%s.csv'%(underlying, t_date))
#    df=win_loss(df, lookfwd_period)
#    enable_print()
    #df.loc[df['play']=='BF', 'win_22']=np.abs(df['p_22_fwd']-df['close_qdate'])<=df['p_22_sig']
    #print("win_22 done")
#    df_view=feature_view(df)
    end_time=timer()
    test_time=end_time - start_time
    print("test prep is done in seconds:  %s"%test_time)
    #return df, df_view