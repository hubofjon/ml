# -*- coding: utf-8 -*-
"""

"""
import pandas as pd
import numpy as np 
import datetime as datetime
import sqlite3 as db
from timeit import default_timer as timer
from dateutil import parser
import scipy.stats
from termcolor import colored, cprint
import warnings
from P_commons import to_sql_append, to_sql_replace, read_sql, type_convert,to_sql_delete, get_conn
from P_commons import * 
from R_stat import stat_VIEW, stat_run_base, stat_PLOT
from R_plot import plot_base
from R_getdata import get_FUN, get_DIV, get_SI
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format

"""
    logic: risk control by delta (i_delta) and weigh( i_ip)
    var_id_max=cap * Max_loss_per_pos/ Buff_var_id
    delta_max=var_id_max/ var_id
    var_id= atr_hd * iv_hv
    ic_max_id= delta_max/ i_detla
    weigh_max= cap * weigh_per_pos
    ic_max_weigh= weigh_max/ i_ip
    i_ic@entry = min (ic_max_id, ic_max_weigh)
"""
weigh_per_pos=0.05   
MAX_loss_per_pos=0.03
BUFF_var_id=3  # R: stop@ 3 std_daily
#    v_stk_vol_pct=2.5
key_level_pct=0.01    
exit_days_pct=0.5
event_days=5
itm_pct=0.02
spike_min=1
stop_spike=BUFF_var_id
stop_spike_etd=1.1
hiv_chg_pct=0.2
hv_rank_chg_min=0.1
loss_size_pct_max=0.2
gain_size_pct_min=0.9
size_chg_days_pct_max=0.3
vega_min= 15
days_pct_tgt_p=0.3

#%%
def track_otick(q_date):
    dt=read_sql("select * from tbl_oc where exit_dt ='N'")
    dt=dt[~(dt['pid'].str[:1]=='U')]
    dt.sort_values(['ticker','cid','entry_dt'], inplace=True)
    #keep the first entry_dt  per cid
    dt.drop_duplicates('cid',keep='first', inplace=True)
    dc=read_sql("select * from tbl_cid")
    df=dt.merge(dc, on=['cid'],how='left')

#%%
def oraw(q_date): 
    '''
    Source: tbl_oc, tbl_act, stat_VIEW, tbl_mc_raw, tbl_bc_raw, tbl_risk, flask_trd
    Immediate control:
    0) daily update IBQ_cap
    1) con_weigh (risk_live/cap)>max_weigh_per_pos
    2) size_pct: max(var_id,var_hd)*BUFF_var_id )/(cap* MAX_loss_per_pos))
    3) spike>Buff_var_id(R multiple: 3* std)
    4) spike_etf>1   
    '''
    dt_all=read_sql("select * from tbl_oc where exit_dt ='N'")
    dt_all=dt_all[~(dt_all['pid'].str[:1]=='U')]
    
    dc=read_sql("select * from tbl_cid")
    dc['date']=pd.to_datetime(dc['date'])
    dc=dc[dc.date==q_date]
    dt_all=dt_all.merge(dc, on=['cid'],how='left')
    dt_all.sort_values(['cid','entry_dt'], inplace=True)
    
#@cid level - consolidation
    dt_tmp=pd.DataFrame(columns=dt_all.columns)
    for t in dt_all.ticker.unique():
        dg=dt_all[dt_all.ticker==t]
        dg.sort_values(['cid','entry_dt'], inplace=True)
        #keep the first entry cid
        dg_tmp=dg.head(1)
        col_g=['comm_c','delta_c', 'vega_c','theta_c','pl','pl_r','pl_ur', 'risk_live']
        for c in col_g:
            dg_tmp[c]=dg[c].sum()
        dt_tmp=pd.concat([dt_tmp, dg_tmp], axis=0)    
    dt_all=dt_tmp
    #get IV data
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date'])
    div=div[div.date==q_date]
    col_iv=['div', 'div_dt', 'earn_dt_mc', 'ind','iv', 'iv_1y','spike_iv',\
       'iv_chg', 'iv_rank', 'mcap', 'oi', 'oi_p_pct', 'p', 'p_chg',
       'p_chg_pct', 'ticker', 'vol', 'vol_pct', 'vol_stk', 'yld']
    div=div[col_iv]
    dt_all=dt_all.merge(div, on='ticker', how='left')
#@ticker level
    #update cap data
    df_cap=read_sql("SELECT * FROM tbl_act", q_date)
    dt_all=dt_all.merge(df_cap[['act','cap']], on='act',how='left')
    # updte with latest stat_VIEW
    ds=stat_VIEW(q_date, dt_all['ticker'].tolist())
    ds.drop('sec', axis=1, inplace=True)
    col_share=list(set(dt_all.columns).intersection(set(ds.columns)))
    #preserve sec value from tbl_c for non-sp ticker
    col_drop=[x for x in col_share if x not in ['ticker', 'sec']]
    dt_all.drop(col_drop, axis=1, inplace=True)
    dt=pd.merge(dt_all, ds, on='ticker')
    # in mc_raw or bc_raw?
    df_mc=read_sql("SELECT * FROM tbl_mc_raw ", q_date)
    df_mc['date']=pd.to_datetime(df_mc['date'])
    df_mc=df_mc[df_mc.date==q_date]
    loc_mc=dt['ticker'].isin(df_mc['ticker'])
    if loc_mc.any():
        dt.loc[loc_mc,'mc']=df_mc['ticker'] +'|' + df_mc['v_pct'].astype(str)\
            +'|'+df_mc['pct_c'].astype(str)
    else:
        dt['mc']=np.NaN
    df_bc=read_sql("SELECT * FROM tbl_obc_raw ", q_date)
    df_bc['date']=pd.to_datetime(df_bc['date'])
    df_bc=df_bc[df_bc.date==q_date]
    loc_bc=dt['ticker'].isin(df_bc['ticker'])
    if loc_bc.any():
        dt.loc[loc_bc,'bc']=df_bc['ticker'] +'|' + df_bc['v_oi'].astype(str)\
            +'|'+df_bc['type'].astype(str)
    else:
        dt['bc']=np.NaN
    dt['entry_dt']=pd.to_datetime(dt['entry_dt']).dt.date
#if first date then update si, div_dt , earn_dt
    con_new=dt['entry_dt']==q_date
    dt.loc[pd.isnull(dt.earn_dt), 'earn_dt']=dt['earn_dt_mc']
    
    for index, row in dt[con_new].iterrows():
        try:
#            fun_col=[ 'beta', 'earn_dt', 'earn_last', 'pe',  'ta', 'yld', 'sector'] 
            fun_col=['beta','pe','ta']
            FUN=get_FUN(row.ticker)  
            for k in fun_col:
                dt.loc[index, k]=FUN[k]
        except:
            for k in fun_col:
                dt.loc[index, k]=0
        try:
            si_col= ['si'] 
            SI=get_SI(row.ticker)
            for k in si_col:
                dt.loc[index, k]=SI[k]
        except:
            for k in si_col:
                dt.loc[index, k]=0
#Clean/convert data
    #1. from flask 
#    dt['date']=q_date
#    dt['date']=pd.to_datetime(dt['date'])
    dummy_dt='2000-1-1'
    flask_val=['ioc','iop','comm','strike']
    flask_dt=['entry_dt', 'oexp_dt', 'earn_dt', 'div_dt']
          
    for x in flask_val:
        dt.loc[con_new, x]=dt.loc[con_new, x].replace('',0).replace('None',0).astype(float)
    
    for x in flask_dt:
        dt[x]=pd.to_datetime(dt[x])
    #data prep for cal
    col_float=['delta_c','vega_c','pl', 'pl_r','pl_ur','theta_c' ]
    dt=type_convert(dt, col_float)
#    """
#    for x in flask_dt:
#        for ch in ['','None','N','N/A','0']:
#            dt.loc[con_new, x]=dt.loc[con_new, x].str.strip()
#            dt.loc[con_new, x]=dt.loc[con_new, x].replace(ch,dummy_dt).astype(str)
#        dt.loc[con_new, x]=dt.loc[con_new, x].apply(lambda i: parser.parse(i))
#    """
    dt['tgt_dt']=dt['entry_dt']+(dt['oexp_dt']-dt['entry_dt'])/2
    dt['days_to_exp']=dt['oexp_dt'].subtract(dt['date']).dt.days   
    dt['days_all']= dt['oexp_dt'].subtract(dt['entry_dt']).dt.days   
    dt['days_pct']=(1-dt['days_to_exp']/dt['days_all']).round(2)
    dt['days_to_div']=dt['div_dt'].subtract(dt['date']).dt.days
    dt['days_to_earn']=dt['earn_dt'].subtract(dt['date']).dt.days
    dt['days_to_tgt_dt']=dt['tgt_dt'].subtract(dt['entry_dt']).dt.days
    
    
#    col_ot=['ticker','pl_ur_pct','o_oi_chg','o_oi','delta_c','vega_c','theta_c',\
#            'risk_live','lp','mp','lc','ta','rtn_5_pct','rtn_22_pct','srtn_22_pct']
    
#    dt['days_to_event']=dt['event_dt'].subtract(dt['date']).dt.days

    dt['var_hd']=dt['delta_c']*dt['atr_hd']
    dt['var_hv']=dt['vega_c']*dt['atr_hv']*100
    dt['atr_id']=dt['close']*dt['iv']/(252**0.5)
    dt['var_id']=dt['delta_c']*dt['atr_id']
    dt['var_iv']=dt['vega_c']*dt['atr_id']
    dt['iv_hv']=dt['iv']/dt['hv_22']
  
    # prob of profit
#    dt=prob(dt)

#ALERT data prepare
    #    dt['fm_strike']=(dt['close']/dt['strike']-1).round(2)
    dt['weigh']=dt['risk_live']/dt['cap']
#    dt['srtn_22_chg']=dt['srtn_22_pct']-dt['i_srtn_22_pct']
#    dt['rtn_22_chg']=dt['rtn_22_pct']-dt['i_rtn_22_pct']
#    dt['hv_22_chg_pct']=dt['hv_22']/dt['i_hv_22']-1
    #    dt['rsi_chg']=dt['rsi']<dt['i_rsi']
    
#    dt['days_etd']=dt['days_all']-dt['days_to_exp']
#    dt['sig_etd']=dt['entry_p']*dt['i_iv']*np.sqrt(dt['days_etd']/252)
#    dt['spike_etd']=(dt['close']-dt['entry_p'])/dt['sig_etd']
#    dt['sig_etd2']=dt['entry_p']*dt['i_hv_22']*np.sqrt(dt['days_etd']/252)
#    dt['spike_etd2']=(dt['close']-dt['entry_p'])/dt['sig_etd2']   
#    dt['spike_etd']=dt[['spike_etd','spike_etd2']].max(axis=1)
    
    #get risk profile (r, rx, risky)
    dr=read_sql("SELECT * FROM tbl_risk")
    dr=type_convert(dr, ['r','rx'], 'float')
    col_risk=[x for x in dr.columns if x not in ['index','play']]
#    dt.drop(col_risk, axis=1, inplace=True)    
    #update with tbl_risk profile
    dt=pd.merge(dt, dr, on='play')  
    dt['size_pct']=np.abs((dt[['var_id','var_hd']].max(axis=1)*BUFF_var_id )/  \
              ( dt['cap']* MAX_loss_per_pos))
    dt['size_buff']=( dt['cap']*MAX_loss_per_pos)- \
            np.abs(dt[['var_id','var_hd']].max(axis=1)* BUFF_var_id )
    #reporting            
    dt['v_und']=dt['delta']*dt['close']
    spy=read_sql("select close from tbl_pv_etf where ticker ='SPY'")
    spy=spy.tail(1).iloc[0,0]
    dt['beta']=dt['beta'].replace('',1).astype(float)
    dt['v_spy']=dt['v_und']*dt['beta']/spy

    #size_chg
    dt['delta_to_adj']=dt['delta_c']*(1-dt['size_pct'])
    dt['weigh_to_adj']=(weigh_per_pos - dt['weigh'])*dt['cap']
#, no new column from here onward
# for proper risk calc, move dead to tbl_c_hist
    scm_t_c=list(dict.fromkeys(dt.columns.tolist()))
    scm_t_c=[x for x in scm_t_c if x not in ['index','index_x','index_y',\
        'r_x', 'r_y','rx_x', 'rx_y', 'risky_x','risky_y']]
    dt=dt[scm_t_c]
    con_live=dt['exit_dt']=='N'
    dt_dead=dt[~ con_live]
    try:
        z3_test=dt.groupby('act')['pl'].sum()
    except:
        print("track_raw: ln341:  Must produce aggregated value")
    #validate dead trade
    con_lc=dt['lc']==0  #no live contract
    if (con_live & con_lc).any() | (~con_live & ~con_lc).any():
        print("track_raw: ln337, con_live <>con_lc")
    if ~ dt_dead.empty:
        to_sql_append(dt_dead, 'tbl_track_hist')
        print("track_raw: tbl_c_hist appended: %s"%dt_dead.ticker.tolist())
    dt=dt[con_live]
    if dt.empty:
        print("track_raw: ln367, dt.empty")
        return
    else:
        to_sql_replace(dt, 'tbl_track')
        #Track @ Act & asset level
    z1=dt.groupby('act')['risk_live'].sum()    
    z2=dt.groupby('act')['weigh'].sum()
    z3=dt.groupby('act')['pl'].sum()
    z=list(zip(z1, z2, z3))
    dt_overview=pd.DataFrame(z,columns=['risk_live','weigh', 'pl'], index=z1.index)
    print (" - --Overview ---- \n # of tickers: %s \n"%dt.shape[0], dt_overview)   
    #reporting
    dt['wrtn_22_pct']=dt['weigh']*dt['rtn_22_pct']
    col_rpt=['v_spy', 'var_id', 'var_hv', 'vega', 'risk_live','weigh', 'pl_ur', 'pl_r', 'pl', 'theta_c','wrtn_22_pct']  
    dt[col_rpt]=dt[col_rpt].replace('',0)      
    rpt_1=dt.pivot_table(index=['oexp_dt','sec'], values= col_rpt, aggfunc= 'sum', \
            fill_value= 0, margins = True, margins_name= 'total')
    show_rpt_1=['v_spy','var_id','vega','pl_ur', 'pl', 'theta_c', 'weigh','risk_live']
#    rpt_1=pd.DataFrame(rpt_1.to_records())
    rpt_2=dt.pivot_table(index=['sec'], values= col_rpt, aggfunc= 'sum', \
            fill_value= 0, margins = True, margins_name= 'total')
    rpt_2=pd.DataFrame(rpt_2.to_records())
    rpt_2=pd.merge(rpt_2, dt[['sec','srtn_22_pct']], on='sec', how='left')
    rpt_2=srtn_update(rpt_2)
    rpt_2.drop_duplicates(subset=['sec'],keep='first', inplace=True)

    show_rpt_2=['sec','v_spy','var_id','vega','weigh','wrtn_22_pct',\
                'srtn_22_pct', 'pl_r', 'pl_ur','risk_live','theta_c']
    pd.set_option('display.expand_frame_repr', False)
    print(" --REPORT BY EXP_DT, SEC --\n", rpt_1[show_rpt_1])
    print(" --REPORT BY SEC --\n", rpt_2[show_rpt_2].sort_values('var_id'))
    
    
    
    con_plot=(rpt_2['weigh']>=0.05)|(np.abs(rpt_2['var_id'])>50)
#    stat_PLOT(q_date, rpt_2[con_plot].sec.tolist())

    CON_stop= (dt['pl_ur_pct']<= dt['r'])
    CON_out=(dt['tgt_dt']<q_date) | (dt['days_pct']>=exit_days_pct)
    CON_exit=dt['pl_ur_pct']> dt['rx']
# alert_itm:    

    con_l=dt['delta_c']>0
    con_s=dt['delta_c']<0
#    con_n=dt['lsnv']=='N'
#    con_v=dt['lsnv']=='V'
#    con_fm_strike_up=(dt['close']/dt['strike']-1)>=itm_pct
#    con_fm_strike_dn=(dt['close']/dt['strike']-1)<=(0 - itm_pct)
#    con_sc_up=(dt['play'].isin(['SC','SCV','SCP','BW'])) & con_fm_strike_up
#    con_sp_dn=(dt['play'].isin(['SP','SPV','SCP','SYN'])) & con_fm_strike_dn
#    con_nc_up= ((dt['pc']=='C') & (dt['play'].isin(['CAL','BF']))) & con_fm_strike_up
#    con_np_dn= ((dt['pc']=='P') & (dt['play'].isin(['CAL','BF']))) & con_fm_strike_up
#    CON_itm=con_sc_up | con_sp_dn | con_nc_up |con_np_dn
    
#a_be
#    CON_be=(dt.close>dt.beup) | (dt.close< dt.bedn)
#a_event        
    con_earn_dt=dt['days_to_earn']>0
    con_div_dt=dt['days_to_div']>0
#    con_event_dt=dt['days_to_event']>0
    CON_event=(dt['days_to_div']<=event_days & con_div_dt)\
            |(dt['days_to_earn']<=event_days & con_earn_dt)
#              |(dt['days_to_event']<=event_days & con_event_dt )  
#a_momt    
#    con_momt_l= con_l & (  (dt['srtn_22_pct']<dt['i_srtn_22_pct']) \
#                    | (dt['rtn_22_pct']<dt['i_rtn_22_pct']) )
#    con_momt_s= con_s & ( (dt['srtn_22_pct']>dt['i_srtn_22_pct']) \
#                   | (dt['rtn_22_pct']>dt['i_rtn_22_pct']) )
#    CON_momt= con_momt_l | con_momt_s
#a_key_level
    CON_key_level=(np.abs(dt['fm_50'])<= key_level_pct) \
          |(np.abs(dt['fm_200'])<= key_level_pct) \
          |(np.abs(dt['fm_hi'])<= key_level_pct) \
          |(np.abs(dt['fm_lo'])<= key_level_pct)   
#a_unop              
    CON_unop=pd.notnull(dt['mc']) |pd.notnull(dt['bc'])  
#a_vol
#    con_lv_play=dt['vega']< vega_min
#    con_hv_play=dt['vega']> vega_min
#    con_hiv_up=(dt['hv_22']/dt['i_hv_22']> (1+hiv_chg_pct)) & con_lv_play
#    con_hiv_dn=(dt['hv_22']/dt['i_hv_22']< (1-hiv_chg_pct)) & con_hv_play
    
    CON_spike= (np.abs(dt['spike'])>spike_min) |(np.abs(dt['spike_iv'])>spike_min)
#    con_hv_rankup=dt['hv_rank']>dt['i_hv_rank']*1.1
#    con_hv_rankdn=dt['hv_rank']<dt['i_hv_rank']*0.9
#    con_hiv= con_hiv_up | con_hiv_dn
#    CON_spike= (np.abs(dt['spike'])>spike_min)
#    CON_spike_stop=(np.abs(dt['spike'])>stop_spike ) |(np.abs(dt['spike_etd'])>stop_spike_etd)
    #a_delta vega wrong
#    con_dv_ln=(dt['lsnv']=='LN') & (dt['delta']<0)
#    con_dv_sn=(dt['lsnv']=='SN') & (dt['delta']>0)
#    con_dv_n=(dt['lsnv']=='N') & CON_spike  #main play is N, start trending
#    con_dv_v=(dt['lsnv']=='V') & con_hiv  # main play is Vol
#    CON_dv=(con_dv_ln | con_dv_sn |con_dv_n | con_dv_v)
    #a_size
    con_weigh=dt['weigh'] >=weigh_per_pos
    con_oversize=dt['size_pct']>=1
    con_add=(dt['pl_ur_pct']>0) & (dt['days_pct']<size_chg_days_pct_max) & (dt['size_pct']<gain_size_pct_min)
    con_cut=(dt['pl_ur_pct']<0) & (dt['days_pct']>=size_chg_days_pct_max) & (dt['size_pct']>=loss_size_pct_max)
    con_cut=con_cut | con_weigh | con_oversize
    CON_size=con_add | con_cut
    #a_tgt_p, pre-order?
#    CON_tgt_p= (dt['days_pct']>days_pct_tgt_p) & (dt['tgt_p']==0)

    
#UPDATE alert
    dt['a_out']=CON_out
    dt['a_stop']=CON_stop
    dt['a_exit']=CON_exit
#    dt['a_size']=CON_size
#    dt['a_be']=CON_be
#    dt['a_dv']=CON_dv
    dt['a_spike']=CON_spike
#    dt['a_itm']=CON_itm
    dt['a_event']=CON_event
#    dt['a_momt']=CON_momt 
    dt['a_key']=CON_key_level
    dt['a_unop']=CON_unop
#    dt['a_tgt_p']=CON_tgt_p
    dt.loc[con_add, 'a_size']='+'
    dt.loc[con_cut, 'a_size']='-'
#clean display
    dt.replace(False, "", inplace=True)
    dt.replace(np.nan, "", inplace=True)
#    dt.loc[~con_event_dt, 'event_dt']=np.nan
    dt.loc[~con_earn_dt, 'earn_dt']=np.nan    
    dt.loc[~con_div_dt, 'div_dt']=np.nan
    CON_event_show=pd.notnull(dt['div_dt'])|pd.notnull(dt['earn_dt'])
#        |pd.notnull(dt['event_dt'])

#    show_alerts=['ticker','risk_live', 'pl_pct', 'pl_ur','var_id','prob_t',\
#                 'a_out', 'a_stop', 'a_exit', 'a_size', 'a_be', 'a_dv', 'a_spike', 'a_itm' \
#                 , 'a_momt','a_unop', 'a_key','theta','delta','si','pe','yld']
    show_alerts=['ticker','risk_live', 'pl_ur_pct', 'pl_ur','var_id',\
                 'a_out', 'a_stop', 'a_exit', 'a_size',  'a_spike', \
                'a_unop', 'a_key','theta_c','delta_c']
    print(dt[show_alerts])
    return dt



    
    show_base=['ticker','risk_live','pl_pct','days_pct', 'prob_t', 'prob','tgt_p','close','beta','si','pe','yld']
    show_stop=show_base + ['bedn','beup','theta']
    show_out=show_base 
    show_exit=show_base + ['days_to_exp']
    show_size=['ticker','a_size','pl_pct','size_pct', 'weigh','size_buff','delta_to_adj',\
               'risk_live','weigh_to_adj', 'mp','days_pct','iv_hv', 'risky','play']
    show_be=['ticker','close','bedn','beup', 'play', 'delta', 'days_pct', 'prob_t','prob']
    show_dv=['ticker','var_id', 'vega','iv','i_iv', 'hv_22','hv_22_chg_pct','iv_hv','play']
    show_spike=['ticker','spike','spike_etd', 'beup','bedn','close',\
                'entry_p', 'iv', 'i_iv','pl_pct','days_pct']
    show_itm=['ticker','days_pct','close', 'strike','prob_t','prob', 'div_dt', 'lsnv','pc','play']
    show_unop=['ticker','mc','bc']
    show_event= ['ticker','days_pct','close','div_dt','event_dt', 'earn_dt']
    show_momt=['ticker', 'delta','rtn_22_chg','srtn_22_chg','entry_p','strike','close', 'play','sec']
    show_tgt_p=['ticker', 'days_pct','tgt_p','pl_pct', 'tgt_dt', 'prob_t', 'prob']

    dt.sort_values(['risk_live','pl_pct','days_pct'], ascending=False, inplace=True)
    pd.set_option('display.expand_frame_repr', False)
    print(" \n---- ALERT  ---  \n ", dt[show_alerts].to_string(index=False))
    print("\n ---- STOP ---   \n ", dt[CON_stop][show_stop])
    print("\n ---- OUT ---    \n ", dt[CON_out][show_out])
    print("\n ---- EXIT ---   \n ", dt[CON_exit][show_exit])
    print("\n ---- SIZE ---   \n ", dt[CON_size][show_size].sort_values(['size_pct','weigh'], ascending=False))
    print("\n ---- BE ---   \n ", dt[CON_be][show_be])
    print("\n ---- SPIKE OUT ---   \n ", dt[CON_spike_stop][show_spike].sort_values(['spike','spike_etd']))
    print("\n ---- SPIKE actioin ---   \n ", dt[CON_spike][show_spike].sort_values(['spike','spike_etd']))
    print("\n ---- LSNV or PLAY wrong ---   \n ", dt[CON_dv][show_dv])
    print("\n ---- ITM ---    \n ", dt[CON_itm][show_itm])
    print("\n ---- UNOP ---    \n ", dt[CON_unop][show_unop])
    print("\n ---- EVENT---   \n ", dt[CON_event & CON_event_show][show_event])
    print("\n ---- MOMT ---    \n ", dt[CON_momt][show_momt].sort_values(['delta'], ascending=False))
    print("\n ---- TGT_P ---    \n ", dt[CON_tgt_p][show_tgt_p]) 
    pd.set_option('display.expand_frame_repr', True)
    return dt

# INTEL_op
def t_convert(df, cols, type='float'):
    if type=='float':
        for x in cols:
            df[x]=df[x].astype(type)
            return df
    elif type=='datetime':
        dummy_dt='2000-1-1'
        for x in cols:
            df[x]=df[x].replace('',dummy_dt).astype(str)
            df[x]=df[x].replace('None', dummy_dt).astype(str)
            df[x]=df[x].apply(lambda i: parser.parse(i))
        return df 

def prob(dt):
    #update the prob@tgt_dt and prob @exp date

    for index, row in dt.iterrows():
            p_mean=row['close']
            std_t=row['iv']*np.sqrt(row['days_to_tgt_dt']/252)
            std= row['iv']*np.sqrt(row['days_to_exp']/252)
            
            if row['bedn']==0: #less or equal
                dt.loc[index, 'prob_t']=scipy.stats.norm.cdf(row['beup'], p_mean, std_t*p_mean)
                dt.loc[index, 'prob']=scipy.stats.norm.cdf(row['beup'], p_mean, std*p_mean)
                
            elif row['beup']==0:  #greater or equal
                dt.loc[index, 'prob_t']=scipy.stats.norm.sf(row['bedn'], p_mean, std_t*p_mean) 
                dt.loc[index, 'prob']=scipy.stats.norm.sf(row['bedn'], p_mean, std* p_mean )
    
            elif (row['bedn']>0) & (row['beup']>0):  #range
                if row['play']=='LCP': #straddle/strangle
                    dt.loc[index, 'prob_t']=scipy.stats.norm.sf(row['beup'], p_mean, std_t*p_mean) + \
                            scipy.stats.norm.cdf(row['bedn'], p_mean, std_t*p_mean)        
                    dt.loc[index, 'prob']= scipy.stats.norm.sf(row['beup'], p_mean, std*p_mean) + \
                        scipy.stats.norm.cdf(row['bedn'], p_mean, std*p_mean)
                else:
                    dt.loc[index, 'prob_t']=scipy.stats.norm.cdf(row['beup'], p_mean, std_t*p_mean)- \
                            scipy.stats.norm.cdf(row['bedn'], p_mean, std_t*p_mean)        
                    dt.loc[index, 'prob']= scipy.stats.norm.cdf(row['beup'], p_mean, std*p_mean)- \
                        scipy.stats.norm.cdf(row['bedn'], p_mean, std*p_mean)
            else:
                dt.loc[index, 'prob_t']=-1
                dt.loc[index, 'prob']=-1
    return dt

#def prob_t(['close','iv','days_to_tgt_dt','days_to_exp','bedn','beup']):
def prob_t(close ,iv, days_to_tgt_dt, days_to_exp, bedn, beup):  
    std_t=iv*np.sqrt(days_to_tgt_dt/252)
    std=iv*np.sqrt(days_to_exp/252)
    p_mean=close
    if bedn==0:  #less or equal
        prob_t=scipy.stats.norm.cdf(beup, p_mean, std_t*p_mean)
        prob=scipy.stats.norm.cdf(beup, p_mean, std*p_mean)
        
    elif beup==0:#greater or equal
        prob_t=scipy.stats.norm.sf(bedn, p_mean, std_t*p_mean) 
        prob=scipy.stats.norm.sf(bedn, p_mean, std* p_mean )
        
    elif (bedn>0 & beup>0):
        prob_t=scipy.stats.norm.cdf(beup, p_mean, std_t*p_mean)- \
                  scipy.stats.norm.cdf(bedn, p_mean, std_t*p_mean)        
        prob= scipy.stats.norm.cdf(beup, p_mean, std*p_mean)- \
                  scipy.stats.norm.sf(bedn, p_mean, std*p_mean)
    else: 
        print("track_raw:  ln319: beup/bedn both 0")
        return
    return prob_t, prob

def prob_o(df, q_date):  
    
    import scipy.stats
    con_lc=(df.bs=='b') & (df.type=='Call')
    con_sc=(df.bs=='s') & (df.type=='Call')
    con_lp=(df.bs=='b') & (df.type=='Put')
    con_sp=(df.bs=='s') & (df.type=='Put') 
    df.loc[con_lc, 'bedn']=df.loc[con_lc, 'strike'] + df.loc[con_lc, 'iop']
    df.loc[con_sc, 'beup']=df.loc[con_sc, 'strike'] + df.loc[con_sc, 'iop']
    df.loc[con_lp, 'beup']=df.loc[con_lp, 'strike'] - df.loc[con_lp, 'iop']
    df.loc[con_sp, 'bedn']=df.loc[con_sp, 'strike'] - df.loc[con_sp, 'iop']
    
    con_iv=pd.isnull(df.iv)
    df.loc[con_iv, 'iv']=df.loc[con_iv, 'civ']
    df['dte']=df['oexp_dt'].subtract(q_date).dt.days
    df['std']=df['iv']*np.sqrt(df['dte']/252)

#    con_beup= pd.notnull(df['bedn'])
#    con_bedn= pd.notnull(df['beup'])
#    df.loc[con_beup, 'prob']=df.loc[con_beup].apply(lambda x: scipy.stats.norm.cdf(x['beup'], x['p'], x['std']*x['p']), axis=1)
#    df.loc[con_bedn, 'prob']=df.loc[con_bedn].apply(lambda x: scipy.stats.norm.sf(x['bedn'], x['p'], x['std']*x['p']), axis=1)    
    df=df.head(20)
    df=type_convert(df, ['p','std'])
    for index, row in df.iterrows():
        std_p=row['p']*row['std']
        if row['beup']>0:
            df.loc[index, 'prob']=scipy.stats.norm.cdf(row['beup'], row['p'], std_p)
        elif row.bedn>0:
            df.loc[index, 'prob']=scipy.stats.norm.sf(row['bedn'], row['p'], std_p)
        else:
            pass
    df['prob']=df['prob'].apply(lambda x: "{0:.0f}%".format(x*100))
    return df