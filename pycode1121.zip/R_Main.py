# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 11:13:46 2017
Purpose: main program
Functions:  daily_run_eod
Imported:

"""
import pandas as pd
import datetime as datetime
from pandas.tseries.offsets import BDay
import warnings
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
from P_commons import read_sql, to_sql_append, to_sql_replace
from P_update_price import update_pv_eod, trig_run, vpj_plot, trig_run_1, update_price_eod

from R_stat import stat_run_base, stat_VIEW, stat_PLOT
from R_play import play_candy
from R_track import trade_TRACK
#from R_options import unop
from R_options import unop_mc, unop_bc, unop_combo
from R_plot import plot_base

today=datetime.datetime.today()
todate=today.date()
watch_list=['KLAC','URI','BID',\
    'NTLA','CRSP','EDIT','SGMO','CLXT',\
    'PLNT','CDXS','MILN','LNGR','MIND',\
    'BLOK','ZBTC']
positions=['CLXT','SGMO','ZS','CBM','MDR','CORI','ON']
#capital=15000
#DF_sp500=pd.read_csv('c:\\pycode\pyprod\constituents.csv')
#df_etf=pd.read_csv('c:\\pycode\pyprod\etf.csv')
#df_sp500=DF_sp500.ix[:,0] #serie
#df_etf=df_etf.ix[:,0]
# --------0----EXECUTION ----------------------
#trade_entry('etf') 
#trade_entry('sp500') 
RUN_COUNT='n'
RUN_COUNT=input("todate? -- Run EOD?  yes/n:    ")
if RUN_COUNT=='yes':
#    todate=datetime.date(2018,8,15)
    print(" ---- STARTS %s ----"%todate)
    update_pv_eod('etf')  # take date from eod_price file, to tbl_pv_etf:)
    update_pv_eod('sp500') #tbl_pv_ is the original raw table
    update_pv_eod('all')
    update_price_eod('etf') #same eod file, to tbl_price_sp, etf
    update_price_eod('sp500')
    print("-----positions ----")
    plot_base(todate, positions) #from tbl_pv_all
#    trig_run_1('sp500')  #fm tbl_pv to tbl_pvt_
#    trig_run_1('etf')
#    vpj_plot('sp500')
#    vpj_plot('etf')
    RUN_COUNT='n'
    
    stat_run_base(todate, 'sp500') #from tbl_price_, to tb_stat_
    stat_run_base(todate, 'etf')
    stat_VIEW(todate) #from tb_stat_, view only
    stat_PLOT(todate)# from tb_stat_
#    trade_TRACK(todate)
    
    dmc=unop_mc(todate)
    dbc=unop_bc(todate)
    dup=unop_combo(dmc,dbc)
#    plot_base(todate, dup.ticker.unique().tolist(), dup)
#    print(" -------- WATCH LIST ---")
#    plot_base(todate, watch_list)
#    
# -----------------------------------------------  #
    
def trade_entry(underlying):
    if underlying =='sp500':
        df_trade=pd.read_excel(open(r'c:\pycode\trade.xlsx','rb'))
    #df_trade=pd.read_csv('G:\Trading\Trade_python\pycode\\trade.xlsx')
        to_sql_append(df_trade, 'tbl_trade')  #log trades and track performance
        to_sql_append(df_trade, 'tbl_trade_bkup') #keep trde only
        print ("trade is saved in tbl_trade")
    elif underlying == 'etf':
        df_trade=pd.read_excel(open(r'c:\pycode\trade_etf.xlsx','rb'))
    #df_trade=pd.read_csv('G:\Trading\Trade_python\pycode\\trade.xlsx')
        to_sql_append(df_trade, 'tbl_trade_etf')  #log trades and track performance
        to_sql_append(df_trade, 'tbl_trade_etf_bkup') #keep trde only
        print ("trade is saved in tbl_trade_etf")   
    else:
        print ("trade_entry missing env")
        exit    
#dates = pd.date_range('1/1/2000', periods=8)
        #eoddata, boxofjon@gmail.com, Mima2008@