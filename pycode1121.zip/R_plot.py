# -*- coding: utf-8 -*-
"""
Created on Sun Jul 15 16:07:44 2018

@author: jon
"""
import pandas as pd
import numpy as np
import datetime as datetime
import pandas_datareader.data as web
from pandas_datareader import data, wb
import sys, os
import sqlite3 as db
import pandas.io.sql as pd_sql
from P_commons import read_sql, to_sql_replace, to_sql_append

def plot_base(q_date, ticks='', do=''): #ticks =['x','y'], do(unop)
    import plotly.plotly as plty
    import plotly.graph_objs as plgo
    import matplotlib.pyplot as plt
    from matplotlib.finance import candlestick2_ohlc as cdl
    ticks = [x.upper() for x in ticks]
#    tickers=df['ticker'].values
#    tickers=list(set(tickers))  #get only unique list value
    p_date=q_date-datetime.timedelta(100)
#    qry_sp="SELECT * FROM tbl_pvt_sp500  wHERE date BETWEEN '%s' AND '%s'" %(p_date, q_date)
#    qry_etf="SELECT * FROM tbl_pvt_etf  wHERE date BETWEEN '%s' AND '%s'" %(p_date, q_date)
#    dp_etf=read_sql(qry_etf, q_date)
#    dp_sp=read_sql(qry_sp,q_date)
#    dp=pd.concat([dp_etf, dp_sp], axis=0)
    qry="SELECT * FROM tbl_pv_all  wHERE date BETWEEN '%s' AND '%s'" %(p_date, q_date)
    dp=read_sql(qry,q_date)
    pd.set_option('display.expand_frame_repr', False)
    for t in ticks:
        if t in dp.ticker.unique():
            dt=dp[dp.ticker == t]
            dt=dt.sort_values('date', ascending=True)
            dt=dt.tail(80)
            dt['date']=dt['date'].astype(str).apply(lambda x: x[:10])
    #        dt=dt[['date', 'close','volume']]
    #        dt=dt.set_index('date')
    #        dt.plot(subplots=True, figsize=(10,4), rot=45)
    #        plt.legend(loc='best')
    #        plt.show()   
            dt=dt.set_index('date')
            fig, ax=plt.subplots(figsize=(16,3))
#            if (do.empty | len(do)==0):
            if len(do)==0:
                plt.title("%s:  "%(t))
            else:
                plt.title("%s:  "%(do[do.ticker==t]))

            cdl(ax,dt['open'], dt['high'], dt['low'], dt['close'], width=0.6)
            plt.show()
            dt['volume']=dt['volume']/100000
            dt['volume'].plot(rot=90, figsize=(15,2), kind='bar')
            plt.show()
    pd.set_option('display.expand_frame_repr', True)      
