# -*- coding: utf-8 -*-
"""
Created on Sun Sep 29 16:37:16 2019

@author: frebo
"""

import requests
import pandas as pd
pd.set_option('display.max_rows', 1000)
def getocc(symbol):
    s = requests.Session()
    url = 'https://www.theocc.com/webapps/series-search'
    r = s.post(url,data={'symbolType': 'U','symbolId': symbol})
#    r = s.post(url,data={'symbolType': 'O','symbolId': symbol})
    df = pd.read_html(r.content)[0]
    df.columns = df.columns.droplevel()
    df['Strike'] = df['Integer'] + (df['Dec']*0.001)
    cols_of_interest=['Product Symbol', 'Year', 'Month', 'Day', 'Strike', 'Call', 'Put']
    df = df[cols_of_interest]
    return df
#getocc('AAPL')