# -*- coding: utf-8 -*-
"""
Using 3rd party 
1. reqSecDefOptParams
2. reqContractDetails
3. reqHistoricalData
4. ib.reqHeadTimeStamp
5. recipes (vol calc, news, div, ratios, scanner)

"""
from ib_insync import *
import logging
import time

def get_cid_greeks_ib(q_date):

    
    CLIENT_ID = 2
    USE_TWS = True  # True => TWS,  False => IB-Gateway
    
    if USE_TWS:
        TCP_PORT = 7496     # TWS
    else:
        TCP_PORT = 4002     # IB-Gateway
    
    util.startLoop()
    
    ib = IB()
    ib.connect('127.0.0.1', TCP_PORT, clientId=CLIENT_ID)
    ib.reqMarketDataType( 2 )  #frozen data (eod)
    ib.client.MaxRequests = 10
    
    #SYMBOL = 'AAPL'
    #cds_symbol = ib.reqContractDetails(option)
    #contracts = [cd.summary for cd in cds_symbol]
    #tickers = ib.reqTickers(*contracts)
    
    cids=['ZNGA-191018C00006000', 'TWNK-191018C00015000','SIG-191018C00017000', 'AA-200117C00015000','SGMS-191018C00021000']
    cids=cids[0]
    for cid in cids[1:2]: 
        ticker=cid.split("-")[0]
        expiry= '20' + cid.split("-")[1][:6]
        type= cid.split("-")[1][6:7]
        if type=='C':
            type='CALL'
        else:
            type='PUT'
        strike=int(cid.split("-")[1][7:].lstrip("0"))/1000
        
        cont=Option(ticker, expiry, strike, type, 'SMART',100, 'USD')
        time.sleep(1)
        print("cont_1:", cont)
        ib.qualifyContracts(cont)
        time.sleep(1)
        print("cont_2:", cont)
    #    tk= ib.reqTickers(cont)
        md=ib.reqMktData(cont, genericTickList='101')  #open intereset

        time.sleep(8)
        print("md:", md)
        
        bid=md.bid
        ask=md.ask
        sale=md.last
        o_vol=md.volume
        o_dt=q_date
        print("here i am:", bid, ask, sale, o_vol)
        try:
            if len(md.lastGreeks)>0:
                print("I'm good")
                delta=md.lastGreeks.delta
                gamma=md.lastGreeks.gamma
                theta=md.lastGreeks.theta
                vega=md.lastGreeks.vega
                civ=md.lastGreeks.impliedVol
                p=md.lastGreeks.undPrice
                
            else:
                print("I'm bad")
                delta=md.modelGreeks.delta
                gamma=md.modelGreeks.gamma
                theta=md.modelGreeks.theta
                vega=md.modelGreeks.vega
                civ=md.modelGreeks.impliedVol
                p=md.modelGreeks.undPrice
        except:
            print("cid_get_greeks_ib no greeks:", cid)
            return
    #    keys=['cid','p','o_dt', 'bid','ask','sale','sale_prev', 'o_oi','o_vol','delta','theta','vega','gamma']
    keys=['civ', 'cid','p','o_dt', 'bid','ask','sale','o_vol','delta','theta','vega','gamma']
    vals=[civ, cid, p, o_dt, bid, ask, sale, o_vol, delta, theta, vega, gamma]
    ib.disconnect()
    return dict(zip(keys, vals))

    
#    [ticker] = ib.reqTickers(spx)
#    spxValue = ticker.marketPrice()
#    chains = ib.reqSecDefOptParams(spx.symbol, '', spx.secType, spx.conId)
#
#
#df=util.df(chains)
#chain = next(c for c in chains if c.tradingClass == 'SPX' and c.exchange == 'SMART')
#strikes = [strike for strike in chain.strikes
#        if strike % 5 == 0
#        and spxValue - 20 < strike < spxValue + 20]
#expirations = sorted(exp for exp in chain.expirations)[:3]
#rights = ['P', 'C']
#
#contracts = [Option('SPX', expiration, strike, right, 'SMART', tradingClass='SPX')
#        for right in rights
#        for expiration in expirations
#        for strike in strikes]
#
#contracts = ib.qualifyContracts(*contracts)
#tickers = ib.reqTickers(*contracts)

#%%
def op_calc():
    option = Option('EOE', '20171215', 490, 'P', 'FTA', multiplier=100)
    
    calc = ib.calculateImpliedVolatility(
        option, optionPrice=6.1, underPrice=525)
    print(calc)
    
    calc = ib.calculateOptionPrice(
        option, volatility=0.14, underPrice=525)
    print(calc)






"""
use
re_entry. CID chart (iv, p, vol)
bars = ib.reqHistoricalData(
        contract,
        endDateTime='',
        durationStr='60 D',
        barSizeSetting='1 hour',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1)

note: Ambiguous contracts are great to use with reqContractDetails
OptionForQuery()


testing details: 
kems = ib.reqContractDetails(kem)
ib.reqHeadTimeStamp(contract, whatToShow='TRADES', useRTH=True)
Historical tick data can be fetched with a maximum of 1000 ticks at a time. Either the start time or the end time must be given, and one of them must remain empty:
bars = ib.reqHistoricalData(
        contract,
        endDateTime='',
        durationStr='60 D',
        barSizeSetting='1 hour',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1)
Time & sales
[tick]=ib.reqHistoricalTicks(spx,"20190926",null,100,"TRADES",1, True,null)
        )

"""
