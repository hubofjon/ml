# -*- coding: utf-8 -*-
"""
Created on Sat Sep 28 13:23:08 2019

@author: frebo
"""


from ibapi.wrapper import EWrapper
from ibapi.client import EClient

from ibapi.contract import Contract

class TestApp(EWrapper, EClient):
    def __init__(self):
        EClient.__init__(self, self)
    def error(self, reqId,errorCode, errorString):
        print("Error:", reqId, errorCode, errorString)
    def contractDetails(self, reqId, contractDetails):
        print("contractdetails:", reqId, contractDetails)
    def historicaldata(self, reqId, historicaldata):
        print("histdata", reqId, historicaldata)
    
def main():
    app=TestApp()
    app.connect("127.0.0.1", 7496,0)
    contract=Contract()
    
    contract.exchange     = "SMART"
    contract.secType      = "STK"
    contract.symbol       = "AAPL"
    contract.currency     = "USD"
    contract.primaryExchange ="NASDAQ"
#    contract.strike = 17
#    contract.right = "CALL"
#    contract.LastTradeDateOrContractMonth='20191220'
    endtime = '20190926 01:00:00'
    app.reqContractDetails(1, contract)
    app.reqHistoricalData(2,contract,endtime,"1 D","50 min","TRADES",0,1, False, False)
    app.run()
    
    app.disconnect()
#    
#if __name__=="__main__":
#    main()
    
        