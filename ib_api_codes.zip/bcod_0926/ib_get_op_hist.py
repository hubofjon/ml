# -*- coding: utf-8 -*-
"""
use IB original

calculateImpliedVolatility(self, reqId:TickerId, contract:Contract,
                                   optionPrice:float, underPrice:float,
                                   implVolOptions:TagValueList)
reqPnL(self, reqId: int, account: str, modelCode: str)
reqPositions
reqAccountSummary
reqNewsBulletins
eqHistoricalData(self, reqId:TickerId , contract:Contract, endDateTime:str,
                          durationStr:str, barSizeSetting:str, whatToShow:str,
                          useRTH:int, formatDate:int, keepUpToDate:bool, chartOptions:TagValueList
whattoshow:
                TRADES
            MIDPOINT
            BID
            ASK
            BID_ASK
            HISTORICAL_VOLATILITY
            OPTION_IMPLIED_VOLATILITY

"""

# get historical contract
from ib.ext.Contract import Contract
from ib.ext.ContractDetails import ContractDetails
from ib.opt import ibConnection, message
import time
import datetime

def watcher(msg):
    print(msg)

def contractDetailsHandler(msg):
    contracts.append(msg.contractDetails.m_summary)

def contractDetailsEndHandler(msg):
    global DataWait
    DataWait =  False

def contractHistDetailsHandler(msg):
    contracts.append(msg.contractDetails.m_summary)

#con=connect(host='127.0.0.1', port=7497, clientId=1, timeout=2, readonly=True)
con = ibConnection()
con.host = "..."
con.port = ...
con.clientId = 5
con.registerAll(watcher)
con.register(contractDetailsHandler, 'ContractDetails')
con.register(contractDetailsEndHandler, 'ContractDetailsEnd')
con.register(contractHistDetailsHandler, message.historicalData)

con.connect()

contract = Contract()
contract.exchange     = "SMART"
contract.secType      = "OPT"
contract.symbol       = "KEM"
contract.currency     = "USD"
contract.strike = 17
contract.right = "CALL"
contract.LastTradeDateOrContractMonth='20191220'


endtime = '20170102 01:00:00'

con.reqContractDetails(1, contract)

con.reqHistoricalData(2,contract,endtime,"5 M","1 sec","TRADES",0,1)
con.reqHistoricalData(3,contract,endtime,"5 M","1 sec","MIDPOINT",0,1)


#time & sales
con.reqHistoricalTicks(18001, ContractSamples.USStockAtSmart(), "20190927 08:00:00", "", null,
100, "TRADES", 1, true, null);
                       
                       
contracts = []

DataWait = True  ;  i = 0
while DataWait and i < 90:
    i += 1 ; print(i),
    time.sleep(1)

con.disconnect()
con.close()

print(contracts)