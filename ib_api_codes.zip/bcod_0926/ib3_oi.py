# -*- coding: utf-8 -*-
"""
Created on Sat Sep 28 23:01:13 2019
https://groups.io/g/insync/attachment/1977/0/get_oi.py
https://groups.io/g/insync/topic/24466947?p=Created,,,20,2,0,0

http://holowczak.com/ib-api-socket-csharp-realtime/3/


CME tool:
    https://www.cmegroup.com/tools-information/quikstrike/cross-correlation.html
@author: frebo
"""

from ib_insync import *
import logging

CLIENT_ID = 111
USE_TWS = False  # True => TWS,  False => IB-Gateway

if USE_TWS:
    TCP_PORT = 7497     # TWS
else:
    TCP_PORT = 4002     # IB-Gateway


util.logToConsole(logging.DEBUG)

ib = IB()
ib.connect('127.0.0.1', TCP_PORT, clientId=CLIENT_ID)

ib.reqMarketDataType( 2 )

ib.client.MaxRequests = 10

SYMBOL = 'AAPL'

option = Option(SYMBOL, exchange='SMART')
cds_symbol = ib.reqContractDetails(option)
contracts = [cd.summary for cd in cds_symbol]
tickers = ib.reqTickers(*contracts)

twenty = tickers[0:20]

for t in tickers:
#for t in twenty:
    ib.reqMktData(t.contract, genericTickList='101')


print('len(ib.pendingTickers()):', len(ib.pendingTickers()))

ib.sleep(60.0)


print('len(ib.pendingTickers()):', len(ib.pendingTickers()))

for t in tickers:
#for t in twenty:
    print('OI-1 conId', t.contract.conId, 'localSymbol:', t.contract.localSymbol, 'callOI:', t.callOpenInterest, 'putOI:', t.putOpenInterest)

ib.disconnect()
