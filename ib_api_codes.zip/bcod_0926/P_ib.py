# -*- coding: utf-8 -*-
"""
Business model: https://www.quantrocket.com/docs/
code sample -----
  https://github.com/erdewit/ib_insync
https://dimon.ca/dmitrys-tws-api-faq/


Tutorial:  https://www.youtube.com/watch?v=hogXB07OJ_I
https://qoppac.blogspot.com/2017/03/interactive-brokers-native-python-api.html
https://qoppac.blogspot.com/2017/03/historic-data-from-native-ib-pyhon-api.html

Shahgahi stock api
https://product.intrinio.com/developer-sandbox

https://github.com/anthonyng2/ib
https://www.quora.com/Which-platforms-allow-me-to-plug-in-trading-algorithms-written-in-Python-to-start-trading-and-not-just-backtesting
Created on Wed Sep 18 11:36:03 2019

https://groups.io/g/twsapi/
https://www.quantrocket.com/docs/api/

1. api doc.http://interactivebrokers.github.io/tws-api/functions.html
2. https://qoppac.blogspot.com/2017/03/interactive-brokers-native-python-api.html
3. https://www.quantstart.com/articles/Using-Python-IBPy-and-the-Interactive-Brokers-API-to-Automate-Trades
4. https://github.com/ranaroussi/ezibpy#request-market-data
download op chain
5. http://www.quantacademy.com/2014/09/options-chain-download-from-interactive-brokers-with-python/
6. http://www.tradinggeeks.net/downloads/ib-data-downloader/




Alt-2 scrape
https://testdriven.io/blog/building-a-concurrent-web-scraper-with-python-and-selenium/
https://github.com/calebpollman/web-scraping-parallel-processing/blob/master/script.py

"""

#%%

