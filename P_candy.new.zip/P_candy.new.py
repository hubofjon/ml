# -*- coding: utf-8 -*-
"""
1  candy_intel: 'c_vet' (p_chg, iv_chg, stk_vol_pct) refreshed at candy@flask, along update to 'watch'  
2  candy_update: lookback=7
3  candy_track: track only non-q_date by tid; spec@flaks update 'watch' into tbl_candy,update,track by TID
    because accuracy depends on accuracy of 'bs' which is ONLY updated after tbl updated @q_date
    'watch' !=N: reviewed
    'p_vet' + 'pair' + 'watch' + 'r-vet'-> decision to copy trade or not (paper/candy/real_vet)
3a prob_o

Arch:
"""
import pandas as pd
import numpy as np 
import datetime 
from datetime import timedelta
import warnings
from P_commons import to_sql_append, to_sql_replace, read_sql, type_convert, get_conn, tbl_nodupe_append, reg_convert, fmt_map
from P_stat import stat_VIEW
from R_plot import plot_base
from P_getdata import get_SI, get_FUN, get_EARN
from dateutil import parser
from termcolor import colored, cprint
from timeit import default_timer as timer
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format


look_back=15  #update_op_CID('op_spec') & obmc_update_tbl_track
dte_min=10

#%%    
def candy_intel(q_date): 
    """
    use: rule-based filter candy@ q_date for manual vet of ioc/iop/play
    source: tbl_bc_raw, tbl_mc, tbl_pv_all (max_dt), stat_VIEW (max_dt)
    ext_source: get_EARN
    dest: tbl_candy, called by obmc_update_tbl_track()
    intel: label 'why': hikes, 'value', 'sig_dte'
    values: 1->5, iv_hv, hv_rank: 0.3,0.2 (3 phases)
    """
    print("candy_intel started")
    start_time=timer()
    # filter for bc
    ioc_min=1500  #bc cvol min
    iop_min=0.2
    iop_max=6
    dte_min_premium_max=2  #premium max for short term option
    dte_max=140
    p_max=300
    p_min=5
    atm_max=0.4    # atm: spec nature
    bet_min=100000/1000
    d2earn_max=7
    
    # filter for mc
    ioc_avg_max=25000  #avoid high optios volume ticker
    #bc_only tid filter
    v_oi_ratio=6
    volume_stk_max=7500000  #avoid high option tickers
    #"why" criteria
    hv_rank_min=0.3
    iv_hv_diff=0.2
    key_level_pct=0.015
    spike_mark=2
    #bc data    
    dbc=read_sql("SELECT * FROM tbl_bc", q_date)
    dbc['date']=pd.to_datetime(dbc['date'])
    dbc=dbc[dbc.date>=q_date]
    dbc=type_convert(dbc, ['v_oi','dte','ioc','iop', 'p','atm'])
    con_ioc=dbc['ioc']>ioc_min
    con_dte= (dbc.dte>dte_min) & (dbc.dte<dte_max)  #ignore long dated
    con_iop=(dbc['iop']>iop_min) & (dbc['iop']<iop_max)
    con_p=(dbc['p']<p_max) & (dbc['p']>p_min)
    con_atm= (dbc['atm']<=atm_max)
    con_short=(dbc['dte']<dte_min) & (dbc['iop']>dte_min_premium_max)
    con_bet=dbc.bet>bet_min
    dbc=dbc[con_ioc & con_dte & con_iop & con_p & con_atm & con_bet & (~con_short)] 
    col_bc=['atm', 'bs', 'cid', 'civ', 'date', 'dte', 'ioc','bet','iop_p',
       'iop', 'oexp_dt', 'oi', 'p',  'strike', 'ticker', 'type', 'v_oi', 'tid']
    dbc=dbc[col_bc]
    #mc data
    dmc=read_sql("SELECT * FROM tbl_mc", q_date)
    dmc['date']=pd.to_datetime(dmc['date'])
    dmc=dmc[dmc.date>=q_date]
    con_ioc_avg_max=dmc['v_opt_avg']<ioc_avg_max
    dmc=dmc[con_ioc_avg_max]
    col_mc=['ticker','p_chg','v_pct', 'pct_c', 'iv', 'iv_chg','earn_dt','event_dt']
    dmc=dmc[col_mc]
   
    df_bmc=dbc.merge(dmc, on='ticker',how='left')  
    df=df_bmc[pd.notnull(df_bmc.iv) ] # in both mc & bc
    dn=df_bmc[pd.isnull(df_bmc.iv)] #in bc only, not in mc
    #filter bc_only tid by stk_vol of previous b_day from tbl_pv_all
#    p_date=q_date-timedelta(1)
    dp=read_sql("SELECT * FROM tbl_pv_all")
    max_dt=dp.date.max()
    dp=dp[dp.date== max_dt]
    dp['date']=pd.to_datetime(dp['date'])
    dn=dn.merge(dp[['ticker','volume']], on='ticker', how='left')
    con_v_oi=dn.v_oi> v_oi_ratio
    con_vol_stk=dn.volume< volume_stk_max
    dn=dn[ con_v_oi & con_vol_stk]
    dn.drop('volume', axis=1, inplace=True)
    
    dfn=pd.concat([df, dn], axis=0)
#   merge with stat_VIEW
    dv=read_sql("select * from tbl_stat")
    dv['date']=pd.to_datetime(dv['date']).dt.date
    max_stat_dt=dv.date.max()

    ds=stat_VIEW(max_stat_dt, dfn.ticker.unique().tolist())
    dt=dfn.merge(ds, on='ticker')
#re_calc spike, fm_keys for hikes if q_date> ma_stat_dt
    if q_date > max_stat_dt:
        for x in ['spike','fm_lo','fm_hi', 'fm_50', 'fm_200']:
            dt[x]=(dt['p']*(1+dt[x]))/dt['close']-1

    dt['sig_dte']=dt['p']*dt['iv']*np.sqrt(dt['dte']/252)
    con_earn_dt=pd.isnull(dt.earn_dt)
    list_tickers=dt[con_earn_dt].ticker.unique()
    
    for t in list_tickers:
        try:
            dt.loc[dt.ticker==t, 'earn_dt']= get_EARN(t)
        except:
            pass
    
    CON_key_level=(np.abs(dt['fm_50'])<= key_level_pct) \
      |(np.abs(dt['fm_200'])<= key_level_pct) \
      |(np.abs(dt['fm_hi'])<= key_level_pct) \
      |(np.abs(dt['fm_lo'])<= key_level_pct)
    
    con_iv=pd.isnull(dt.iv)
    dt.loc[con_iv, 'iv']=dt.loc[con_iv, 'civ']
    dt['iv_hv']=dt['iv']/dt['hv_22']
    CON_iv_hv= (dt['iv_hv']> (1+ iv_hv_diff)) & (dt['iv_hv']<(1-iv_hv_diff))
    
    CON_hv_rank=(dt['hv_rank']< hv_rank_min) & (dt['hv_rank']> (1-hv_rank_min))
    
    dt['earn_dt']=pd.to_datetime(dt['earn_dt']).dt.date
    dt['oexp_dt']=pd.to_datetime(dt['oexp_dt']).dt.date
    CON_earn=(dt['oexp_dt']>dt['earn_dt']) & (dt['earn_dt']>q_date)
    CON_spike=dt['spike'] > spike_mark
# option value    
    con_ll=(dt['iv_hv']<(1-iv_hv_diff)) & (dt['hv_rank']< hv_rank_min)
    con_lh=(dt['iv_hv']<(1-iv_hv_diff)) & (dt['hv_rank']> (1-hv_rank_min))
    con_hl=(dt['iv_hv']> (1+ iv_hv_diff)) &  (dt['hv_rank']< hv_rank_min)
    con_hh=(dt['iv_hv']> (1+ iv_hv_diff)) & (dt['hv_rank']> (1-hv_rank_min))
    con_mm=  ~ (con_ll | con_lh | con_hl |con_hh)

    dt.loc[con_ll, 'fair']=1
    dt.loc[con_lh, 'fair']=2
    dt.loc[con_mm, 'fair']=3
    dt.loc[con_hl, 'fair']=4
    dt.loc[con_hh, 'fair']=5
    
    dt['why']=''
    dt.loc[CON_hv_rank, 'why']='h'
    dt.loc[CON_iv_hv, 'why']=dt.loc[CON_iv_hv, 'why']+'i'
    dt.loc[CON_key_level, 'why']=dt.loc[CON_key_level, 'why'] + 'k'
    dt.loc[CON_earn, 'why']=dt.loc[CON_earn, 'why']+'e'
    dt.loc[CON_spike, 'why']=dt.loc[CON_spike, 'why']+'S'

    col=['atm', 'hv_rank', 'fm_200', 'fm_50', 'fm_hi', 'fm_lo', 'spike', 'rtn_22_pct', \
          'srtn_22_pct', 'iv_hv', 'iv', 'sig_dte', 'bet']
    dt=fmt_map(dt, col)  #formate float for flask easiness
    dt['date']=pd.to_datetime(dt['date']).dt.date
    dt['candy_dt']=dt['date']
    tbl_nodupe_append(q_date, dt, 'tbl_candy')
    end_time=timer()
    print("candy_intel time: ", end_time-start_time)
    return dt

#%%
def candy_update(q_date):
    """
    use: update tbl_candy_update from op_spec: mp=mid_point, only 'watch' is NULL
    source: tbl_candy, op_spec, lookback <no new data>
    ext_source: no
    dest:tbl_obmc_track
    filter:  re_calc dte, lookback=7, exception: watch (dte>7)
    recacl 'dte' but not to change origal df, which is writent to dest. table
    trick: exclude candy@q_date as its 'bs' and 'watch' not reviewed yet@q_date
    """
    print("candy_update started")
    dc=read_sql("select * from tbl_candy where (watch IS NOT 'N')")
    dc['candy_dt']=pd.to_datetime(dc['candy_dt']).dt.date
    dc['oexp_dt']=pd.to_datetime(dc['oexp_dt']).dt.date
    dte=(dc['oexp_dt']-q_date).dt.days
    lbk_date=q_date - timedelta(look_back)
    con_lbk=dc.candy_dt >lbk_date
    con_dte= dte > dte_min
    dc_lb=dc[con_dte & con_lbk ]
# include candy before look-back date as exepmption: watched & 
    con_bf_lb=(dc['watch']!='N') & (pd.notnull(dc.watch)) & \
        ( (dc['watch']=='') | (dc.watch.str.len()>1) )
    dc_bf_lb=dc[con_dte & con_bf_lb & (~con_lbk)]
    dc=pd.concat([dc_lb, dc_bf_lb], axis=0)  

    do=read_sql("select * from op_spec")
    do['o_dt']=pd.to_datetime(do['o_dt']).dt.date
    do=do[do.o_dt==q_date]
    do['mp']=(do['bid']+do['ask'])*0.5
    # p from op_spec (for daily non-candy update p)
    dc.drop('p', axis=1, inplace=True)
    df=dc.merge(do[['cid','mp','o_oi','o_vol', 'p', 'o_dt']])
    df['date']=q_date
    tbl_nodupe_append(q_date, df, 'tbl_candy_update')
    return df

    
#%%    -
def candy_track(q_date):
    """
    use: label e_sig (lcp, scp, vlp) from candy_update (candy_dt <7days)
    source: tbl_candy_update, tbl_bc (incl. un_candies entries), prob_o 
    (e_sig depend on accuracy of 'bs')
    dest:   filter: candy_dt> look_back_track
    filter: candy_dt< lkbk, obc_raw_date<lkbk, lo_oi_i_chg_min: 1000
    stop tracking if updated dte< dte_min (10 days).i.e. no candy if dte<10 days
    intel: e_sig, prob, up_cnt
    (30% of filterd) get_SI, get_FUN
    e_sig: clp, clc: count in 'bs' for watched cid ONLY
        lc,lp...: only suggested, not count in 'bs' yet
    'dte' re_calc into 'dte_t' in tbl_candy_track
    """
    print(" candy_track started")
    start_time=timer()

    o_oi_i_chg_min=1000  #2nd day after entry: min impact on oi_chg from vol>1500, or is wash if new trade
    #eg. o_vol is 5000, but the 2nd day o_oi_chg is only 500, meanng most is wash-trade or close existing position
    bet_bc_raw_min=50000/1000
    bargain_min= -0.55
    mp_max= 6
    
    #filter 
    o_vol_min=500  #min o_vol
    o_vol_2_oi_chg_max =5  #min vol impact on oi_chg
    #eg. o_vol is 4000, oi_chg s 200, then ratio is 20>3, meaning vol impact on oi is small,mainly wash
    o_oi_i_chg_pct_add_min= 0.2
    o_oi_i_chg_pct_cut_min= -0.3 
    o_oi_chg_min=500
#exclude candy@q_adate, bt o_dt can be q_date, ie. prior cid get latest update of cid 
    dt=read_sql("select * from tbl_candy_update  where (watch IS NOT 'N') \
                AND candy_dt <>'%s'"%q_date)
    dt['candy_dt']=pd.to_datetime(dt['candy_dt']).dt.date
    dt['oexp_dt']=pd.to_datetime(dt['oexp_dt']).dt.date
    dt['o_dt']=pd.to_datetime(dt['o_dt']).dt.date
    dt['dte']=(dt['oexp_dt']-q_date).dt.days
    lbk_date=q_date - timedelta(look_back)
    con_dte= dt['dte'] > dte_min
    con_lbk=dt.candy_dt >lbk_date
    dt_lb=dt[con_dte & con_lbk ]
# include candy before look-back date as exepmption: watched & 
    con_bf_lb=(dt['watch']!='N') & (pd.notnull(dt.watch)) & \
        ( (dt['watch']=='') | (dt.watch.str.len()>1) )
    dt_bf_lb=dt[con_dte & con_bf_lb & (~con_lbk)]
    
    dt=pd.concat([dt_lb, dt_bf_lb], axis=0)
    dt=dt.sort_values(['tid','o_dt'])
    dt['o_oi_i_chg']=dt.groupby('tid')['o_oi'].apply(lambda x:x-(x.iloc[0]))
    dt['o_oi_i_chg_pct']=dt.groupby('tid')['o_oi'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    dt['mp_i_chg_pct']=dt.groupby('tid')['mp'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    dt['p_i_chg_pct']=dt.groupby('tid')['p'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    dt['rsi_i_chg']=dt.groupby('tid')['rsi'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    dt['hv_i_chg']=dt.groupby('tid')['hv_22'].apply(lambda x:x-(x.iloc[0]))
    
    con_candy_day1= (dt['o_dt']==dt['candy_dt'])
    con_candy_day2= (dt['o_dt']-dt['candy_dt']).dt.days==1
    con_oi_chg= dt['o_oi_i_chg'] <o_oi_chg_min
    con_wash= con_candy_day2 & con_oi_chg
    
    dt.loc[ ~con_candy_day1, 'ioc']=0
    dt.loc[ ~con_candy_day1, 'iop']=0
    wash_tid=dt[con_wash].tid.unique().tolist()
    dt.loc[dt.tid.isin(wash_tid), 'watch']='N'
    con_no_watch=dt.watch=='N'
    dt_no_watch=dt[con_no_watch]
    no_watch_list=dt_no_watch.tid.unique().tolist()
    dw=dt[~ con_no_watch]

    
    """
# prepare bc_raw for concat data 
    dbc=read_sql("select * from tbl_bc where date>='%s'"%lbk_date)
    dbc['date']=pd.to_datetime(dbc['date'])
    dbc['oexp_dt']=pd.to_datetime(dbc['oexp_dt']).dt.date
    dbc['dte']=dbc['dte'].astype(float)
    dbc['dte']=(dbc['oexp_dt']-q_date).dt.days
    dbc['tid']=dbc['cid']+ '-' +dbc['date'].apply(lambda x: x.strftime('%y%m%d'))
    con_bet=dbc.bet>bet_bc_raw_min
    dbc=dbc[con_bet & (dbc['dte']>dte_min)]
    set_dt=set(dt.columns.tolist())
    set_bc=set(dbc.columns.tolist())    
    col_share=list(set_dt & set_bc)
#   update @cid level
    df=pd.DataFrame()
    list_cid=dt.cid.unique()
    for cid in list_cid:
    #candy_dt from tbl_candy, date for tbl_bc_raw, o_dt for greeks udpate timing
    #mp_i_chg_pct is the unique INDEX to align same tid together
        dg=dt[dt.cid==cid]
        dg.sort_values('o_dt', inplace=True)
        #o_oi_i_chg: last day (not incl. impact from o_vol@q_date) vs, 2nd day o_oi (ie. o_oi after un_op)
        # if dg.shape=2 then oi_i_chg=0
        #'o_oi_i_chg' is used for beachmark thus enforced a fixe value into a columns
        o_oi_i_chg=dg['o_oi'].tail(1).values[0]-dg['o_oi'].head(1).values[0] 
        o_oi_i_chg_pct =o_oi_i_chg /dg['o_oi'].head(1).values[0]
        dg['o_oi_i_chg']=o_oi_i_chg
        dg['o_oi_i_chg_pct']=o_oi_i_chg_pct
        dg['o_oi_chg']=dg['o_oi'].shift(-1)- dg['o_oi']
        #assess vol to oi_chg percent
        dg['o_vol_2_oi_chg']=dg['o_vol']/dg['o_oi_chg']
        dg['mp_p_chg']=dg['mp']-dg['mp'].shift(1)
        mp_i_chg_pct=(dg['mp'].tail(1).values[0]-dg['mp'].head(1).values[0])/ \
                (dg['mp'].head(1).values[0]) 
        dg['mp_i_chg_pct']=mp_i_chg_pct
        dg['up_cnt']=dg[dg['mp_p_chg']>0].shape[0]
        dg['dn_cnt']=dg[dg['mp_p_chg']<0].shape[0]
        dg['cnt']=dg.shape[0]
        p_i_chg_pct=(dg['p'].tail(1).values[0]/dg['p'].head(1).values[0])-1
        dg['p_i_chg_pct']=p_i_chg_pct
        #when new trade has rsi
        dg['rsi_i_chg']=dg['rsi'].tail(1).values[0]-dg['rsi'].head(2).tail(1).values[0] 
        dg['hv_i_chg']=dg['hv_22'].tail(1).values[0]-dg['hv_22'].head(2).tail(1).values[0] 
        #exclude wash candy from y'day
        if (dg.shape[0]==2) & (o_oi_i_chg <o_oi_i_chg_min):
            dg['watch']='N'
            
#        else:  risk of override already labelled 'watch' filed value
#            dg['watch']=np.NaN
        watch=dg['watch'].head(1).values[0]
        #merge dbc_raw on tid basis
        dbc_g=dbc[dbc.ticker.isin(dg.ticker) & ~(dbc.tid.isin(dg.tid))]
        dbc_g=dbc_g[col_share]
        dbc_g['o_oi_i_chg']= o_oi_i_chg
        dbc_g['o_oi_i_chg_pct']= o_oi_i_chg_pct
        dbc_g['mp_i_chg_pct']=mp_i_chg_pct
        dbc_g['p_i_chg_pct']=p_i_chg_pct
        dbc_g['watch']=watch
        df=pd.concat([df,dg, dbc_g], axis=0)
    
    
# FILTER: EXclude NO_WATCH tid   
    # exclude:  o_vol_min, impact on  o_oi or new trade
    #below filter only applicable to dg only, not dbc_g (from obc_raw) as col_share has not conditioned fileds
    con_o_vol=df['o_vol']> o_vol_min
    con_o_vol_2_oi_chg=np.abs(df['o_vol_2_oi_chg'])<o_vol_2_oi_chg_max  # vol has impact on oi_chg
    con_new= (df['o_dt']==df['candy_dt']) #not the q_date (as oi is missing)
    con_q_date=df['o_dt']==q_date
    CON_in=(con_o_vol & con_o_vol_2_oi_chg)| con_new | con_q_date

    
    dw=df[CON_in]
    df_no_watch=df[~CON_in]
    df_no_watch['watch']='N'
    """
    
# update tbl_candy with 'watch' filed
    
    if len(no_watch_list)>0:
        conn = get_conn()
        cursor = conn.cursor()
        for w in no_watch_list:
            cursor.execute("UPDATE tbl_candy SET watch='N' WHERE tid='%s' "%w )
            cursor.execute("UPDATE tbl_candy_update SET watch='N' WHERE tid='%s' "%w )
        conn.commit()
        conn.close()    
    #no dupe 'uid'???
#    df.drop_duplicates(['tid'], keep='first', inplace=True)
    col_sort=[ 'o_oi_i_chg_pct','mp_i_chg_pct', 'tid','o_dt']    
    col_asc=[0, 0, 1,1]    
    dw.sort_values(col_sort, ascending=col_asc,  inplace=True)    
    dw['date']=q_date    

#re_calcl dte
#Entry_singal_op: mp_up, oi_up    
    con_oi_up=dw.o_oi_i_chg>=0    
    con_mp_up=dw.mp_i_chg_pct>0    
    con_p_up=dw.p_i_chg_pct>0    
    con_rsi_up=dw.rsi_i_chg>0    
    con_hv_up =dw.hv_i_chg>0    #hv expand    
    con_c=dw.type=='Call'    
    con_p=dw.type=='Put'    
    con_iv_up=dw.iv_chg.astype(float)>0        
    con_act=(dw['watch']!='N') & (pd.notnull(dw.watch)) & \
        ( (dw['watch']=='') | (dw.watch.str.len()>1) )    
    con_lc=(~con_act) & con_oi_up & con_mp_up & con_c & con_p_up #& con_rsi_up & con_hv_up    
    con_lp=(~con_act) & con_oi_up & con_mp_up & con_p & (~ con_p_up) #& (~ con_rsi_up) & con_hv_up    
    con_sc= (~con_act) & ( con_oi_up) & (~ con_mp_up) & con_c# & (~ con_rsi_up)    
    con_sp= (~con_act) & ( con_oi_up) & (~ con_mp_up) & con_p #& con_rsi_up    
    con_clc=(~con_act) & (~ con_oi_up) & con_mp_up & con_c & con_p_up #& con_rsi_up & con_hv_up    
    con_clp= (~con_act) & (~ con_oi_up) & con_mp_up & con_p & (~ con_p_up) #& (~ con_rsi_up) & con_hv_up    
    con_csc= (~con_act) & ( ~con_oi_up) & (~ con_mp_up) & con_c# & (~ con_rsi_up)    
    con_csp= (~con_act) & ( ~con_oi_up) & (~ con_mp_up) & con_p #& con_rsi_up        
    con_why= (dw.why != '')    
    con_barg= (dw.mp_i_chg_pct < bargain_min) & (dw.mp< mp_max)    
    #over-write with confirmed CLC/CLP    
    con_l=dw.bs=='b'    
    con_s=dw.bs=='s'        
    con_alc=con_act & con_c & con_mp_up & con_l    
    con_alcn=con_act & con_c & (~con_mp_up) & con_l    
    con_alp=con_act & con_p & (~con_mp_up) & con_l    
    con_alpn=con_act & con_p & (con_mp_up) & con_l    
    con_asc=con_act & con_c & (~con_mp_up) & con_s    
    con_ascn=con_act & con_c & (con_mp_up) & con_s    
    con_asp=con_act & con_p & con_mp_up & con_s    
    con_aspn=con_act & con_p & (~con_mp_up) & con_s
    # a: watched, c: cover        
    dw.loc[con_lc, 'e_sig']='lc'    
    dw.loc[con_lp, 'e_sig']='lp'    
    dw.loc[con_sc, 'e_sig']='sc'    
    dw.loc[con_sp, 'e_sig']='sp'         
    dw.loc[con_clc, 'e_sig']='clc'    
    dw.loc[con_clp, 'e_sig']='clp'    
    dw.loc[con_csc, 'e_sig']='csc'    
    dw.loc[con_csp, 'e_sig']='csp'     
    dw.loc[con_barg, 'e_sig']='barg'        
    dw.loc[con_alc, 'e_sig']='alc'    
    dw.loc[con_alp, 'e_sig']='alp'    
    dw.loc[con_asc, 'e_sig']='asc'    
    dw.loc[con_asp, 'e_sig']='asp'    
    dw.loc[con_alcn, 'e_sig']='alcn'    
    dw.loc[con_alpn, 'e_sig']='alpn'    
    dw.loc[con_ascn, 'e_sig']='ascn'    
    dw.loc[con_aspn, 'e_sig']='aspn'

#   prob_o critiera
    dw=candy_prob(dw, q_date)  
# enrich filterd candy with get_FUN, get_SI  
# leverage eisting tbl-candy=track to get these values to save time
    dk=read_sql("select * from tbl_candy_track")
    dk['date']=pd.to_datetime(dk['date'])
    con_dk= dk['date']> (q_date - timedelta(dte_min))
    dk=dk[con_dk]
    dk.sort_values(['ticker','date'], ascending=[True, False], inplace=True)
    dk.drop_duplicates('ticker', keep='first', inplace=True)
    
    new_tickers=list(set(dw.ticker.tolist()) - set(dk.ticker.tolist()))
    print("candy_track new ticker list:", new_tickers)

    dw.drop('beta', axis=1, inplace=True)
    dw=dw.merge(dk[['ticker','beta','pe','ta','eg']], on='ticker',how='left')
# get_values for new candy_track tickers only    
#    con_ext= pd.notnull(dw.e_sig) & pd.isnull(dw['ta']) 
#    list_ext=dw[con_ext].ticker.unique().tolist()
    
    if len(new_tickers)>0:
        for t in new_tickers:
            try:
                fun_col=['beta','pe','ta','eg']
                FUN=get_FUN(t)  
                for k in fun_col:
                    dw.loc[dw.ticker==t, k]=FUN[k]
            except:
                for k in fun_col:
                    dw.loc[dw.ticker==t, k]=0
            try:
                si_col=['si']
                SI=get_SI(t)  
                for k in si_col:
                    dw.loc[dw.ticker==t, k]=SI[k]
            except:
                for k in si_col:
                    dw.loc[dw.ticker==t, k]=0
# replace 'ta' from dictionary values
        dict_ta={'Strongbuy':4, 'buy':2 ,'Weakbuy': 1, 'hold':0, 'Weaksell': -1, 'sell': -2,\
             'Strongsell': -4, 'Learnaboutou': -99}
        dw['ta']=dw['ta'].replace(dict_ta)
    
#preserve dw_orig with e_sig laebl of "ls/cp' for tbl_candy-track
    
    col_val=['atm','bet', 'hv_rank','iv','fm_50', 'fm_200', 'fm_hi', 'fm_lo','spike',\
             'rtn_22_pct',  'iv_hv', 'sig_dte', 'mp', 'mp_i_chg_pct','o_oi_i_chg_pct', 'mp']
    dw=type_convert(dw, col_val)
    dw=fmt_map(dw, col_val)

    dw['earn_dt']=pd.to_datetime(dw['earn_dt']).dt.date
    dw['oexp_dt']=pd.to_datetime(dw['oexp_dt']).dt.date

    dw=candy_track_score(dw)
    dw=candy_track_vet(dw)
    tbl_nodupe_append(q_date, dw, 'tbl_candy_track')    
    end_time=timer()
    print("candy_track time: ", end_time-start_time)
    return dw

#%%    
def candy_prob(dp, q_date):  
    """
    prioity:
    1. watched: alc/p
    2. non_watch e_sig: suggested
    3. non_watch, e_sig: null 
    """
    import scipy.stats
    df=dp.sort_values('date')
    
    sig_0=['lc','lp','sc','sp']
    sig_2=['a'+s for s in sig_0]
    sig_3=[s + 'n' for s in sig_2]
    sig_4=['c'+s for s in sig_0]
    sig_5=[s + 'n' for s in sig_4]
    sigs=sig_0+sig_2+sig_3 + sig_4 + sig_5
    
    con_e_sig=df.e_sig.isin(sigs)
    
    dg=df[con_e_sig]
    con_lc= dg.e_sig.str.contains('lc')
    con_sc= dg.e_sig.str.contains('lp')
    con_lp= dg.e_sig.str.contains('sc')
    con_sp= dg.e_sig.str.contains('sp') 
    dg.loc[con_lc, 'bedn']=dg.loc[con_lc, 'strike'] + dg.loc[con_lc, 'iop']
    dg.loc[con_sc, 'beup']=dg.loc[con_sc, 'strike'] + dg.loc[con_sc, 'iop']
    dg.loc[con_lp, 'beup']=dg.loc[con_lp, 'strike'] - dg.loc[con_lp, 'iop']
    dg.loc[con_sp, 'bedn']=dg.loc[con_sp, 'strike'] - dg.loc[con_sp, 'iop']
    
    dng=df[~ con_e_sig]
    con_lc=(dng.bs=='b') & (dng.type=='Call')
    con_sc=(dng.bs=='s') & (dng.type=='Call')
    con_lp=(dng.bs=='b') & (dng.type=='Put')
    con_sp=(dng.bs=='s') & (dng.type=='Put') 
    dng.loc[con_lc, 'bedn']=dng.loc[con_lc, 'strike'] + dng.loc[con_lc, 'iop']
    dng.loc[con_sc, 'beup']=dng.loc[con_sc, 'strike'] + dng.loc[con_sc, 'iop']
    dng.loc[con_lp, 'beup']=dng.loc[con_lp, 'strike'] - dng.loc[con_lp, 'iop']
    dng.loc[con_sp, 'bedn']=dng.loc[con_sp, 'strike'] - dng.loc[con_sp, 'iop']
    
    df=pd.concat([dg, dng], axis=0)
    con_iv=pd.isnull(df.iv)
    df.loc[con_iv, 'iv']=df.loc[con_iv, 'civ']
    df['oexp_dt']=pd.to_datetime(df['oexp_dt'])
    df['dte']=df['oexp_dt'].subtract(q_date).dt.days
    df['std']=df['iv']*np.sqrt(df['dte']/252)
    df=type_convert(df, ['p','std'])
    for index, row in df.iterrows():
        std_p=row['p']*row['std']
        if row['beup']>0:
            df.loc[index, 'prob']=scipy.stats.norm.cdf(row['beup'], row['p'], std_p)
        elif row.bedn>0:
            df.loc[index, 'prob']=scipy.stats.norm.sf(row['bedn'], row['p'], std_p)
        else:
            pass
    df['prob']=df['prob'].astype(float).apply(lambda x: "{0:.0f}%".format(x*100))
    return df

#%%
def candy_track_score(df):
    """
    use: 
    """
#    df['up_cnt_pct']=df['up_cnt']/df['cnt']
    val=['p_i_chg_pct', 'srtn_22_pct']
    df=type_convert(df, val)
    lcp=df.e_sig.isin(['lc','lp'])
#    df.loc[lcp, 's_cnt']=df.loc[lcp, 'up_cnt_pct']>=0.5
    df.loc[lcp,'s_fair']=df.loc[lcp,'fair']<=3
    df.loc[lcp,'s_bs']=df.loc[lcp,'bs']=='b'
    scp=df.e_sig.isin(['sc','sp'])
#    df.loc[scp,'s_cnt']=df.loc[scp,'up_cnt_pct']<0.5
    df.loc[scp,'s_fair']=df.loc[scp,'fair']>3
    df.loc[scp,'s_bs']=df.loc[scp, 'bs']=='s'
    
    lc=df.e_sig=='lc'
    df.loc[lc, 's_ta']=df.loc[lc, 'ta']>3
    df.loc[lc, 's_p']=df.loc[lc, 'p_i_chg_pct']>0
    df.loc[lc, 's_srtn']=df.loc[lc, 'srtn_22_pct']>=5
#    lc['s_rsi']=lc['rsi_i_chg']>0         
 
    lp= df.e_sig=='lp'
    df.loc[lp, 's_ta']=df.loc[lp,'ta']<3
    df.loc[lp,'s_p']=df.loc[lp,'p_i_chg_pct']<0
    df.loc[lp,'s_srtn']=df.loc[lp,'srtn_22_pct']<=5
#    lp['s_rsi']=lp['rsi_i_chg']<0 
    col=['s_fair','s_bs', 's_ta', 's_p', 's_srtn']
    df[col]=df[col].replace({True: 1, False: 0})

    df['s_op']=( df['s_fair'] + df['s_bs']).fillna(0)
    df['s_tas']=(df['s_ta']+ df['s_p']+df['s_srtn']).fillna(0) #+ df['s_rsi']
    df.drop(['s_bs','s_fair','s_p', 's_srtn', 's_ta'], axis=1, inplace=True)
    return df
    """   
    aggregations = {
    'up_cnt_pct': {'s_cnt': lambda x: x>=0.5},
    'fair': {'s_fair': lambda x: list(x<=3)},
    'bs': {'s_bs': lambda x:x=='b'}}
    df.groupby('e_sig', as_index=False).agg(aggregations)
    
    """
#%%
def candy_track_vet(dp):
    """
    use: vet paper with actual chg in mp, p, oi(iv only for live ticker)
    source:
    """
    df=dp.sort_values('date')
    col_val=['mp_i_chg_pct','p_i_chg_pct', 'o_oi_i_chg', 'p_chg','iv_chg', 'ta']
    df=type_convert(df, col_val)
    con_l= df['bs']=='b'
    con_s= df['bs']=='s'
    con_c= df['type'].str[0]=='C'
    con_p= df['type'].str[0]=='P'
    con_mp_up= df['mp_i_chg_pct']>0
    con_p_i_up= df['p_i_chg_pct']>0
    con_o_oi_i_up= df['o_oi_i_chg']>0
    con_p_up= df['p_chg']>0
    con_iv_up= df['iv_chg']>0
    con_barg=df['mp_i_chg_pct']<-0.3
#t_vet & c_vet    
    con_lc=con_l & con_c
    con_sc= con_s & con_c
    con_lp= con_l & con_p
    con_sp= con_s & con_p
    
    df.loc[con_l & (df.mp_i_chg_pct>0), 't_mp']='1'
    df.loc[con_l & ~(df.mp_i_chg_pct>0), 't_mp']='0'
    df.loc[con_s & (df.mp_i_chg_pct<0), 't_mp']='1'
    df.loc[con_s & ~(df.mp_i_chg_pct<0), 't_mp']='0'
    
    df.loc[(con_lc | con_sp) & (df.p_i_chg_pct>0), 't_p']='1'
    df.loc[(con_lc | con_sp) & ~(df.p_i_chg_pct>0), 't_p']='0'
    df.loc[(con_sc | con_lp) & ( df.p_i_chg_pct<0), 't_p']='1'   
    df.loc[(con_sc | con_lp) & ~(df.p_i_chg_pct<0), 't_p']='0' 
    
    df.loc[df.o_oi_i_chg>0, 't_oi']='1'
    df.loc[~(df.o_oi_i_chg>0), 't_oi']='0'

    df[['t_mp','t_p','t_oi']]=df[['t_mp','t_p','t_oi']].fillna('')
    df['tv_poi']=df['t_p']+df['t_oi']
    
# c_vet
    df.loc[(con_lc | con_sp) & (df.p_chg>0), 'c_p']='1'
    df.loc[(con_lc | con_sp) & ~(df.p_chg>0), 'c_p']='0'
    df.loc[(con_sc | con_lp) & ( df.p_chg<0), 'c_p']='1'   
    df.loc[(con_sc | con_lp) & ~(df.p_chg<0), 'c_p']='0' 
   
    df.loc[con_l & (df.iv_chg>0), 'c_iv']='1'
    df.loc[con_l & ~(df.iv_chg>0), 'c_iv']='0'
    df.loc[con_s & (df.iv_chg>0), 'c_iv']='1'   
    df.loc[con_s & ~(df.iv_chg>0), 'c_iv']='0' 
    df[['c_p','c_iv']]=df[['c_p','c_iv']].fillna('')
    df['cv_piv']=df['c_p']+df['c_iv']  #+t['t_iv']  
    df.drop(['t_mp','t_p','t_oi', 'c_p','c_iv'], axis=1, inplace=True)                   
#vet    
    con_LC=con_l & con_mp_up & con_c &  (df['ta']>=0) & con_p_i_up  # & (con_p_up | con_iv_up)
    con_LP=con_l & con_mp_up & con_p &  (df['ta']<=0) & (~con_p_i_up)
    con_LC_barg=con_l & con_barg & con_c & con_p_i_up & con_o_oi_i_up & con_p_up & con_iv_up
    con_LP_barg=con_l & con_barg & con_p & (~con_p_i_up) & con_o_oi_i_up & (~con_p_up) & con_iv_up
    con_LC_rev= con_l & (~con_mp_up) & con_c & (df['ta']<=2) & (~con_p_i_up) & (~con_p_up) & (con_iv_up)
    con_LP_rev= con_l & (~con_mp_up) & con_p & (df['ta']>=2) & (con_p_i_up) & (con_p_up) & (~con_iv_up)    
    
    con_SC=con_s & (~con_mp_up) & con_c &  (df['ta']<=2) & (~con_p_i_up)
    con_SP=con_s & (~con_mp_up) & con_p &  (df['ta']>=2) & (con_p_i_up)    

#    for x in ['LC', 'LP', 'LC_barg', 'LP_barg', 'LC_rev', 'LP_rev', 'SC', 'SP']:
#        CON ='con_%s'%x
#        df.loc[CON, 'do']=x
    df.loc[con_LC, 'vet']='LC'
    df.loc[con_LP, 'vet']='LP'
    df.loc[con_LC_barg, 'vet']='LC_barg'
    df.loc[con_LP_barg, 'vet']='LP_barg'
    df.loc[con_LC_rev, 'vet']='LC_rev'
    df.loc[con_LP_rev, 'vet']='LP_rev'
    df.loc[con_SC, 'vet']='SC'    
    df.loc[con_SP, 'vet']='SP'   
#  decision 
   
    return df
#%%
def paper_vet_another_approach(dp):
    """
    use: vet paper with actual chg in mp, p, oi(iv only for live ticker)
    source:
    """
    df=dp.sort_values('date')
    col_val=['mp_i_chg_pct','p_i_chg_pct', 'o_oi_i_chg', 'p_chg','iv_chg']
    df=type_convert(df, col_val)
    con_l=df['bs']=='b'
    con_s=df['bs']=='s'
    con_c=df['type'].str[0]=='C'
    con_p=df['type'].str[0]=='P'

    con_lc=con_l & con_c
    con_sc= con_s & con_c
    con_lp= con_l & con_p
    con_sp= con_s & con_p
    
    df.loc[con_l & (df.mp_i_chg_pct>0), 't_mp']='1'
    df.loc[con_l & ~(df.mp_i_chg_pct>0), 't_mp']='0'
    df.loc[con_s & (df.mp_i_chg_pct<0), 't_mp']='1'
    df.loc[con_s & ~(df.mp_i_chg_pct<0), 't_mp']='0'
    
    df.loc[(con_lc | con_sp) & (df.p_i_chg_pct>0), 't_p']='1'
    df.loc[(con_lc | con_sp) & ~(df.p_i_chg_pct>0), 't_p']='0'
    df.loc[(con_sc | con_lp) & ( df.p_i_chg_pct<0), 't_p']='1'   
    df.loc[(con_sc | con_lp) & ~(df.p_i_chg_pct<0), 't_p']='0' 
    
    df.loc[df.o_oi_i_chg>0, 't_oi']='1'
    df.loc[~(df.o_oi_i_chg>0), 't_oi']='0'

    df[['t_mp','t_p','t_oi']]=df[['t_mp','t_p','t_oi']].fillna('')
    df['t_vet']=df['t_p']+df['t_oi']
    
# c_vet
    df.loc[(con_lc | con_sp) & (df.p_chg>0), 'c_p']='1'
    df.loc[(con_lc | con_sp) & ~(df.p_chg>0), 'c_p']='0'
    df.loc[(con_sc | con_lp) & ( df.p_chg<0), 'c_p']='1'   
    df.loc[(con_sc | con_lp) & ~(df.p_chg<0), 'c_p']='0' 
   
    df.loc[con_l & (df.iv_chg>0), 'c_iv']='1'
    df.loc[con_l & ~(df.iv_chg>0), 'c_iv']='0'
    df.loc[con_s & (df.iv_chg>0), 'c_iv']='1'   
    df.loc[con_s & ~(df.iv_chg>0), 'c_iv']='0' 
    df[['c_p','c_iv']]=df[['c_p','c_iv']].fillna('')
    df['c_vet']=df['c_p']+df['c_iv']  #+t['t_iv']  
    df.drop(['t_mp','t_p','t_oi', 'c_p','c_iv'], axis=1, inplace=True)
    
#  decision 
   
    return df
    

    




    

