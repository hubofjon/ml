# -*- coding: utf-8 -*-
"""
Created on Thu Feb  7 13:02:52 2019
@author: qli1
"""

import pandas as pd
import numpy as np
import datetime as datetime
import pandas_datareader.data as web
from pandas_datareader import data, wb
import sys, os
import sqlite3 as db
import pandas.io.sql as pd_sql
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec   
import warnings

from P_commons import read_sql, type_convert
pd.set_option('display.expand_frame_repr', False)
pd.options.display.float_format = '{:,.2f}'.format
warnings.filterwarnings("ignore")

dte_mins=[1, 5,20,60]
q_date=datetime.datetime(2019,4,12).date()

def atm():
    """
    USE: track p&l of each contract to assess ITM/OTM by dte(on trend or on depressed)
    source: tbl_bc_raw
    dest:
    """
    q_date=datetime.datetime(2019,4,12)
    df=read_sql("SELECT * FROM tbl_bc_raw" )
    df['tid']=df['ticker']+ '  '+ df['oexp_dt']+'  '+ df['strike'].astype(str)+df['type']
    df['date']=pd.to_datetime(df['date'])
    df['oexp_dt']=pd.to_datetime(df['oexp_dt'])
    df=type_convert(df, ['price','strike','dte', 'midpoint','last','vol','ba_pct'])
    df['prem']=df['midpoint']* df['vol']*100
    df['prem_p']=(df['midpoint']/df['price'])*df['vol']*100
    df['type']=df['type'].str.replace('Put','P').replace('Call','C')

    df.sort_values(['tid','date'], ascending=[True, False], inplace=True)
    # find repeated cont
    df=df[df.duplicated(['tid'], keep=False)]
    # un-expired
    con_exp=df['oexp_dt']<q_date
#    df.loc[~con_exp, 'op_dt']=q_date
    df.loc[con_exp, 'op_dt']=df.loc[con_exp, 'oexp_dt']
    dp=read_sql("select * from tbl_pv_all")
    dp['date']=pd.to_datetime(dp['date'])
    #avoid dupe
    dp.rename(columns={'date':'close_date'}, inplace=True)        
    du=df.merge(dp[['ticker','close_date','close']], left_on=['ticker','op_dt'],\
                right_on=['ticker','close_date'])

    du.loc[du.ba_pct>=0.5, 'bos']='B'
    du.loc[du.ba_pct<0.5, 'bos']='S'
#conditions    
    con_c=du['type']=='C'
    con_p=du['type']=='P'
    con_B=du.bos=='B'
    con_S=du.bos=='S'
#    con_B=du.bs=='b'
#    con_S=du.bs=='s'
    #define atm
    du.loc[con_c, 'atm']=du.loc[con_c,'price']/du.loc[con_c,'strike']-0.5
    du.loc[con_p, 'atm']=du.loc[con_p,'strike']/du.loc[con_p,'price']-0.5
    
    #define LONG, itm@oexp_dt, strike vs. close, measure actual move
    du.loc[con_c, 'itm']= du.loc[con_c,'close']- du.loc[con_c,'strike']
    du.loc[con_p, 'itm']=du.loc[con_p,'strike']-du.loc[con_p,'close'] 
    du['itm_s']=du['itm']/du['strike']
    du['itm_s_vol']=du['vol']* du['itm']/du['strike']
    con_itm=du['itm']>0
    
    #1:itm
    con_ibc=(con_itm) & con_B & con_c
    con_isc=(con_itm) & con_S & con_c
    con_ibp=(con_itm) & con_B & con_p
    con_isp=(con_itm) & con_S & con_p    
    
    con_obc=(~con_itm) & con_B & con_c
    con_obp=(~con_itm) & con_B & con_p
    con_osc=(~con_itm) & con_S & con_c
    con_osp=(~con_itm) & con_S & con_p
    
    con_ic=con_ibc | con_isc
    con_ip=con_ibp | con_isp    
    con_ob=con_obc | con_obp
    con_os=con_osc | con_osp    
    
    du.loc[con_ic,'pl']=(du.loc[con_ic,'close']-du.loc[con_ic,'strike']- du.loc[con_ic,'midpoint'])
    du.loc[con_ip,'pl']=du.loc[con_ip,'strike']-du.loc[con_ip,'close']- du.loc[con_ip,'midpoint']
    du.loc[con_ob,'pl']= 0 - du.loc[con_ob,'midpoint']
    du.loc[con_os,'pl']= du.loc[con_os,'midpoint']
    
    du['pl_p']=du['pl']/ du['price']
    du['pl_p_vol']=du['pl']*du['vol']/du['price']
    
    c1=datetime.datetime(2018,12,24)
    c2=
    con_mup=du.date>cut_date
    con_pl=du.pl>=0
    
    du['PL']=du['pl_p']
    
    pl_mup_c_B=du[con_mup & con_c & con_B].PL.sum()
    pl_mup_c_B_w=du[con_mup & con_c & con_B & con_pl].PL.sum()
    pl_mup_c_B_l=du[con_mup & con_c & con_B & (~con_pl)].PL.sum()
    pl_mup_c_B_hit=du[con_mup & con_c & con_B & con_pl].shape[0]/ \
                    du[con_mup & con_c & con_B].shape[0]
    
    pl_mup_c_S=du[con_mup & con_c & con_S].PL.sum()
    pl_mup_c_S_w=du[con_mup & con_c & con_S & con_pl].PL.sum()
    pl_mup_c_S_l=du[con_mup & con_c & con_S & (~con_pl)].PL.sum()
    pl_mup_c_S_hit=du[con_mup & con_c & con_S & con_pl].shape[0]/ \
                    du[con_mup & con_c & con_S].shape[0]
    
    pl_mup_p_B=du[con_mup & con_p & con_B].PL.sum()
    pl_mup_p_B_w=du[con_mup & con_p & con_B & con_pl].PL.sum()
    pl_mup_p_B_l=du[con_mup & con_p & con_B & (~con_pl)].PL.sum()
    pl_mup_p_B_hit=du[con_mup & con_p & con_B & con_pl].shape[0]/ \
                du[con_mup & con_p & con_B ].shape[0]
    
    pl_mup_p_S=du[con_mup & con_p & con_S].PL.sum()
    pl_mup_p_S_w=du[con_mup & con_p & con_S & con_pl].PL.sum()    
    pl_mup_p_S_l=du[con_mup & con_p & con_S & (~con_pl)].PL.sum()  
    pl_mup_p_S_hit=du[con_mup & con_p & con_S & con_pl].shape[0]/\
                du[con_mup & con_p & con_S].shape[0]
    
    print( 'mup_c_b:', pl_mup_c_B,  pl_mup_c_B_w,  pl_mup_c_B_l,pl_mup_c_B_hit, '\n', \
        'mup_c_s:', pl_mup_c_S, pl_mup_c_S_w, pl_mup_c_S_l, pl_mup_c_S_hit, '\n',\
        'mup_p_b:', pl_mup_p_B, pl_mup_p_B_w, pl_mup_p_B_l,pl_mup_p_B_hit, '\n', \
        'mup_p_s:', pl_mup_p_S, pl_mup_p_S_w, pl_mup_p_S_l,pl_mup_p_S_hit )
    

    
    
    col=['ticker','oexp_dt','strike','type','date','itm','vol','prem','prem_p','last','midpoint','ba_pct','price','close']
    return du
    
    
def sentis():
    """
    Use: unop_bc premium ratio corr to SP return in periods of 1, 5, 20, + 
    source: tbl_bc_raw, tbl_pv_etf, 
    dest:
    sub_f: senti
    """
    print("sentis started")
    dbc=read_sql("SELECT * FROM tbl_bc_raw" )
    dmc=read_sql("SELECT * FROM tbl_mc_raw" )
    dates=dbc.date.unique()
    dbc_grp=dbc.groupby('date')
#    dmc_grp=dmc.groupby('date')
    ds=pd.DataFrame()
    for d,g in dbc_grp:
        ds_tmp=senti(d, g)
        ds=pd.concat([ds, ds_tmp], axis=0)
    ds['date']=pd.to_datetime(ds['date'])
    dp=read_sql("SELECT * FROM tbl_pv_etf WHERE ticker='SPY'")
    dp['date']=pd.to_datetime(dp['date'])
    dp['rtn']=dp['close'].pct_change()
    dp['rtn_1']=dp['close'].pct_change().shift(1)
    dp['rtn_5']=dp['close'].pct_change().shift(5)
    dp['rtn_20']=dp['close'].pct_change().shift(20)
    dp=dp[dp.date.isin(ds.date)]
    df_sentis=pd.merge(ds, dp[['date','rtn','rtn_1','rtn_5', 'rtn_20','close']], on='date')
#    dsp=pd.merge(ds, dp[['date','rtn','rtn_log']].shift(1), on='date')
#SHIFT rtn one day forward to test predicting correlation 
    col_pr=['pr_CP', 'pr_cp', 'pr_bubr','pr_bcbp','pr_scsp','pr_sc', 'pr_sp']
    for d in dte_mins:
        df=df_sentis[df_sentis['dte_min']==d]
        corr=df[['pr_cp', 'pr_bubr','pr_bcbp', 'pr_scsp', 'pr_CP', 'pr_sc','pr_sp',\
            'rtn_1','rtn_5','rtn_20']].corr (method='pearson')
        con=(corr!=1) & (np.abs(corr)>0.5)
 #       corr=corr[con].fillna('')
        corr=corr[con][col_pr].iloc[7:,:]
        if corr.notnull().values.any():
            corr=corr[con].fillna('')
            print('\n corr_%s: \n'%d, corr )
    return df_sentis

def senti(q_date, df_grp):
    """
    Use:
    source:
    dest:
    sub_f: 
    """
    #q_date, df (without date columns), return ds@q_date

    p_min=10
    pct_c_min=70
    v_opt_min=1000
    
    #Filter for conviction    
    ds_data=[]
    for x in  np.arange(len(dte_mins)):
        #df muted at each iteration!
        df=df_grp.sort_values('ticker')  
        if x<= (len(dte_mins)-2):
            con_dte= (dte_mins[x]<= df['dte']) & (df['dte'] < dte_mins[x+1])
        else:
            con_dte= (dte_mins[x]<= df['dte'])
        con_p=df['price']>p_min  
        df=df[con_dte & con_p]
        df['prem']=df['last']* df['vol']
        con_c=(df['type'].str.upper()=='CALL')
        con_p=(df['type'].str.upper()=='PUT') 
        con_bc=(df['type'].str.upper()=='CALL') & (df['bs']=='b')
        con_sc=(df['type'].str.upper()=='CALL') & (df['bs']=='s')    
        con_bp=(df['type'].str.upper()=='PUT') & (df['bs']=='b')
        con_sp=(df['type'].str.upper()=='PUT') & (df['bs']=='s')   
        prem_c='{:.1f}'.format(df[con_c].prem.sum())
        prem_p='{:.1f}'.format(df[con_p].prem.sum())
        prem_bc='{:.1f}'.format(df[con_bc].prem.sum())
        prem_sc='{:.1f}'.format(df[con_sc].prem.sum())    
        prem_bp='{:.1f}'.format(df[con_bp].prem.sum())
        prem_sp='{:.1f}'.format(df[con_sp].prem.sum())      
        prem_bcsp=(float(prem_bc)+ float(prem_sp))
        prem_scbp=(float(prem_sc)+ float(prem_bp))  
        
        if float(prem_p)!=0:
            pr_CP= '{:.1f}'.format(float(prem_c)/float(prem_p))
        else:
            pr_CP=np.nan
            
        if (float(prem_bp) + float(prem_sp))!=0:
            pr_cp= '{:.1f}'.format(float((float(prem_bc)+ float(prem_sc))/(float(prem_bp) + float(prem_sp))))
        else:
            pr_cp=np.nan
            
        if float(prem_scbp) !=0:
            pr_bubr='{:.1f}'.format(float(float(prem_bcsp)/float(prem_scbp)))
        else:
            pr_bubr=np.nan
            
        if float(prem_bp) !=0:
            pr_bcbp='{:.1f}'.format(float(float(prem_bc)/float(prem_bp)))
        else:
            pr_bcbp=np.nan
            
        if float(prem_sp) !=0:
            pr_scsp='{:.1f}'.format(float(float(prem_sc)/float(prem_sp)))
        else:
            pr_scsp=np.nan
        
        if float(prem_c) !=0:
            pr_sc='{:.1f}'.format(float(float(prem_sc)/float(prem_c)))
        else:
            pr_sc=np.nan
            
        if float(prem_p) !=0:
            pr_sp='{:.1f}'.format(float(float(prem_sp)/float(prem_p)))
        else:
            pr_sp=np.nan
    #    pr_bcbp=(prem_bc/prem_bp).round(2)   
    
        date=q_date
        ds_tmp=[date, prem_bc, prem_sc, prem_bp, prem_sp, pr_cp, pr_bubr, \
                pr_bcbp, pr_scsp, dte_mins[x], prem_c, prem_p, pr_CP, pr_sc, pr_sp]
        ds_data.append(ds_tmp)
#    return bc_data
    ds_data=np.asarray(ds_data)
    ds_data=ds_data.transpose()
    ds_columns=['date','prem_bc', 'prem_sc', 'prem_bp', 'prem_sp', 'pr_cp', 'pr_bubr', \
        'pr_bcbp', 'pr_scsp','dte_min', 'prem_c','prem_p','pr_CP','pr_sc','pr_sp']
#    ds_bc=pd.DataFrame(bc_data, columns=bc_columns, index=np.arange(1))

    ds=pd.DataFrame(dict(zip(ds_columns, ds_data)), index=np.arange(len(dte_mins)))
    cols= ['prem_bc','prem_sc', 'prem_bp', 'prem_sp', 'pr_cp', 'pr_bubr',\
         'pr_bcbp', 'pr_scsp', 'dte_min','prem_c','prem_p','pr_CP', 'pr_sc','pr_sp']   
    ds=convert(ds, cols, 'float')
    return ds
    #mc
#    con_p_mc=dmc['p'].astype(float)> p_min
#    con_v_opt=dmc['v_opt'].astype(float)> v_opt_min
#    dmc=dmc[con_p_mc & con_v_opt]



def sentis_intel(df_sentis, q_date): 
#df =dsp , output of sentis(), intel@q_date
    col_pr=['pr_CP', 'pr_cp', 'pr_bubr','pr_bcbp','pr_scsp','pr_sc', 'pr_sp']
    col_prem=['prem_bc', 'prem_bp', 'prem_c', 'prem_p', 'prem_sc', 'prem_sp']
    #stat @q_date
    dx=df_sentis[df_sentis.date==q_date]
    dx.fillna(0, inplace=True)
    dx['bc_pct']=dx['prem_bc']/(dx['prem_bc'].sum())
    dx['sc_pct']=dx['prem_sc']/(dx['prem_sc'].sum())
    dx['bp_pct']=dx['prem_bp']/(dx['prem_bp'].sum())
    dx['sp_pct']=dx['prem_sp']/(dx['prem_sp'].sum())
    show=['dte_min', 'pr_CP', 'pr_cp', 'pr_bcbp', 'pr_bubr',  'pr_sc',\
       'pr_scsp', 'pr_sp', 'prem_bc', 'prem_bp', 'prem_c', 'prem_p', 'prem_sc',\
       'prem_sp', 'bc_pct', 'sc_pct', 'bp_pct', 'sp_pct']
    #s: Sum of dte_min=1, 5, 20, 60
    s=dx[col_prem].sum()
    s['pr_CP']=s['prem_c']/s['prem_p']
    s['pr_cp']=(s['prem_bc'] + s['prem_sc'])/(s['prem_bp'] + s['prem_sp'])
    s['pr_bubr']=(s['prem_bc'] + s['prem_sp'])/(s['prem_sc'] + s['prem_bp'])
    s['pr_bcbp']=s['prem_bc']/s['prem_bp']
    s['pr_scsp']=s['prem_sc']/s['prem_sp']
    s['pr_sc']=s['prem_sc']/s['prem_c']
    s['pr_sp']=s['prem_sp']/s['prem_p']
#    s['date']=q_date
#dx: df_sentis@q_date
#dy, dx+ row of sum
#    col_prem=['prem_bc', 'prem_bp', 'prem_c', 'prem_p', 'prem_sc','prem_sp']
    show=['dte_min']+col_pr+col_prem
    dy=dx.append(s, ignore_index=True)
#get describe stat by dte_min of whole dataset

    ds=pd.DataFrame()  #describe of dx
    dys=pd.DataFrame()
    for x in dte_mins:
        df=df_sentis[df_sentis.dte_min==x]
        ds_tmp=df[col_pr].describe()
        ds_tmp=ds_tmp.iloc[[4,6],:]
        ds_tmp['dte_min']=x
        ds=pd.concat([ds, ds_tmp], axis=0)

        dy_pr=dy[dy.dte_min==x][col_pr]
        dy_prem=dy[dy.dte_min==x][['dte_min'] + col_prem]
        con_25= dy_pr< ds_tmp.iloc[0]  #show only<25% or >75%
        con_75= dy_pr> ds_tmp.iloc[1]      
        con= (con_25 | con_75)
        dys_tmp=pd.concat([dy_pr[con], dy_prem], axis=1)
        dys=pd.concat([dys, dys_tmp], axis=0)
#    print(dx[show])
    dys.fillna('',inplace=True)
    pd.set_option('display.expand_frame_repr', False)
    print("%s, pr <25% or >75% :\n", dys[show])
    print("pr_describe:  \n", ds[['dte_min']+col_pr])
    pd.set_option('display.expand_frame_repr', True)
#    return ds
    

def convert(df, cols, type='float'):
    for x in cols:
        df[x]=df[x].astype(type)
    return df

def senti_mc():
    iv_chg_min=15
    pct_c_min=20
    pct_c_max=100- pct_c_min
    dm=read_sql("SELECT * FROM tbl_mc_raw")
    dm['iv_chg']=dm['iv_chg'].str.replace('%','')
    dm['iv_chg']=dm['iv_chg'].astype(float)  
    dm['p_chg']=dm['p_chg'].str.replace('%','')
    dm['p_chg']=dm['p_chg'].astype(float)
    
    dmg=dm.groupby('date')
    data=[]
    for n,g in dmg:
        data.append([n,g[g.pct_c>pct_c_max].shape[0]/g.shape[0], g[g.pct_c<pct_c_min].shape[0]/g.shape[0]])
    data=np.asarray(data)
    data=data.transpose()
    cols=['date','pct_c','pct_p']
    df=pd.DataFrame(dict(zip(cols,data)))
        
    df['pct_c']=df['pct_c'].astype(float)
    df['pct_p']=df['pct_p'].astype(float)
    df['pct_cp']=df['pct_c']/df['pct_p']
    df['c-p']=df['pct_c']-df['pct_p']
    
    dp=read_sql("SELECT * FROM tbl_pv_etf WHERE ticker='SPY'")
#    df.plot(x='date', y=['pct_c', 'pct_p'], kind='line', rot=90)
    df.plot(x='date', y=['pct_c', 'pct_p'], kind='line', rot=90)
