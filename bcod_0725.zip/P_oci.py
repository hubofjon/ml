# -*- coding: utf-8 -*-
"""
@author: jon
1.  get_mc
1a  get_mc_web
2   get_bc
2a  download_bc
3   get_iv
3a  get_iv_table
4   get_cid
4a  get_cid greeks
5   get_CONTRACT_oo
"""
import pandas as pd
import numpy as np
import datetime as datetime
import time
from P_commons import bdate, tbl_nodupe_append, get_profile, type_convert, reg_convert, read_sql, to_sql_replace, fmt_map
pd.options.display.float_format = '{:.2f}'.format
#from termcolor import colored
from timeit import default_timer as timer
from P_getdata import get_EARN, get_DIV, get_SI, get_RSI, get_FUN
#from R_plot import plot_base 
#from R_plot import plot_base
#from datetime import timedelta
from P_stat import stat_VIEW #stat_VIEW
from dateutil import parser
#from timeit import default_timer as timer
from termcolor import colored, cprint
import os

dir_eod='l:\\pycode\\eod'
path_driver="l:\\pycode\Github\chromedriver.exe"

#%%
def get_mc(q_date): 
    """
    use:
    ext_source: mc.com
    dest: tbl_mc_raw
    sub_f: get_unop_mc
    """
    print(" ------ chamerlain unop_mc starts ------")
    fm_last_earn_dt=60
    pages, mc_date=get_unop_mc()
    if mc_date !=q_date:
        print("mc_date not equal q_date")
        return
    #remove empty element
    pages=[x for x in pages if x]  
    df=pd.DataFrame(data=pages[1:], columns=pages[0], index=range(len(pages)-1))
    df.rename(columns={'Symbol':'ticker', 'Volume':'v_opt', 'Calls':'pct_c', \
           'Puts':'pct_p', 'Relative Volume':'v_pct', 'Price':'p',\
           '% Chg':'p_chg', 'Earnings':'earn_dt', 'Event':'event',\
           'IV':'iv', 'IV Chg':'iv_chg',
           '#Call Trades':'num_c', '#Put Trades':'num_p'}, inplace=True)
    df['v_pct']=df.v_pct.astype(float)
    df['p_chg_abs']=df.p_chg.str.replace("+","").str.replace("-","")\
        .str.replace("%","").astype(float)
    df['p_chg']=df.p_chg.str.replace("+","")\
        .str.replace("%","").astype(float)        
    df['iv_chg_abs']=  df.iv_chg.str.replace("+","").str.replace("-","")\
        .str.replace("%","").astype(float)
    df['iv_chg']=  df.iv_chg.str.replace("+","")\
        .str.replace("%","").astype(float)
    df['v_opt']=df['v_opt'].str.replace(",", "").astype(float)
    df['v_opt_avg']=df['v_opt']/df['v_pct']
    def rgx(val):
        import re
        evt=re.search('(\d{1,2}-\S{3}-\d{4})',val)
        if evt:
            return evt.group(0)
        else:
            return np.nan        
    df['event_dt']=df['event'].apply(rgx)
    #Filter outdated earn_dt from mc website   
    #deal with datetime type issue: earn_dt<q_date, but no more than 2mth old
    df['earn_dt']= pd.to_datetime(df['earn_dt'].str.split(' ').str[0])
    df['earn_dt'].fillna('2018-01-01', inplace=True)
    df['earn_dt']=pd.to_datetime(df['earn_dt'])
    try:
        con_earn_dt_1= df['earn_dt']<q_date
        con_earn_dt_2= (q_date -df['earn_dt'].dt.date)<datetime.timedelta(fm_last_earn_dt)
        con_earn_dt=con_earn_dt_1 & con_earn_dt_2 
        df.loc[con_earn_dt, 'earn_dt']=np.datetime64('NaT')    
    except:
        print(" --con_earn_dt type error --")
        pass
    df.sort_values(by=['v_pct','iv_chg_abs', 'p_chg_abs'], ascending=[False, True, True]
                ,axis=0, inplace=True)

    df['pct_c']=df['pct_c'].str.replace("%","").astype(float)
    df['date']=q_date
    df['iv']=df['iv'].astype(float) /100
    #datetime.datetime.strptime(mc_date, '%Y-%m-%d').date()
    df['date']=pd.to_datetime(df['date']).dt.date
    tbl_nodupe_append(q_date, df, 'tbl_mc_raw')    
    return df

#%%    
def get_bc(q_date): 
    """
    use: update with bc.csv @q_date
    ext_source: bc.csv
    dest: tbl_obc_raw
    """
    print("  ---- unop_bc_dev starts -----  ")
    bid_ask_mark=0.5  #mark b or s, label for agreessivness, i.e. sweeping
    
    path_eod=dir_eod
    path_eod=r"%s"%path_eod
    files=os.listdir(path_eod)
    f_unop=[f for f in files if f[:7]=='unusual']
    if len(f_unop)!=1:
        print("bc eod file not available or more than one file")
        return
    f_unop=f_unop[0]
    unop_date=f_unop[-14:-4]
    unop_date=parser.parse(unop_date).date()
    if unop_date!=q_date:
        print("upon_bc: bc_unop_csv not euqal to q_date")
        return
    df=pd.read_csv(os.path.join(path_eod, f_unop))
    #last row is text useless
    df.drop(df.index[-1], inplace=True) 
    df.columns=df.columns.str.lower()
    df.rename(columns={'symbol':'ticker', 'exp date':'oexp_dt', 'open int':'oi'\
            ,'volume':'ioc', 'vol/oi':'v_oi', 'time':'date', 'iv':'civ',\
            'price':'p','last':'iop'}, inplace=True)
        #    date_fmt="{:%m/%d/%y}".format(q_date)) -not working as %s converted dt to str already!!
    df['civ']=df['civ'].str.replace('%','')
    df['civ']=df['civ'].astype(float)/100
    df['date']=pd.to_datetime(df['date']).dt.date
    df['ba_pct']= (df['iop']-df['bid'])/(df['ask']-df['bid'])
    df.loc[df['ba_pct']>bid_ask_mark, 'bs']='b'
    df.loc[df['ba_pct']<(1-bid_ask_mark), 'bs']='s'
    df.loc[df['ba_pct']==(1-bid_ask_mark), 'bs']='n'
    oexp_dt=pd.to_datetime(df['oexp_dt']).dt.strftime('%y%m%d')
    strike=df['strike'].apply(lambda x: str(int(x *1000)).rjust(8,'0'))
    df['cid']=df.ticker+ '-' + oexp_dt+df['type'].str[:1]+strike
    df['atm']=np.abs(df['strike']/df['p']-1)
    df['bet']=(df['iop']*df['ioc']*100/1000).astype(int)
    df['iop_p']=df['iop']/df['p']
    df['tid']=df['cid']+ '-' + df['date'].apply(lambda x: x.strftime('%y%m%d'))
    tbl_nodupe_append(q_date, df, 'tbl_obc_raw')
    return df 


#%%
def get_mc_web():  # take max 5 pages from unop  url
    """
    use:
    source:
    dest: 
    #http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/
    """
    from lxml import html
    from selenium.webdriver.chrome.options import Options
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException
    from bs4 import BeautifulSoup
# parameters  
#    gecko="c:\\pycode\Github\chromedriver.exe"
#    path_driver="c:\\pycode\Github\chromedriver.exe"
#    path_user_data=r"C:\Users\jon\AppData\Local\Google\Chrome\User Data\Default"
#    path_plugin_overlay="c:\\pycode\Github\extension_1_0_7_overlay_remove.crx"
#    path_plugin_ad="c:\\pycode\Github\extension_1_13_8.crx"
#    page_max= 11
    u_name='freeofjon@gmail.com'
    u_pswd='kevin2008'
    url_login="https://marketchameleon.com/Account/Login"
    url_unop ="https://marketchameleon.com/Reports/UnusualOptionVolumeReport"
    chrome_options=Options()
    chrome_options.add_argument("--start-maximized")  #full screen
    driver=webdriver.Chrome(executable_path= path_driver, chrome_options=chrome_options)
#url_log_in
    driver.get(url_login)
    try:
        username=driver.find_element_by_xpath('//*[@id="UserName"]')
        password=driver.find_element_by_xpath('//*[@id="Password"]')
        username.send_keys(u_name)
        password.send_keys(u_pswd)
        submit=driver.find_element_by_xpath('//*[@id="site-body-inner"]/div/div[1]/form/div[3]/input')
        time.sleep(2) 
        submit.send_keys('\n')  
    except:
        return ("unop_mc login failed")
        pass  #if user login cache preserved    
        """
trying to get symov_history table
#    url='https://marketchameleon.com/Overview/wrk/DailyHistory/'
#    driver.get(url)
#    time.sleep(5)
#    html_pg=driver.page_source
#    soup=BeautifulSoup(html_pg, 'lxml')
#    aray=[]
#    lis=[]
#    table=soup.find("table",{"id":"symov_daily_history_tbl"})
#    for row in table.find_all('tr'):
#        for td_tags in row.find_all('td'):
#            x= td_tags.get_text()
#            lis.append(x)
#        aray.append(lis)
#        lis=[]
#    driver.close()
#    driver.quit()
#    return lis, aray
    """
#url_unop
    driver.get(url_unop)
    time.sleep(2)
    html_pg=driver.page_source
    soup=BeautifulSoup(html_pg, 'lxml')
    #find report date
    try:
        mc_date=soup.findAll("div",{"class":"report_as_of_time"})[0].text[13:]
    except: 
        mc_date=datetime.date.today().strftime("%Y-%m-%d")
    #find subtitle
    titles=[]
    subs=soup.find("tr",{"class":"sub_heading"})
    for th_tags in subs.find_all('th'):
        titles.append(th_tags.get_text())
    #find table contents
    table=soup.find("table",{"id":"opt_unusual_volume"})
    pages=[]
    pages.append(titles)   # APPEND whole list of subtile as first element
    aray=[]
    lis=[]
    for row in table.find_all('tr'):
        for td_tags in row.find_all('td'):
            x= td_tags.get_text()
            lis.append(x)
        aray.append(lis)
        lis=[]
    pages.extend(aray)
    nxt=driver.find_element_by_css_selector("a.paginate_button.next")
#    nxt_dis=driver.find_element_by_css_selector("a.paginate_button.next.disabled")
    page_num=0
    page_max=15
    nxt_dis=False
    while (nxt and page_num<page_max and (not nxt_dis)):
#        if page_num<10:
            try:
                nxt.send_keys(Keys.END)
            except:
                pass
    #        driver.execute_script("window.scrollTo(0,  document.body.scrollHeight);")
            time.sleep(2)
            try:
                nxt.click()
            except:
                driver.close()
                return pages, mc_date

            time.sleep(3)
            html=driver.page_source
            soup=BeautifulSoup(html, 'lxml')
            table=soup.find("table",{"id":"opt_unusual_volume"})
            aray=[]
            lis=[]
            for row in table.find_all('tr'):
                for td_tags in row.find_all('td'):
                    x= td_tags.get_text()
                    lis.append(x)
                aray.append(lis)
                lis=[]
            pages.extend(aray)
    #        next=driver.find_element_by_id("opt_unusual_volume_next")
            page_num+=1
            nxt=driver.find_element_by_css_selector("a.paginate_button.next")
            try:
                nxt_dis=driver.find_element_by_css_selector("a.paginate_button.next.disabled")
            except:
                pass
    driver.close()
    driver.quit()
    mc_date=parser.parse(mc_date).date()
    return pages, mc_date  


#%%
def get_iv(q_date):  
    """
    use: daily update tbl_iv for tbl_oc p&l
    ext_source: mc.com, get_iv_table()
    dest: tbl_iv
    #http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/
    """
# check if watch list need update
    div=read_sql("select * from tbl_iv")
    div=div[div.date==div.date.max()]
    l_iv=div.ticker.unique().tolist()
    doc=read_sql("select * from tbl_oc where exit_dt='N' " )
    doc=doc[~(doc['pid'].str[:1]=='U')]
    l_oc=doc.ticker.unique().tolist()
    watch_to_add=list(set(l_oc) - set(l_iv))
    watch_to_cut=list(set(l_iv) - set(l_oc))
    if len(watch_to_add)>0:
        print("get_IV: watchlist_to_add: ", watch_to_add)
        print("get_IV: watchlist_to_cut: ", watch_to_cut)
        MODE=input(" watchlist added? -- YES:  ")
      
        if MODE=='YES':
            pass
        else:
            return

    from lxml import html
    from selenium.webdriver.chrome.options import Options
    from selenium import webdriver
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException
    from selenium.webdriver.common.by import By
    from bs4 import BeautifulSoup
    import numpy as np
    import re
# parameters    
#    """
#    path_driver="c:\\pycode\Github\chromedriver.exe"
#    gecko="c:\\pycode\Github\chromedriver.exe"
#    path_user_data=r"C:\Users\jon\AppData\Local\Google\Chrome\User Data\Default"
#    path_plugin_overlay="c:\\pycode\Github\extension_1_0_7_overlay_remove.crx"
#    path_plugin_ad="c:\\pycode\Github\extension_1_13_8.crx"
#    page_max= 11
#    """
    u_name='freeofjon@gmail.com'
    u_pswd='kevin2008'
    url_login="https://marketchameleon.com/Account/Login"
    url_watchlist="https://marketchameleon.com/Account/Watchlists"
    chrome_options=Options()
    chrome_options.add_argument("--start-maximized")  #full screen
    driver=webdriver.Chrome(executable_path= path_driver, chrome_options=chrome_options)
    wait = WebDriverWait(driver, 10)
#url_log_in
    driver.get(url_login)
    try:
        username=driver.find_element_by_xpath('//*[@id="UserName"]')
        password=driver.find_element_by_xpath('//*[@id="Password"]')
        username.send_keys(u_name)
        password.send_keys(u_pswd)
        submit=driver.find_element_by_xpath('//*[@id="site-body-inner"]/div/div[1]/form/div[3]/input')
        time.sleep(2) 
        submit.send_keys('\n')  
    except:
        return ("unop_mc login failed")
        pass  #if user login cache preserved    
#url_unop
    driver.get(url_watchlist)
    ds=get_IV_table(driver)
    ds.rename(columns={'% Chg':'p_chg_pct','Chg':'p_chg', 'Div Amt':'div', 'Div Ex-Date':'div_dt',\
        'Div Yield': 'yld', 'Earnings':'earn_dt_mc', 'Industry':'ind', 'Last Price':'p',\
        'Market Cap':'mcap', 'Sector':'sec', 'Symbol':'ticker', 'Volume':'vol_stk'}, inplace=True)
    ds=ds[['p_chg_pct','p_chg', 'div', 'div_dt','yld', 'earn_dt_mc','ind', 'p',\
           'mcap', 'sec', 'ticker', 'vol_stk']]
    
    btn_option=driver.find_element_by_xpath('//*[@id="stockWatchlistMenu_Options"]')
    btn_option.click()
    do=get_IV_table(driver)
#    wait.until(EC.visibility_of_element_located_by_xpath("//*[contains(text(), 'Option Volume')]"))
    do.rename(columns={'1-Yr Volatility':'iv_1y', 'IV % Rank':'iv_rank', \
        'IV30 % Chg':'iv_chg_pct', 'IV30 Last':'iv',  'Open Interest':'oi',
       'Open Interest Put Pct':'oi_p_pct', 'Option Volume':'vol', 'Relative Volume':'vol_pct', \
       'Symbol':'ticker', '1-Day Volatility':'iv_d'}, inplace=True)
    df=ds.merge(do, on='ticker', how='outer')
    df['date']=q_date
# data processing
    col_dt=['earn_dt_mc','div_dt']
    pattern=r'\d{1,2}\-[A-Za-z]{3}'
    today=datetime.datetime.today()
    for c in col_dt:
        con_dt= ~(df[c]=='')
        for index, row in df[con_dt].iterrows():
            val=re.findall(pattern, row[c])
            val=datetime.datetime.strptime(val[0], '%d-%b' )
            if val.month < today.month:
                val_year=today.year+1
            else:
                val_year=today.year
            val=datetime.datetime(val_year, val.month, val.day).date()
            df.loc[index, c]=val
    
    col_val=['p', 'p_chg_pct', 'p_chg', 'vol_stk', 'iv_d', 'iv_1y', 'iv', 'iv_chg_pct',\
              'oi','oi_p_pct','vol']
    df=reg_convert(col_val, df)
    for x in [ 'iv_d', 'iv_1y', 'iv']:
        df[x]=df[x] * 0.01
    
    p_prev=df['p']-df['p_chg']
    iv_prev=df['iv']/(1+df['iv_chg_pct'])
    p_imp=p_prev *iv_prev*np.sqrt(1/252)
    df['spike_iv']=df['p_chg']/p_imp
    df['oi_p']=df['oi']*df['oi_p_pct']
    df['oi_c']=df['oi']* (1-df['oi_p_pct'])
    df['date']=pd.to_datetime(df['date']).dt.date
    tbl_nodupe_append(q_date, df, 'tbl_iv')
    driver.close()
    driver.quit() 
    return df
#%%
def get_iv_table(driver):
    time.sleep(5)
    row_header=driver.find_element_by_xpath('''//*[@id="watchlist_tbl_wrapper"]/div/div[3]/div/div[1]/div/table''')
    header=[]
    for h in row_header.find_elements_by_tag_name("th"):
        val=h.text.replace('\n',' ')          
        header.append(val)
    tbl_op=driver.find_element_by_xpath('//*[@id="watchlist_tbl"]')
    rows=tbl_op.find_elements_by_tag_name("tr")
    arry=[]
    cell=[]
    for r in rows:
        for c in r.find_elements_by_tag_name("td"):
            val=c.text           
            cell.append(val)
        arry.append(cell)
        cell=[]
    #assemble data
    arry=np.asarray(arry[1:])
    arry=np.transpose(arry)
    df=pd.DataFrame(dict(zip(header, arry)))
    return df
#%%
def download_bc():  # take max 5 pages from unop  url
    """
    use: download unop_bc raw spreadsheet
    source:
    dest: 
    #http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/
    """
    from lxml import html
    from selenium.webdriver.chrome.options import Options
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException
    u_name='boxofjon@yahoo.com'
    u_pswd='kevin2008'
    url_login="https://www.barchart.com/login"
    url_bc ="https://www.barchart.com/options/unusual-activity/stocks"
    chrome_options=Options()
    chrome_options.add_argument("--start-maximized")  #full screen
    driver=webdriver.Chrome(executable_path= path_driver, chrome_options=chrome_options)
#url_log_in
    driver.get(url_login)
    try:
#        username=driver.find_element_by_xpath('//*[@id="bc-login-form"]/div[1]/input')
#        password=driver.find_element_by_xpath('//*[@id="login-form-password"]')
        username=driver.find_element_by_xpath('//*[@id="bc-main-content-wrapper"]/div/div[2]/div[2]/div/div/div/div[2]/form/div[1]/input')
        password=driver.find_element_by_xpath('//*[@id="login-page-form-password"]')
        username.send_keys(u_name)
        password.send_keys(u_pswd)
#        submit=driver.find_element_by_xpath('//*[@id="bc-login-form"]/div[6]/button')
        submit=driver.find_element_by_xpath('//*[@id="bc-main-content-wrapper"]/div/div[2]/div[2]/div/div/div/div[2]/form/div[4]/button')
        time.sleep(2) 
        submit.send_keys('\n')  
    except:
        return ("download_bc login failed")
        pass  #if user login cache preserved    
        
    driver.get(url_bc)
    time.sleep(15)
    try:
        btn=driver.find_element_by_xpath('//*[@id="main-content-column"]/div/div[5]/div[2]/div[2]/a[4]')
        btn.click()
        time.sleep(15)
    except:
        print(" error btn_2 ")

    driver.close()
    driver.quit()  
    
#%%
class get_CONTRACT_oo():
    """
    use: get greeks from nasdaq
    argument: from tbl_c, expiry@datetime, 
    source:
    """
    def __init__(self, ticker, expiry='',  cp='', strike='' ):
       
        self.ticker=ticker
        self.expiry=expiry
        self.cp=cp
        self.strike=strike
        
    def get_greeks_oo(self):
        cp=self.cp.lower()
        strike=str(int(self.strike*1000)).rjust(8,'0')
        expiry=self.expiry.strftime('%y%m%d')
        contract=(expiry + self.cp + strike).upper()
        cid=self.ticker.upper()+contract
        url= 'https://www.nasdaq.com/symbol/{0}/option-chain/{1}-{0}-call'.format(self.ticker, contract)
            
        soup=get_soup(url)
        mkt_dt=soup.find('span', {"id":"qwidget_markettime"}).text
        oi=soup.find(text='Open Interest').findNext('span').text
        vol=soup.find(text='Volume').findNext('span').text
        close=soup.find(text='Last Sale').findNext('span').text
        close_prev=soup.find(text='Prev Close').findNext('span').text
        bid=soup.find(text='Bid').findNext('span').text
        ask=soup.find(text='Ask').findNext('span').text
        if cp=='c':
            color='yellow'
        else:
            color='white'
        id='%s-delta'%color
        delta=soup.find(id='%s-delta'%color).findNext('span').findNext('span').text
        theta=soup.find(id='%s-theta'%color).findNext('span').findNext('span').text        
        vega=soup.find(id='%s-vega'%color).findNext('span').findNext('span').text  
        gamma=soup.find(id='%s-gamma'%color).findNext('span').findNext('span').text
        
        keys=['mkt_dt','cid', 'ticker','expiry','strike','cp', 'bid','ask','close','close_prev', 'oi','vol','delta','theta','vega','gamma']
        vals=[mkt_dt, cid, self.ticker, self.expiry, strike, cp, bid, ask, close, close_prev, oi, vol, delta, theta, vega, gamma]
        return dict(zip(keys, vals))
#%%    
def get_cid(q_date, tbl=''):
    """
    use: for live ticker, update greeks to op_c/op_spec
    source: get_greeks(), tbl_oc, tbl_candy
    dest: op_c, op_spec
    """
    from P_get_opcidiv import get_gcid_reeks
    from datetime import timedelta
#    look_back=5
    print("update_op_CID: %s started"%tbl)
    start_time=timer()
    dt=read_sql("select * from tbl_oc where exit_dt ='N' ") 
    if tbl=='op_spec':
        do=read_sql("select * from tbl_candy where (watch IS NOT 'N')")
#        do.rename(columns={'date':'candy_dt'}, inplace=True)
        do['candy_dt']=pd.to_datetime(do['candy_dt'])
        p_date=q_date - timedelta(look_back)
        con_lookback=do.candy_dt > p_date
        con_t= do.ticker.isin(dt.ticker)
        do=do[con_lookback & (~con_t)]
        dt=do
    lis=[]
    fail=[]
    list_cid=dt.cid.unique()
    for cid in list_cid:       
        try:
            g=get_greeks(cid)  
            lis.append(g)
        except:
            fail.append(cid)
    if len(fail)>1:
        cprint("get_CID:%s,  get_greeks failed tickers: %s"%(tbl, fail),'red')
    df=pd.DataFrame(lis)
    df['o_dt']=pd.to_datetime(df['o_dt']).dt.date
    df['date']=q_date
    df['time']=datetime.datetime.now().strftime('%H:%M:%S')
    col_val=['p','bid','ask','sale','sale_prev', 'o_oi','o_vol','delta','theta','vega','gamma']
    df=reg_convert(col_val, df, 'float')
    if tbl=='op_spec':
        df['ticker']=df['cid'].str.split('-').str[0]

    tbl_nodupe_append(q_date, df, tbl)
    end_time=timer()
    print("time: ", end_time-start_time)
    return df
#%%
def get_cid_greeks(cid):
    from P_getdata import get_soup
#    type=type.lower()
#    strike=str(int(self.strike*1000)).rjust(8,'0')
#    expiry=self.expiry.strftime('%y%m%d')
#    contract=(expiry + self.cp + strike).upper()
#    cid=self.ticker.upper()+contract
    ticker=cid.split('-')[0]
    contract=cid.split('-')[1]
    url= 'https://www.nasdaq.com/symbol/{0}/option-chain/{1}-{0}-call'.format(ticker, contract)
        
    soup=get_soup(url)
    p=soup.find('div', {"id":"qwidget_lastsale"}).text
    p=p.replace('$','')
    o_dt=soup.find('span', {"id":"qwidget_markettime"}).text
    o_oi=soup.find(text='Open Interest').findNext('span').text
    o_vol=soup.find(text='Volume').findNext('span').text
    sale=soup.find(text='Last Sale').findNext('span').text
    sale_prev=soup.find(text='Prev Close').findNext('span').text
    bid=soup.find(text='Bid').findNext('span').text
    ask=soup.find(text='Ask').findNext('span').text
    if 'C' in contract.upper():
        color='yellow'
    else:
        color='white'
    delta=soup.find(id='%s-delta'%color).findNext('span').findNext('span').text
    theta=soup.find(id='%s-theta'%color).findNext('span').findNext('span').text        
    vega=soup.find(id='%s-vega'%color).findNext('span').findNext('span').text  
    gamma=soup.find(id='%s-gamma'%color).findNext('span').findNext('span').text
    
    keys=['cid','p','o_dt', 'bid','ask','sale','sale_prev', 'o_oi','o_vol','delta','theta','vega','gamma']
    vals=[cid, p, o_dt, bid, ask, sale, sale_prev, o_oi, o_vol, delta, theta, vega, gamma]
    return dict(zip(keys, vals))
#%%
def get_option_simple(ticker=''):
#ref: http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/
    from lxml import html
    from selenium.webdriver.chrome.options import Options
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException

    chrome_options=Options()
    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_0_7_overlay_remove.crx")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
    x=r"C:\Users\jon\AppData\Local\Google\Chrome\User Data\Default"
    chrome_options.add_argument("user-data-dir=%s"%x)
    url_1="https://marketchameleon.com/Overview/"+ticker
    url_2=url_1+"/OptionSummary/"
    url_3=url_1+"/StockPosts/"
    url_4=url_1+"/SymbolReview/"
    gecko="c:\\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="c:\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
#LOG IN
    url_0="https://marketchameleon.com/Account/Login"
#    driver.get(url_0)
#    time.sleep(4)
#    try:
#        ol=driver.find_element_by_class_name("register-flyer-close")
#        ol=driver.find_element
#        ol.click()
#    except:
#        print("no find flyer close")
#        pass
#    username = driver.find_element_by_id("UserName")
#    password = driver.find_element_by_id("Password")
#    username.send_keys("freeofjon@gmail.com")
#    password.send_keys("kevin2008")
#    submit=driver.find_element_by_xpath('//input[@class="site-login-control btn"]')
#    time.sleep(2)
#    submit.send_keys('\n')

#go to url_1
    driver.get(url_1)
    time.sleep(1)
    try:
        ol=driver.find_element_by_class_name("register-flyer-close")
        ol=driver.find_element
        ol.click()
    except:
        pass
    iv_30_rank=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[6]/span[2]').get_attribute('textContent')
    iv_30s=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[5]/span[2]').get_attribute('textContent')
    hv_1y=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[4]/span[2]').get_attribute('textContent')
    hv_22=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[3]/div[3]/span[2]').get_attribute('textContent')

    v_stk=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[2]/span[2]').get_attribute('textContent')
    v_stk_avg=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[3]/span[2]').get_attribute('textContent')
    v_opt=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[4]/span[2]').get_attribute('textContent')
    v_opt_avg=driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[2]/div[5]/span[2]').get_attribute('textContent')
    v_stk=v_stk.replace(",","")
    v_stk_avg=v_stk_avg.replace(",","")
    v_opt=v_opt.replace(",","")
    v_opt_avg=v_opt_avg.replace(",","")
    v_stk_pct='{:.1%}'.format(float(v_stk)/float( v_stk_avg))
    try:
        v_opt_pct='{:.1%}'.format(float(v_opt)/ float(v_opt_avg))
    except:  #v_op is zero
        pass
#    etf_o=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[1]/span/a').get_attribute('textContent')
#    corr_etf=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[4]').get_attribute('textContent')
#    p_chg_etf=driver.find_element_by_xpath('//*[@id="mkt_corr_tbl"]/tbody/tr[1]/td[7]/span').get_attribute('textContent')
#    p_chg=driver.find_element_by_xpath('//*[@id="sym_heading_top"]/div[1]/div[2]/div[2]/p[3]').get_attribute('textContent')
#    p=driver.find_element_by_xpath('//*[@id="overview_last_price"]').get_attribute('textContent')
#    earn_date= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[4]/span[2]').get_attribute('textContent')
    ex_div= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[2]/span[2]').get_attribute('textContent')
    yld= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[3]/span[2]').get_attribute('textContent')
#    pe= driver.find_element_by_xpath('//*[@id="symov_main_sidebar"]/div[1]/div[4]/div[5]/span[2]').get_attribute('textContent')
    iv_30=float(iv_30s.split(" ")[0])
    iv_30_chg=float(iv_30s.split(" ")[1])
    iv_30_chg='{:.1%}'.format(iv_30_chg/ iv_30)
    iv_30_rank=iv_30_rank.split(" ")[0]
    iv_hv=float(iv_30)/float(hv_22)
    hv_rank=float(hv_22)/float(hv_1y)

#go to url_2: option summary for call, put volume
    driver.get(url_2)
    time.sleep(1)
    try:
        ol=driver.find_element_by_class_name("register-flyer-close")
        ol=driver.find_element
        ol.click()
    except:
        pass
    v_c= driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[6]').get_attribute('textContent')
    v_p= driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[7]').get_attribute('textContent')
    oi_c= driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[8]').get_attribute('textContent')
    oi_p= driver.find_element_by_xpath('//*[@id="option_summary_MainTotal"]/tbody/tr/td[9]').get_attribute('textContent')
    v_c=float(v_c.replace(",", ""))
    v_p=float(v_p.replace(",", ""))
    oi_c=float(oi_c.replace(",", ""))
    oi_p=float(oi_p.replace(",", ""))
    pcr_v=v_p/ v_c
    pcr_oi=oi_p/ oi_c #avoid division by zero
    names=['iv_30', 'iv_30_rank', 'iv_hv', 'hv_1y', 'hv_22', 'hv_rank',   \
        'v_stk', 'v_stk_avg', 'v_opt', 'v_opt_avg', 'v_stk_pct','v_opt_pct', \
        'ex_div', 'yld', 'pcr_v', 'pcr_oi']
    values=[iv_30, iv_30_rank, iv_hv,  hv_1y, hv_22, hv_rank,\
            v_stk, v_stk_avg, v_opt, v_opt_avg, v_stk_pct, v_opt_pct, \
       ex_div, yld, pcr_v, pcr_oi]
    do=pd.DataFrame(data=[], columns=names)
    do.loc[0,names]=values
    do['ticker']=ticker
    driver.quit()
#    driver.close
    return do    
 



# =============================================================================
# critical selenium source
# 1. selenium + ajax table
# https://www.guru99.com/handling-dynamic-selenium-webdriver.html
# 2.youtubeWaits: Selenium and Python 3
# https://www.youtube.com/watch?v=Ho7zzgfh4bQ&list=PLCDERj-IUIFA4nAWEsV0xAvGFEzqDpXrR&index=6&t=0s
# 3. barchart api simular header
# https://stackoverflow.com/questions/55006553/scraping-an-ajax-web-page-using-python-and-requestshttps://stackoverflow.com/questions/55006553/scraping-an-ajax-web-page-using-python-and-requests
# 4. datatbale allinone
# https://datatables.net/manual/tech-notes/1
#    4. webdriver
 #   https://www.guru99.com/accessing-forms-in-webdriver.html
# =============================================================================
