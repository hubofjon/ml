# -*- coding: utf-8 -*-
"""
Created on Fri Sep 20 14:52:59 2019

@author: qli1
"""

def get_cid_greeks_api_bc(cid, q_date):
    from suds.client import Client
    import requests
    import json
    ondemand = Client('https://ondemand.websol.barchart.com/service?wsdl')
    
    url_api_act= "http://ondemand.websol.barchart.com/getAccountDetails.json?clientkey=d6a2c6fb3486fef3d8abdb157a384d76"
    
    
#    url_sample="http://ondemand.websol.barchart.com/getEquityOptions.csv?apikey=d6a2c6fb3486fef3d8abdb157a384d76\
#        &underlying_symbols=IBM&fields=volatility,delta,gamma,theta,vega,rho,bid,bidSize,bidDate,ask,askSize,askDate,\
#        premium,settlement,lastTradeDate,openInterest"
        
    api_key_bc="d6a2c6fb3486fef3d8abdb157a384d76"
    vals="volatility,delta,gamma,theta,vega,rho,bid,bidSize,bidDate,ask,askSize,askDate,\
        premium,settlement,lastTradeDate,openInterest"
    vals_extra="last,previous,change,volume, settlement, flag, premium"
    vals_api=vals + vals_extra
    cid_api=cid.replace('-','')
    ticker=cid.split('-')[0]
    
    url_api="http://ondemand.websol.barchart.com/getEquityOptions.json?apikey={0}\
        &underlying_symbols={1}&fields={2}".format(api_key_bc, ticker, vals_api )
        
    url_api_cid="https://ondemand.websol.barchart.com/getEquityOptions.json?apikey={0}&symbols={1}".formate(api_key_bc, cid)
#    result = client.service.getEquityOptions({0}, {1}, {2}, {3}, {4}, 'bid,bidSize,ask,askSize', '1')\
#        .format(api_key_bc, ticker, type, strike, expiry )
    resp = requests.get(url=url_api_cid)
    data = resp.json()   
    
    print (data)