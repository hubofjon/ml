# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 11:13:46 2017
"""
import pandas as pd
#from pandas.tseries.offsets import BDay
import warnings
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
from P_commons import read_sql, to_sql_append, to_sql_replace, bdate, backup_db
from P_update_price import update_pv_eod, update_price_eod, download_eod
from P_stat import stat_run_base, stat_VIEW, stat_PLOT, etf_corr, sec_leadlag, sec_sharpe
from P_getdata import get_NEWS, get_response
from P_oci import download_bc, get_bc, get_mc, get_cid, get_iv, watchlist_ready 
from P_candy import candy_intel, candy_update, candy_track
from P_track import reports, tbl_cid_update, CID_pl_attr, cid_sanity_check
from R_plot import plot_base, plot_QI
from R_senti import sentis, sentis_intel, senti_mc
import datetime
from P_track_pid import preports,  ptbl_cid_update, pCID_pl_attr

run_date=bdate()
position_list=read_sql("select * from tbl_oc WHERE exit_dt =='N' and oexp_dt>='%s' \
                AND substr(pid,1,1)<>'U'"%run_date).ticker.unique()

extreme_list=['DBA','TLT']
long_test=['GPRE','PETS','NTNX']
short_test=['NXPI']
bet=['AMBC','BMRN']
spec=['CRM','NGL']


#run_date=datetime.date(2019, 4, 18)
MODE=input(" - copy db? tbl_oc entry? -- optionor EOD?  option/EOD:  ")
    
if MODE=='EOD':
#    backup_db()
#   get_response()
#    download_eod()
    print(" ---- STARTS %s ----"%run_date)
    update_pv_eod('etf', run_date)  #  since jun 2018
    update_pv_eod('sp500',run_date) 
    update_pv_eod('all', run_date)
    update_price_eod('etf', run_date) # since 2013
    update_price_eod('sp500', run_date)
    
    print("-----positions ----")
#    
    ds_sec=stat_run_base(run_date, 'sec')    
    ds_sp=stat_run_base(run_date, 'sp500')
    ds_etf=stat_run_base(run_date, 'etf_all')
    df_stat=stat_VIEW(run_date) 
    stat_PLOT(run_date) 
    
    download_bc(run_date)
#    download_bc(run_date, 'stocks')
#    download_bc(run_date, 'etfs')    
    bc=get_bc(run_date)   
    mc=get_mc(run_date)
    
    candy=candy_intel(run_date)  #today
    
    op_spec=get_cid(run_date, 'op_spec')
    du=candy_update(run_date)
    dk=candy_track(run_date)

    op_c=get_cid(run_date, 'op_c')
    du=ptbl_cid_update(run_date, 'cid')
#    du= tbl_cid_update(run_date)
    div=get_iv(run_date)
    dpl=pCID_pl_attr(run_date, 'cid')
#     dpl=CID_pl_attr(run_date)    
 
# report_pid_trial
    acid=ptbl_cid_update(run_date, 'acid')    
    apid=ptbl_cid_update(run_date, 'apid')   
    bpid=ptbl_cid_update(run_date, 'bpid')   
    
    pacid=pCID_pl_attr(run_date, 'acid')
    pacid=pCID_pl_attr(run_date, 'apid')    
    pacid=pCID_pl_attr(run_date, 'bpid')
    
    
    plot_QI()
    plot_base(run_date, position_list)    
#    preports(run_date)
#    mp_track(run_date)
#    get_NEWS(position_list)
#  
#    df_sentis=sentis()
#    sentis_intel(df_sentis, run_date)
#    senti_mc()
#    etf_corr()
#    sec_sharpe()
#    sec_leadlag(run_date)
#    
#    spec_track(run_date)
#    df_track=track_raw(run_date)
"""
to do
1. money flow : http://www.wsj.com/mdc/public/page/2_3022-mfsctrscan-moneyflow-20190104.html?mod=mdc_pastcalendar
2. asset overview https://www.wsj.com/graphics/track-the-markets/?mod=topnav_2_3022
3. https://www.quantopian.com/posts/measuring-money-flows
4. https://www.ici.org/research/stats/flows/ltflows/flows_04_17_19
5.https://github.com/six519/pyoptionchain/blob/master/pyoptionchain/google_api.py
6.https://www.quantconnect.com/data/tree
7.http://www.quantmod.com/
8.https://github.com/gyanesh-m/Sentiment-analysis-of-financial-news-data
9.https://github.com/eliangcs/pystock-data

READ_HTML
https://beenje.github.io/blog/posts/parsing-html-tables-in-python-with-pandas/
https://stackoverflow.com/questions/25062365/python-parsing-html-table-generated-by-javascript
!!REQUEST+JAVASCRI[T
http://theautomatic.net/2019/01/19/scraping-data-from-javascript-webpage-python/]
readlist : http://theautomatic.net/recommended-reading-list/
# -----------------------------------------------  #
#mutable funcion https://docs.python.org/3/faq/programming.html#how-do-i-write-a-function-with-output-parameters-call-by-reference
#https://stackoverflow.com/questions/38895768/python-pandas-dataframe-# to_do:

pre-spec
"earning_pattern: https://marketchameleon.com/Overview/CCK/Earnings/Earnings-Charts"
option insight:
OI/IV chg:     https://marketchameleon.com/Overview/CCK/OpenInterestTrends/
eARN pattern,
#past 30 days option iv, volume data (jsp table)
https://marketchameleon.com/Overview/CCK/DailyHistory/
#json.dumps(), loads() to store dictionary into table
for earn_history, fun_bc tables
selenium python
https://selenium-python.readthedocs.io/
https://github.com/calebpollman/web-scraping-parallel-processing/blob/master/script.py

NEXT TO DO:
1. FOR SPEC; past 1 month IV chg, and option vol. status
https://marketchameleon.com/Overview/SGMS/DailyHistory/  
2. o_spec rolling slider
3. candy_track, update stat_view (fm_50,200 etc)

TIP:
    %reset can clear all variable in ipytho
"""