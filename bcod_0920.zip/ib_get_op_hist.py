# -*- coding: utf-8 -*-
"""
Created on Wed Sep 18 14:42:06 2019

@author: qli1
"""

# get historical contract
from ib.ext.Contract import Contract
from ib.ext.ContractDetails import ContractDetails
from ib.opt import ibConnection, message
import time
import datetime

def watcher(msg):
    print(msg)

def contractDetailsHandler(msg):
    contracts.append(msg.contractDetails.m_summary)

def contractDetailsEndHandler(msg):
    global DataWait
    DataWait =  False

def contractHistDetailsHandler(msg):
    contracts.append(msg.contractDetails.m_summary)


con = ibConnection()
con.host = "..."
con.port = ...
con.clientId = 5
con.registerAll(watcher)
con.register(contractDetailsHandler, 'ContractDetails')
con.register(contractDetailsEndHandler, 'ContractDetailsEnd')
con.register(contractHistDetailsHandler, message.historicalData)

con.connect()

contract = Contract()
contract.m_exchange     = "SMART"
contract.m_secType      = "OPT"
contract.m_symbol       = "SPY"
contract.m_currency     = "USD"
contract.m_strike = 230
contract.m_right = "CALL"


endtime = '20170102 01:00:00'

#con.reqContractDetails(1, contract)

con.reqHistoricalData(2,contract,endtime,"5 M","1 sec","TRADES",0,1)
con.reqHistoricalData(3,contract,endtime,"5 M","1 sec","MIDPOINT",0,1)

contracts = []

DataWait = True  ;  i = 0
while DataWait and i < 90:
    i += 1 ; print(i),
    time.sleep(1)

con.disconnect()
con.close()

print(contracts)