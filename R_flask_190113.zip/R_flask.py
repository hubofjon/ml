# -*- coding: utf-8 -*-
from flask import Flask, request, render_template, url_for, redirect, session, flash, g
import os
import sqlite3
import pandas.io.sql as pd_sql

host = os.getenv("IP", "127.0.0.1")
port = int(os.getenv("PORT", "8080"))

# configuration details
#DATABASE = "C:\\Users\qli1\BNS_wspace\flask\f_trd\trd.db"
#DATABASE = "C:\\pycode\db_op_20170907"
SECRET_KEY = "my_secret"

app = Flask(__name__)
app.config.from_object(__name__) # pulls in app configuration by looking for uppercase variables

def connect_db():
#    return sqlite3.connect(app.config["C:\Users\qli1\BNS_wspace\flask\f_books\books.db"])
    connect=sqlite3.connect(r"C:\pycode\db_op.db")
    return connect
    
@app.route("/trd_main")
def trd_main():
    # create connection to db
    g.db = connect_db()
    trades = []
    df=pd_sql.read_sql("SELECT * FROM tbl_c", g.db)
    for index, row in df.iterrows():  #"trd_id":df.index.values[index],
        trades.append({ "ticker":df.loc[index,'ticker'],  "mp":df.loc[index,'mp'], \
            "note":df.loc[index,'note'],"exp_dt":df.loc[index,'exp_dt'],"earn_dt":df.loc[index,'earn_dt'],\
            "div_dt":df.loc[index,'div_dt'],\
            "exit_dt":df.loc[index,'exit_dt'],"tgt_dt":df.loc[index,'tgt_dt'],"tgt_p":df.loc[index,'tgt_p'],\
            "ic1":df.loc[index,'ic1'],"ip1":df.loc[index,'ip1'],"ic2":df.loc[index,'ic2'],"ip2":df.loc[index,'ip2'],\
            "comm":df.loc[index,'comm'],\
            "oc1":df.loc[index,'oc1'],"op1":df.loc[index,'op1'],"oc2":df.loc[index,'oc2'],"op2":df.loc[index,'op2'] })
    # pass books data to our template for use
    return render_template("trd_main.html", trades=trades)

# edit route
@app.route("/trd_edit", methods=["GET", "POST"])
def trd_edit():
    msg = ""
    # get query string arguments
    ticker = request.args.get("ticker")
    tgt_dt = request.args.get("tgt_dt")
    exit_dt = request.args.get("exit_dt")
    mp = request.args.get("mp")
    note = request.args.get("note")
    exp_dt = request.args.get("exp_dt")
    earn_dt = request.args.get("earn_dt")
    div_dt = request.args.get("div_dt")    
    tgt_p = request.args.get("tgt_p")
    ic1 = request.args.get("ic1")
    ip1 = request.args.get("ip1")
    ic2 = request.args.get("ic2")
    ip2 = request.args.get("ip2")
    comm = request.args.get("comm")
    oc1 = request.args.get("oc1")
    op1 = request.args.get("op1")
    oc2 = request.args.get("oc2")
    op2 = request.args.get("op2")
    
    trd = {
#        "trd_id": trd_id,
        "ticker":ticker,
        "tgt_dt":tgt_dt,
        "exit_dt":exit_dt,
        "mp":mp,
        "note":note,
        "exp_dt":exp_dt,
        "earn_dt":earn_dt,
        "div_dt":div_dt,
        "tgt_p":tgt_p,
        "ic1":ic1,
        "ip1":ip1,
        "ic2":ic2,
        "ip2":ip2,
        "comm":comm,
        "oc1":oc1,
        "op1":op1,
        "oc2":oc2,
        "op2":op2        
    }
    
    if request.method == "POST":
        # get the data from form
 #       trd_id = request.form["trd_id"]
        ticker = request.form["ticker"]
        tgt_dt = request.form["tgt_dt"]
        exit_dt = request.form["exit_dt"]
        mp = request.form["mp"]
        note = request.form["note"]
        exp_dt = request.form["exp_dt"]
        earn_dt = request.form["earn_dt"]
        div_dt = request.form["div_dt"]
        tgt_p= request.form["tgt_p"]
        ic1 = request.form["ic1"]
        ip1 = request.form["ip1"]
        ic2 = request.form["ic2"]
        ip2 = request.form["ip2"]
        comm= request.form["comm"]
        oc1 = request.form["oc1"]
        op1 = request.form["op1"]
        oc2 = request.form["oc2"]
        op2 = request.form["op2"]
        # connect db and update record
        g.conn = connect_db()
        cursor = g.conn.cursor()
        cursor.execute("UPDATE tbl_c SET ticker=?, tgt_dt=?, exit_dt=?, mp=?, tgt_p=?\
                       ,note=?, exp_dt=?, earn_dt=?, div_dt=?\
                       ,ic1=?, ip1=?, ic2=?, ip2=?, comm=?,oc1=?, op1=?, oc2=?, op2=? \
                       WHERE ticker=?", (ticker, tgt_dt, exit_dt, mp, tgt_p, note, exp_dt, earn_dt, div_dt, \
                       ic1, ip1, ic2, ip2, comm, oc1, op1, oc2, op2, ticker))
        g.conn.commit()
        g.conn.close()
        trd = {
   #         "trd_id": trd_id,
            "ticker":ticker,
            "tgt_dt":tgt_dt,
            "exit_dt":exit_dt,
            "mp":mp,
            "note":note,
            "exp_dt":exp_dt,
            "earn_dt":earn_dt,
            "div_dt":div_dt,
            "tgt_p":tgt_p,
            "ic1":ic1,
            "ip1":ip1,
            "ic2":ic2,
            "ip2":ip2,
            "comm":comm,
            "oc1":oc1,
            "op1":op1,
            "oc2":oc2,
            "op2":op2             
        }
        msg = "tbl_c successfully updated!"
    return render_template('trd_edit.html', t=trd, message=msg)

# add menu to tbl_spec_candy
@app.route("/spec_main")
def spec_main():
    # create connection to db
    g.db = connect_db()
    specs = []
    df=pd_sql.read_sql("SELECT * FROM tbl_spec_candy", g.db)
    for index, row in df.iterrows():  #"trd_id":df.index.values[index],
        specs.append({ "ticker":df.loc[index,'ticker'],  "date":df.loc[index,'date'], \
            "note":df.loc[index,'note'],"lsn":df.loc[index,'lsn'],"bet":df.loc[index,'bet']})
    # pass books data to our template for use
    return render_template("spec_main.html", specs=specs)

# spec_edit route
@app.route("/spec_edit", methods=["GET", "POST"])
def spec_edit():
    msg = ""
    # get query string arguments
    ticker = request.args.get("ticker")
    date = request.args.get("date")
    note = request.args.get("note")
    lsn = request.args.get("lsn")
    bet = request.args.get("bet")
    
    spec = {
#        "trd_id": trd_id,
        "ticker":ticker,
        "date":date,
        "note":note,
        "lsn":lsn,
        "bet":bet
    }
    
    if request.method == "POST":
        # get the data from form
 #       trd_id = request.form["trd_id"]
        ticker = request.form["ticker"]
        date = request.form["date"]
        note = request.form["note"]
        lsn = request.form["lsn"]
        bet = request.form["bet"]

        # connect db and update record
        g.conn = connect_db()
        cursor = g.conn.cursor()
        cursor.execute("UPDATE tbl_spec_candy SET ticker=?, date=?, note=?, lsn=?, bet=?\
                       WHERE ticker=?", (ticker, date, note, lsn, bet, ticker))
        g.conn.commit()
        g.conn.close()
        spec = {
   #         "trd_id": trd_id,
            "ticker":ticker,
            "date":date,
            "note":note,
            "lsn":lsn,
            "bet":bet
        
        }
        msg = "tbl_spec_candy successfully updated!"
    return render_template('spec_edit.html', t=spec, message=msg)

# add menu to tbl_trd_candy
@app.route("/candy_main")
def candy_main():
    # create connection to db
    g.db = connect_db()
    candy = []
    df=pd_sql.read_sql("SELECT * FROM tbl_trade_candy", g.db)
    for index, row in df.iterrows():  #"trd_id":df.index.values[index],
        candy.append({ \
        "act":df.loc[index, 'act'], "entry_dt":df.loc[index, 'entry_dt'], "ticker":df.loc[index, 'ticker']\
        , "note":df.loc[index, 'note'], "term":df.loc[index, 'term'], "play":df.loc[index, 'play']\
        , "bedn":df.loc[index, 'bedn'], "beup":df.loc[index, 'beup'], "comm":df.loc[index, 'comm']\
        , "div_dt":df.loc[index, 'div_dt'], "earn_dt":df.loc[index, 'earn_dt'], \
        "exp_dt":df.loc[index, 'exp_dt'], "entry_p":df.loc[index, 'entry_p'], "ic1":df.loc[index, 'ic1']\
        , "iiv":df.loc[index, 'iiv'], "ip1":df.loc[index, 'ip1'], "strike":df.loc[index, 'strike']\
        , "tgt_dt":df.loc[index, 'tgt_dt'], "tgt_p":df.loc[index, 'tgt_p']\
            })
    # pass books data to our template for use
    return render_template("candy_main.html", candy=candy)

# candy_edit route
@app.route("/candy_edit", methods=["GET", "POST"])
def candy_edit():
    msg = ""
    # get query string arguments
    ticker = request.args.get("ticker")
    act = request.args.get("act")
    entry_dt = request.args.get("entry_dt")
    ticker = request.args.get("ticker")
    note = request.args.get("note")
    term = request.args.get("term")
    play = request.args.get("play")
    bedn = request.args.get("bedn")
    beup = request.args.get("beup")
    comm = request.args.get("comm")
    div_dt = request.args.get("div_dt")
    earn_dt = request.args.get("earn_dt")
    exp_dt = request.args.get("exp_dt")
    entry_p = request.args.get("entry_p")
    ic1 = request.args.get("ic1")
    iiv = request.args.get("iiv")
    ip1 = request.args.get("ip1")
    strike = request.args.get("strike")
    tgt_dt = request.args.get("tgt_dt")
    tgt_p = request.args.get("tgt_p")

    
    candy = {
#        "trd_id": trd_id,
    "ticker":ticker,
    "act":act,
    "entry_dt":entry_dt,
    "ticker":ticker,
    "note":note,
    "term":term,
    "play":play,
    "bedn":bedn,
    "beup":beup,
    "comm":comm,
    "div_dt":div_dt,
    "earn_dt":earn_dt,
    "exp_dt":exp_dt,
    "entry_p":entry_p,
    "ic1":ic1,
    "iiv":iiv,
    "ip1":ip1,
    "strike":strike,
    "tgt_dt":tgt_dt,
    "tgt_p":tgt_p
    }
    
    if request.method == "POST":
        # get the data from form
 #       trd_id = request.form["trd_id"]
        ticker = request.form["ticker"]
        act = request.form["act"]
        entry_dt = request.form["entry_dt"]
        ticker = request.form["ticker"]
        note = request.form["note"]
        term = request.form["term"]
        play = request.form["play"]
        bedn = request.form["bedn"]
        beup = request.form["beup"]
        comm = request.form["comm"]
        div_dt = request.form["div_dt"]
        earn_dt = request.form["earn_dt"]
        exp_dt = request.form["exp_dt"]
        entry_p = request.form["entry_p"]
        ic1 = request.form["ic1"]
        iiv = request.form["iiv"]
        ip1 = request.form["ip1"]
        strike = request.form["strike"]
        tgt_dt = request.form["tgt_dt"]
        tgt_p = request.form["tgt_p"]


        # connect db and update record
        g.conn = connect_db()
        cursor = g.conn.cursor()
        cursor.execute("UPDATE tbl_spec_candy SET ticker=?,act=?,entry_dt=?,ticker=?,note=?,term=?,\
                       play=?,bedn=?,beup=?,comm=?,div_dt=?,earn_dt=?,exp_dt=?,entry_p=?,ic1=?,iiv=?,\
                       ip1=?,strike=?,tgt_dt=?,tgt_p=?\
                       WHERE ticker=?", (ticker,act,entry_dt,ticker,note,term,play,bedn,beup,comm,\
                           div_dt,earn_dt,exp_dt,entry_p,ic1,iiv,ip1,strike,tgt_dt,tgt_p ))
        g.conn.commit()
        g.conn.close()
    candy = {
#        "trd_id": trd_id,
        "ticker":ticker,
        "act":act,
        "entry_dt":entry_dt,
        "ticker":ticker,
        "note":note,
        "term":term,
        "play":play,
        "bedn":bedn,
        "beup":beup,
        "comm":comm,
        "div_dt":div_dt,
        "earn_dt":earn_dt,
        "exp_dt":exp_dt,
        "entry_p":entry_p,
        "ic1":ic1,
        "iiv":iiv,
        "ip1":ip1,
        "strike":strike,
        "tgt_dt":tgt_dt,
        "tgt_p":tgt_p
        }
    msg = "tbl_trade_candy successfully updated!"
    return render_template('candy_edit.html', t=candy, message=msg)

    
if __name__ == "__main__":
    app.run(host=host, port=port, debug=True)
        