#! C:\Users\qli1\BNS_prog\strawberry\perl\bin\perl.exe -w
#print "hello\n";
@array1=('a','b','c');
@array2=(1,2,3);
#unshift @array2, @array1;
$tea="black";
#push @array1, $tea;
@array1=($tea, @array1);
$count=@array1;
splice @array1, 2, 1, $tea;
@list1=join "+", "what", "heck";

$,=" ";
#sort{$a<=>$b}@array1;
#print join('*', map{ucfirst(lc($_));}@array1),"\n";
%age=('tom',26, 'peter',20, 'jay',5);
# print "pls enter name >>";
# chomp($tofind=<STDIN>);
# if (exists($age{$tofind})) {
# print "\"$tofind\" found!\n";
# }
# else{
# print "\"$tofind\" died \n";}
my $fhLOG;
#my $retval=open($fhLOG, "<t1.txt");


#print $retval;
# my $testDIR ="dir_test";
# if (! -d $testDIR)
# {
# mkdir $testDIR;
# print "DIR made";
# }
# open F1, "<t1.txt" or die "cannot open file";
# my $line;
# while ($line=readline(F1)){
# print $line;
# }
# close F1;
# my $dh_DIR1;
# my $rtn=open $dh_DIR1, "c:\Users\qli1\BNS_wspace\dir_test";
# # my $dir_line = readdir ($dh_DIR1);
# # while ($dir_line){
# # print $dir_line;
# # 
# print $rtn;
sub muffin{
	$_[2]=5;
	$_[3]=6;
	}
my @a=(1,2,3);
my $b=4;
muffin(@a, $b);
print join(',', @a, $b);
