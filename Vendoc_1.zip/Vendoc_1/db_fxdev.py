# -*- coding: utf-8 -*-
"""
"""
import pandas as pd
import numpy as np
import cx_Oracle as co
ip = 'XX.XX.X.XXX'
port = YYYY
SID = 'DW'
dsn_tns = cx_Oracle.makedsn(ip, port, SID)

connection = cx_Oracle.connect('BA', 'PASSWORD', dsn_tns)
df_ora = pd.read_sql(query, con=connection)
print ("what;")
import cx_Oracle
var4='sbdsvrwm815.dev.ib.tor.scotiabank.com:1535/ORDFX'
var1='ordapp'
var2='ordfx'
var3='2010rt'
#db_fxdev = co.connect(var1, var2+var3, var4)
#db1 = cx_Oracle.connect('hr/hrpwd@localhost:1521/XE')
#dsn_tns = cx_Oracle.makedsn('localhost', 1521, 'XE')
#print dsn_tns
#(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521)))
#(CONNECT_DATA=(SID=XE)))
