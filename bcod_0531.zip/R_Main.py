# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 11:13:46 2017
"""
import pandas as pd
#from pandas.tseries.offsets import BDay
import warnings
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
from P_commons import read_sql, to_sql_append, to_sql_replace, bdate, backup_db
from R_update_price import update_pv_eod, update_price_eod
from R_stat import stat_run_base, stat_VIEW, stat_PLOT, etf_corr, sec_leadlag, sec_sharpe
from R_options import unop_mc, mc_intel, unop_bc, bc_intel, bmc_intel,  candy_combo
from o_options import unop_omc, omc_intel, unop_obc,  obmc_intel, get_IV
#from R_entry import pre_spec, re_spec, spec_track, trade_candy, trade_entry
from R_track import track_raw
from o_track import oraw
from R_entry import spec_track
from o_entry import update_op_CID, obmc_update_tbl_track, obmc_track, update_tbl_cid, calc_tbl_cid
from R_plot import plot_base, plot_QI
from R_senti import sentis, sentis_intel, senti_mc
from R_getdata import get_NEWS
import datetime

position_list=read_sql("SELECT ticker FROM tbl_c where exit_dt ='N' order by ticker").ticker
indicator_list=['AAPL','KLAC','URI','BID',\
    'EDIT','SGMO','PLNT','CDXS','MILN','LNGR']
extreme_list=['DF','FXE','ZBTC','GUSH','XNET','IDEX','MAXR','DBC']
trend_list=['EDIT','PLNT','SGMO']

q_date=bdate()
#q_date=datetime.date(2019, 4, 18)
MODE=input(" - copy db? tbl_oc entry? -- optionor EOD?  option/EOD:  ")
    
if MODE=='option':
#    backup_db()
    dmc=unop_omc(q_date)
    dmct=omc_intel(q_date)
    bce=unop_obc(q_date)
    bmcte=obmc_intel(q_date)
    do_spec=update_op_CID(q_date, 'op_spec')
    df_obmc=obmc_update_tbl_track(q_date)
    lcp, barg, rest, df=obmc_track(q_date)
    
    do_c=update_op_CID(q_date, 'op_c')
    dt_cid= update_tbl_cid(q_date)
    div=get_IV(q_date)
    dt_c=oraw(q_date)
    
    
#    get_NEWS(position_list)
    
    
elif MODE=='EOD':
    print(" ---- STARTS %s ----"%q_date)
    update_pv_eod('etf', q_date)  #  since jun 2018
    update_pv_eod('sp500',q_date) 
    update_pv_eod('all', q_date)
    update_price_eod('etf', q_date) # since 2013
    update_price_eod('sp500', q_date)
    
    print("-----positions ----")
    plot_base(q_date, position_list) 
    
    ds_sec=stat_run_base(q_date, 'sec')    
    ds_sp=stat_run_base(q_date, 'sp500')
    ds_etf=stat_run_base(q_date, 'etf_all')
    df_stat=stat_VIEW(q_date) 
    stat_PLOT(q_date) 
    
#    dmc=unop_mc(q_date) 
#    dmct=mc_intel(q_date)
#    dbc=unop_bc(q_date, 'EOD')
#    dbct=bc_intel(q_date,'EOD')
#    dbmct=bmc_intel(q_date,'EOD')
    
    
    dc=candy_combo(q_date,'EOD')  
    
    df_sentis=sentis()
    sentis_intel(df_sentis, q_date)
    senti_mc()
    etf_corr()
    sec_sharpe()
    sec_leadlag(q_date)
    plot_QI()

    spec_track(q_date)

#    df_track=track_raw(q_date)
"""
to do
1. money flow : http://www.wsj.com/mdc/public/page/2_3022-mfsctrscan-moneyflow-20190104.html?mod=mdc_pastcalendar
2. asset overview https://www.wsj.com/graphics/track-the-markets/?mod=topnav_2_3022
3. https://www.quantopian.com/posts/measuring-money-flows
4. https://www.ici.org/research/stats/flows/ltflows/flows_04_17_19
5.https://github.com/six519/pyoptionchain/blob/master/pyoptionchain/google_api.py
6.https://www.quantconnect.com/data/tree
7.http://www.quantmod.com/
8.https://github.com/gyanesh-m/Sentiment-analysis-of-financial-news-data
9.https://github.com/eliangcs/pystock-data

READ_HTML
https://beenje.github.io/blog/posts/parsing-html-tables-in-python-with-pandas/
https://stackoverflow.com/questions/25062365/python-parsing-html-table-generated-by-javascript
!!REQUEST+JAVASCRI[T
http://theautomatic.net/2019/01/19/scraping-data-from-javascript-webpage-python/]
readlist : http://theautomatic.net/recommended-reading-list/
# -----------------------------------------------  #
#mutable funcion https://docs.python.org/3/faq/programming.html#how-do-i-write-a-function-with-output-parameters-call-by-reference
#https://stackoverflow.com/questions/38895768/python-pandas-dataframe-# to_do:

pre-spec
"earning_pattern: https://marketchameleon.com/Overview/CCK/Earnings/Earnings-Charts"
option insight:
OI/IV chg:     https://marketchameleon.com/Overview/CCK/OpenInterestTrends/
eARN pattern,
#past 30 days option iv, volume data (jsp table)
https://marketchameleon.com/Overview/CCK/DailyHistory/
#json.dumps(), loads() to store dictionary into table
for earn_history, fun_bc tables
selenium python
https://selenium-python.readthedocs.io/
"""