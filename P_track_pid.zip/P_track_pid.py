# -*- coding: utf-8 -*-
"""
arch:
    tbl_cid has aggregaged tbl_oc by lc/lp/comm (tbl_oc just record trans and as proof of live oc
    )
1. report_data()
2. report_data_process()
3. report_pid()


"""
import pandas as pd
import numpy as np 
import datetime as datetime
import sqlite3 as db
from timeit import default_timer as timer
from dateutil import parser
import scipy.stats
from termcolor import colored, cprint
import warnings
from P_commons import to_sql_append, to_sql_replace, read_sql, type_convert,to_sql_delete, get_conn, tbl_nodupe_append, fmt_map, sanity_check
from P_commons import * 
from P_stat import stat_VIEW
from R_plot import plot_base
from P_getdata import get_FUN, get_DIV, get_SI
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format

"""
    logic: risk control by delta (i_delta) and weigh( i_ip)
    var_id_max=cap * Max_loss_per_pos/ Buff_var_id
    delta_max=var_id_max/ var_id
    var_id= atr_hd * iv_hv
    ic_max_id= delta_max/ i_detla
    weigh_max= cap * weigh_per_pos
    ic_max_weigh= weigh_max/ i_ip
    i_ic@entry = min (ic_max_id, ic_max_weigh)
        Immediate control:
    0) daily update IBQ_cap
    1) con_weigh (risk_live/cap)>max_weigh_per_pos
    2) size_pct: max(var_id,var_hd)*BUFF_var_id )/(cap* MAX_loss_per_pos))
    3) spike>Buff_var_id(R multiple: 3* std)
    4) spike_etf>1  
"""
weigh_per_pos=0.05   
MAX_loss_per_pos=0.03
BUFF_var_id=3  # R: stop@ 3 std_daily
#    v_stk_vol_pct=2.5
itm_pct=0.015
itm_deep=0.8
ext_v_min=0.2

key_level_pct=0.01    
exit_days_pct=0.5
event_days=5

spike_min=1
stop_spike=BUFF_var_id
stop_spike_etd=1.1
hiv_chg_pct=0.2
hv_rank_chg_min=0.1
#preport_by_pid parameters: 
#add /cut 
loss_size_pct_max=0.2 # min_size_pct to qualify for cut (ignore if too smal)
gain_size_pct_min=0.9 # no action is current size_pct big enough
size_chg_days_pct_max=0.5  # max days_pct to add position

vega_min= 15
days_pct_tgt_p=0.3

oi_chg_min=500
oi_chg_pct_min=0.1
o_vol_pct_min=2

cid_pl_pct_chg=0.5
cid_oi_chg_min=500
cid_oi_chg_pct_min=0.3

#%%
def preports(q_date): 
# tbl_oc & tbl_cid    
#    du=report_data(q_date, 'cid', 'U')
    
#    dz=report_data('ticker')
    rcid=preport_by_cid(q_date, 'acid')
    dy=preport_data_get(q_date, 'apid')
    dyp=preport_data_process(dy, q_date)
    rpid=preport_by_pid(dyp, q_date)
    preport_by_ticker(dyp, ['act','ticker'])


#%%
def preport_data_get(q_date, rpt_by=''): #rpt_by: 'acid', 'bpid', 'apid'
    """
    use: aggregate/re_cacl data (pl, greek, lc, mp, margin, risk_live) to rpt_by level ('cid','acid','bpid','apid')
    source: tbl_oc, tbl_cid
    note: margin rule: 
        https://optionalpha.com/understanding-options-trading-margin-requirements-for-naked-options-9650.html
    tip: groupby (,as_index=False).agg()
    
    """
    def pid_calc_combo_from_cids(dg):
#   cacl combo(pid) lc/lp by pid consisting multiple different cids   
        g_lc=np.abs(dg['lc']).min()
        g_lp=(dg['lc']*dg['lp']).sum()/g_lc
        g_mp=(dg['lc']*dg['mp']).sum()/g_lc
        if g_lp <0:  #enter as sell_premium combo, whose mp neeed to be >0
            g_margin, g_risk_live=pid_calc_combo_margin(dg, g_lc, g_mp, g_lp)
        else:
            g_margin=dg['risk_live'].sum()
            g_risk_live=g_margin
        return g_lc, g_lp, g_mp, g_margin, g_risk_live
    def pid_calc_combo_margin(dp, lc, mp, lp):
        #when lp < 0
        df=dp.sort_values('ticker')  #avoid mute
        if df.tail().play.values[0] in ['SC','SP']:
            margin=( df.tail(1).close.values[0] * 0.2 + np.abs(lp) ) * 100* lc 
        elif df.tail().play.values[0] in ['SCV','SPV']:
            margin=np.abs(df.tail(1).strike.values[0]- df.tail(2).head(1).strike.values[0]) * 100* lc
        elif df.tail().play.values[0] in ['IC','DD']:
            df.sort_values('strike', inplace=True)
            margin=np.abs(df.tail(1).strike.values[0]- df.tail(2).head(1).strike.values[0])*100*lc
        else:
            margin=df['risk_live'].sum()
        risk_live=margin + mp* lc *100
        return margin, risk_live

# get common data from tbl_oc   (one unique row is enough)
    dt=read_sql("select * from tbl_oc WHERE exit_dt =='N' and oexp_dt>='%s' \
                AND substr(pid,1,1)<>'U'"%q_date)
    if rpt_by in ['cid', 'acid']:
        # get 'cid'-level data from tbl_oc
        dt.drop_duplicates('cid', keep='first', inplace=True)
    elif rpt_by in ['bpid', 'apid']:
        # get 'pid'-level data from tbl_oc
        dt.drop_duplicates(['pid','cid'], keep='first', inplace=True)
        
    dcid=read_sql("select * from tbl_%s"%rpt_by)
    dcid['date']=pd.to_datetime(dcid['date']).dt.date
    dcid=dcid[dcid.date==q_date]
    #['ticker','cid'] are common fields btn 2 dataframe   
    df=dcid.merge(dt, on=['ticker','cid'],how='left') 
#! tbl_a/bpid is unique by a/bpid + cid
    df.drop_duplicates([rpt_by, 'cid'], keep='first', inplace=True )
    df.sort_values(['cid','entry_dt'], inplace=True)

    if rpt_by in ['cid','acid']:
        return df
# PID level aggregation/cacl    
# get price to calc margin ('p' not in tbl_oc, tbl_cid)
    dp=read_sql("select * from tbl_pv_all where date='%s' "%q_date)
    df=df.merge(dp[['ticker','close']], on='ticker', how='left')
    # Data -1: pl, greeks, risks
    val_g=['pl','pl_delta', 'pl_gamma','pl_theta','pl_vega', 'pl_exp',\
         'pl_p', 'pl_p_delta', 'pl_p_gamma','pl_p_theta','pl_p_vega', 'pl_p_exp', \
         'pl_ur', 'risk_live',\
         'delta', 'gamma', 'theta', 'vega',\
         'delta_p', 'gamma_p', 'theta_p', 'vega_p',\
         'delta_i', 'gamma_i', 'theta_i', 'vega_i',\
         'var_iv', 'var_delta', 'var_gamma', 'var_theta',\
         'delta_c',  'gamma_c', 'theta_c', 'vega_c', 'comm_c',\
         'lc', 'lp', 'mp']
    # Data -2: dates and common fields
    dt_g=['oexp_dt','entry_dt','earn_dt','play', 'sec','beta','ticker','act']
    df=type_convert(df, val_g, 'float')
    dg=pd.DataFrame()
# PID-CALC-STEP-1: Aggregate cids to pid: Data-1, re_calc pl_pct, val_dt.min()  @pid level
    for x in val_g:
        dg[x]=df.groupby(rpt_by)[x].sum()
    # earliest date (earn_dt, div, event)  for multiple cids in one pid combo
    for y in dt_g:
        dg[y]=df.groupby(rpt_by)[y].min()

#    dg['pl_ur_pct']=dg['pl_ur']/(dg['risk_live']-dg['pl_ur'])
#    dg['pl_exp_pct']=dg['pl_exp']/dg['pl_ur']
#    dg['pl_p_exp_pct']=dg['pl_p_exp']/dg['pl_p']
    dg.reset_index(inplace=True)
    

# PID-CALC-STEP 2: Re-calc combo lc,lp,mp from cids by pid
    if rpt_by in ['bpid', 'apid']:  
        # Combo recalc step -1: lc, lp, mp
        dc=df.groupby('%s'%rpt_by).apply(pid_calc_combo_from_cids)
        dc=dc.to_frame()
        dc['lc']=dc[0].str[0]
        dc['lp']=dc[0].str[1]
        dc['mp']=dc[0].str[2]
        dc['margin']=dc[0].str[3]
        dc['risk_live']=dc[0].str[4]
        
        dc.reset_index(inplace=True)
        col_c=[rpt_by,'lc','lp','mp','margin', 'risk_live']
        # replaced by value from sub_functions
        dg.drop(['lc','lp','mp', 'risk_live'], axis=1, inplace=True)
        dg=pd.merge(dg, dc[col_c], on= rpt_by, how='left')
        # Combo reclac-2: var_iv, greek/combo (pid); note: var_gamma offset var_theta
        dg['var_iv']=(np.abs(dg['var_delta'])+np.abs(dg['var_gamma']+dg['var_theta'])) 
        dg['delta']=dg['delta_c']/np.abs(dg['lc'])
        dg['gamma']=dg['gamma_c']/np.abs(dg['lc'])
        dg['theta']=dg['theta_c']/np.abs(dg['lc'])
        dg['vega']=dg['vega_c']/np.abs(dg['lc'])
        

    elif rpt_by in ['cid','acid']:
        col_share=list(set(df.columns.tolist()) - set(dg.columns.tolist()))
        col_add=col_share + list(rpt_by)
        dg=dg.merge(df[col_add], on=rpt_by, how='left')
    #re_calc pct as source data changed   
    dg['pl_ur_pct']=dg['pl_ur']/(dg['risk_live']-dg['pl_ur'])
    dg['pl_exp_pct']=dg['pl_exp']/dg['pl_ur']
    dg['pl_p_exp_pct']=dg['pl_p_exp']/dg['pl_p']
    
    col_format=['pl_ur_pct','var_delta', 'var_theta','var_gamma','var_iv']
    dg=fmt_map(dg, col_format)
   
    return dg

#%%
def preport_data_process(df, q_date):
    """
    use: 1. aggregate data soruce (act, risk, stat_view) to report_data_by_cid/pid;
        2.  derive new fileds : dates_to_earn etc, size_pct, buff etc
    source: preport_data_get, tbl_act, tbl_risk, stat_VIEW
    dest: preport_by_pid
    """
    print ("report_data_process started")
    dt=df.sort_values('ticker')  #avoid mute
#tbl_act
    dt_cap=read_sql("SELECT * FROM tbl_act", q_date)
    dt=dt.merge(dt_cap[['act','cap']], on='act',how='left')
#tbl_risk
    dr=read_sql("SELECT * FROM tbl_risk")
    dr=type_convert(dr, ['r','rx'], 'float')
    dt=pd.merge(dt, dr, on='play', how='left')  
#tbl_iv
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date']).dt.date
    div.sort_values(['ticker','date'], inplace=True)
    col_v=['oi','oi_c', 'iv_chg_pct','oi_p', 'vol_pct','iv','oi_p_pct']
    div=reg_convert(col_v, div, 'float')
    
    div['oi_i_chg_pct']=div.groupby('ticker')['oi'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    div['iv_i_chg']=div.groupby('ticker')['iv'].apply(lambda x:x-(x.iloc[0]))
    div['p_i_chg_pct']=div.groupby('ticker')['p'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    div['oi_p_pct_i_chg']=div.groupby('ticker')['oi_p_pct'].apply(lambda x:x-(x.iloc[0]))
    div['oi_c_i_chg_pct']=div.groupby('ticker')['oi_c'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    div['oi_p_i_chg_pct']=div.groupby('ticker')['oi_p'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    div['oi_c_chg_pct']=div.groupby('ticker')['oi_c'].apply(lambda x:x.div(x.shift(1)).subtract(1))
    div['oi_p_chg_pct']=div.groupby('ticker')['oi_p'].apply(lambda x:x.div(x.shift(1)).subtract(1))
    div['oi_c_chg']=div.groupby('ticker')['oi_c'].apply(lambda x:x-x.shift(1))
    div['oi_p_chg']=div.groupby('ticker')['oi_p'].apply(lambda x:x-x.shift(1))
    
    div_x=div[div.date==q_date]
    #only live ticker, as iloc[0] incl. non q_date ticker
    div_b=div[div.ticker.isin(div_x.ticker)].groupby('ticker')['iv_rank'].apply(lambda x:x.iloc[0])
    div_b=div_b.to_frame()
    div_b.reset_index(inplace=True)
    div_b.rename(columns={'iv_rank':'iv_i_rank'}, inplace=True)
    div=pd.merge(div_x, div_b, on='ticker', how='left')

    col_iv=['div', 'div_dt', 'earn_dt_mc', 'ind','iv', 'iv_1y',\
       'iv_chg_pct', 'iv_rank', 'mcap', 'oi', 'oi_c','oi_p','oi_p_pct', 'p', 'p_chg',
       'p_chg_pct', 'spike_iv', 'ticker', 'vol', 'vol_pct', 'vol_stk', 'yld']
    col_iv_new=['oi_i_chg_pct', 'iv_i_rank', 'iv_i_chg','p_i_chg_pct','oi_c_chg','oi_p_chg',\
        'oi_p_pct_i_chg', 'oi_c_i_chg_pct', 'oi_p_i_chg_pct', 'oi_c_chg_pct','oi_p_chg_pct']

    col_iv=col_iv + col_iv_new
    div=div[col_iv]
    dt=dt.merge(div, on='ticker', how='left')

# stat_VIEW
    dv=read_sql("select * from tbl_stat")
    dv['date']=pd.to_datetime(dv['date']).dt.date
    max_stat_dt=dv.date.max()
    
    ds=stat_VIEW(max_stat_dt, dt['ticker'].unique().tolist())
    ds.drop('sec', axis=1, inplace=True)
    col_share=list(set(dt.columns).intersection(set(ds.columns)))
    #preserve sec value from tbl_c for non-sp ticker
    col_drop=[x for x in col_share if x not in ['ticker', 'sec']]
    dt.drop(col_drop, axis=1, inplace=True)
    dt=dt.merge(ds, on='ticker', how='left')
    
#tbl_mc_raw, tbl_bc_raw
    dt_mc=read_sql("SELECT * FROM tbl_mc ", q_date)
    dt_mc['date']=pd.to_datetime(dt_mc['date']).dt.date
    dt_mc=dt_mc[dt_mc.date==q_date]
    loc_mc=dt['ticker'].isin(dt_mc['ticker'])
    if loc_mc.any():
        dt.loc[loc_mc,'mc']=dt_mc['ticker'] +'|' + dt_mc['v_pct'].astype(str)\
            +'|'+dt_mc['pct_c'].astype(str)
    else:
        dt['mc']=np.NaN
    dt_bc=read_sql("SELECT * FROM tbl_bc ", q_date)
    dt_bc['date']=pd.to_datetime(dt_bc['date']).dt.date
    dt_bc=dt_bc[dt_bc.date==q_date]
    loc_bc=dt['ticker'].isin(dt_bc['ticker'])
    if loc_bc.any():
        dt.loc[loc_bc,'bc']=dt_bc['ticker'] +'|' + dt_bc['v_oi'].astype(str)\
            +'|'+dt_bc['type'].astype(str)
    else:
        dt['bc']=np.NaN
#    for index, row in dt[con_new].iterrows():
#        try:
#            fun_col=['beta','pe','ta']
#            FUN=get_FUN(row.ticker)  
#            for k in fun_col:
#                dt.loc[index, k]=FUN[k]
#        except:
#            for k in fun_col:
#                dt.loc[index, k]=0
#        try:
#            si_col= ['si'] 
#            SI=get_SI(row.ticker)
#            for k in si_col:
#                dt.loc[index, k]=SI[k]
#        except:
#            for k in si_col:
#                dt.loc[index, k]=0
#Clean/convert data
    dt['date']=q_date
    dt.loc[pd.isnull(dt.earn_dt), 'earn_dt']=dt['earn_dt_mc']
    col_dt=['entry_dt', 'oexp_dt', 'earn_dt', 'div_dt','date']
    dt=type_convert(dt, col_dt, 'datetime')
#    for x in flask_val:
#        dt.loc[con_new, x]=dt.loc[con_new, x].replace('',0).replace('None',0).astype(float)
    col_float=['delta_c','vega_c','pl', 'pl_ur','theta_c', 'iv',\
               'pl_ur_pct']
    dt=type_convert(dt, col_float, 'float')

    dt['tgt_dt']=dt['entry_dt']+(dt['oexp_dt']-dt['entry_dt'])/2
    dt['days_to_exp']=dt['oexp_dt'].subtract(dt['date']).dt.days   
    dt['days_all']= dt['oexp_dt'].subtract(dt['entry_dt']).dt.days   
    dt['days_pct']=(1-dt['days_to_exp']/dt['days_all']).round(2)
    dt['days_to_div']=dt['div_dt'].subtract(dt['date']).dt.days
    dt['days_to_earn']=dt['earn_dt'].subtract(dt['date']).dt.days
    dt['days_to_tgt_dt']=dt['tgt_dt'].subtract(dt['entry_dt']).dt.days
#    dt['days_to_event']=dt['event_dt'].subtract(dt['date']).dt.days

# insert var_greeks cacl once from tbl_cid
    dt['var_delta_hv']=dt['delta_c']*dt['atr_hd']
    dt['var_vega_hv']=dt['vega_c']*dt['atr_hv']*100
    dt['var_hv']=np.abs(dt['var_delta_hv'])+np.abs(dt['var_vega_hv'])

    dt['iv_hv']=dt['iv']/dt['hv_22']  
    
    dt['weigh']=dt['risk_live']/dt['cap']
    dt['size_pct']=np.abs((dt[['var_iv','var_hv']].max(axis=1)*BUFF_var_id )/  \
              ( dt['cap']* MAX_loss_per_pos))
    dt['size_buff']=( dt['cap']*MAX_loss_per_pos)- \
            np.abs(dt[['var_iv','var_hv']].max(axis=1)* BUFF_var_id ) 
                #size_chg
    dt['delta_to_adj']=dt['delta_c']*(1-dt['size_pct'])
    dt['con_to_adj']=dt['delta_to_adj']/(dt['delta'])
    dt['weigh_to_adj']=(weigh_per_pos - dt['weigh'])*dt['cap']
    return dt

#%%
def preport_by_pid(df, q_date):
    
    """
    use: decide action on pid: stop/ exit/ out/ add/cut - set condition and print alert 
    source: preport_data_process()
    
    """
    print(" report_by_pid started ....   ")
    #avoid mute of orig df
    dt=df.sort_values('ticker')
    CON_stop= (dt['pl_ur_pct'].astype(float) <= dt['r'].astype(float))
    con_tgt_dt= dt['tgt_dt']<q_date
    con_days_pct = dt['days_pct'].astype(float)>=exit_days_pct
    CON_out= con_tgt_dt | con_days_pct
    CON_exit=dt['pl_ur_pct'].astype(float) > dt['rx'].astype(float)
    #a_event        
    con_earn_dt=dt['days_to_earn']>0
    con_div_dt=dt['days_to_div']>0
#    con_event_dt=dt['days_to_event']>0
    CON_event=(dt['days_to_div']<=event_days & con_div_dt)\
            |(dt['days_to_earn']<=event_days & con_earn_dt)
#              |(dt['days_to_event']<=event_days & con_event_dt )  
#a_key_level
    CON_key_level=(np.abs(dt['fm_50'])<= key_level_pct) \
          |(np.abs(dt['fm_200'])<= key_level_pct) \
          |(np.abs(dt['fm_hi'])<= key_level_pct) \
          |(np.abs(dt['fm_lo'])<= key_level_pct)  
#a_unop or oi_chg
    con_oi_c = (np.abs(dt['oi_c_chg'])> oi_chg_min) & (np.abs(dt['oi_c_chg_pct'])>oi_chg_pct_min)
    con_oi_p = (np.abs(dt['oi_p_chg'])> oi_chg_min) & (np.abs(dt['oi_p_chg_pct'])>oi_chg_pct_min)    
    con_oi = con_oi_c | con_oi_p
#    con_vol=dt['vol_pct']> o_vol_pct_min 
    
    con_bmc=pd.notnull(dt['mc']) |pd.notnull(dt['bc'])  
    CON_unop=con_bmc | con_oi          
#    CON_spike= (np.abs(dt['spike'])>spike_min) 
    CON_spike= (np.abs(dt['spike'])>spike_min) |(np.abs(dt['spike_iv'])>spike_min)          
    #a_size
    con_weigh=dt['weigh'] >=weigh_per_pos
    con_oversize=dt['size_pct']>=1
    con_add=(dt['pl_ur_pct']>0) & ((dt['days_pct']<size_chg_days_pct_max)| (dt['days_to_exp']>30))\
            & (dt['size_pct']<gain_size_pct_min)
    con_cut=(dt['pl_ur_pct']<0) & (dt['days_pct']>=size_chg_days_pct_max) \
            & (dt['size_pct']>=loss_size_pct_max)
    con_cut=con_cut | con_weigh | con_oversize
    CON_size=con_add | con_cut

    dt['a_out']=CON_out
    dt['a_stop']=CON_stop
    dt['a_exit']=CON_exit
    dt['a_size']=CON_size
    dt['a_spike']=CON_spike
    dt['a_event']=CON_event
    dt['a_key']=CON_key_level
    dt['a_unop']=CON_unop
    dt.loc[con_add, 'a_size']='+'
    dt.loc[con_cut, 'a_size']='-'  

#clean display
    dt.replace(False, "", inplace=True)
    dt.replace(np.nan, "", inplace=True)
#    dt.loc[~con_event_dt, 'event_dt']=np.nan
    dt.loc[~con_earn_dt, 'earn_dt']=np.nan    
    dt.loc[~con_div_dt, 'div_dt']=np.nan
#    CON_event_show=pd.notnull(dt['div_dt'])|pd.notnull(dt['earn_dt'])
#        |pd.notnull(dt['event_dt'])
    show_alerts=['apid','play','risk_live', 'pl_ur_pct', 'pl_ur','var_iv',\
                  'a_stop', 'a_exit','a_out','a_unop', 'a_size',  'a_spike', \
                'a_unop', 'a_key','theta_c','delta_c']
    
    show_base=['apid','play','apid', 'risk_live', 'margin', 'pl', 'pl_ur_pct','days_pct', 'close', 'iv_hv','iv_rank', 'hv_rank','spike_iv']
    show_action=['a_stop','a_exit','a_out']+ show_base
    show_size=['apid','play','risk_live','margin', 'a_size','pl_ur_pct','size_pct', 'weigh','size_buff','delta_to_adj',\
               'con_to_adj','weigh_to_adj', 'mp','days_pct','iv_hv', 'risky','play']
    show_unop=['apid','mc','bc','p_chg', 'iv_rank', 'iv_i_rank',  'p_i_chg_pct', \
               'oi_c_chg', 'oi_c_chg_pct','oi_p_chg', 'oi_p_chg_pct','iv_chg_pct']
    show_event= ['apid','days_pct','close','div_dt','earn_dt'] #'event_dt', 
#display percentage
    col_pct=['hv_rank','pl_exp_pct', 'pl_p_exp_pct', 'pl_ur_pct','days_pct','size_pct','oi_c_chg_pct',\
             'oi_p_chg_pct', 'oi_p_pct', 'spike_iv','weigh', 'iv_chg_pct']
    
    for p in col_pct:
        dt[p]=dt[p].replace(np.inf,0).replace(-np.inf,0).replace(np.nan,0).replace('',0)
        dt[p] =dt[p].astype(float).apply(lambda x: "{0:.0f}%".format(x*100))
    dt.sort_values(['risk_live','pl_ur_pct','days_pct'], ascending=False, inplace=True)
    pd.set_option('display.expand_frame_repr', False)
    print(" \n---- ALERT_WARN  ---  \n ", dt[show_alerts]) #.to_string(index=False))
    print("\n ---- STOP_EXIT_OUT ---   \n ", dt[CON_stop |CON_exit |CON_out][show_action])

    print("\n ---- SIZE ---   \n ", dt[CON_size][show_size].sort_values(['size_pct','weigh'], ascending=False))
    print("\n ---- UNOP ---    \n ", dt[CON_unop][show_unop])
    print("\n ---- EVENT---   \n ", dt[CON_event][show_event])
    return dt  

#%%
def preport_by_ticker(dp, rpt_by='ticker'): #['act','ticker']
    """
    use: report ticker_level risk, pl, greeks, var, spy_und
    source: preport_data_process('apid') -needed processed data like var
    """
    print("preport_by_ticker started ....")
    dv=dp.sort_values('ticker')
    # SPY_equivalent delta   
    dv['v_und']=dv['delta_c']*dv['close']
    spy=read_sql("select close from tbl_pv_etf where ticker ='SPY'")
    spy=spy.tail(1).iloc[0,0]
    dv['beta']=dv['beta'].replace('',1).astype(float)
    dv['v_spy']=dv['v_und']*dv['beta']/spy 
    
    list_act= dv['act'].unique().tolist()
    col_agg=['risk_live', 'pl_ur','pl','weigh','var_iv','var_hv', 'delta_c','gamma_c',\
             'theta_c','vega_c','comm_c','v_spy','margin', 'pl_ur_pct']
    col_one=['cap', 'beta']
    dv=type_convert(dv, col_agg, 'float')
    dg=pd.pivot_table(dv, index=rpt_by,  values=col_agg, aggfunc=np.sum) #columns='act',
    do=pd.pivot_table(dv, index=rpt_by,  values=col_one, aggfunc=np.mean) 
    df=pd.concat([dg, do], axis=1)
    df['size_pct']=np.abs((df[['var_iv','var_hv']].max(axis=1)*BUFF_var_id )/  \
              ( df['cap']* MAX_loss_per_pos))
    df['size_buff']=( df['cap']*MAX_loss_per_pos)- \
            np.abs(df[['var_iv','var_hv']].max(axis=1)* BUFF_var_id )  
#alert @ticker-level    
    con_weigh=df['weigh'] >=weigh_per_pos
    con_oversize=df['size_pct']>=1
    CON_size=con_weigh | con_oversize
#a_momt  
#    con_momt_l= (df['delta_c']>0) &   (df['rtn_22_pct']<df['i_rtn_22_pct'])
##                    | (df['srtn_22_pct']<df['i_srtn_22_pct']) )
#    con_momt_s=  (df['delta_c']<0) &  (df['rtn_22_pct']>dt['i_rtn_22_pct']) 
##                   | (dt['rtn_22_pct']>dt['i_rtn_22_pct']) )
#    CON_momt= con_momt_l | con_momt_s    
    df.loc[CON_size, 'a_size']='-'
    df.sort_values(['risk_live'], ascending=False, inplace=True)  
# sub_total
    for x in list_act:
       df.loc[('%s_total'%x,''),:]=df.loc[x].sum()
# grand_total section      
    row_end= df.shape[0]
    rowcnt_subtotal= len(list_act)
    row_begin=row_end-rowcnt_subtotal
    df.loc[('Grand_total',''),:]=df.iloc[row_begin:row_end,:].sum()
    
    df['weigh']=df['weigh'].astype(float).apply(lambda x: "{0:.0f}%".format(x*100))
    df['size_pct']=df['size_pct'].astype(float).apply(lambda x: "{0:.0f}%".format(x*100))
    pd.options.display.float_format = '{:.0f}'.format
    show=['a_size', 'weigh','var_iv','v_spy', 'risk_live','margin', 'pl_ur', 'pl_ur_pct', 'size_pct','size_buff', \
          'delta_c', 'gamma_c','theta_c','vega_c','comm_c','cap']
    print(df[show])
#%%
def preport_by_cid(q_date, rpt_by=''):  #'cid' or 'acid'
    """
    use: risk_view@cid by sec/oexp_dt
    source: report_by('cid')
    """
    import re
    cid_pl_pct_chg=0.5
    cid_o_oi_chg_min=500
    cid_o_oi_chg_pct_min=0.3
    cid_o_vol_min=1000
    
    
    df=preport_data_get(q_date, '%s'%rpt_by)
    df['date']=pd.to_datetime(df['date']).dt.date
# prep for cid_alert
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date']).dt.date
    div=div[div.date==q_date]
    col_iv=['ticker','date', 'iv', 'oi', 'oi_c', 'oi_p', 'vol','p','p_chg', 'div_dt', 'div','iv_chg_pct']
    
    con_div=div['div'].str.len()>0
    div.loc[con_div, 'div']=div.loc[con_div, 'div'].apply(lambda x: float(re.findall("\d+\.\d+",x)[0]))
    div.loc[~con_div, 'div']=0
    df=df.merge(div[col_iv], on=['ticker','date'], how='left')
    
    df=prob_oc(df, q_date)
    

#Alert: ITM, Assign, cid_oi_chg
    # alert ITM: extrinsic value vs. dividend -> assign risk for short call
    con_c= (df['type']=='C')
    con_p= (df['type']=='P')
    df.loc[con_c, 'ext_v']=df.loc[con_c,'mp']- (df.loc[con_c, 'p']-df.loc[con_c, 'strike'])
    df.loc[con_p, 'ext_v']=df.loc[con_p,'mp']- (df.loc[con_p, 'strike']-df.loc[con_p, 'p'])
    con_ext_v_min= (df.ext_v< ext_v_min)
    
    con_itm_pct=np.abs(df['p']/df['strike'] -1)>itm_pct
    con_itm_sc=(df['lc']<0) & (df['type']=='C') & con_itm_pct & (df['p']>df['strike'])
    con_itm_sp=(df['lc']<0) & (df['type']=='P') & con_itm_pct & (df['p']<df['strike'])
    con_itm_deep=np.abs(df['delta'])>itm_deep
    CON_itm_s= con_itm_sc | con_itm_sp 
    CON_itm_ext_v= con_itm_deep | con_ext_v_min
    
    CON_assign=(df['lc']<0) & (df['type']=='C') & con_div & (df['ext_v'].astype(float)< df['div'].astype(float))
    
    df['mp_i_chg']=df['mp'] - df['iop']
    con_neg_1=(df['p_chg']*df['mp_p_chg']<0) & (df['type']=='C')
    con_neg_2=(df['p_chg']*df['mp_p_chg']>0) &  (df['type']=='P')   
    con_neg_3=(df['p_i_chg']*df['mp_i_chg']<0) & (df['type']=='C')
    con_neg_4=(df['p_i_chg']*df['mp_i_chg']>0) &  (df['type']=='P')
    CON_neg=con_neg_1 | con_neg_2| con_neg_3 |con_neg_4

    con_o_oi_chg= np.abs(df['o_oi_chg'])>cid_o_oi_chg_min    
    con_o_oi_chg_pct=np.abs(df['o_oi_chg_pct'])>cid_o_oi_chg_pct_min 
    con_o_vol=df['o_vol']>cid_o_vol_min
    CON_oi_vol=con_o_oi_chg | con_o_oi_chg_pct |con_o_vol
    
    col_factors=['pl','delta', 'delta_i_chg','vega', 'iv_i_chg','p_i_chg','o_oi_i_chg','mp_i_chg']
    df= pl_score(df, col_factors)
    
    
    df['a_assign']=CON_assign
    df['a_itm_s']=CON_itm_s
    df['a_itm_ext_v']=CON_itm_ext_v
    df['a_neg']=CON_neg
    df['a_oi_vol']=CON_oi_vol
    show_base=['cid','score_act','score_pl','pl_ur_pct','lc','iop', 'mp','mp_p_chg','p_chg','o_vol', 'o_oi','o_oi_chg_pct','o_oi_i_chg','risk_live', 'var_iv']
    show_itm=['ticker','type','oexp_dt','p', 'strike', 'delta','lc', 'lp','mp','ext_v', 'div_dt','div']
#    show_neg=['cid', 'type','lc', 'mp','iv_chg_pct', 'mp_p_chg', 'p_chg', 'iv_i_chg','mp_i_chg', 'p_i_chg']
    pd.set_option('display.expand_frame_repr', False)
    print("\n ---- DIV Assign---    \n ", df[CON_assign][show_itm])
    print("\n ---- ITM Short---    \n ", df[CON_itm_s][show_itm])
    print("\n ---- ITM DEEP/ EXT_V ---    \n ", df[CON_itm_ext_v][show_itm])
    print("\n ---- UNOP_OI_VOL ---    \n ", df[CON_oi_vol][show_base])
    print("\n ---- SCORE_ACT: delta/chg -vega/iv- delta/p-mp/oi---    \n ", df[pd.notnull(df['score_act'])][show_base])
    return df

#%%
def pl_score(dp, col_factors):
    """
    use: add/cut cid by assessing pl vs. supporting consistences of each of 5 facotrs, decide to add/cut cid
    col_factors: varies by a/cid, a/bpid, tickers
    
    """
    score_add='10100'
    score_cut='00100'
    
    df=dp.sort_values('cid')  #avoid mute
    col=['f_pl_chg','f_delta', 'f_delta_chg','f_vega', 'f_iv_chg','f_p_chg','f_oi_chg','f_mp_chg']
    df[col]=df[col_factors]
    df=type_convert(df, col, 'float')
    
    con_pl=df['f_pl_chg']>0
    df.loc[con_pl, 's_pl']='1'
    df.loc[~con_pl, 's_pl']='0'
    
    con_delta_chg= (df['f_delta'] * df['f_delta_chg'])>0
    df.loc[con_delta_chg, 's_delta_chg']='1'
    df.loc[~con_delta_chg, 's_delta_chg']= '0'
    
    con_iv_vega= (df['f_vega'] * df['f_iv_chg'])>0 
    df.loc[con_iv_vega, 's_iv_vega']= '1'
    df.loc[~con_iv_vega, 's_iv_vega']= '0'
    
    con_p_delta= (df['f_delta'] * df['f_p_chg'])>0
    df.loc[con_p_delta, 's_p_delta']= '1'
    df.loc[~con_p_delta, 's_p_delta']= '0'    
    
    con_oi_mp= (df['f_mp_chg'] * df['f_oi_chg'])>0
    df.loc[con_oi_mp, 's_oi_mp']= '1'
    df.loc[~con_oi_mp, 's_oi_mp']= '0'
    
    df['score_pl']=df['s_pl']+ df['s_delta_chg']+df['s_iv_vega']+df['s_p_delta']+df['s_oi_mp'] 
    con_add=df['score_pl']>= score_add
    con_cut=df['score_pl']<= score_cut
    
    df.loc[con_add, 'score_act']=(df.loc[con_add, 'score_pl'].apply(lambda x: '+' * (x.count('1')-1)))
    df.loc[con_cut, 'score_act']=(df.loc[con_cut, 'score_pl'].apply(lambda x: '-' * (x.count('0')-1)))
#    df['score_act'].fillna('', inplace=True)
    df.drop(col, axis=1, inplace=True)
    return df
    
    
#%%
def ptrack_cid(q_date):
    """
    use: plot chg_mp, iv, vol, close@cid level
    raw source: tbl_oc, tbl_cid, tbl_iv, tbl_pv_all
    intel: i_chg in (o_oi, mp, iv, close, volume)
    alert: mp_i_chg_pct (add)
    
    2. risk_view_by_sec_exp
    """
    print("  track_cid started .... ")
# aggr data@cid level, incl. 'U1' tid
    dt=read_sql("select * from tbl_oc where exit_dt ='N' and oexp_dt>='%s'"%q_date)
#    dt['oexp_dt']=pd.to_datetime(dt['oexp_dt'])
#    dt['entry_dt']=pd.to_datetime(dt['entry_dt'])    
#    dt['days_to_exp']=dt['oexp_dt'].subtract(q_date).dt.days   
#    dt['days_all']= dt['oexp_dt'].subtract(dt['entry_dt']).dt.days   
#    dt['days_pct']=(1-dt['days_to_exp']/dt['days_all']).round(2)
    col_dt=['cid','pid']
#    list_t=dt.ticker.unique().tolist()
    
    do=read_sql("select * from tbl_cid")
    do['date']=pd.to_datetime(do['date'])
#    do['ticker']=do['cid'].str.split('-').str[0]
    col_cid=['cid', 'mp', 'pl', 'o_oi','o_vol','date', 'ticker']
    dot=do[col_cid].merge(dt[col_dt], on='cid', how='left')
#    do=do[do.ticker.isin(list_t)]
    
    div=read_sql("select * from tbl_iv")
    div['date']=pd.to_datetime(div['date'])  
    col_iv=['ticker','date', 'iv', 'oi', 'oi_c', 'oi_p', 'vol','p_chg']
    
    dpv=read_sql("select * from tbl_pv_all")
    dpv['date']=pd.to_datetime(dpv['date'])      
    col_pv=['ticker','date','close','volume']
    
    df=dot.merge(div[col_iv], on=['ticker','date'], how='left')
    df=df.merge( dpv[col_pv], on=['ticker','date'], how='left' )
#rolling chg from i_date <tbl_iv> 
    df.sort_values(['cid','date'], inplace=True)
    df['o_oi_i_chg']=df.groupby('cid')['o_oi'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['mp_i_chg']=df.groupby('cid')['mp'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['iv_i_chg']=df.groupby('cid')['iv'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['close_i_chg']=df.groupby('cid')['close'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    df['volume_i_chg']=df.groupby('cid')['volume'].apply(lambda x:x.div(x.iloc[0]).subtract(1))
    con_u= df['pid'].str[:1]=='U'
    con_days_pct=df['days_pct']<0.5
    
    dft=df[(~con_u) & con_days_pct]
    dv_q=dft[dft.date==q_date][['cid','mp_i_chg', 'mp','days_pct']].sort_values('mp_i_chg')
    print(dv_q)
    dv_1=pd.pivot_table(dft, index='date', columns='cid', values='mp_i_chg')
# plot mp_chg for all cid    
    dv_1.sort_values(by=q_date, ascending=False, axis=1, inplace=True)
    dv_1.plot(kind='line',  figsize=(16,8), rot=45, alpha=0.7)    

    dfu=df[con_u & con_days_pct]  
    dv_u=dfu[dfu.date==q_date][['cid','mp_i_chg', 'mp','days_pct']].sort_values('mp_i_chg')
    print(dv_u)
    du_1=pd.pivot_table(dfu, index='date', columns='cid', values='mp_i_chg')
#    dv_2.plot(kind='line',  figsize=(16,8), rot=45, alpha=0.7)
    du_1.sort_values(by=q_date, ascending=False, axis=1, inplace=True)
    du_1.plot(kind='line',  figsize=(16,8), rot=45, alpha=0.7)
#plot mp_chg, close_chg, iv_chg for each cid
#    for c in df.cid.unique().tolist():
#        dg=df[df.cid==c]
#        dg.plot(x='date', y=['close_chg','mp_chg','iv_chg'])
 #%%    
def prob_oc(df, q_date):  
    import scipy.stats
    col_val=['lc','strike','iop','iv']
    df=type_convert(df, col_val)
    #lc: live contract, lp: live price
    con_lc= (df.lc >0) & (df.type == 'C')
    con_sc= (df.lc <0) & (df.type == 'C')
    con_lp= (df.lc >0) & (df.type == 'P')
    con_sp= (df.lc <0) & (df.type == 'P')
 
    df.loc[con_lc, 'bedn']=df.loc[con_lc, 'strike'] + df.loc[con_lc, 'iop']
    df.loc[con_sc, 'beup']=df.loc[con_sc, 'strike'] + df.loc[con_sc, 'iop']
    df.loc[con_lp, 'beup']=df.loc[con_lp, 'strike'] - df.loc[con_lp, 'iop']
    df.loc[con_sp, 'bedn']=df.loc[con_sp, 'strike'] - df.loc[con_sp, 'iop']
    
    df['oexp_dt']=pd.to_datetime(df['oexp_dt'])
    df['dte']=df['oexp_dt'].subtract(q_date).dt.days
    df['std']=df['iv']*np.sqrt(df['dte']/252)
    df=type_convert(df, ['p','std'])
    for index, row in df.iterrows():
        std_p=row['p']*row['std']
        if row['beup']>0:
            df.loc[index, 'prob']=scipy.stats.norm.cdf(row['beup'], row['p'], std_p)
        elif row.bedn>0:
            df.loc[index, 'prob']=scipy.stats.norm.sf(row['bedn'], row['p'], std_p)
        else:
            pass
    df['prob']=df['prob'].astype(float).apply(lambda x: "{0:.0f}%".format(x*100))
    return df

#%%
def ptbl_cid_greek_derive(q_date):
    """
    use: to derive greeks from op_c, live oc only, excl. U1
    source: op_c, tbl_oc
    dest: tbl_cid_update
    note: i_: earlist cid entry_dt, thus pl_i_chg etc. only meaning for view by cid ONLY, not pid
    """
    df=read_sql("select * from op_c where oexp_dt>='%s' "%q_date)
    dt=read_sql("select * from tbl_oc WHERE exit_dt =='N' and oexp_dt>='%s' \
                AND substr(pid,1,1)<>'U'"%q_date)

    df=df[df.cid.isin(dt.cid)]
    df['o_dt']=pd.to_datetime(df['o_dt']).dt.date
#process data from op_c
    dict_list=[]
    for cid in df.cid.unique():
        dg=df[df.cid==cid]
        dg.sort_values('o_dt', inplace=True)
        i_delta=dg['delta'].head(1).values[0]
        delta_i_chg=dg['delta'].tail(1).values[0]-i_delta
        delta_p_chg=dg['delta'].tail(1).values[0]-dg['delta'].tail(2).head(1).values[0]
        i_vega=dg['vega'].head(1).values[0]
        vega_i_chg=dg['vega'].tail(1).values[0]-i_vega
        vega_p_chg=dg['vega'].tail(1).values[0]-dg['vega'].tail(2).head(1).values[0] 
        o_oi_chg=dg['o_oi'].tail(1).values[0]-dg['o_oi'].tail(2).head(1).values[0] 
#        o_oi_chg=dg['o_oi'].shift(-1)- dg['o_oi']
        #o_oi_i_chg is actually the net change since day2 of candy_dt, i.e.post-unop oi change
        o_oi_chg_pct=(dg['o_oi'].tail(1).values[0]/dg['o_oi'].tail(2).head(1).values[0])-1 
        o_oi_i_chg =dg['o_oi'].tail(1).values[0]-dg['o_oi'].head(2).tail(1).values[0] 
        o_oi_i_chg_pct =o_oi_i_chg /dg['o_oi'].head(2).tail(1).values[0]
        o_vol=dg['o_vol'].tail(1).values[0]
        delta=dg['delta'].tail(1).values[0]
        theta=dg['theta'].tail(1).values[0]
        gamma=dg['gamma'].tail(1).values[0]
        vega=dg['vega'].tail(1).values[0]
        bid=dg['bid'].tail(1).values[0]
        ask=dg['ask'].tail(1).values[0]
        sale=dg['sale'].tail(1).values[0]
        o_oi=dg['o_oi'].tail(1).values[0]
        delta_i=dg['delta'].head(1).values[0]
        theta_i=dg['theta'].head(1).values[0]
        gamma_i=dg['gamma'].head(1).values[0]
        vega_i=dg['vega'].head(1).values[0]
        delta_p=dg['delta'].tail(2).head(1).values[0]
        theta_p=dg['theta'].tail(2).head(1).values[0]
        gamma_p=dg['gamma'].tail(2).head(1).values[0]
        vega_p=dg['vega'].tail(2).head(1).values[0]
        keys=['cid', 'delta' ,'gamma', 'vega', 'theta',  'delta_i_chg', 'delta_p_chg', \
            'vega_i_chg', 'vega_p_chg', 'o_oi_chg', 'o_vol','bid','ask','sale','o_oi',\
            'o_oi_chg_pct', 'o_oi_i_chg', 'o_oi_i_chg_pct', \
            'delta_i','theta_i', 'gamma_i', 'vega_i', \
            'delta_p', 'theta_p', 'gamma_p', 'vega_p']
        vals=[cid, delta ,gamma, vega, theta, delta_i_chg, delta_p_chg, \
            vega_i_chg, vega_p_chg, o_oi_chg, o_vol, bid, ask, sale, o_oi,\
            o_oi_chg_pct, o_oi_i_chg, o_oi_i_chg_pct, \
            delta_i, theta_i, gamma_i, vega_i, 
            delta_p, theta_p, gamma_p, vega_p]     
        dic=dict(zip(keys, vals))
        dict_list.append(dic)
    dx=pd.DataFrame(dict_list)   #same shape as unique_cid
    return dx
    
#%%
def ptbl_cid_update(q_date, seg_by=''): #agg=='cid','acid', 'apid','bpid'
    """
    use: (live oc, excl. 'U'), merge tbl_oc field to tbl_cid
        tbl_cid: cacl mp, pl, risk_live, greek_i,greek_p, cid @q_date, mp=(mid, sale)
    source: tbl_oc, tbl_cid_greek_enrich()
    intel: by='acid','apid'
    view_by is at same cid level, just by 'acid' and 'apid' view 
    agg_to_pid_level; need calc btn differnt cids
    'ioc',iop is meaningless for view/agg by pid level
    
    pl attr: https://www.elitetrader.com/et/threads/explaining-options-p-l-by-greeks.321460/
    """
    print("tbl_%s _update started  ---"%seg_by)
#    if seg_by not in ['acid','apid','pid']:
#        return
#process data from op_c
    dx=ptbl_cid_greek_derive(q_date)
# process data from tbl_oc      
    dt=read_sql("select * from tbl_oc WHERE exit_dt =='N' and oexp_dt>='%s' \
                AND substr(pid,1,1)<>'U'"%q_date)
    dt['acid']=dt['act']+'-' + dt['cid']
    dt['bpid']=dt['ticker']+'-'+ dt['pid']
    dt['apid']=dt['act']+'-'+dt['bpid']
    
    dtx=dt.merge(dx, on='cid', how='left')
    da=pd.DataFrame()
    dp=pd.DataFrame()
#default always agg by 'act' level, then 'pid' or 'cid'
    for a in dtx['act'].unique().tolist():
        dax=dtx[dtx.act==a]
        
        if seg_by in ['cid','bpid']:  #not by act
            dax=dtx
#agg tid_to_cid level; cid level is unique by a/pid+cid
        list_pcid=(dax['%s'%seg_by]+dax['cid']).unique().tolist()
        for x in list_pcid:
# !! # prep to cid levels:  a/cid, or a/bpid+cid level
            dtp=dax[(dax['%s' %seg_by]+dax['cid'])== x]  
            df=agg_tid_to_cid(dtp, q_date)  #agg tid to cid level
            #df only contains new calcled fields, merged with original data set
            #but if pid, then df.shape=1, only need to merge with one row, as greeks are common data
#            if seg_by in ['apid','bpid']:
            dtp_head=dtp.head(1)

            df=dtp_head.merge(df, on ='cid', how='left')
            con_lc= df['lc'] >0
            df.loc[con_lc , 'mp']=df.loc[con_lc, 'bid']
            df.loc[ ~con_lc , 'mp']=df.loc[~con_lc, 'ask']
            df['pl_ur']=(df['mp']-df['lp'])*df['lc']*100
            df['pl']=df['pl_r']+df['pl_ur']-df['comm_c'].astype(float)
            #consider l or s
            df['pl_ur_pct']=(df['mp']/df['lp']-1)*(df['lc']/np.abs(df['lc']))  
            df['risk_live']=df['lc']*df['mp']*100
            df['delta_c']=df['delta']* df['lc']*100
            df['vega_c']=df['vega']* df['lc']*100
            df['theta_c']=df['theta']* df['lc']*100
            df['gamma_c']=df['gamma']* df['lc']*100
            df['date']=q_date
            dp=pd.concat([dp, df], axis=0)
            #to ensure comparion is equal for 'cid' and 'pid'
            dp.sort_values(['act','ticker','pid','cid'], inplace=True)
            dp.reset_index(drop=True, inplace=True)
# if by 'cid' then each loop by act has equal dataframe, then no more concat after first one (breakloop)            
        if ~da.equals(dp):
            da=pd.concat([da, dp], axis=0)
# dp has only live cid, while dx has older cid too    
    #extr col to tbl_cid
    col_oc_keep=['ticker','cid','acid', 'apid','bpid']
    col_oc=dt.columns.tolist()
    col_oc_drop=list(set(col_oc)-set(col_oc_keep))
    col_a=da.columns.tolist()
    col_a_keep=[x for x in col_a if x not in col_oc_drop]
    da=da[col_a_keep]
    col_val=['delta_p', 'theta_p', 'gamma_p', 'vega_p']
    da=type_convert(da, col_val, 'float')
    
#    col_sanity=['pl_ur','risk_live','mp','o_oi_i_chg',\
#         'delta_i_chg','vega_i_chg','delta_p_chg','gamma_p']
#    sanity_alert=sanity_check(df, col_sanity)
#    if sanity_alert:
#        cprint("tbl_cid_update: sanity alert: bad_data_pct>50%", 'red', 'on_white')
#        return
#    tbl_nodupe_append(q_date, da, 'tbl_cid')
#    tbl_nodupe_append(q_date, da, 'tbl_%s'%view_by)
    if seg_by in ['acid','bpid','apid']:
        tbl_nodupe_append(q_date, da, 'tbl_%s'%seg_by)
    return da

#%%        
def agg_tid_to_cid(dp, q_date):
    """
    use:  aggregate tids to cid level ->cacl pl_r, lc, lp, comm_c@cid (sum)
    source: tbl_oc
    dest: update_tbl_cid()
    intel: pl_r change at each cacl, but key is pl_all. pl_r has no comm
    note: pl_r just need tbl_oc (exit_dt, and lc/lp) then pl_r can be calculated from tbl_oc alone
    ioc, iop meaning is lost in view_by_pid or agg_by_pid
    """
#    dc=read_sql("select * from tbl_oc WHERE exit_dt =='N' and oexp_dt>='%s' \
#                AND substr(pid,1,1)<>'U'"%q_date)
    dc=dp.sort_values('uid')   #no_mute
    
    dc.sort_values('uid',axis=0, inplace=True)
    col_val=['comm','ioc','iop']
    dc=type_convert(dc, col_val)
    dict_list=[]
    for cid in dc.cid.unique():
        df=dc[dc.cid==cid] #contain trde history per cid
        df_ic=df[df.ioc>0]
        if not df_ic.empty:
            sum_ic=df_ic.ioc.sum()
            prem_ic=(df_ic['ioc']*df_ic['iop']).sum()
            lp_avg_ic=prem_ic/ sum_ic  #average price for buy contracts
        else:
            sum_ic=0
            prem_ic=0
            lp_avg_ic=0
        
        df_oc=df[df.ioc<0]
        if not df_oc.empty:
            sum_oc=np.abs(df_oc.ioc.sum())
            prem_oc=(df_oc['ioc']*df_oc['iop']).sum()   
            lp_avg_oc=prem_oc/ sum_oc  #average price for sold contracts
        else:
            sum_oc=0
            prem_oc=0
            lp_avg_oc=0
        lc=df['ioc'].sum()
        comm=df['comm'].sum()
        if lc>0: # bought more than sold
            lp= lp_avg_ic
            pl_r=sum_oc *( lp_avg_oc - lp_avg_ic)*100
        else:
            lp= np.abs(lp_avg_oc) # as lp always positive
            pl_r=sum_ic *( lp_avg_ic - lp_avg_oc)*100
        keys=[ 'cid', 'lc', 'lp', 'pl_r','comm_c']
        vals=[ cid, lc, lp, pl_r, comm]
        dic=dict(zip(keys, vals))
        dict_list.append(dic)
    df=pd.DataFrame(dict_list)
    con_pl_r=pd.isnull(df['pl_r'])
    df.loc[con_pl_r, 'pl_r']=0
    return df
    #pid, or should be dt for live_oc only
#    dt['srtn_22_chg']=dt['srtn_22_pct']-dt['i_srtn_22_pct']
#    dt['rtn_22_chg']=dt['rtn_22_pct']-dt['i_rtn_22_pct']
#    dt['hv_22_chg_pct']=dt['hv_22']/dt['i_hv_22']-1
    #    dt['rsi_chg']=dt['rsi']<dt['i_rsi']
    #reporting            
#    dt['v_und']=dt['delta_c']*dt['close']
#    spy=read_sql("select close from tbl_pv_etf where ticker ='SPY'")
#    spy=spy.tail(1).iloc[0,0]
#    dt['beta']=dt['beta'].replace('',1).astype(float)
#    dt['v_spy']=dt['v_und']*dt['beta']/spy
#

#%%
def cid_calc_var(df):
    """
    use: cacl var_greeks,
    source: tbl_cid, cid_calc_iv(need iv)
    dest: tbl_cid
    """
    df['atr_iv']=df['p']*df['iv']*np.sqrt(1/252)
    df['var_delta']=df['atr_iv']*df['delta'] *df['lc']*100
    df['var_gamma']=df['gamma']* 0.5 * 0.5* df['atr_iv']*df['lc']*100
    df['var_theta']=df['theta']*df['lc']*100
    df['var_iv']=np.abs(df['var_delta'])+np.abs(df['var_gamma']+df['var_theta'])
    
    return df
#    df['var_iv']=np.abs(df['var_delta'])+np.abs(df['var_gamma']+df['var_theta'])
    
#%%    
def pCID_pl_attr(q_date, seg_by=''):  #seg_by: acid
    """
    use: append tbl_cid with pl_attr explained & outlier
    source: tbl_cid, cid_calc_iv() (from tbl_iv, tbl_oc)
    dest: tbl_cid
    alert: pl_ur_pct, 
    note: p_u_chg is accuare (based on entry_dt, tbl_pv_all)
    pl_greek (greek_i depends on tbl_iv avaibability - up to watchlist updated date), can be off
    #https://www.elitetrader.com/et/threads/explaining-options-p-l-by-greeks.321460/
    """
    print("CID_pl_attr_%s started ......."%seg_by )

    pl_exp_pct=0.7
    pl_ur_pct_min=0.3
#get iv data    
    div=cid_calc_iv(q_date)
    div['date']=pd.to_datetime(div['date'])
    div['entry_dt']=pd.to_datetime(div['entry_dt'])  
    
    #exclude unop trade, but might include exired cid as tbl_cid has not expir info
    #this will be updated by tbl_iv data
    did=read_sql("select * from tbl_%s WHERE comm_c IS NOT NULL"%seg_by)  
    did['date']=pd.to_datetime(did['date'])
# !! get mp_chg, pl_chg wiht new approach
    did.sort_values(['cid','date'], inplace=True)
    did['mp_p_chg']=did.groupby('cid')['mp'].apply(lambda x:x-x.shift(1))
    did['pl_p']=did['mp_p_chg']*did['lc']*100
    
    did=did[did.date==q_date]
#    did['ticker']=did['cid'].str.split('-').str[0]
    share_vd=['iv_d', 'iv_i_chg', 'iv_i_rank', 'p_i_chg']
    col_did=[x for x in did.columns.tolist() if not x in share_vd]
    #merge on live div only
    df=did[col_did].merge(div, on=['ticker','date'], how='right')
    col_val=['delta_p', 'theta_p', 'gamma_p', 'vega_p']
    df=type_convert(df, col_val, 'float')
    
    df['pl_delta']=df['delta_i']  *df['lc']*100* df['p_i_chg']
    df['pl_vega']=df['vega_i'] *df['lc']*100* df['iv_i_chg']*100  
    df['pl_gamma']= (df['gamma_i'] + df['gamma']) * 0.5 *df['lc']*100* 0.5* (df['p_i_chg'] **2 )
    df['theta_dt']=df['date'].subtract(df['entry_dt']).dt.days      
    df['pl_theta']=(df['theta'] + df['theta_i'])*0.5 * df['lc']*100* df['theta_dt']   
    df['pl_exp']=df['pl_delta']+df['pl_vega']+df['pl_theta']+df['pl_gamma']
    df['pl_exp_pct']=df['pl_exp']/df['pl'].astype(float)
   
# daily pl_attr
    df['pl_p_delta']=df['delta_p']*df['lc']*100* df['p_chg'] 
    df['pl_p_vega']=df['vega_p']*df['lc']*100* df['iv_chg']*100  
    df['pl_p_gamma']= df['gamma_p']*df['lc']*100* 0.5* (df['p_chg'] **2 )
    df['pl_p_theta']= df['theta_p'] * df['lc']*100
    df['pl_p_exp']= df['pl_p_delta'] +  df['pl_p_vega']+ df['pl_p_gamma']+ df['pl_p_theta']
    df['pl_p_exp_pct']=df['pl_p_exp']/df['pl_p'].astype(float)
   
    df=cid_calc_var(df)
    
# data sanity check
    col_sanity=['atr_iv', 'var_delta','var_gamma','var_theta','var_iv']
    sanity_alert=sanity_check(df, col_sanity)
    if sanity_alert:
        cprint("CID_pl_attr sanity alert: bad_data_pct>20%", 'red', 'on_white')
        return    
    
    con_out=np.abs(df['pl_exp_pct']-1)> (1- pl_exp_pct)
    con_p_out_1=np.abs(df['pl_p_exp_pct']-1)> (1- pl_exp_pct)
    con_p_out_2= df['pl_p_exp_pct']< (pl_exp_pct-1)
    con_p_out= con_p_out_1 | con_p_out_2
    
    col=['cid','pl_ur_pct','pl', 'lp', 'mp', 'pl_exp_pct','pl_delta','pl_vega', 'pl_gamma', 'pl_theta',\
         'pl_p_exp_pct', 'pl_p', 'pl_p_delta','pl_p_vega', 'pl_p_gamma', 'pl_p_theta']
    try:  #re_fun might be error if already %
        col_fmt=['pl_ur_pct', 'pl']
        df=fmt_map(df, col_fmt)
        df[['pl_ur_pct', 'pl_exp_pct', 'pl_p_exp_pct']] =df[['pl_ur_pct', 'pl_exp_pct', 'pl_p_exp_pct']].astype(float).applymap(lambda x: "{0:.0f}%".format(x*100))
    except:
        pass
    pd.set_option('display.expand_frame_repr', False)
    print("pl_outlier \n", df[con_out][col])
    print("pl_p_outlier: \n", df[con_p_out][col])
    pd.set_option('display.expand_frame_repr', True)
 # drop tbl_cid@q_date then add enriched back
    col_cid=did.columns.tolist()
    col_pl= ['pl_theta', 'pl_gamma', 'iv_i_rank', 'pl_exp', 'theta_dt', \
        'pl_delta', 'pl_vega', 'iv_i_chg', 'pl_exp_pct', 'p_i_chg', 'iv_d',\
        'pl_p_exp_pct', 'pl_p_exp','pl_p_delta','pl_p_vega', 'pl_p_gamma', 'pl_p_theta',\
        'pl_p', 'mp_p_chg']
    col_var=['atr_iv','var_delta','var_gamma','var_theta','var_iv']
    col_new=col_cid + col_pl+col_var
    col=list(set(col_new))  #drop duplicated 'var_delta'?
    if df.empty | (df.shape[0]==0) :
        print("cid_pl_attr: df empty")
        return
    

    if seg_by not in ['acid','apid','bpid']:
        return 
    conn=get_conn()
    cur=conn.cursor()
#    q_datetime=datetime.datetime(q_date.year, q_date.month, q_date.day)
    cur.execute("DELETE FROM tbl_%s WHERE date >='%s' "%(seg_by, q_date))
    conn.commit()
    cur.close()
    
    tbl_nodupe_append(q_date, df[col], 'tbl_%s'%seg_by)
    
    return df[col]
    
#%%    
def cid_calc_iv(q_date):  
    """
    use: cacl iv_i_chg, iv_i_rank, p_i_chg, iv_p ('i_date' depends on 'entry_dt'@tbl_oc
       , prep for cid_pl_attr()
    source: tbl_oc, tbl_iv, tbl_pv_all
    dest: cid_pl_attr()
    key: entry_dt must be accurate to decide the p_i_chg
    """
    div=read_sql("select * from tbl_iv")
    #tbl_oc: for entry_dt to decide i_date
    dt=read_sql("select * from tbl_oc WHERE exit_dt =='N' and oexp_dt>='%s' \
                AND substr(pid,1,1)<>'U'"%q_date)
    #tbl_pv_all: for p_i in case watchlist is added later
    dp=read_sql("select * from tbl_pv_all")
    dp['date']=pd.to_datetime(dp['date'])
    dtv=div.merge(dt[['ticker','entry_dt']], on ='ticker', how='right')
    dtv['date']=pd.to_datetime(dtv['date'])
    dtv['entry_dt']=pd.to_datetime(dtv['entry_dt'])
    col_val=['iv','p']
    dtv=type_convert(dtv, col_val)
    df=pd.DataFrame()
    for t in dtv.ticker.unique().tolist():
        dg=dtv[dtv.ticker==t]
        dg.sort_values('date', inplace=True)
        #exclude tikcer from previous trade 
        dg=dg[dg.date>=dg.entry_dt]   
        dpt=dp[dp.ticker==t] 
        entry_dt=dg['entry_dt'].head(1).values[0]
        try:
            try:  #if entry_dt==q_date and EOD not ready yet
                p_i=dpt[dpt.date==entry_dt]['close'].values[0]
            except:
                p_i=dg['p'].head(1).values[0]
            dg['iv_i_chg']=dg['iv'].tail(1).values[0]-dg['iv'].head(1).values[0] 
            dg['iv_chg']=dg['iv'].tail(1).values[0]-dg['iv'].tail(2).head(1).values[0]
            dg['iv_i_rank']=dg['iv_rank'].head(1).values[0]
            dg['p_i_chg']=dg['p'].tail(1).values[0]- p_i

        except:
            print("cid_calc_iv error:", t)
            pass
        #get snapshot @q_date only
        dg=dg.tail(1)
        df=pd.concat([df, dg], axis=0)
#    col=['date', 'div','div_dt', 'earn_dt_mc', 'entry_dt', 'ind', 'iv', 'iv_1y', 'iv_chg_pct',
#       'iv_d', 'iv_i_chg_pct', 'iv_i_rank', 'iv_rank', 'mcap', 'oi', 'oi_c',
#       'oi_p', 'oi_p_pct', 'p', 'p_chg', 'p_chg_pct', 'p_i_chg', 'sec',
#       'spike_iv', 'ticker', 'vol', 'vol_pct', 'vol_stk', 'yld']
    return df

def cid_sanity_check():
    """
    live cid cnt: tbl_oc, tbl_cid, op_c
    """
    max_dt=read_sql("select max(date) from tbl_cid").iloc[0].values[0]
    dt=read_sql("select * from tbl_oc WHERE exit_dt =='N' and oexp_dt>='%s' \
                AND substr(pid,1,1)<>'U'"%max_dt)
    
    op_c=read_sql("select * from op_c where oexp_dt>='%s' AND o_dt>='%s' "%(max_dt, max_dt))
    dcid=read_sql("select * from tbl_cid where date>='%s' "%max_dt)
    lt=dt.cid.unique().tolist()
    lo=op_c.cid.unique().tolist()
    lc=dcid.cid.unique().tolist()
    
    shared_cid=list(set(lt) & set(lo) & set(lc))
    lt_ex=set(lt)-set(shared_cid)
    lo_ex= set(lo)-set(shared_cid)
    lc_ex= set(lc)-set(shared_cid)
    
    sanity_cid= {'tbl_oc':lt_ex, 'op_c': lo_ex, 'tbl_cid': lc_ex}
    print(sanity_cid)
    
#%%
def cacl_beta():
    # import libraries
    #https://medium.com/python-data/capm-analysis-calculating-stock-beta-as-a-regression-in-python-c82d189db536
    import pandas as pd
    import statsmodels.api as sm
    

    fb = pd.read_csv('FB.csv', parse_dates=True, index_col='Date',)
    sp_500 = pd.read_csv('^GSPC.csv', parse_dates=True, index_col='Date')
    
    # joining the closing prices of the two datasets 
    monthly_prices = pd.concat([fb['Close'], sp_500['Close']], axis=1)
    monthly_prices.columns = ['FB', '^GSPC']
    
    # check the head of the dataframe
    print(monthly_prices.head())
    
    # calculate monthly returns
    monthly_returns = monthly_prices.pct_change(1)
    clean_monthly_returns = monthly_returns.dropna(axis=0)  # drop first missing row
    print(clean_monthly_returns.head())
    
    # split dependent and independent variable
    X = clean_monthly_returns['^GSPC']
    y = clean_monthly_returns['FB']
    
    # Add a constant to the independent value
    X1 = sm.add_constant(X)
    
    # make regression model 
    model = sm.OLS(y, X1)
    
    # fit model and print results
    results = model.fit()
    print(results.summary())    
    