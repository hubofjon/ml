# -*- coding: utf-8 -*-
"""
sub_func
    1.get_DIV, (nasdaq: div_dt, yld, pe, beta)
    2.get_RSI (calc: rsi -14 days)
    3. get_SI (sqz: si, si_chg, si_dtc, cap, inst)
    3.1 get_si (alternative: nasdaq)
    4. get_EARN (whisper)

Not in use: 
    6. view_corr_etf  (180 day ETF correlation to SPY)
    7. view_rtn_etf
    8. view_corr_tsv  (22 days sp500 components correlation, sector, Vxx)
    9. view_unpv  (Today's unusual price, volume change)
    10.get_trades_marketbeat  (live trades: rating, headline, insider)
    11.marketbeat (rating, news, insider)
    12.get_ta (stocktrendchart.com    weekly trend reading)
    13.get_betas (get beta of all sp500 stocks nasdaq.com)
    14.get_share_nasdaq (nasdaq.com, ex_div, beta )
"""
import pandas as pd
import numpy as np 
import datetime as datetime
#from pandas_datareader import data as pdr
#from timeit import default_timer as timer
#import bs4
#import requests
import time
import warnings
warnings.filterwarnings("ignore")
from termcolor import colored, cprint
from P_commons import read_sql, type_convert, reg_convert, get_proxies, get_ua
from pandas.tseries.offsets import BDay

#from fake_useragent import UserAgent
today=datetime.datetime.today()
todate=today.date()
LBdate=(todate-BDay(1)).date()

def get_soup(url):
    import requests
    import bs4
    from random import randint
    from time import sleep
    #scrape_para
    user_agent = get_ua()
    user_agent_perm='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36'
#    proxy_pool=get_proxies()
    referer="https://google.com" #http://www.nasdaq.com" #  # ,
    timeout=(30,20)   #connection, page laod
#    proxy_pool=get_proxies()
    headers = {
        "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding":"gzip, deflate",
        "Accept-Language":"en-GB,en;q=0.9,en-US;q=0.8,ml;q=0.7",
        "Connection":"keep-alive",
#        "Host":"www.nasdaq.com",
        "Referer":referer,
        "Upgrade-Insecure-Requests":"1",
        #"User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.119 Safari/537.36"
        "User-Agent":user_agent_perm
        
        }
    #try proxies first
#    try: 
#        for i in range(0,len(proxy_pool)):
#    #        proxy = next(proxy_pool)
#            proxy=proxy_pool[i]
#            proxies={"http": proxy, "https": proxy}
#            try:  # connation via proxy might throw excpetion wro response
#                response = requests.get(url,headers=headers, proxies=proxies, timeout=timeout, verify=False)
#                if response.status_code== 200 :  #exit loop if good
#                    i=100    
#            except:
#                i+=1
#    #try non-proxy  
#    except:
    try:
        response = requests.get(url,headers=headers,timeout=timeout, verify=False)
        if response.status_code!=200:
            return ("respond code <> 200 ")
    except:
        raise ValueError("Invalid Response")
    sleep(randint(1,3))   
    soup = bs4.BeautifulSoup(response.text, 'html.parser')
#    page_count= soup.select('.pager-pages > li > a')
#    if ~ page_count:
#        print("no page returned to soup")
#        return
    return soup

class get_CONTRACT_oo():
    """
    use: get greeks from nasdaq
    argument: from tbl_c, expiry@datetime, 
    source:
    """
    def __init__(self, ticker, expiry='',  cp='', strike='' ):
       
        self.ticker=ticker
        self.expiry=expiry
        self.cp=cp
        self.strike=strike
        
    def get_greeks_oo(self):
        cp=self.cp.lower()
        strike=str(int(self.strike*1000)).rjust(8,'0')
        expiry=self.expiry.strftime('%y%m%d')
        contract=(expiry + self.cp + strike).upper()
        cid=self.ticker.upper()+contract
        url= 'https://www.nasdaq.com/symbol/{0}/option-chain/{1}-{0}-call'.format(self.ticker, contract)
            
        soup=get_soup(url)
        mkt_dt=soup.find('span', {"id":"qwidget_markettime"}).text
        oi=soup.find(text='Open Interest').findNext('span').text
        vol=soup.find(text='Volume').findNext('span').text
        close=soup.find(text='Last Sale').findNext('span').text
        close_prev=soup.find(text='Prev Close').findNext('span').text
        bid=soup.find(text='Bid').findNext('span').text
        ask=soup.find(text='Ask').findNext('span').text
        if cp=='c':
            color='yellow'
        else:
            color='white'
        id='%s-delta'%color
        delta=soup.find(id='%s-delta'%color).findNext('span').findNext('span').text
        theta=soup.find(id='%s-theta'%color).findNext('span').findNext('span').text        
        vega=soup.find(id='%s-vega'%color).findNext('span').findNext('span').text  
        gamma=soup.find(id='%s-gamma'%color).findNext('span').findNext('span').text
        
        keys=['mkt_dt','cid', 'ticker','expiry','strike','cp', 'bid','ask','close','close_prev', 'oi','vol','delta','theta','vega','gamma']
        vals=[mkt_dt, cid, self.ticker, self.expiry, strike, cp, bid, ask, close, close_prev, oi, vol, delta, theta, vega, gamma]
        return dict(zip(keys, vals))
#%%
def get_greeks(cid):
#    type=type.lower()
#    strike=str(int(self.strike*1000)).rjust(8,'0')
#    expiry=self.expiry.strftime('%y%m%d')
#    contract=(expiry + self.cp + strike).upper()
#    cid=self.ticker.upper()+contract
    ticker=cid.split('-')[0]
    contract=cid.split('-')[1]
    url= 'https://www.nasdaq.com/symbol/{0}/option-chain/{1}-{0}-call'.format(ticker, contract)
        
    soup=get_soup(url)
    p=soup.find('div', {"id":"qwidget_lastsale"}).text
    p=p.replace('$','')
    o_dt=soup.find('span', {"id":"qwidget_markettime"}).text
    o_oi=soup.find(text='Open Interest').findNext('span').text
    o_vol=soup.find(text='Volume').findNext('span').text
    sale=soup.find(text='Last Sale').findNext('span').text
    sale_prev=soup.find(text='Prev Close').findNext('span').text
    bid=soup.find(text='Bid').findNext('span').text
    ask=soup.find(text='Ask').findNext('span').text
    if 'C' in contract.upper():
        color='yellow'
    else:
        color='white'
    delta=soup.find(id='%s-delta'%color).findNext('span').findNext('span').text
    theta=soup.find(id='%s-theta'%color).findNext('span').findNext('span').text        
    vega=soup.find(id='%s-vega'%color).findNext('span').findNext('span').text  
    gamma=soup.find(id='%s-gamma'%color).findNext('span').findNext('span').text
    
    keys=['cid','p','o_dt', 'bid','ask','sale','sale_prev', 'o_oi','o_vol','delta','theta','vega','gamma']
    vals=[cid, p, o_dt, bid, ask, sale, sale_prev, o_oi, o_vol, delta, theta, vega, gamma]
    return dict(zip(keys, vals))

#%%
def get_response(ticker='KEM'):
    """
    use: test ext. site availability
    
    """
    import requests
    import bs4
    from random import randint
    from time import sleep
    url_mc="https://marketchameleon.com/Reports/UnusualOptionVolumeReport"
    url_earn = "https://www.earningswhispers.com/stocks/" + ticker
    url_si= "http://shortsqueeze.com/?symbol="+ ticker
    url_fun= "https://www.barchart.com/stocks/quotes/"+ ticker +"/profile"
    url_op= 'https://www.nasdaq.com/symbol/' + ticker
    url_op="https://www.nasdaq.com/symbol/kem/option-chain/200117P00018000-kem-put"
    urls=[url_mc, url_earn, url_si, url_fun, url_op]
    #scrape_para
    user_agent_perm='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.108 Safari/537.36'
    referer="https://google.com" #http://www.nasdaq.com" #  # ,
    timeout=(30,20)   #connection, page laod
    headers = {
        "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding":"gzip, deflate",
        "Accept-Language":"en-GB,en;q=0.9,en-US;q=0.8,ml;q=0.7",
        "Connection":"keep-alive",
        "Referer":referer,
        "Upgrade-Insecure-Requests":"1",
        "User-Agent":user_agent_perm       
        }
    res=[]
    for url in urls:
        try:
            r_code = requests.get(url,headers=headers,timeout=timeout, verify=False)
#            if response.status_code!=200:
#                return ("respond code <> 200 ")
        except:
            r_code='invalid response'
#        r={url: r_code}
#        res.append(r)
        print("get_response: %s  "%url, r_code.status_code) 

#%%
def get_FUN_table(tick=''):
    url='https://www.barchart.com/stocks/quotes/'+tick+'/profile'
    dt=pd.read_html('https://www.barchart.com/stocks/quotes/CCK/profile', header=None)
    dt[3].columns=[0,1]
    df=pd.concat([dt[x] for x in range(len(dt))], axis=0)
    dict_fun=df.set_index(0)[1].to_dict()
    return dict_fun
    

def get_FUN(tick=''):
    """
    use: if mode =='candy': return ta, eg, earn_dt, yld, sector
         if 'spec': ta, beta, eg, ps, pcf, pb, pe, earn_dt, div, yld, sector, news
    source: barchart
    """

    url='https://www.barchart.com/stocks/quotes/'+tick+'/overview'  

    soup=get_soup(url)
   
    ta= soup.find(text='Barchart Technical Opinion').findNext('a').text.strip()
    ta=ta.replace(' ','')[:12]
    #fundamental
    beta=soup.find(text='60-Month Beta').findNext('span').text.strip()
    pe=soup.find(text='Price/Earnings ttm').findNext('span').text.strip()
    earn_dt=soup.find(text='Next Earnings Date').findNext('span').text 
    earn_last=soup.find(text='Most Recent Earnings').findNext('span').text
    
    eg=soup.find(text='Growth Rate Est. (year over year)').findNext('span').text
    sector=soup.find(text='Sectors:').findNext('span').text.strip()
    sector=sector.replace(' ','')[8:24]
   
    ps=soup.find(text='Price/Sales').findNext('span').text
    pcf=soup.find(text='Price/Cash Flow').findNext('span').text
    pb=soup.find(text='Price/Book').findNext('span').text
    divyld=soup.find(text='Annual Dividend & Yield').findNext('span').text
    div=divyld.split()[0]
    yld=divyld.split()[1]
    yld=yld.replace('(','').replace(')','').replace('%','')
    
    stories=soup.find_all('div',{'class':'story clearfix'})
    news=[]
    for story in stories[:4]:
        news.append(story.get_text().split('-')[:2])
    col_val=[ta, beta, pe, earn_dt, earn_last, eg, sector, ps, pb, pcf, div, yld, news]
    col_key=['ta', 'beta', 'pe', 'earn_dt', 'earn_last', 'eg', 'sector', 'ps', 'pb'\
             , 'pcf', 'div', 'yld', 'news']
    return dict(zip(col_key, col_val))

def get_FUN_new(ticker=''):
    """
    use: if mode =='candy': return ta, eg, earn_dt, yld, sector
         if 'spec': ta, beta, eg, ps, pcf, pb, pe, earn_dt, div, yld, sector, news
    source: barchart
    """
    url='https://www.barchart.com/stocks/quotes/'+ticker+'/overview'  
    soup=get_soup(url)
    txt=ticker.upper() + ' Related stocks'
    table=soup.find(text= txt).findNext('table')
    arry=[]
    lis=[]
    for tr in table.find_all('tr'):
        for td in tr.find_all('td'):
            val=td.get_text()
            lis.append(val)
        arry.append(lis)
        lis=[]
    peers=[x for x in arry if len(x)==2]       
    peers=np.asarray(peers)
    peers=np.transpose(peers)
    col=['ticker','rtn_66']
    peers=dict(zip(col, peers))
    return peers
#    ta= soup.find(text='Barchart Technical Opinion').findNext('a').text.strip()
#    ta=ta.replace(' ','')[:12]
#    beta=soup.find(text='60-Month Beta').findNext('span').text.strip()
    """
    pe=soup.find(text='Price/Earnings ttm').findNext('span').text.strip()
    earn_dt=soup.find(text='Next Earnings Date').findNext('span').text 
    earn_last=soup.find(text='Most Recent Earnings').findNext('span').text
    
    eg=soup.find(text='Growth Rate Est. (year over year)').findNext('span').text
    sector=soup.find(text='Sectors:').findNext('span').text.strip()
    sector=sector.replace(' ','')[8:24]
   
    ps=soup.find(text='Price/Sales').findNext('span').text
    pcf=soup.find(text='Price/Cash Flow').findNext('span').text
    pb=soup.find(text='Price/Book').findNext('span').text
    divyld=soup.find(text='Annual Dividend & Yield').findNext('span').text
    div=divyld.split()[0]
    yld=divyld.split()[1]
    yld=yld.replace('(','').replace(')','').replace('%','')
    """
#    stories=soup.find_all('div',{'class':'story clearfix'})
#    news=[]
#    for story in stories[:4]:
#        news.append(story.get_text().split('-')[:2])
#    col_val=[ta, beta, pe, earn_dt, earn_last, eg, sector, ps, pb, pcf, div, yld]
#    col_key=['ta', 'beta', 'pe', 'earn_dt', 'earn_last', 'eg', 'sector', 'ps', 'pb'\
#             , 'pcf', 'div', 'yld']
#    return dict(zip(col_key, col_val))

#%%
def get_DIV(ticker=''):
    import requests
    import bs4
    import re
    from lxml import html
    from lxml import etree
    url = 'http://www.nasdaq.com/symbol/' + ticker#.lower()
#    request = requests.get(earnings_url)
#    soup = bs4.BeautifulSoup(request.text, 'html.parser')
    soup=get_soup(url)
    try:    
        div_dt= soup.find(text="Ex Dividend Date").find_next('div').text.strip()
    except:
        div_dt='N/A'
#    try:    
#        yld= soup.find(text="Current Yield").find_next('div').text.strip()
#        yld=float(yld.replace('%','').replace(' ',''))
#    except:
#        yld=0
#    try:
#        pe=soup.find(text="P/E Ratio").find_next('div').text.strip()
#        pe=float(pe.replace('NE','0'))
#    except:
#        pe=0
#    try:        
#        pe_f=soup.find(text="Forward P/E (1y)").find_next('div').text.strip()
#        pe=float(pe.replace('NE','0'))
#    except:
#        pe_f=0
#    try:
#        beta=soup.find(text="Beta").find_next('div').text.strip()
#        beta=float(beta)
#    except:
#        beta=0
#        tree = html.fromstring(request.content)
#        tbl="""//div[@class="genTable thin"]/table/tbody/"""
#        ex_div=tree.xpath(tbl+'/tr[12]/td[2]/text()')
#    keys=['div_dt', 'yld', 'pe', 'pe_f', 'beta']
#    values=[div_dt, yld, pe, pe_f, beta]
#        
#    return dict(zip(keys, values))
    return {'div_dt':div_dt}
#%%
def get_RSI(series, period):
    delta = series.diff().dropna()
    u = delta * 0
    d = u.copy()
    u[delta > 0] = delta[delta > 0]
    d[delta < 0] = -delta[delta < 0]
    u[u.index[period-1]] = np.mean( u[:period] ) #first value is sum of avg gains
    u = u.drop(u.index[:(period-1)])
    d[d.index[period-1]] = np.mean( d[:period] ) #first value is sum of avg losses
    d = d.drop(d.index[:(period-1)])
    rs = pd.stats.moments.ewma(u, com=period-1, adjust=False) / \
         pd.stats.moments.ewma(d, com=period-1, adjust=False)
 #https://stackoverflow.com/questions/20526414/relative-strength-index-in-python-pandas   
#    data = pd.Series( [ 44.34, 44.09, 44.15, 43.61,46.03, 46.41, 46.22, 45.64 ] )
    return 100 - 100 / (1 + rs)   

def get_SIs_sqz(df):
    for index, row in df.iterrows():
        ticker=row['ticker']
        try:
            names=['si', 'si_chg', 'pe', 'hi_1y_fm', \
                   'lo_1y_fm', 'ma_200_fm', 'ma_50_fm', 'sec','ind']
            df=pd.concat([df,pd.DataFrame(columns=names)])
            df.loc[index,names]=get_si_sqz(ticker)
            #ds=ds.append(df)
        except:
            print("error: ", ticker)
            pass
    return df
#%%
def get_SI(ticker=''):
    import urllib3
    import bs4
    import requests
    import re
    http=urllib3.PoolManager()
    url = "http://shortsqueeze.com/?symbol=" + ticker + "&submit=Short+Quote%E2%84%A2"
    soup=get_soup(url)
#    si=soup.find('div', class="Short Percent of Float")
#    tag = soup.find(text=re.compile('Short Percent of Float*'))
    ts=soup.get_text()
    ts=ts.split("\n")
    s0='Short Percent of Float'
    s1='Short % Increase / Decrease'
    s2='Short Interest Ratio (Days To Cover)'
    s3='Market Cap.'
    s4='% Owned by Institutions'
    s=[s0,s1,s2,s3]
    i0=ts.index(s0)
    si=float(ts[i0+1].strip().replace(" ","").replace("%","").replace("",'0'))/100
    si='{:.2f}'.format(si)
    
    i1=ts.index(s1)
    si_chg=float(ts[i1+1].strip().replace(" ","").replace("%",""))/100

    i2=ts.index(s2)
    si_dtc=float(ts[i2+1].strip().replace(" ",""))     
    si_dtc=float(ts[i2+1].strip().replace(" ","")) 
    
    i3=ts.index(s3)
    m_cap=float(ts[i3+2].strip().replace(" ","").replace(",",""))/1000000000
    m_cap='{:.2f}'.format(m_cap)
    
    i4=ts.index(s4)
    inst=float(ts[i4+1].strip().replace(" ","").replace("%","").replace("",'0'))/100
    inst='{:.2f}'.format(inst)
    
    keys=['si','si_chg', 'si_dtc','m_cap','inst']
    values=[float(si), si_chg, si_dtc, float(m_cap), float(inst) ]
    return dict(zip(keys,values))
#%%
def get_EARN(ticker=''):
    import urllib3
    import bs4
    import requests
    import re
    import datetime
    from dateutil import parser
    http=urllib3.PoolManager()
    url = "https://www.earningswhispers.com/stocks/" + ticker 
#    request = requests.get(url)
#    soup = bs4.BeautifulSoup(request.text, 'html.parser')
    soup=get_soup(url)
    earn_list=soup.find_all('div', attrs={"class":"mainitem"})
    for e in earn_list:
        if e.text !='N/A':
            earn_dt=e.text
        else:
            pass
    earn_dt=earn_dt + ' 2019'
    earn_dt=parser.parse(earn_dt)
    return earn_dt
#    earn_dt=earning.next_sibling.get_text()
#    earning_time=soup.find('div', id="earningstime").get_text()
#    st=soup.find('div', id="stprice")
#    st=st['class'][2].split("-")[1]
#    it=soup.find('div', id="itprice")['class'][2].split("-")[1]
#    lt=soup.find('div', id="ltprice")['class'][2].split("-")[1]    
#    i_sent=soup.find('div', id="vsent")['class'][2].split("-")[1]
#    a_sent=soup.find('div', id="asent")['class'][2].split("-")[1]  
#    com=soup.find('div', attrs={"class":"lowerboxcont"}).get_text()     
    #add Year to earning date
    today=datetime.datetime.today()
    earn=datetime.datetime.strptime(earn_dt, '%b %d' )
    if earn.month < today.month:
        earn_year=today.year+1
    else:
        earn_year=today.year
    earn_dt=datetime.datetime(earn_year,earn.month,earn.day).date()
    return earn_dt
        
def get_si_nasdaq(ticker=''):
    import urllib3
    import bs4
    import requests
    
    http=urllib3.PoolManager()
    url = "http://www.nasdaq.com/symbol/" + ticker + "/short-interest"
    res=http.request('GET', url)
    html=res.read()
    soup =bs4.BeautifulSoup(html)
    si = soup.find("div", {"id": "quotes_content_left_ShortInterest1_ContentPanel"})
    si = si.find("div", {"class": "genTable floatL"})
    df = pd.read_html(str(si.find("table")))[0]
    df.index = pd.to_datetime(df['Settlement Date'])
    del df['Settlement Date']
    df.columns = ['ShortInterest', 'ADV', 'D2C']
    return df.sort()
#%%
def get_NEWS(ticks=['']):
    """
    use: headline, insider
    source: https://www.marketbeat.com/
    """
    import requests
    import bs4
    import re
    from lxml import html
    from lxml import etree
    for ticker in ticks:
    # NYSE or NASDAQ
        url="https://www.marketbeat.com/stocks/NYSE/" + ticker + "/news/"
        request = requests.get(url)
        soup = bs4.BeautifulSoup(request.text, 'html.parser')
        mkt=soup.find('title').get_text().strip().split(':')[0]
       # headlines 
        news=[]
        url_news="https://www.marketbeat.com/stocks/"+ mkt + '/'+ ticker + "/news/"
        request = requests.get(url_news)
        soup = bs4.BeautifulSoup(request.text, 'html.parser')
        try:
            table=soup.find_all('div', {'id': 'dvHeadlines'}) [0] 
            row=table.find_all('tr')
            row_max=3
            for r in row[:row_max]:
                for c in r.find_all('td'):
                    news.append(c.get_text())
        except:
            pass
        #insider
        url_insider=url_news="https://www.marketbeat.com/stocks/"+ mkt + '/'+ ticker + "/insider-trades/"
        request = requests.get(url_insider)
        soup = bs4.BeautifulSoup(request.text, 'html.parser')    
        insider=[]
        try:
            table=soup.find_all('table', {'class': 'ratingstable'})[0] 
            row=table.find_all('tr')
            row_max=2
            for r in row[:row_max]:
                for c in r.find_all('td'):
                    insider.append(c.get_text())
        except:
            pass
        print(ticker, '\n', news, '\n', insider)   



#%%
def get_marketbeat(ticker=''):
    """
    use: headline, insider, rating etc.
    source: marketbeat.com
    """
    #ref: http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/ 
    from lxml import html
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException   
    from selenium.webdriver.chrome.options import Options
    chrome_options=Options()
    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_0_7_overlay_remove.crx")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
    url="https://www.marketbeat.com/"
    gecko="c:\\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="c:\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
    driver.get(url)
#    driver.execute_script("window.open(url);")
    try:
        ol_close=driver.find_element_by_class_name("overlay-close")
        ol.click()
    except:
        pass
    time.sleep(2)
    symbol=driver.find_element_by_xpath('//input[@class="main-searchbox autocomplete ui-autocomplete-input"]')
    symbol.send_keys(ticker)
    submit=driver.find_element_by_xpath('//a[@class="main-search-button"]')
    submit.click()
    
    time.sleep(2)   #get_attribute('innerHTML')
    rating=driver.find_elements_by_xpath('//*[@id="AnalystRatings"]/div[2]/table/tbody/tr[2]/td[2]')[0].get_attribute('textContent')
    p_target= driver.find_elements_by_xpath('//*[@id="AnalystRatings"]/div[2]/table/tbody/tr[3]/td[2]')[0].get_attribute('textContent')   
    rating_1=driver.find_elements_by_xpath('//*[@id="DataTables_Table_0"]/tbody/tr[1]')[0].get_attribute('textContent')
    rating_2=driver.find_elements_by_xpath('//*[@id="DataTables_Table_0"]/tbody/tr[2]')[0].get_attribute('textContent')
   
    news_1=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[1]/td[2]')[0].get_attribute('textContent')
    news_2=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[2]/td[2]')[0].get_attribute('textContent')
    news_3=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[3]/td[2]')[0].get_attribute('textContent')

    ins=driver.find_elements_by_xpath('//*[@id="InsiderTrades"]/div[1]')[0].get_attribute('textContent')
    ins_1=driver.find_elements_by_xpath('//*[@id="DataTables_Table_3"]/tbody/tr[1]')[0].get_attribute('textContent')
    ins_2=driver.find_elements_by_xpath('//*[@id="DataTables_Table_3"]/tbody/tr[2]')[0].get_attribute('textContent')
    return rating, p_target, rating_1, rating_2, news_1, news_2, news_3,ins, ins_1, ins_2
    





              
    """
RESOURCES:
https://news.ycombinator.com/item?id=14091952
https://github.com/six519/pyoptionchain
https://developer.tradier.com/documentation/markets/get-options-chains
https://github.com/rkohli3/Option_Scraper
https://github.com/eliangcs/pystock-data
https://stackoverflow.com/questions/16599717/python-rpy2-and-quantmod-examples
https://github.com/jackluo/py-quantmod
https://github.com/gyanesh-m/Sentiment-analysis-of-financial-news-data
https://medium.com/@aliciagilbert.itsimplified/a-slick-crud-application-built-using-python-with-flask-and-sqlite3-to-teach-simple-mysql-queries-bd75e1109582
https://github.com/anthonyng2/ib/blob/master/IbPy%20Demo%20v2018-04-05.ipynb
OI: https://www.theocc.com/webapps/series-search
iv
http://www.cboe.com/delayedquote/detailed-quotes?ticker=CCK
"""