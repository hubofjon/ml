# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 11:13:46 2017
Purpose: main program
Functions:  daily_run_eod
Imported:

"""
import pandas as pd
import datetime as datetime
from pandas.tseries.offsets import BDay
import warnings
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
from P_commons import read_sql, to_sql_append, to_sql_replace, bdate
from R_update_price import update_pv_eod, trig_run, vpj_plot, trig_run_1, update_price_eod

from R_stat import stat_run_base, stat_VIEW, stat_PLOT
from R_play import play_candy
from R_track import track_raw
#from R_options import unop
from R_options_dev import unop_mc_dev, unop_bc, unop_combo, untel, spec_track, spec_candy
from R_plot import plot_base
import datetime

position_list=['CLXT','ZS','CMCSA','AXDX','TD','BMY','QSR','BUD',\
           'MRVL','NVRO','SIG''XPO']
indicator_list=['AAPL','KLAC','URI','BID','TIF','FTCH',\
    'CRSP','EDIT','SGMO','PLNT','CDXS','MILN','LNGR','MIND']
extreme_list=['UNG','ZBTC','GUSH','DUST','XNET','IDEX']
long_list=['FRO','NAT','DHT','ARGT','GLD']
short_list=['TLT','UUP','JNK','EWG']

q_date=bdate()
#q_date=datetime.date(2018, 12, 24)
RUN_COUNT='n'
RUN_COUNT=input("todate? earningwhisper FIXED??? -- Run EOD?  yes/n:    ")
if RUN_COUNT=='yes':
#    todate=datetime.date(2018,8,15)

    print(" ---- STARTS %s ----"%q_date)
#    update_pv_eod('etf')  # take date from eod_price file, to tbl_pv_etf:)
#    update_pv_eod('sp500') #tbl_pv_ is the original raw table
#    update_pv_eod('all')
#    update_price_eod('sp500')
#    update_price_eod('etf') #same eod file, to tbl_price_sp, etf

    print("-----positions ----")
    plot_base(q_date, position_list) #from tbl_pv_all
#    trig_run_1('sp500')  #fm tbl_pv to tbl_pvt_
#    trig_run_1('etf')
#    vpj_plot('sp500')
#    vpj_plot('etf')
    RUN_COUNT='n'
    
    stat_run_base(q_date, 'sp500') #from tbl_price_, to tb_stat_
    stat_run_base(q_date, 'etf')
    stat_VIEW(q_date) #from tb_stat_, view only
    stat_PLOT(q_date)# from tb_stat_
#    trade_TRACK(todate)
    
    dmc=unop_mc_dev(q_date)
    dbc=unop_bc(q_date)
    dup=unop_combo(dmc,dbc)
    plot_base(q_date, dup.ticker.unique().tolist(), dup)
    df_spec=spec_track(q_date)
    print(" ---- early bc_raw stock volume moved  ----")
    df_tel=untel(q_date) #earlier tbl_bc_raw confirmed by stk volumn change
    plot_base(q_date, df_tel.ticker.unique(),df_tel)
#    dt=track_raw(q_date)
    
#    print(" -------- indicator_list ---")
#    plot_base(q_date, indicator_list)
#    print(" -------- extreme_list ---")
#    plot_base(q_date, indicator_list)
#    print(" -------- long_list ---")
#    plot_base(q_date, indicator_list)
#    print(" -------- short_list ---")
#    plot_base(q_date, indicator_list)    
#    
# -----------------------------------------------  #
#mutable funcion https://docs.python.org/3/faq/programming.html#how-do-i-write-a-function-with-output-parameters-call-by-reference
#https://stackoverflow.com/questions/38895768/python-pandas-dataframe-is-it-pass-by-value-or-pass-by-reference/38925257