# -*- coding: utf-8 -*-
from flask import Flask, request, render_template, url_for, redirect, session, flash, g
import os
#import sqlite3
import pandas.io.sql as pd_sql
import pandas as pd
from o_functions import sql_query, sql_query_var, sql_query_one, sql_read, sql_append, sql_edit_insert, sql_delete
from P_commons import to_sql_replace, read_sql
from dateutil import parser

host = os.getenv("IP", "127.0.0.1")
port = int(os.getenv("PORT", "5000"))
candy_max_dt=read_sql("select max(date) from tbl_candy ").iloc[0,0]
candy_track_max_dt=read_sql("select max(date) from tbl_candy_track ").iloc[0,0]
SECRET_KEY = "my_secret"
app = Flask(__name__)
app.config.from_object(__name__) # pulls in app configuration by looking for uppercase variables

#%% add menu to tbl_trd_candy
@app.route("/")
def o_entry():
    #refresh uid
    df=sql_read("select * from tbl_otrade_candy")
    df['uid']=df['entry_dt'].astype(str)+df['ticker']+df['oexp_dt']+df['type']+df['strike'].astype(str)+df['pid']
    to_sql_replace(df, 'tbl_otrade_candy')
    results = sql_query(''' SELECT * FROM tbl_otrade_candy ORDER BY ticker, pid''')
    return render_template('o_entry.html', results=results) 
#%%
@app.route('/insert_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def insert_form():
    if request.method == 'GET':
        i_ticker = request.args.get('i_ticker')
        e_leg=sql_query_one(' SELECT * FROM tbl_otrade_candy where ticker=?',([i_ticker]))
    results = sql_query(''' SELECT * FROM tbl_otrade_candy ORDER BY ticker, pid''')
    msg="insert_form msg"
    return render_template('o_entry.html', e_leg=e_leg, results=results, msg=msg)
#%%
@app.route('/insert',methods = ['POST', 'GET']) #this is when user submit after edit
def insert():
    if request.method == 'POST':	
        act = request.form["act"].upper()
        ticker = request.form["ticker"].upper()
        entry_dt = request.form["entry_dt"]
        type = request.form["type"].upper()
        strike = request.form["strike"]
        oexp_dt = request.form["oexp_dt"]
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        comm = request.form["comm"]
        pid = request.form["pid"].upper()
        play = request.form["play"].upper()
        sec = request.form["sec"].upper()
        #rebuld cid/uid
        expiry=parser.parse(oexp_dt)
        expiry=expiry.strftime('%y%m%d')
        strike_tmp=str(int(float(strike) *1000)).rjust(8,'0')
        cid=ticker + '-' + expiry +type+strike_tmp
        uid=cid + pid + entry_dt
        uid=entry_dt+ticker+oexp_dt+type+strike+pid
        df=sql_read("select * from tbl_otrade_candy")
        if uid in df['uid'].values:
            msg="insert: dupe, no insert"
        else: 
            sql_edit_insert('INSERT INTO tbl_otrade_candy (act, ticker, entry_dt, type, strike, oexp_dt, ioc, iop,\
            comm, pid, play, sec) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', (act, ticker, entry_dt, type, strike,\
            oexp_dt, ioc, iop,comm, pid, play, sec) )
            msg= "inserted"
    e_leg=sql_query_one(' SELECT * FROM tbl_otrade_candy where ticker=?',([ticker]))
    all_legs=sql_query_var(" SELECT * FROM tbl_otrade_candy where ticker=? ",([ticker]))
    results = sql_query(''' SELECT * FROM tbl_otrade_candy ORDER BY ticker, pid''')
    #[ticker, play, pid]
    return render_template('o_entry.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg)  
#%%
@app.route('/edit_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def edit_form():
    if request.method == 'GET':
        e_ticker = request.args.get('e_ticker')
        e_pid = request.args.get('e_pid')
        e_leg=sql_query_var(" SELECT * FROM tbl_otrade_candy where ticker=? and pid=?",(e_ticker,e_pid))
        all_legs=sql_query_var(" SELECT * FROM tbl_otrade_candy where ticker=? ",([e_ticker]))
    results = sql_query(''' SELECT * FROM tbl_otrade_candy ORDER BY ticker, pid''')
    msg="edit form"
    return render_template('o_entry.html', e_leg=e_leg[0], all_legs=all_legs, results=results, msg=msg)
#%%
@app.route('/edit',methods = ['POST', 'GET']) #this is when user submit after edit
def edit():
    if request.method == 'POST':	
        act = request.form["act"].upper()
        ticker = request.form["ticker"].upper()
        pid = request.form["pid"].upper()
        type = request.form["type"].upper()
        strike = request.form["strike"]
        oexp_dt = request.form["oexp_dt"]
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        comm = request.form["comm"]
        play = request.form["play"].upper()
        sec = request.form["sec"].upper()
        old_uid = request.form["old_uid"]
#        sql_edit_insert("UPDATE tbl_otrade_candy SET type=?, strike=?, oexp_dt=?, ioc=?, iop=?, comm=?,\
#                play=? WHERE ticker=? and pid=?", (type, strike, oexp_dt, ioc, iop, comm, play, ticker, pid)) 
        sql_edit_insert("UPDATE tbl_otrade_candy SET act=?, type=?, strike=?, oexp_dt=?, ioc=?, iop=?, comm=?,\
        play=?, sec=?, pid=? WHERE uid=?", (act, type, strike, oexp_dt, ioc, iop, comm, play, sec, pid, old_uid)) 
        e_leg=sql_query_var(" SELECT * FROM tbl_otrade_candy where ticker=? and pid=?",(ticker,pid))
        all_legs=sql_query_var(" SELECT * FROM tbl_otrade_candy where ticker=? ",([ticker]))
    results = sql_query(''' SELECT * FROM tbl_otrade_candy ORDER BY ticker, pid''')
    msg=  "edit success" 
    return render_template('o_entry.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg) 
#%%
@app.route('/delte',methods = ['GET']) #this is when user submit after edit
def delete():
    if request.method == 'GET':
#        ticker = request.args.get('d_ticker')
        uid = request.args.get('d_uid')
#        sql_delete("  DELETE FROM tbl_otrade_candy where ticker = ? and pid = ? ", (ticker, pid) )
        sql_delete("  DELETE FROM tbl_otrade_candy where uid= ? ", ([uid]) )
    results = sql_query(''' SELECT * FROM tbl_otrade_candy ORDER BY ticker, pid''')
    msg= "ticker, pid, vol" #[ticker, play, pid]
    return render_template('o_entry.html', results=results, msg=msg) 


#%% add menu to tbl_trd_candy
@app.route("/o_trd")
def o_trd():
    results = sql_query(''' SELECT * FROM tbl_oc WHERE exit_dt='N' ORDER BY ticker, cid, pid ''')
    return render_template('o_trd.html', results=results) 
#%%
@app.route('/t_insert_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def t_insert_form():
    if request.method == 'GET':
        i_uid = request.args.get('i_uid')
        e_leg=sql_query_one(' SELECT * FROM tbl_oc where uid=?',([i_uid]))
    results = sql_query(''' SELECT * FROM tbl_oc WHERE exit_dt='N' ORDER BY ticker, cid, pid ''')
    msg="insert_form msg"
    return render_template('o_trd.html', e_leg=e_leg, results=results, msg=msg)
#%%
@app.route('/t_insert',methods = ['POST', 'GET']) #this is when user submit after edit
def t_insert():
    if request.method == 'POST':	
        act = request.form["act"].upper()
        ticker = request.form["ticker"].upper()
        entry_dt = request.form["entry_dt"]
        type = request.form["type"].upper()
        strike = request.form["strike"]
        oexp_dt = request.form["oexp_dt"]
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        comm = request.form["comm"]
        pid = request.form["pid"].upper()
        play = request.form["play"].upper()
        exit_dt = request.form["exit_dt"]
        sec = request.form["sec"].upper()
        #rebuld cid/uid
        expiry=parser.parse(oexp_dt)
        expiry=expiry.strftime('%y%m%d')
        strike_tmp=str(int(float(strike) *1000)).rjust(8,'0')
        cid=ticker + '-' + expiry +type+strike_tmp
        uid=cid + pid + entry_dt
        df=sql_read("select * from tbl_oc")
        if uid in df['uid'].values:
            msg="insert: dupe, no insert"
        else: 
            sql_edit_insert('INSERT INTO tbl_oc (act, ticker, entry_dt, type, strike, oexp_dt, ioc, iop,\
            comm, pid, play, exit_dt, sec, cid, pid, uid) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', (act, ticker, entry_dt, type, strike,\
            oexp_dt, ioc, iop,comm, pid, play, exit_dt, sec, cid, pid,uid) )
            msg= "inserted"
    e_leg=sql_query_one(' SELECT * FROM tbl_oc where ticker=?',([ticker]))
    all_legs=sql_query_var(" SELECT * FROM tbl_oc where ticker=? ",([ticker]))
    results = sql_query(''' SELECT * FROM tbl_oc WHERE exit_dt='N' ORDER BY ticker, cid, pid ''')
    #[ticker, play, pid]
    return render_template('o_trd.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg)  
#%%
@app.route('/t_edit_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def t_edit_form():
    if request.method == 'GET':
        e_ticker = request.args.get('e_ticker')
        e_pid = request.args.get('e_pid')
        e_uid = request.args.get('e_uid')
        e_leg=sql_query_var(" SELECT * FROM tbl_oc where uid=?",([e_uid]))
        all_legs=sql_query_var(" SELECT * FROM tbl_oc where ticker=? ",([e_ticker]))
    results = sql_query(''' SELECT * FROM tbl_oc WHERE exit_dt='N' ORDER BY ticker, cid, pid ''')
    msg="t_edit_form"
    return render_template('o_trd.html', e_leg=e_leg[0], all_legs=all_legs, results=results, msg=msg)
#%%
@app.route('/t_edit',methods = ['POST', 'GET']) #this is when user submit after edit
def t_edit():
    if request.method == 'POST':	
        act = request.form["act"].upper()
        ticker = request.form["ticker"].upper()
        entry_dt = request.form["entry_dt"]
        pid = request.form["pid"].upper()
        type = request.form["type"].upper()
        strike = request.form["strike"]
        oexp_dt = request.form["oexp_dt"]
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        comm = request.form["comm"]
        play = request.form["play"].upper()
        exit_dt = request.form["exit_dt"]
        sec = request.form["sec"].upper()
        old_uid = request.form["old_uid"]
        #rebuld cid/uid
        expiry=parser.parse(oexp_dt)
        expiry=expiry.strftime('%y%m%d')
        strike_tmp=str(int(float(strike) *1000)).rjust(8,'0')
        cid=ticker + '-' + expiry +type+strike_tmp
        uid=cid + pid + entry_dt
        
        sql_edit_insert("UPDATE tbl_oc SET act=?, type=?, strike=?, oexp_dt=?, ioc=?, iop=?, comm=?,\
                        play=?, exit_dt=?, sec=?, cid=?, pid=?, uid=? WHERE uid=?", (act, type, strike, oexp_dt, ioc,\
                        iop, comm, play, exit_dt, sec, cid, pid, uid, old_uid)) 
        e_leg=sql_query_var(" SELECT * FROM tbl_oc where ticker=? and pid=?",(ticker,pid))
        all_legs=sql_query_var(" SELECT * FROM tbl_oc where ticker=? ",([ticker]))
    results = sql_query(''' SELECT * FROM tbl_oc WHERE exit_dt='N' ORDER BY ticker, cid, pid ''')
    msg= "t_edit success" 
    return render_template('o_trd.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg) 
#%%
@app.route('/t_delte',methods = ['GET']) #this is when user submit after edit
def t_delete():
    if request.method == 'GET':
#        ticker = request.args.get('d_ticker')
        uid = request.args.get('d_uid')
#        sql_delete("  DELETE FROM tbl_otrade_candy where ticker = ? and pid = ? ", (ticker, pid) )
        sql_delete("  DELETE FROM tbl_oc where uid= ? ", ([uid]) )
    results = sql_query(''' SELECT * FROM tbl_oc WHERE exit_dt='N' ORDER BY ticker, cid, pid ''')
    msg= "delete_t msg" #[ticker, play, pid]
    return render_template('o_trd.html', results=results, msg=msg) 

#%%
#  O_CANDY: candy@q_date
@app.route("/o_candy")
def o_candy():
#    results = sql_query(''' SELECT * FROM tbl_candy WHERE (watch IS NOT 'N' AND \
#            date='%s') OR watch ='Y' \
#            AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' ))\
#            ORDER BY watch '''%candy_max_dt)
    results = sql_query(''' SELECT * FROM tbl_candy WHERE (watch IS NOT 'N' AND \
            date='%s') ORDER BY atm, bet DESC, why '''%candy_max_dt)
    return render_template('o_candy.html', results=results)     
#%%
@app.route('/o_edit_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def o_edit_form():
    if request.method == 'GET':
        e_tid = request.args.get('e_tid')
        e_leg=sql_query_one(' SELECT * FROM tbl_candy where tid=?',([e_tid]))
    results = sql_query(''' SELECT * FROM tbl_candy WHERE (watch IS NOT 'N' AND \
            date='%s') ORDER BY atm, bet DESC, why '''%candy_max_dt)
    msg="o_edit_form"
    return render_template('o_candy.html', e_leg=e_leg,  results=results, msg=msg)
#%%
@app.route('/o_edit',methods = ['POST', 'GET']) #this is when user submit after edit
def o_edit():
    if request.method == 'POST':	
        tid = request.form["tid"]
        sec = request.form["sec"].upper()
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        bs = request.form["bs"].lower()
        watch = request.form["watch"].upper()
        sql_edit_insert("UPDATE tbl_candy SET ioc=?, iop=?, bs=?, watch=?, sec=?\
                WHERE tid=?", (ioc, iop, bs, watch, sec, tid))   
        sql_edit_insert("UPDATE tbl_candy_track SET ioc=?, iop=?, bs=?, watch=?, sec=? \
                WHERE tid=?", (ioc, iop, bs, watch, sec, tid))  
        sql_edit_insert("UPDATE tbl_candy_update SET ioc=?, iop=?, bs=?, watch=?, sec=? \
                WHERE tid=?", (ioc, iop, bs, watch, tid)) 
    results = sql_query(''' SELECT * FROM tbl_candy WHERE (watch IS NOT 'N' AND \
            date='%s') ORDER BY atm, bet DESC, why '''%candy_max_dt)
    msg=" o_edit msg"
    return render_template('o_candy.html', results=results, msg=msg)


#%%
# SPEC: tbl_candy_track@q_date with e_sig-ed
@app.route("/spec")
def spec():
#    results = sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
#            e_sig IS NOT NULL AND why IS NOT NULL AND candy_dt != date AND date='%s') OR watch ='Y' \
#            ORDER BY watch DESC,abs(mp_i_chg_pct), \
#            e_sig, why DESC, tid, o_dt '''%candy_track_max_dt)
    results=sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
            (e_sig IS NOT NULL OR why IS NOT NULL) AND candy_dt != '%s' AND date='%s') \
                AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' )) \
                ORDER BY abs(mp_i_chg_pct), watch DESC, e_sig, bs, why DESC, \
                tid, o_dt '''%(candy_track_max_dt, candy_track_max_dt))
    return render_template('o_spec.html', results=results)     
#%%
@app.route('/spec_edit_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def spec_edit_form():
    if request.method == 'GET':
        e_tid = request.args.get('e_tid')
        e_leg=sql_query_one(' SELECT * FROM tbl_candy where tid=?',([e_tid]))
    results=sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
            (e_sig IS NOT NULL OR why IS NOT NULL) AND candy_dt != '%s' AND date='%s') \
                AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' )) \
                ORDER BY abs(mp_i_chg_pct), watch DESC, e_sig, bs, why DESC, \
                tid, o_dt '''%(candy_track_max_dt, candy_track_max_dt))
    msg="spec_edit_form"
    return render_template('o_spec.html', e_leg=e_leg,  results=results, msg=msg)
#%%
# Update to 'watch' is to tbl_candy (not track!!)
@app.route('/spec_edit',methods = ['POST', 'GET']) #this is when user submit after edit
def spec_edit():
    if request.method == 'POST':	
        tid = request.form["tid"]
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        bs = request.form["bs"].lower()
        watch = request.form["watch"].upper()
        sql_edit_insert("UPDATE tbl_candy_track SET ioc=?, iop=?, bs=?, watch=? \
                WHERE tid=?", (ioc, iop, bs, watch, tid))  
        sql_edit_insert("UPDATE tbl_candy_update SET ioc=?, iop=?, bs=?, watch=? \
                WHERE tid=?", (ioc, iop, bs, watch, tid)) 
        sql_edit_insert("UPDATE tbl_candy SET ioc=?, iop=?, bs=?, watch=? \
                WHERE tid=?", (ioc, iop, bs, watch, tid))   
    results=sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
            (e_sig IS NOT NULL OR why IS NOT NULL) AND candy_dt != '%s' AND date='%s') \
                AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' )) \
                ORDER BY abs(mp_i_chg_pct), watch DESC, e_sig, bs, why DESC, \
                tid, o_dt '''%(candy_track_max_dt, candy_track_max_dt))
    msg=" spec_edit msg"
    return render_template('o_spec.html', results=results, msg=msg)
#%%
@app.route('/flo_insert',methods = ['POST', 'GET']) #this is when user submit after edit
def flo_insert():
    if request.method == 'POST':	
        ticker = request.form["ticker"].upper()
        dc=sql_read("select * from tbl_candy where ticker ='%s' order by date desc"%ticker)
        if dc.empty:
            msg="%s: no candy history"%ticker
        else: 
            dc=dc.head(1)
            r=dc.to_dict('records')[0]
            act='IBQ'
            entry_dt = candy_max_dt
            pid= 'U1'
            play=''
            exit_dt='N'
            comm=0
            sql_edit_insert('INSERT INTO tbl_oc (act, ticker, entry_dt, type, strike, oexp_dt, ioc, iop,\
            comm, pid, play, exit_dt, sec, cid, uid) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',\
               (act, r['ticker'], entry_dt, r['type'], r['strike'], r['oexp_dt'], r['ioc'], r['iop'],\
                comm, pid, play, exit_dt, r['sec'], r['cid'], r['tid']) )
            msg= "candy: %s inserted"%ticker
    e_leg=sql_query_one(' SELECT * FROM tbl_oc where ticker=?',([ticker]))
    all_legs=sql_query_var(" SELECT * FROM tbl_oc where ticker=? ",([ticker]))
    results = sql_query(''' SELECT * FROM tbl_oc ORDER BY ticker, pid''')
    #[ticker, play, pid]
    return render_template('o_trd.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg)  

if __name__ == "__main__":
    app.run(host=host, port=port, debug=True)

"""
RESOURCE:
    https://medium.com/@aliciagilbert.itsimplified/a-slick-crud-application-built-using-python-with-flask-and-sqlite3-to-teach-simple-mysql-queries-bd75e1109582
    https://github.com/itsimplified/slick-crud-app
    
    table: https://sarahleejane.github.io/learning/python/2015/08/09/simple-tables-in-webapps-using-flask-and-pandas-with-python.html
    #ajax table
    https://stackoverflow.com/questions/51468834/how-to-get-python-to-retrieve-user-inputted-data-from-a-dynamic-table-using-flas
{# 
         {% for key, value in result_dictionary.iteritems() %}
            <tr>
               <th> {{ key }} </th>
               <td> {{ value }} </td>
            </tr>
         {% endfor %}
	return a form in dictionary format:	 
	if request.method == 'POST':
    result = request.form
    return render_template("result.html",result = result)
	
	3. cookie
	   resp = make_response(render_template('readcookie.html'))
   resp.set_cookie('userID', user)
   name = request.cookies.get('userID')
   
   
#}
!! dataframe to table or pages
https://galaxydatatech.com/2018/03/31/passing-dataframe-web-page/

#flask_alchmey
https://www.codementor.io/garethdwyer/building-a-crud-application-with-flask-and-sqlalchemy-dm3wv7yu2
#ajax call
https://www.codementor.io/codementorteam/how-to-scrape-an-ajax-website-using-python-qw8fuitvi
https://stackoverflow.com/questions/55006553/scraping-an-ajax-web-page-using-python-and-requests
https://stackoverflow.com/questions/52228851/python-extract-xhr-response-data-from-website


Flask - spec_flo image
https://towardsdatascience.com/python-plotting-api-expose-your-scientific-python-plots-through-a-flask-api-31ec7555c4a8
"""
    