# -*- coding: utf-8 -*-
"""
sub_func
    1.get_DIV, (nasdaq: div_dt, yld, pe, beta)
    2.get_RSI (calc: rsi -14 days)
    3. get_SI (sqz: si, si_chg, si_dtc, cap, inst)
    3.1 get_si (alternative: nasdaq)
    4. get_EARN (whisper)

Not in use: 
    6. view_corr_etf  (180 day ETF correlation to SPY)
    7. view_rtn_etf
    8. view_corr_tsv  (22 days sp500 components correlation, sector, Vxx)
    9. view_unpv  (Today's unusual price, volume change)
    10.get_trades_marketbeat  (live trades: rating, headline, insider)
    11.marketbeat (rating, news, insider)
    12.get_ta (stocktrendchart.com    weekly trend reading)
    13.get_betas (get beta of all sp500 stocks nasdaq.com)
    14.get_share_nasdaq (nasdaq.com, ex_div, beta )
"""
import pandas as pd
import numpy as np 
import datetime as datetime
#from pandas_datareader import data as pdr
#from timeit import default_timer as timer
#import bs4
#import requests
import time
import warnings
warnings.filterwarnings("ignore")
from termcolor import colored, cprint
from P_commons import to_sql_append, to_sql_replace, read_sql, type_convert, reg_convert, get_proxies
from pandas.tseries.offsets import BDay

today=datetime.datetime.today()
todate=today.date()
LBdate=(todate-BDay(1)).date()


def get_o_nsdq(ticks=[]):
    """
    use: get option chain
    source:
    """
    import requests
    import bs4
    from random import randint
    from time import sleep
#    import re
#    from lxml import html
#    from lxml import etree
#    url="https://www.barchart.com/stocks/quotes/WRK/options?expiration=2019-10-18&moneyness=allRows&view=stacked_ohl"
    user_agent = get_random_ua()    
    headers = {
        "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding":"gzip, deflate",
        "Accept-Language":"en-GB,en;q=0.9,en-US;q=0.8,ml;q=0.7",
        "Connection":"keep-alive",
        "Host":"www.nasdaq.com",
        "Referer":"http://www.nasdaq.com", #'https://google.com',
        "Upgrade-Insecure-Requests":"1",
        "User-Agent":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.119 Safari/537.36"
        }
    url="https://www.nasdaq.com/symbol/wrk/option-chain/191018P00032500-wrk-put"   
    proxy_pool=get_proxies()
    for i in range(1,11):
    #Get a proxy from the pool
        proxy = next(proxy_pool)
        print("Request #%d"%i)
        try:
            response = requests.get(url,proxies={"http": proxy, "https": proxy})
            print(response.json())
        except:
        #Most free proxies will often get connection errors. You will have retry the entire request using another proxy to work. 
        #We will just skip retries as its beyond the scope of this tutorial and we are only downloading a single url 
            print("Skipping. Connnection error")
        
    response = requests.get(url, header=headers, timeout=(31,5), verify=False) #delay access/read
    if response.status_code!=200:
        raise ValueError("get_o_nsdq: Invalid Response")
    sleep(randint(1,3))   
    soup = bs4.BeautifulSoup(response.text, 'html.parser')
    oi=soup.find(text='Open Interest').findNext('span').text
    vol=soup.find(text='Volume').findNext('span').text
    last=soup.find(text='Last Sale').findNext('span').text
    
    delta=soup.find(id='white-delta').findNext('span').findNext('span').text
    return soup

def get_FUN(tick='', mode='candy'):
    """
    use: if mode =='candy': return ta, eg, earn_dt, yld, sector
         if 'spec': ta, beta, eg, ps, pcf, pb, pe, earn_dt, div, yld, sector, news
    source: barchart
    """
    import requests
    import bs4
#    import re
#    from lxml import html
#    from lxml import etree
    url='https://www.barchart.com/stocks/quotes/'+tick+'/overview'  
    request = requests.get(url)
    soup = bs4.BeautifulSoup(request.text, 'html.parser')
    ta= soup.find(text='Barchart Technical Opinion').findNext('a').text
    #fundamental
    beta=soup.find(text='60-Month Beta').findNext('span').text
    pe=soup.find(text='Price/Earnings ttm').findNext('span').text
    earn_dt=soup.find(text='Next Earnings Date').findNext('span').text    
    eg=soup.find(text='Growth Rate Est. (year over year)').findNext('span').text
    sector=soup.find(text='Sectors:').findNext('span').text
    if mode == 'candy':
        return ta, beta, pe, earn_dt, eg, sector
    
    ps=soup.find(text='Price/Sales').findNext('span').text
    pcf=soup.find(text='Price/Cash Flow').findNext('span').text
    pb=soup.find(text='Price/Book').findNext('span').text
    divyld=soup.find(text='Annual Dividend & Yield').findNext('span').text
    div=divyld.split()[0]
    yld=divyld.split()[1]
    yld=yld.replace('(','').replace(')','').replace('%','')
    
    stories=soup.find_all('div',{'class':'story clearfix'})
    news=[]
    for story in stories[:4]:
        news.append(story.get_text().split('-')[:2])
    return ta, beta, pe, earn_dt, eg, sector, ps, pb, pcf, div, yld, news
#%%
def get_ratio_bc(ticks=''):

    """
    use: inv_chg, ar_chg, peer_form
    source:  JAVA Script scraping
    import requests

    bibtex_id = '10.1007/s00425-007-0544-9'

    url = "http://www.doi2bib.org/#/doi/{id}".format(id=bibtex_id)
    xhr_url = 'http://www.doi2bib.org/doi2bib'

    with requests.Session() as session:
        session.get(url)

        response = session.get(xhr_url, params={'id': bibtex_id})
        print(response.content)
    """
    import requests
    import bs4
    import re
    from lxml import html
    from lxml import etree
    import json
    import urllib
    url="https://www.barchart.com/stocks/quotes/WRK/competitors?viewName=main"
    req = urllib.request.Request(url)
#soup approach    
    soup = bs4.BeautifulSoup(req.text, 'html.parser')
    peers=[]
    table=soup.find_all('div',attr={'class':'bc-table-scrollable-inner'})
    table=soup.find_all('table')[0] 
    row=table.find_all('tr')
    for r in row:
        for c in r.find_all('td'):
            peers.append(c.get_text())
    return peers

    url_bs="https://www.barchart.com/stocks/quotes/WRK/balance-sheet/quarterly"
    req = urllib.request.Request(url)
    soup = bs4.BeautifulSoup(req.text, 'html.parser')
    qtr_date=[]
    qtrs=soup.find('tr',{'class':'bc-financial-report__row-dates'})
    for c in qtrs.find_all('td'):
        qtr_date.append(c.get_text())
    inv=[]
    inventories=soup.find(text='Inventories')
    for c in inventories.find_all('td'):
        inv.append(c.get_text())       
    ar=[]
    receivables=soup.find(text='Receivables')
    for c in receivables.find_all('td'):
        ar.append(c.get_text())  
    return inv, ar

#json approach
#    req = urllib.request.Request(url)
#    resp = urllib.request.urlopen(req)
#    js_file = json.loads(resp.read())
#    if js_file['data']:
#        for i in (js_file['data']['Call']):
#            call_list_df.append(pd.DataFrame.from_dict(i['raw'], orient= 'index'))

#%%
def get_DIV(ticker=''):
    import requests
    import bs4
    import re
    from lxml import html
    from lxml import etree
    earnings_url = 'http://www.nasdaq.com/symbol/' + ticker#.lower()
    request = requests.get(earnings_url)
    soup = bs4.BeautifulSoup(request.text, 'html.parser')
    try:    
        div_dt= soup.find(text="Ex Dividend Date").find_next('div').text.strip()
    except:
        div_dt='N/A'
    try:    
        yld= soup.find(text="Current Yield").find_next('div').text.strip()
        yld=float(yld.replace('%','').replace(' ',''))
    except:
        yld=0
    try:
        pe=soup.find(text="P/E Ratio").find_next('div').text.strip()
        pe=float(pe.replace('NE','0'))
    except:
        pe=0
    try:        
        pe_f=soup.find(text="Forward P/E (1y)").find_next('div').text.strip()
        pe=float(pe.replace('NE','0'))
    except:
        pe_f=0
    try:
        beta=soup.find(text="Beta").find_next('div').text.strip()
        beta=float(beta)
    except:
        beta=0
#        tree = html.fromstring(request.content)
#        tbl="""//div[@class="genTable thin"]/table/tbody/"""
#        ex_div=tree.xpath(tbl+'/tr[12]/td[2]/text()')
    return div_dt, yld, pe, pe_f, beta
#%%
def get_RSI(series, period):
    delta = series.diff().dropna()
    u = delta * 0
    d = u.copy()
    u[delta > 0] = delta[delta > 0]
    d[delta < 0] = -delta[delta < 0]
    u[u.index[period-1]] = np.mean( u[:period] ) #first value is sum of avg gains
    u = u.drop(u.index[:(period-1)])
    d[d.index[period-1]] = np.mean( d[:period] ) #first value is sum of avg losses
    d = d.drop(d.index[:(period-1)])
    rs = pd.stats.moments.ewma(u, com=period-1, adjust=False) / \
         pd.stats.moments.ewma(d, com=period-1, adjust=False)
 #https://stackoverflow.com/questions/20526414/relative-strength-index-in-python-pandas   
#    data = pd.Series( [ 44.34, 44.09, 44.15, 43.61,46.03, 46.41, 46.22, 45.64 ] )
    return 100 - 100 / (1 + rs)   

def get_SIs_sqz(df):
    for index, row in df.iterrows():
        ticker=row['ticker']
        try:
            names=['si', 'si_chg', 'pe', 'hi_1y_fm', \
                   'lo_1y_fm', 'ma_200_fm', 'ma_50_fm', 'sec','ind']
            df=pd.concat([df,pd.DataFrame(columns=names)])
            df.loc[index,names]=get_si_sqz(ticker)
            #ds=ds.append(df)
        except:
            print("error: ", ticker)
            pass
    return df
#%%
def get_SI(ticker=''):
    import urllib3
    import bs4
    import requests
    import re
    http=urllib3.PoolManager()
    url = "http://shortsqueeze.com/?symbol=" + ticker + "&submit=Short+Quote%E2%84%A2"
    request = requests.get(url)
    soup = bs4.BeautifulSoup(request.text, 'html.parser')
#    si=soup.find('div', class="Short Percent of Float")
#    tag = soup.find(text=re.compile('Short Percent of Float*'))
    ts=soup.get_text()
    ts=ts.split("\n")
    s0='Short Percent of Float'
    s1='Short % Increase / Decrease'
    s2='Short Interest Ratio (Days To Cover)'
    s3='Market Cap.'
    s4='% Owned by Institutions'
    s=[s0,s1,s2,s3]
    i0=ts.index(s0)
    si=float(ts[i0+1].strip().replace(" ","").replace("%","").replace("",'0'))/100
    si='{:.2f}'.format(si)
    
    i1=ts.index(s1)
    si_chg=float(ts[i1+1].strip().replace(" ","").replace("%",""))/100

    i2=ts.index(s2)
    si_dtc=float(ts[i2+1].strip().replace(" ",""))     
    si_dtc=float(ts[i2+1].strip().replace(" ","")) 
    
    i3=ts.index(s3)
    m_cap=float(ts[i3+2].strip().replace(" ","").replace(",",""))/1000000000
    m_cap='{:.2f}'.format(m_cap)
    
    i4=ts.index(s4)
    inst=float(ts[i4+1].strip().replace(" ","").replace("%","").replace("",'0'))/100
    inst='{:.2f}'.format(inst)
#    s=soup.find_next_siblings(tag)
#    return tag[tag.index(':') + 1:].strip()
#    si = soup.find("div", {"id": "quotes_content_left_ShortInterest1_ContentPanel"})
#    si = si.find("div", {"class": "genTable floatL"})
#    df = pd.read_html(str(si.find("table")))[0]
    return [float(si), si_chg, si_dtc, float(m_cap), float(inst) ]
#%%
def get_EARN(ticker=''):
    import urllib3
    import bs4
    import requests
    import re
    import datetime
    from dateutil import parser
    http=urllib3.PoolManager()
    url = "https://www.earningswhispers.com/stocks/" + ticker 
    request = requests.get(url)
    soup = bs4.BeautifulSoup(request.text, 'html.parser')
    earn_list=soup.find_all('div', attrs={"class":"mainitem"})
    for e in earn_list:
        if e.text !='N/A':
            earn_dt=e.text
        else:
            pass
    earn_dt=earn_dt + ' 2019'
    earn_dt=parser.parse(earn_dt)
    return earn_dt
#    earn_dt=earning.next_sibling.get_text()
#    earning_time=soup.find('div', id="earningstime").get_text()
#    st=soup.find('div', id="stprice")
#    st=st['class'][2].split("-")[1]
#    it=soup.find('div', id="itprice")['class'][2].split("-")[1]
#    lt=soup.find('div', id="ltprice")['class'][2].split("-")[1]    
#    i_sent=soup.find('div', id="vsent")['class'][2].split("-")[1]
#    a_sent=soup.find('div', id="asent")['class'][2].split("-")[1]  
    com=soup.find('div', attrs={"class":"lowerboxcont"}).get_text()     
    #add Year to earning date
    today=datetime.datetime.today()
    earn=datetime.datetime.strptime(earn_dt, '%b %d' )
    if earn.month < today.month:
        earn_year=today.year+1
    else:
        earn_year=today.year
    earn_dt=datetime.datetime(earn_year,earn.month,earn.day).date()
    return [earn_dt,com]
        
def get_si_nasdaq(ticker=''):
    import urllib3
    import bs4
    import requests
    
    http=urllib3.PoolManager()
    url = "http://www.nasdaq.com/symbol/" + ticker + "/short-interest"
    res=http.request('GET', url)
    html=res.read()
    soup =bs4.BeautifulSoup(html)
    si = soup.find("div", {"id": "quotes_content_left_ShortInterest1_ContentPanel"})
    si = si.find("div", {"class": "genTable floatL"})
    df = pd.read_html(str(si.find("table")))[0]
    df.index = pd.to_datetime(df['Settlement Date'])
    del df['Settlement Date']
    df.columns = ['ShortInterest', 'ADV', 'D2C']
    return df.sort()
#%%
def get_NEWS(ticks=['']):
    """
    use: headline, insider
    source: https://www.marketbeat.com/
    """
    import requests
    import bs4
    import re
    from lxml import html
    from lxml import etree
    for ticker in ticks:
    # NYSE or NASDAQ
        url="https://www.marketbeat.com/stocks/NYSE/" + ticker + "/news/"
        request = requests.get(url)
        soup = bs4.BeautifulSoup(request.text, 'html.parser')
        mkt=soup.find('title').get_text().strip().split(':')[0]
       # headlines 
        news=[]
        url_news="https://www.marketbeat.com/stocks/"+ mkt + '/'+ ticker + "/news/"
        request = requests.get(url_news)
        soup = bs4.BeautifulSoup(request.text, 'html.parser')
        try:
            table=soup.find_all('div', {'id': 'dvHeadlines'}) [0] 
            row=table.find_all('tr')
            row_max=3
            for r in row[:row_max]:
                for c in r.find_all('td'):
                    news.append(c.get_text())
        except:
            pass
        #insider
        url_insider=url_news="https://www.marketbeat.com/stocks/"+ mkt + '/'+ ticker + "/insider-trades/"
        request = requests.get(url_insider)
        soup = bs4.BeautifulSoup(request.text, 'html.parser')    
        insider=[]
        try:
            table=soup.find_all('table', {'class': 'ratingstable'})[0] 
            row=table.find_all('tr')
            row_max=2
            for r in row[:row_max]:
                for c in r.find_all('td'):
                    insider.append(c.get_text())
        except:
            pass
        print(ticker, '\n', news, '\n', insider)   
#%%        
def plot_corr_etf():
    qry="SELECT * FROM tbl_price_etf"
    df=read_sql(qry, todate)
    df=df[~df.index.duplicated(keep='first')]  
    df=df.set_index('date')
    df.sort_index(axis=0)
    df_risk=df[['SPY','GLD','JJC','WYDE','HYG',\
        'TLT', 'UUP']]
    risk_base=df_risk.corr().ix['SPY',:]
    dr=df_risk.tail(180)
    drp=pd.rolling_corr(dr['SPY'], dr, window=66, pairwise=True)
    drp=drp.drop(['SPY'],1)
    #plot chart
 # forex
    df_fx=df[['UUP','FXC','FXY','FXA','FXE','GLD','TLT']]
    dx=df_fx.tail(180)
    dxp=pd.rolling_corr(dr['UUP'], dx, window=66, pairwise=True)
    dxp=dxp.drop(['UUP'],1)    
    print ("180 day correlation to SPY")
    
    df_sec=df[['SPY','XLY','XLE','XLF','XLV','XLI','XLB','XLK','XLU','XLP','XRT', 'XHB']]

    plot(drp)
    plot(dxp)
    
def plot_corr_tsv():  #sp500 component correlation, sector, volatility
    import matplotlib.pyplot as plt    
    duration=200    
    lookback=22
    #get sp500 componetn correaltion
    qry="SELECT * FROM tbl_price"
    df=read_sql(qry, todate)
    df=df.set_index('date')
    df.sort_index(axis=0)  # 
    df_cosp=df.tail(duration)
    
    df_cs=pd.rolling_corr(df_cosp['SPY'], df_cosp, window=lookback, pairwise=True)
    df_cs=df_cs.tail(duration-lookback)
    df_cs.fillna(0, inplace=True)
    dc=df_cs.mean(axis=1)  #series, correlation of sp500 component
#clean data value and duplicated index
    dc.replace(np.inf, np.nan, inplace=True)
    dc.replace(-np.inf, np.nan, inplace=True)    
    dc.fillna(method='ffill', inplace=True)
    dc=dc[~dc.index.duplicated(keep='first')]
    #get sector corr
    query="SELECT * FROM tbl_price_etf"
    de=read_sql(query,todate)
    de=de.set_index('date')
    de.sort_index(axis=0)
   #get secto etf corr
    df_sec=de[['SPY','XLY','XLE','XLF','XLV','XLI','XLB','XLK','XLU','XLP']]
    df_s=pd.rolling_corr(df_sec['SPY'], df_sec, window=lookback, pairwise=True)
    df_s=df_s.tail(duration-lookback)
    df_s.fillna(0, inplace=True)
    ds=df_s.mean(axis=1) #sector ETF with SPY
    ds=ds[~ds.index.duplicated(keep='first')]
    #get vix
#    dv=de['^VIX']
    dv=de['VXX']
    dv=dv.tail(duration)
    dv=dv[~dv.index.duplicated(keep='first')]
    #get secto etf corr
    df_csv=pd.DataFrame({'cosp':dc, 'sec':ds, 'vxx':dv})   
   #plot on two axis
    fig=plt.figure()  #general figure
    plt.xticks(rotation=45) 
    plt.grid(b=True, which='major', color='black')
    ax1=fig.add_subplot(111)
    df_csv['cosp'].plot(color='b')
    #ax1.plot(df_cv['cosp'])
    df_csv['sec'].plot(color='y')
    ax2=ax1.twinx()
    #ax2.plot(df_cv['vix'])
    df_csv['vxx'].plot(color='r')
    plt.legend(loc='best')
#    plt.grid(b=True, which='minor', color='black')
    print("correlation - Blue: Sector, Brown: sp500 component")
    plt.show()

#%%
def get_marketbeat(ticker=''):
    """
    use: headline, insider, rating etc.
    source: marketbeat.com
    """
    #ref: http://yizeng.me/2014/04/08/get-text-from-hidden-elements-using-selenium-webdriver/ 
    from lxml import html
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.common.keys import Keys
    from selenium.common.exceptions import TimeoutException   
    from selenium.webdriver.chrome.options import Options
    chrome_options=Options()
    chrome_options.add_argument("--disable-popup")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_0_7_overlay_remove.crx")
    chrome_options.add_extension(r"c:\pycode\Github\extension_1_13_8.crx")  #fairad
    #chrome_options.add_extension(r"G:\Trading\Trade_python\pycode\Github\extension_0_3_4.crx")
    
    chrome_options.add_argument('--always-authorize-plugins=true')
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--start-maximized")  #full screen
    url="https://www.marketbeat.com/"
    gecko="c:\\pycode\Github\chromedriver.exe"
    driver=webdriver.Chrome(executable_path="c:\pycode\Github\chromedriver.exe", \
        chrome_options=chrome_options)
    driver.get(url)
#    driver.execute_script("window.open(url);")
    try:
        ol_close=driver.find_element_by_class_name("overlay-close")
        ol.click()
    except:
        pass
    time.sleep(2)
    symbol=driver.find_element_by_xpath('//input[@class="main-searchbox autocomplete ui-autocomplete-input"]')
    symbol.send_keys(ticker)
    submit=driver.find_element_by_xpath('//a[@class="main-search-button"]')
    submit.click()
    
    time.sleep(2)   #get_attribute('innerHTML')
    rating=driver.find_elements_by_xpath('//*[@id="AnalystRatings"]/div[2]/table/tbody/tr[2]/td[2]')[0].get_attribute('textContent')
    p_target= driver.find_elements_by_xpath('//*[@id="AnalystRatings"]/div[2]/table/tbody/tr[3]/td[2]')[0].get_attribute('textContent')   
    rating_1=driver.find_elements_by_xpath('//*[@id="DataTables_Table_0"]/tbody/tr[1]')[0].get_attribute('textContent')
    rating_2=driver.find_elements_by_xpath('//*[@id="DataTables_Table_0"]/tbody/tr[2]')[0].get_attribute('textContent')
   
    news_1=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[1]/td[2]')[0].get_attribute('textContent')
    news_2=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[2]/td[2]')[0].get_attribute('textContent')
    news_3=driver.find_elements_by_xpath('//*[@id="dvHeadlines"]/table/tbody/tr[3]/td[2]')[0].get_attribute('textContent')

    ins=driver.find_elements_by_xpath('//*[@id="InsiderTrades"]/div[1]')[0].get_attribute('textContent')
    ins_1=driver.find_elements_by_xpath('//*[@id="DataTables_Table_3"]/tbody/tr[1]')[0].get_attribute('textContent')
    ins_2=driver.find_elements_by_xpath('//*[@id="DataTables_Table_3"]/tbody/tr[2]')[0].get_attribute('textContent')
    return rating, p_target, rating_1, rating_2, news_1, news_2, news_3,ins, ins_1, ins_2
    
def get_nasdaq(ticker=''):
    """
    This function gets the share price for the given ticker symbol. It performs a request to the
    nasdaq url and parses the response to find the share price.
    :param ticker: The stock symbol/ticker to use for the lookup
    :return: String containing the earnings date
    http://www.ianhopkinson.org.uk/2015/11/parsing-xml-and-html-using-xpath-and-lxml-in-python/
    """
    import requests
    import bs4
    from lxml import html
    from lxml import etree
    try:
        earnings_url = 'http://www.nasdaq.com/symbol/' + ticker[0]#.lower()
        request = requests.get(earnings_url)

        tree = html.fromstring(request.content)
        tbl="""//div[@class="genTable thin"]/table/tbody/"""
        ex_div=tree.xpath(tbl+'/tr[12]/td[2]/text()')
#        beta=tree.xpath(tbl+'/tr[15]/td[2]/text()')[0]
#        key= '%s_Volume'%(ticker[0])
#        vol=tree.xpath('//label[@id="%s"]/text()'%key)[0]
#        vol_avg=tree.xpath(tbl + '/tr[4]/td[2]/text()') [0]
#        vol=float(vol.replace(",",""))
#        vol_avg=float(vol_avg.replace(",",""))
#        beta=float(beta.replace(",",""))
#        x=tree.xpath('//label[@id="%s"]/'%key).getsibling()
#        return vol , vol_avg, ex_div, beta
        return ex_div
    except:
        return 'No Data Found'
    
def get_o(ticker=''):
    """
    http://www.ianhopkinson.org.uk/2015/11/parsing-xml-and-html-using-xpath-and-lxml-in-python/
    """
    import requests
    import re
    import bs4
    from lxml import html
    from lxml import etree
    try:
        earnings_url = 'https://marketchameleon.com/Overview/' + ticker#.lower()
        request = requests.get(earnings_url)
       
        soup = bs4.BeautifulSoup(request.text, 'html.parser')
        close=soup.find('p', class_="symov_current_price").text
        p_chg=soup.find('p', class_="symov_current_pricechange").text
     #   p_chg=soup.find(text=re.compile('symov_current_pricechange num_neg')).findNext('p').text
        v_stk=soup.find(text=re.compile('Equity')).findNext('span').text
        v_stk_avg=soup.find(text=re.compile('90-Day Avg')).findNext('span').text
        v_opt=soup.find(text=re.compile('Option:')).findNext('span').text

        iv_30=soup.find(text=re.compile('Todays Stock Vol:')).findNext('span').text
        iv_rank=soup.find(text=re.compile('IV Pct Rank:')).findNext('span').text
        hv_20=soup.find(text=re.compile('20-Day')).findNext('span').text
        hv_252=soup.find(text=re.compile('52-Week \(HV')).findNext('span').text     
        div_date=soup.find(text=re.compile('Dividend:')).findNext('span').text
        div_yld=soup.find(text=re.compile('Div. Yield:')).findNext('span').text
        earning=soup.find(text=re.compile('Earnings:')).findNext('span').text
        pe=soup.find(text=re.compile('P/E Ratio:')).findNext('span').text      
        cap=soup.find(text=re.compile('Market Cap:')).findNext('span').text
#        tree = html.fromstring(request.content)
#        tbl="""//div[@class="genTable thin"]/table/tbody/"""
#        ex_div=tree.xpath(tbl+'/tr[12]/td[2]text()')
#        beta=tree.xpath(tbl+'/tr[15]/td[2]/text()')[0]
#        key= '%s_Volume'%(ticker[0])
#        vol=tree.xpath('//label[@id="%s"]/text()'%key)[0]
##        vol_avg=tree.xpath(tbl + '/tr[4]/td[2]/text()') [0]
##        vol=float(vol.replace(",",""))
##        vol_avg=float(vol_avg.replace(",",""))
##        beta=float(beta.replace(",",""))
#        x=tree.xpath('//label[@id="%s"]/'%key).getsibling()
##        return vol , vol_avg, ex_div, beta
#        for tr in soup.find_all('tr'):
#            tds=soup.find_all('td')
#            print(tds[0].text, tds[1].text)
        
        #return soup
        values=[ticker, close, p_chg, v_stk, v_stk_avg, v_opt, iv_30, iv_rank,\
            hv_20, hv_252, div_date, div_yld, earning, pe, cap]
    except:
        value=[ticker, 1,1,1,1,1,1,1,1,1,1,1,1,1,1]
        pass
    names=['ticker', 'close', 'p_chg', 'v_stk', 'v_stk_avg', 'v_opt', 'iv_30', 'iv_rank',\
            'hv_20', 'hv_252', 'div_date', 'div_yld', 'earning', 'pe', 'cap']
    do=pd.DataFrame(data=[], columns=names)    
    do.loc[0,names]=values
    return do


#%%
def get_earn_chart(ticks=[]):

    """
    use: headline, insider
    source: https://www.marketbeat.com/
    >>> from PIL import Image
>>> from io import BytesIO

>>> i = Image.open(BytesIO(r.content))
    """
    import requests
    import bs4
    import re
    from lxml import html
    from lxml import etree
    from IPython.display import display, Image
    # NYSE or NASDAQ
    url="https://www.marketbeat.com/stocks/NYSE/CCK/earnings/"
    request = requests.get(url)
    body=html.fromstring(request.text)
    #grab link to image
    img_link=body.xpath('//*[@id="cphPrimaryContent_tabEarningsHistory"]/div[1]/img/@src')
    img_link=img_link[0]
    display(Image(url=img_link))
#        try:
#            table=soup.find_all('div', {'id': 'dvHeadlines'}) [0] 
#            row=table.find_all('tr')
#            row_max=3
#            for r in row[:row_max]:
#                for c in r.find_all('td'):
#                    news.append(c.get_text())
#        except:
#            pass

              
    """
RESOURCES:
https://news.ycombinator.com/item?id=14091952
https://github.com/six519/pyoptionchain
https://developer.tradier.com/documentation/markets/get-options-chains
https://github.com/rkohli3/Option_Scraper
https://github.com/eliangcs/pystock-data
https://stackoverflow.com/questions/16599717/python-rpy2-and-quantmod-examples
https://github.com/jackluo/py-quantmod
https://github.com/gyanesh-m/Sentiment-analysis-of-financial-news-data
https://medium.com/@aliciagilbert.itsimplified/a-slick-crud-application-built-using-python-with-flask-and-sqlite3-to-teach-simple-mysql-queries-bd75e1109582
https://github.com/anthonyng2/ib/blob/master/IbPy%20Demo%20v2018-04-05.ipynb
OI: https://www.theocc.com/webapps/series-search
"""