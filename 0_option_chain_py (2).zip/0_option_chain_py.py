# -*- coding: utf-8 -*-
"""
Using 3rd party 
1. reqSecDefOptParams
2. reqContractDetails
3. reqHistoricalData
4. ib.reqHeadTimeStamp
5. recipes (vol calc, news, div, ratios, scanner)

ref.
https://groups.io/g/insync/message/3101
https://dimon.ca/how-to-setup-ibc-and-tws-on-headless-ubuntu-in-10-minutes/
https://www.aeracode.org/2018/02/19/python-async-simplified/
#calc greeks
https://github.com/vollib/py_vollib
https://groups.io/g/insync/topic/5796214
http://vollib.org/documentation/python/1.0.2/
http://www.gammoncap.com/insights/page/5/tutorial-accelerating-py-vollib-with-concurrency/

while trade.isActive():
    ib.waitOnUpdate()
 * reqTickers(*contracts, regulatorySnapshot=False)[source]
Request and return a list of snapshot tickers. The list is returned when all tickers are ready.

This method is blocking. <<fee !!>>

* qualifyContracts(*contracts), fill CONId, blocking
* reqCurrentTime(): tws time

* reqHistoricalData(contract, endDateTime, durationStr, barSizeSetting, whatToShow, useRTH, formatDate=1, keepUpToDate=False, chartOptions=None)
TRADES, BID_ASK, OPTION_IMPLIED_VOLATILITY  (keepUpToDate =False,if no realtime subscription)

* reqHistoricalTicks(contract, startDateTime, endDateTime, numberOfTicks, whatToShow, useRth, ignoreSize=False, miscOptions=None)
Bid_Ask, Trades, max:1000

* reqMktData(contract, genericTickList='', snapshot=False, regulatorySnapshot=False, mktDataOptions=None)
"100, 101, 104, 105,106", snapshot: False for realtime)
reqTickByTickData (endless ticks)

* reqHistogramData(contract, useRTH, period)[source]

* reqSecDefOptParams(underlyingSymbol, futFopExchange, underlyingSecType, underlyingConId), get option chain
"""
from ib_insync import *
import logging
import time
from datetime import datetime

def get_cid_greeks_ib(cid, q_date):
    
    ib = IB()
    ib.connect('127.0.0.1', 7496, 1, timeout=5, readonly=True)
    ib.reqMarketDataType( 2 )  #frozen data (eod)
    ib.client.MaxRequests = 40

    for cid in cids: 
        ticker=cid.split("-")[0]
        expiry= '20' + cid.split("-")[1][:6]
        type= cid.split("-")[1][6:7]
        if type=='C':
            type='CALL'
        else:
            type='PUT'
        strike=int(cid.split("-")[1][7:].lstrip("0"))/1000
        cont=Option(ticker, expiry, strike, type, 'SMART',100, 'USD')
        ib.qualifyContracts(cont)
    #    tk= ib.reqTickers(cont)  #has no voune, no undprice
        md=ib.reqMktData(cont, genericTickList='101')  #open intereset
        #ib.reqMktData(call, "100,101", False, False)
        ib.sleep(3)
        bid=md.bid
        ask=md.ask
        sale=md.last
        o_vol=md.volume
        o_dt=q_date
        
        try:
            if md.lastGreeks is not None:  #len(md.lastGreeks)>0:
                print("I'm good")
                delta=md.lastGreeks.delta
                gamma=md.lastGreeks.gamma
                theta=md.lastGreeks.theta
                vega=md.lastGreeks.vega
                civ=md.lastGreeks.impliedVol
                p=md.lastGreeks.undPrice
                
            else:
                print("I'm bad")
                delta=md.modelGreeks.delta
                gamma=md.modelGreeks.gamma
                theta=md.modelGreeks.theta
                vega=md.modelGreeks.vega
                civ=md.modelGreeks.impliedVol
                p=md.modelGreeks.undPrice
        except:
            print("cid_get_greeks_ib no greeks:", cid)
            
#replace greeks with own cacl()
        if (sale<ask) & (sale > bid):
            mp=sale
        else:
            mp=(bid + ask)/2
        
        r=0.02  #risk free one year treasurye note rate
        expiry_dt=datetime.strptime(expiry, '%Y%m%d').date()
        yr_to_exp=((expiry_dt - q_date).days)/365
        civ, delta, gamma, theta, vega=calc_greeks(mp, p, strike, r, yr_to_exp, type.lower())
        
        o_oi=get_oi_occ(cid)
        # adjust oi if occ has updated already to be sync with old data; once gone should use new
        occ_cutoff=datetime(q_date.year, q_date.month, q_date.day, 22)
        if datetime.now() > occ_cutoff:
            o_oi=o_oi - o_vol
#            return
    #    keys=['cid','p','o_dt', 'bid','ask','sale','sale_prev', 'o_oi','o_vol','delta','theta','vega','gamma']
    keys=['civ', 'cid','p','o_dt', 'bid','ask','sale','o_vol','delta','theta','vega','gamma']
    vals=[civ, cid, p, o_dt, bid, ask, sale, o_vol, delta, theta, vega, gamma]
    ib.disconnect()
    return dict(zip(keys, vals))
#%%
def calc_greeks(op_price, und_price, strike, r, yr_to_exp, type):
    from py_vollib.black.implied_volatility import implied_volatility as iv
    from py_vollib.black.analytical import delta as fd, gamma as fg, theta as ft, veta as fv
    
    #iv( op_price, F: underlying price, K:strike, r:risk_free int one year note rate, t: time to expiration in years (365d), 'p' or 'c' for put or call )
    civ=iv(op_price, und_price, strike, r, yr_to_exp, type)
#    delta(flag, F, K, t, r, sigma) 
    delta=fd(type, op_price, und_price, yr_to_exp, civ)
    gamma=fg(type, op_price, und_price, yr_to_exp, civ)
    theta=ft(type, op_price, und_price, yr_to_exp, civ)
    vega=fv(type, op_price, und_price, yr_to_exp, civ)
#    civ=iv(.01, 100, 120+epsilon, .01, .5, 'c')
    return civ, delta, gamma, theta, vega
    
#%%    
def get_oi_occ(cid):
    """
    use: extract whole op cahin for underlying
    """
    import requests
    import pandas as pd
#pd.set_option('display.max_rows', 1000)
    ticker=cid.split("-")[0]
    s = requests.Session()
    url = 'https://www.theocc.com/webapps/series-search'
    r = s.post(url,data={'symbolType': 'U','symbolId': ticker})
#    r = s.post(url,data={'symbolType': 'O','symbolId': symbol})
    df = pd.read_html(r.content)[0]
    df.columns = df.columns.droplevel()
    df['Strike'] = df['Integer'] + (df['Dec']*0.001)
    cols_of_interest=['Product Symbol', 'Year', 'Month', 'Day', 'Strike', 'Call', 'Put']
    df = df[cols_of_interest]
    #convert to cid
    df['expiry']=df['Year'].astype(str)+df['Month']+df['Day'].astype(str)
    df['expiry']=df['expiry'].apply(lambda x : datetime.strptime(x,"%Y%b%d"))
    df['expiry']=df['expiry'].astype(str).str.replace("-",'')
    
    df['strike']=(df['Strike']*1000).astype(int).astype(str).str.rjust(8,'0')
    
    df['cid']=df['Product Symbol'] + '-' + df['expiry'] +type+strike_tmp

        
    doi=df[df.cid==cid]
    o_oi=doi.oi.values[0]
    return o_oi    



# max 50 request / sec per IB
#for i in range(10):
#    ib.sleep(0.2)
#    if ticker.modelGreeks is not None:
#        print (ticker.modelGreeks.delta)
#    else:
#        print("modelGreeks not yet available")

    
#    [ticker] = ib.reqTickers(spx)
#    spxValue = ticker.marketPrice()
#    chains = ib.reqSecDefOptParams(spx.symbol, '', spx.secType, spx.conId)
#
#
#df=util.df(chains)
#chain = next(c for c in chains if c.tradingClass == 'SPX' and c.exchange == 'SMART')
#strikes = [strike for strike in chain.strikes
#        if strike % 5 == 0
#        and spxValue - 20 < strike < spxValue + 20]
#expirations = sorted(exp for exp in chain.expirations)[:3]
#rights = ['P', 'C']
#
#contracts = [Option('SPX', expiration, strike, right, 'SMART', tradingClass='SPX')
#        for right in rights
#        for expiration in expirations
#        for strike in strikes]
#
#contracts = ib.qualifyContracts(*contracts)
#tickers = ib.reqTickers(*contracts)

#%%
def op_calc():
    option = Option('EOE', '20171215', 490, 'P', 'FTA', multiplier=100)
    
    calc = ib.calculateImpliedVolatility(
        option, optionPrice=6.1, underPrice=525)
    print(calc)
    
    calc = ib.calculateOptionPrice(
        option, volatility=0.14, underPrice=525)
    print(calc)






"""
use
re_entry. CID chart (iv, p, vol)
bars = ib.reqHistoricalData(
        contract,
        endDateTime='',
        durationStr='60 D',
        barSizeSetting='1 hour',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1)

note: Ambiguous contracts are great to use with reqContractDetails
OptionForQuery()


testing details: 
kems = ib.reqContractDetails(kem)
ib.reqHeadTimeStamp(contract, whatToShow='TRADES', useRTH=True)
Historical tick data can be fetched with a maximum of 1000 ticks at a time. Either the start time or the end time must be given, and one of them must remain empty:
bars = ib.reqHistoricalData(
        contract,
        endDateTime='',
        durationStr='60 D',
        barSizeSetting='1 hour',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1)
Time & sales
[tick]=ib.reqHistoricalTicks(spx,"20190926",null,100,"TRADES",1, True,null)
        )

"""
