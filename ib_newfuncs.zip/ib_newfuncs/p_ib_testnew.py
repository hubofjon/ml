# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 13:26:46 2019

@author: frebo
"""
# time and sales
trades = ib.reqHistoricalTicks(
    c2,
    startDateTime=start_dt,
    endDateTime='',
    numberOfTicks=1000,
    whatToShow='TRADES',
    useRth=1,
    ignoreSize=True,
    miscOptions=[])

bidasks = ib.reqHistoricalTicks(
    c2,
    startDateTime=start_dt,
    endDateTime='',
    numberOfTicks=1000,
    whatToShow='BID_ASK',
    useRth=1,
    ignoreSize=True,
    miscOptions=[])

dt=pd.DataFrame(trades)


# scanner https://groups.io/g/insync/topic/22402297#1656
https://groups.io/g/insync/topic/31264538#3358

hot_stk_by_volume = ScannerSubscription(instrument='STK',
                                   locationCode='STK.US.MAJOR',
                                   numberOfRows=5,
                                   scanCode='HOT_BY_VOLUME')
ib.reqScannerData(ht,[])

security=Stock(hts[0].contractDetails.contract.symbol, hts[0].contractDetails.contract.exchange, hts[0].contractDetails.contract.currency)
fun=ib.reqFundamentalData(security, 'ReportSnapshot')


contract=c1
end = datetime.datetime.now()
barsList = []

dt = end
while True:
    bars = ib.reqHistoricalData(
            contract,
            endDateTime=dt,
            durationStr='10 D',
            barSizeSetting='1 hour',
            whatToShow='TRADES',
            useRTH=True,
            formatDate=1)
    if not bars:
        break
    barsList.append(bars)
    dt = bars[0].date

allBars = [b for bars in reversed(barsList) for b in bars]
df = util.df(allBars)