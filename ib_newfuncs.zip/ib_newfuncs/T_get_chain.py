# -*- coding: utf-8 -*-
# =============================================================================
# 1.	get_cid_greeks_ib_occ_sync
# 2.	get_cid_greeks_ib_async
# 3.	get_cid_oi_occ_async
# 
# 
# a.	thread_oi_occ_async
# b.	get_oi_occ_sync
# c.	get_oi_occ_new
# d.	op_calc
# =============================================================================

#import logging
#import time
from datetime import datetime
import numpy as np
from timeit import default_timer as timer
from datetime import timedelta
import time
#import requests
import pandas as pd
from P_commons import *
from ib_insync import *
import asyncio
import nest_asyncio
import random

import warnings
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format

#%%
def intel_chain(q_date, mode):
    #mode in ['trd','indicator']

    if mode in ['trd']:
        dt=read_sql("select * from tbl_oc WHERE exit_dt =='N' and oexp_dt>='%s' \
                AND substr(pid,1,1)<>'U'"%q_date)
        list_tickers=dt.ticker.unique().tolist()
    elif mode in ['unop']:
        dt=read_sql("select * from tbl_oc WHERE exit_dt =='N' and oexp_dt>='%s' \
                AND substr(pid,1,1) == 'U'"%q_date) 
        list_tickers=dt.ticker.unique().tolist()
        
    elif mode in ['barometer']:
        list_tickers=['VIX', 'SVXY','RVX']

    #clear tbl_chain if not living trade nor in key_indicators
    
    dc=read_sql("select * from tbl_chain where ticker in %s"%list_tickers)
    

#plot near two months o_oi
    dc.sort_values(['year','month'], inplace=True)
    yr_min=dc.year.min()
    mth_1=dc.iloc[0].month
    mth_2=dc.iloc[1].month
    dm1=dc[(dc['year']==yr_min) & (dc['month']==mth_1]
    dm1.plot(x='strike')
    
    
#%%
def get_chain(tickers, q_date, category, api=''): #category: stock, index, api='API' /'GW'
    print("get_chain_sync started")
    dg=get_chain_ib_sync(tickers, q_date, category, api)
    doi=get_chain_oi_sync(tickers, q_date)
    df=pd.merge(dg, doi, on='cid', how='inner')
    df['o_dt']=q_date    
    tbl_nodupe_append(dg, 'tbl_chain')
    
#%%    
def get_chain_ib_sync(tickers, q_date, category, api):
#    start = timer()
    nest_asyncio.apply()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        dg= loop.run_until_complete(get_chain_ib_async(tickers, category,api))
    finally:
        loop.close()
    time.sleep(2)
    return dg

#%%    
def get_chain_oi_sync(tickers, q_date):
#    start = timer()
    nest_asyncio.apply()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        doi= loop.run_until_complete(get_chain_oi_async(tickers, category='ticker'))
    finally:
        loop.close()
    time.sleep(2)
    return dg
#%%
async def get_chain_ib_async(tickers, category='S', api):
    start = timer()
    if category in ['S']:
        t_conts=[Stock(t,'SMART','USD') for t in tickers]
    elif category in ['I']:
        t_conts=[Index(t,'SMART','USD') for t in tickers]

    client_id=1
    if api.upper() in ['API']:
        port = 7496
    elif api.upper() in ['GW']:
        port - 4001
    ib = IB()
# connection    
    try:  
        ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
    except:
        try:    #2nd
            client_id= client_id + random.randint(1,10)
            ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
        except:
            try:    #3rd
                client_id= client_id + random.randint(1,10)
                ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
            except:
                return ("ib_greeks_async unable to connect after 3 try")    
    ib.reqMarketDataType( 2 )  #frozen data (eod)
    ib.client.MaxRequests = 48  # max 50 - to pace throttling
    print("ib connected id: ", client_id)
    
    list_greeks_all_chains=[]
    list_ib_error=[]
    for t in t_conts:
        list_greeks_by_chain=[]
        t= await ib.qualifyContractsAsync(t)
        chains=[ib.reqSecDefOptParams(t.symbol, '', t.secType, t.conId)]
        chain = next (x for x in chains if x.tradingClass == upper(t.symbol) and x.exchange =='SMART')
        ..
        forming contracts
        ...
        await ib.qualifyContractsAsync(*contracts)
        mds=ib.reqTickersAsync(*contracts)
        # construct dataframe for a chain of one ticker(all expiry/strikes)
        for md in mds:
            if not md.hasBidAsk():
                print("get_cid_greeks_ib: no mkt data____: ", cid)
                list_ib_error.append(cid)
                continue
            # reconstruct 'cid'
            cid='-'.join(md.contract.localSymbol.split())
            bid=md.bid
            ask=md.ask
            sale=md.last
            o_vol=md.volume
            # if vol_nan_cnt >8 then disconnect, exit the function
            cid_got_cnt += 1
            if np.isnan(o_vol):
                vol_nan_cnt += 1
            if (vol_nan_cnt>=8) & (vol_nan_cnt/cid_got_cnt >=0.8):
                print("_ib_async__ no volume data cnt:", vol_nan_cnt)
                ib.disconnect()
                return
            if md.lastGreeks is not None: 
                delta=md.lastGreeks.delta
                gamma=md.lastGreeks.gamma
                theta=md.lastGreeks.theta
                vega=md.lastGreeks.vega
                civ=md.lastGreeks.impliedVol
                p=md.lastGreeks.undPrice
            elif md.modelGreeks is not None:
                delta=md.modelGreeks.delta
                gamma=md.modelGreeks.gamma
                theta=md.modelGreeks.theta
                vega=md.modelGreeks.vega
                civ=md.modelGreeks.impliedVol
                p=md.modelGreeks.undPrice
            else:
                print("get_cid_greeks_ib: no greeks____: ", cid)
                list_ib_error.append(cid)
                continue #skip this cid, loop next
            sale_prev=0
            keys_g=['civ', 'cid', 'p', 'bid', 'ask', 'sale', 'sale_prev', 'o_vol', 'delta', 'theta', 'vega', 'gamma']
            vals_g=[civ, cid, p,  bid, ask, sale, sale_prev, o_vol, delta, theta, vega, gamma]
            dic_greeks_by_option=dict(zip(keys_g, vals_g))
            list_greeks_by_chain.append(dic_greeks_by_option)
            
    list_greeks_all_chain += list_greeks_by_chain
    df_chains=pd.DataFrame(list_greeks_all_chains)
    df['year']=df['cid'].str.split('-').str[1].str[:2]
    df['month']=df['cid'].str.split('-').str[1].str[2:4]
    df['type']=df['cid'].str.split('-').str[1].str[6:7]
    df['strike']=df['cid'].str.split("-").str[1].str[7:].str.lstrip("0").astype(int)/1000
    df['ticker']=df['cid'].str.split('-').str[0]
    return df_chains
    

#%%
async def get_cid_greeks_ib_async(cids):
# =============================================================================
#     ASYNC use: return dataframe for all cids
#     todo: thread safe for sync section insides async function
# =============================================================================
    start = timer()
    chunk_count= 48
    client_id=1
    port=4001  #7496
    def chunks(cids, chunk_count):
        for i in range(0, len(cids), chunk_count):
             yield cids[i: i+chunk_count]
    list_of_cids=list(chunks(cids, chunk_count))  
    ib = IB()
# connection    
    try:  #1st
        ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
    except:
        try:    #2nd
            client_id= client_id + random.randint(1,10)
            ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
        except:
            try:    #3rd
                client_id= client_id + random.randint(1,10)
                ib.connect('127.0.0.1', port, client_id, timeout=5, readonly=True)  #7496 live
            except:
                return ("ib_greeks_async unable to connect after 3 try")
    ib.reqMarketDataType( 2 )  #frozen data (eod)
    ib.client.MaxRequests = 40  # max 50 - to pace throttling
    print("ib connected id: ", client_id)
    list_greeks=[]
    df_greeks=pd.DataFrame()
    list_ib_error=[]
    vol_nan_cnt=0
    cid_got_cnt=0
# ?? with ib:??   

    for x in list_of_cids: #iter thru all chunks
        list_g=[]
        CONTS=[]
#    with ib:
        for cid in x:    #inter each cid in chunk, 
            ticker=cid.split("-")[0]
            expiry= '20' + cid.split("-")[1][:6]
            type= cid.split("-")[1][6:7]
            if type=='C':
                type_ib='CALL'
            else:
                type_ib='PUT'
            strike=int(cid.split("-")[1][7:].lstrip("0"))/1000
            cont=Option(ticker, expiry, strike, type_ib, 'SMART',100, 'USD')
            CONTS.append(cont)
        CONTS=[c for c in CONTS if c.conId]     #remove unqualified contracts
        await ib.qualifyContractsAsync(*CONTS)
        mds= await ib.reqTickersAsync(*CONTS)
        
        for md in mds:
            #if no market data, log it, then jskip this cid, jump to next cid loop
            if not md.hasBidAsk():
                print("get_cid_greeks_ib: no mkt data____: ", cid)
                list_ib_error.append(cid)
                continue
            # reconstruct 'cid'
            cid='-'.join(md.contract.localSymbol.split())
            bid=md.bid
            ask=md.ask
            sale=md.last
            o_vol=md.volume
    # if vol_nan_cnt >8 then disconnect, exit the function
            cid_got_cnt += 1
            if np.isnan(o_vol):
                vol_nan_cnt += 1
            if (vol_nan_cnt>=8) & (vol_nan_cnt/cid_got_cnt >=0.8):
                print("_ib_async__ no volume data cnt:", vol_nan_cnt)
                ib.disconnect()
                return
                
            if md.lastGreeks is not None: 
                delta=md.lastGreeks.delta
                gamma=md.lastGreeks.gamma
                theta=md.lastGreeks.theta
                vega=md.lastGreeks.vega
                civ=md.lastGreeks.impliedVol
                p=md.lastGreeks.undPrice
            elif md.modelGreeks is not None:
                delta=md.modelGreeks.delta
                gamma=md.modelGreeks.gamma
                theta=md.modelGreeks.theta
                vega=md.modelGreeks.vega
                civ=md.modelGreeks.impliedVol
                p=md.modelGreeks.undPrice
            else:
                print("get_cid_greeks_ib: no greeks____: ", cid)
                list_ib_error.append(cid)
                continue #skip this cid, loop next
                
            sale_prev=0
            keys_g=['civ', 'cid', 'p', 'bid', 'ask', 'sale', 'sale_prev', 'o_vol', 'delta', 'theta', 'vega', 'gamma']
            vals_g=[civ, cid, p,  bid, ask, sale, sale_prev, o_vol, delta, theta, vega, gamma]
            dic_g=dict(zip(keys_g, vals_g))
            list_g.append(dic_g)
            
        list_greeks += list_g  
    df_greeks=pd.DataFrame(list_greeks)
# data cleanup
    df_greeks.fillna(0, inplace=True)
    col_vals=['sale', 'bid', 'ask','o_vol']
    df_greeks[col_vals].apply(lambda x: x.replace('nan',0))
    ib.sleep(1)
    ib.disconnect()
    end = timer()
    print("get_greek_ib:", timedelta(seconds=end-start))
    assert(not df_greeks.empty), "get_cid_greeks empty result"
    return df_greeks
#        mds= ib.reqMktData(cont, genericTickList='101')  #open intereset
#                ib.sleep(0.02)
#                # if no return: no bid and no ask
#                if np.isnan(md.bid) & np.isnan(md.ask):
#                    ib.reqMktData(cont, genericTickList='101')
#                    ib.sleep(5)

#                if sale =='nan':
#                    sale=0
#                elif np.isnan(sale):
#                    sale=0
#                if bid =='nan':
#                    bid=0
#                elif np.isnan(bid):
#                    bid=0
#                if ask =='nan':
#                    ask=0
#                if np.isnan(ask):
#                    ask=0
#                if o_vol =='nan':
#                    o_vol=0
#                if np.isnan(o_vol):
#                    o_vol=0

#                pass
        
#        df=pd.DataFrame(list_g)
#        df_greeks=pd.concat([df_greeks, df], axis=0)

# calc_greeks()  to replace
#    list_vol_error=[]
#    if (sale<ask) & (sale > bid):
#        mp=sale
#    else:
#        mp=(bid + ask)/2
#    r=0.02  #risk free one year treasurye note rate
#    expiry_dt=datetime.strptime(expiry, '%Y%m%d').date()
#    yr_to_exp=((expiry_dt - q_date).days)/365
#
#    try:
#        civ, delta, gamma, theta, vega=calc_greeks(mp, p, strike, r, yr_to_exp, type.lower())
#    except:
#        print("cal_greek error:", cid)
#        list_vol_error.append(cid)
#        pass
   
#%%
async def get_cid_oi_occ_async(symbols, category='cid'): #or 'ticker'
    
# =============================================================================
#     working!
#     ASYNC use: get_oi (whole chain fast)
#     try-except-else: 'else' only when 'try' completed
#     todo: threadsafe
#     default max connections: 100
# =============================================================================
    import aiohttp
    from aiohttp import ClientSession
    start = timer()
    url='https://www.theocc.com/webapps/series-search'
    list_oi=[]
    df_oi=pd.DataFrame()
    connector = aiohttp.connector.TCPConnector(limit=800, limit_per_host=5)
    headers={"User-Agent": "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2225.0 Safari/537.36"}
    async with ClientSession(\
        connector=connector, \
        headers=headers,\
        raise_for_status=True) as session:
        for sym in symbols:
            if category in ['cid']:
                ticker=cid.split("-")[0]
            elif category in ['ticker']:
                ticker=sym
            try:
                r= await session.post(url,data={'symbolType': 'U','symbolId': ticker})
                # if used in sync , r.content is STREAMINGAPI if in async,
                #  r = s.post(url,data={'symbolType': 'O','symbolId': symbol})
                # df = pd.read_html(r.content)[0] #read_html is NOT awaitable
            except:
                print("get_cid_oi_occ_async___: exception occured")
            else:
                rt=await r.text()
        #sync section: will block whole process, OK only when execution is quick enough
                df=pd.read_html(rt)[0]
                df.columns = df.columns.droplevel()
                df['Strike'] = df['Integer'] + (df['Dec']*0.001)
                cols_of_interest=['Product Symbol', 'Year', 'Month', 'Day', 'Strike', 'Call', 'Put']
                df = df[cols_of_interest]    
                df['expiry']=df['Year'].astype(str)+df['Month']+df['Day'].astype(str)
                df['expiry']=df['expiry'].apply(lambda x : datetime.datetime.strptime(x,"%Y%b%d"))
                df['expiry']=df['expiry'].astype(str).str.replace("-",'').str[2:]
                
                df['strike']=(df['Strike']*1000).astype(int).astype(str).str.rjust(8,'0')
                dc=df[['Product Symbol','expiry','strike','Call']]
                dc['cid']=dc['Product Symbol'] + '-' + df['expiry'] +'C'+ df['strike']
                dc['o_oi']=dc['Call']
                dc=dc[['cid','o_oi']]
                
                dp=df[['Product Symbol','expiry','strike','Put']]
                dp['cid']=dp['Product Symbol'] + '-' + dp['expiry'] +'P'+ dp['strike']
                dp['o_oi']=dp['Put']
                dp=dp[['cid','o_oi']]
                dcp=pd.concat([dc,dp], axis=0)
                df_oi=pd.concat([df_oi, dcp], axis=0)
#                o_oi=dcp[dcp.cid==cid].o_oi.values[0]
#                keys_oi=['cid','o_oi']
#                vals_oi=[cid, o_oi]
#                dict_oi=dict(zip(keys_oi, vals_oi))
#ALT- thread safeway
#                executor = concurrent.futures.ThreadPoolExecutor(max_workers=3)
#                loop_oi = asyncio.get_event_loop()   
#                dict_oi= await loop_oi.run_in_executor(executor, thread_oi_occ, rt, cid)
                
                
#                list_oi.append(dict_oi)
#            df_oi=pd.DataFrame(list_oi)
    await session.close() 
    
    if category in ['cid']:
        df_oi=df_oi[df_oi.cid.isin(symbols)]
    end = timer()
    assert(not df_oi.empty), "get_cid_oi empty result"
    print("get_oi_occ:", timedelta(seconds=end-start))
    return df_oi

#%%
def thread_oi_occ_async(resp, cid):
    #thread safe exeuction of sync in async function
    df=pd.read_html(resp)[0]
    df.columns = df.columns.droplevel()
    df['Strike'] = df['Integer'] + (df['Dec']*0.001)
    cols_of_interest=['Product Symbol', 'Year', 'Month', 'Day', 'Strike', 'Call', 'Put']
    df = df[cols_of_interest]    
    df['expiry']=df['Year'].astype(str)+df['Month']+df['Day'].astype(str)
    df['expiry']=df['expiry'].apply(lambda x : datetime.datetime.strptime(x,"%Y%b%d"))
    df['expiry']=df['expiry'].astype(str).str.replace("-",'').str[2:]
    
    df['strike']=(df['Strike']*1000).astype(int).astype(str).str.rjust(8,'0')
    dc=df[['Product Symbol','expiry','strike','Call']]
    dc['cid']=dc['Product Symbol'] + '-' + df['expiry'] +'C'+ df['strike']
    dc['o_oi']=dc['Call']
    dc=dc[['cid','o_oi']]
    
    dp=df[['Product Symbol','expiry','strike','Put']]
    dp['cid']=dp['Product Symbol'] + '-' + dp['expiry'] +'P'+ dp['strike']
    dp['o_oi']=dp['Put']
    dp=dp[['cid','o_oi']]
    
    dcp=pd.concat([dc,dp], axis=0)
    o_oi=dcp[dcp.cid==cid].o_oi.values[0]
#                o_oi=dcp.tail(1).o_oi.values[0]
    keys_oi=['cid','o_oi']
    vals_oi=[cid, o_oi]
    dict_oi=dict(zip(keys_oi, vals_oi))
    return dict_oi


    


#%%    
def get_oi_occ_sync(cid, o_vol, q_date):
    """
    use: extract whole op cahin for underlying
    """
    import requests
    import pandas as pd

    ticker=cid.split("-")[0]
#    s = requests.Session()
    url = 'https://www.theocc.com/webapps/series-search'
    r = s.post(url,data={'symbolType': 'U','symbolId': ticker})
#    r = s.post(url,data={'symbolType': 'O','symbolId': symbol})
    df = pd.read_html(r.content)[0]
    df.columns = df.columns.droplevel()
    df['Strike'] = df['Integer'] + (df['Dec']*0.001)
    cols_of_interest=['Product Symbol', 'Year', 'Month', 'Day', 'Strike', 'Call', 'Put']
    df = df[cols_of_interest]
    #convert to cid
    df['expiry']=df['Year'].astype(str)+df['Month']+df['Day'].astype(str)
    df['expiry']=df['expiry'].apply(lambda x : datetime.strptime(x,"%Y%b%d"))
    df['expiry']=df['expiry'].astype(str).str.replace("-",'').str[2:]
    
    df['strike']=(df['Strike']*1000).astype(int).astype(str).str.rjust(8,'0')
    dc=df[['Product Symbol','expiry','strike','Call']]
    dc['cid']=dc['Product Symbol'] + '-' + df['expiry'] +'C'+ df['strike']
    dc['o_oi']=dc['Call']
    dc=dc[['cid','o_oi']]
    
    dp=df[['Product Symbol','expiry','strike','Put']]
    dp['cid']=dp['Product Symbol'] + '-' + dp['expiry'] +'P'+ dp['strike']
    dp['o_oi']=dp['Put']
    dp=dp[['cid','o_oi']]
    
    dcp=pd.concat([dc,dp], axis=0)
    o_oi=dcp[dcp.cid==cid].o_oi.values[0]
# get_oi_occ() :adjust oi if occ has updated already to be sync with old data; once gone should use new
    occ_cutoff=datetime(q_date.year, q_date.month, q_date.day, 22)
    if datetime.now() > occ_cutoff:
        try:
            o_oi=int(o_oi) - int(o_vol)
        except:
            print(cid, o_oi, o_vol)
            pass

    return int(o_oi)   
#%%    
def get_oi_occ_new(ticker,expiry,type, strike, q_date):
    """
    use: extract whole op cahin for underlying
    """
    import requests
    import pandas as pd

    print("get_oi_occ started")
    start = timer()
    
#pd.set_option('display.max_rows', 1000)
    s = requests.Session()
    url = 'https://www.theocc.com/webapps/series-search'
    r = s.post(url,data={'symbolType': 'U','symbolId': ticker})
#    r = s.post(url,data={'symbolType': 'O','symbolId': symbol})
    df = pd.read_html(r.content)[0]
    df.columns = df.columns.droplevel()
    df['Strike'] = df['Integer'] + (df['Dec']*0.001)
    cols_of_interest=['Product Symbol', 'Year', 'Month', 'Day', 'Strike', 'Call', 'Put']
    df = df[cols_of_interest]
    
    Year=int('20'+expiry[:2])
    Month=expiry[2:4]
    Month=datetime.strptime(Month, "%m").strftime("%b")
    Day=int(expiry[4:])
    
    if type=='C':
        con=(df.Year==Year) & (df.Month==Month) & (df.Day==Day)\
            & (df.Strike==strike)
        o_oi=df[con].Call.values[0]
        
    elif type=='P':
        con=(df.Year==Year) & (df.Month==Month) & (df.Day==Day)\
            & (df.Strike==strike)
        o_oi=df[con].Put.values[0]     
        
    end = timer()
    print(timedelta(seconds=end-start))
    return(o_oi)
    
#%% 
def plot_stackbar(df):
    import numpy as np
    import matplotlib.pyplot as plt
     
    # set width of bar
    barWidth = 0.25
     
    # set height of bar
    bars1 = [12, 30, 1, 8, 22]
    bars2 = [28, 6, 16, 5, 10]
    bars3 = [29, 3, 24, 25, 17]
     
    # Set position of bar on X axis
    r1 = np.arange(len(bars1))
    r2 = [x + barWidth for x in r1]
    r3 = [x + barWidth for x in r2]
     
    # Make the plot
    plt.bar(r1, bars1, color='#7f6d5f', width=barWidth, edgecolor='white', label='var1')
    plt.bar(r2, bars2, color='#557f2d', width=barWidth, edgecolor='white', label='var2')
    plt.bar(r3, bars3, color='#2d7f5e', width=barWidth, edgecolor='white', label='var3')
     
    # Add xticks on the middle of the group bars
    plt.xlabel('group', fontweight='bold')
    plt.xticks([r + barWidth for r in range(len(bars1))], ['A', 'B', 'C', 'D', 'E'])
     
    # Create legend & Show graphic
    plt.legend()
    plt.show()


# max 50 request / sec per IB
#for i in range(10):
#    ib.sleep(0.2)
#    if ticker.modelGreeks is not None:
#        print (ticker.modelGreeks.delta)
#    else:
#        print("modelGreeks not yet available")

    
#    [ticker] = ib.reqTickers(spx)
#    spxValue = ticker.marketPrice()
#    chains = ib.reqSecDefOptParams(spx.symbol, '', spx.secType, spx.conId)
#
#
#df=util.df(chains)
#chain = next(c for c in chains if c.tradingClass == 'SPX' and c.exchange == 'SMART')
#strikes = [strike for strike in chain.strikes
#        if strike % 5 == 0
#        and spxValue - 20 < strike < spxValue + 20]
#expirations = sorted(exp for exp in chain.expirations)[:3]
#rights = ['P', 'C']
#
#contracts = [Option('SPX', expiration, strike, right, 'SMART', tradingClass='SPX')
#        for right in rights
#        for expiration in expirations
#        for strike in strikes]
#
#contracts = ib.qualifyContracts(*contracts)
#tickers = ib.reqTickers(*contracts)


# =============================================================================
# 
# 
# Using 3rd party 
# 1. reqSecDefOptParams
# 2. reqContractDetails
# 3. reqHistoricalData
# 4. ib.reqHeadTimeStamp
# 5. recipes (vol calc, news, div, ratios, scanner)
# 
# FIX:
#     import nest_asyncio
#     nest_asyncio.apply()
# ref.
# https://groups.io/g/insync/message/3101
# https://dimon.ca/how-to-setup-ibc-and-tws-on-headless-ubuntu-in-10-minutes/
# https://www.aeracode.org/2018/02/19/python-async-simplified/
# #calc greeks
# https://github.com/vollib/py_vollib
# https://groups.io/g/insync/topic/5796214
# http://vollib.org/documentation/python/1.0.2/
# http://www.gammoncap.com/insights/page/5/tutorial-accelerating-py-vollib-with-concurrency/
# 
# while trade.isActive():
#     ib.()
#  * reqTickers(*contracts, regulatorySnapshot=False)[source]
# Request and return a list of snapshot tickers. The list is returned when all tickers are ready.
# 
# This method is blocking. <<fee !!>>
# 
# * qualifyContracts(*contracts), fill CONId, blocking
# * reqCurrentTime(): tws time
# 
# * reqHistoricalData(contract, endDateTime, durationStr, barSizeSetting, whatToShow, useRTH, formatDate=1, keepUpToDate=False, chartOptions=None)
# TRADES, BID_ASK, OPTION_IMPLIED_VOLATILITY  (keepUpToDate =False,if no realtime subscription)
# 
# * reqHistoricalTicks(contract, startDateTime, endDateTime, numberOfTicks, whatToShow, useRth, ignoreSize=False, miscOptions=None)
# Bid_Ask, Trades, max:1000
# 
# * reqMktData(contract, genericTickList='', snapshot=False, regulatorySnapshot=False, mktDataOptions=None)
# "100, 101, 104, 105,106", snapshot: False for realtime)
# reqTickByTickData (endless ticks)
# 
# * reqHistogramData(contract, useRTH, period)[source]
# print(f"{status()}\t\tProcess {num}, PID: {os.getpid()}, Delay: {delay} seconds...")
# * reqSecDefOptParams(underlyingSymbol, futFopExchange, underlyingSecType, underlyingConId), get option chain
# 
# use
# re_entry. CID chart (iv, p, vol)
# bars = ib.reqHistoricalData(
#         contract,
#         endDateTime='',
#         durationStr='60 D',
#         barSizeSetting='1 hour',
#         whatToShow='TRADES',
#         useRTH=True,
#         formatDate=1)
# 
# note: Ambiguous contracts are great to use with reqContractDetails
# OptionForQuery()
# 
# 
# testing details: 
# kems = ib.reqContractDetails(kem)
# ib.reqHeadTimeStamp(contract, whatToShow='TRADES', useRTH=True)
# Historical tick data can be fetched with a maximum of 1000 ticks at a time. Either the start time or the end time must be given, and one of them must remain empty:
# bars = ib.reqHistoricalData(
#         contract,
#         endDateTime='',
#         durationStr='60 D',
#         barSizeSetting='1 hour',
#         whatToShow='TRADES',
#         useRTH=True,
#         formatDate=1)
# Time & sales
# [tick]=ib.reqHistoricalTicks(spx,"20190926",null,100,"TRADES",1, True,null)
#         )
# 
    
#    ref. https://groups.io/g/insync/topic/5937415#215
# =============================================================================
