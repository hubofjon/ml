# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 12:02:54 2019
ib_multi_conts

@author: frebo
"""
working:
    check-> unop_price history
    ib.reqHeadTimeStamp(c1, whatToShow='TRADES', useRTH=True)


sp500 updte price
snp = pd.read_html('https://en.wikipedia.org/wiki/List_of_S%26P_500_companies')[0].Symbol
contracts = ib.qualifyContracts(*(Stock(s, 'SMART', 'USD') for s in snp))


## ib new functions
endtime = '20170102 01:00:00'
con.reqHistoricalData(2,contract,endtime,"5 M","1 sec","TRADES",0,1)


"""
use
re_entry. CID chart (iv, p, vol)
bars = ib.reqHistoricalData(
        contract,
        endDateTime='',
        durationStr='60 D',
        barSizeSetting='1 hour',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1)

note: Ambiguous contracts are great to use with reqContractDetails
OptionForQuery()


testing details: 
kems = ib.reqContractDetails(kem)
ib.reqHeadTimeStamp(contract, whatToShow='TRADES', useRTH=True)
Historical tick data can be fetched with a maximum of 1000 ticks at a time. Either the start time or the end time must be given, and one of them must remain empty:
bars = ib.reqHistoricalData(
        contract,
        endDateTime='',
        durationStr='60 D',
        barSizeSetting='1 hour',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1)
Time & sales
[tick]=ib.reqHistoricalTicks(spx,"20190926",null,100,"TRADES",1, True,null)
        )

"""
"""
Using 3rd party 
1. reqSecDefOptParams
2. reqContractDetails
3. reqHistoricalData
4. ib.reqHeadTimeStamp
5. recipes (vol calc, news, div, ratios, scanner)

ref.
https://groups.io/g/insync/message/3101
https://dimon.ca/how-to-setup-ibc-and-tws-on-headless-ubuntu-in-10-minutes/
https://www.aeracode.org/2018/02/19/python-async-simplified/
#calc greeks
https://github.com/vollib/py_vollib
https://groups.io/g/insync/topic/5796214
http://vollib.org/documentation/python/1.0.2/
http://www.gammoncap.com/insights/page/5/tutorial-accelerating-py-vollib-with-concurrency/

while trade.isActive():
    ib.()
 * reqTickers(*contracts, regulatorySnapshot=False)[source]
Request and return a list of snapshot tickers. The list is returned when all tickers are ready.

This method is blocking. <<fee !!>>

* qualifyContracts(*contracts), fill CONId, blocking
* reqCurrentTime(): tws time

* reqHistoricalData(contract, endDateTime, durationStr, barSizeSetting, whatToShow, useRTH, formatDate=1, keepUpToDate=False, chartOptions=None)
TRADES, BID_ASK, OPTION_IMPLIED_VOLATILITY  (keepUpToDate =False,if no realtime subscription)

* reqHistoricalTicks(contract, startDateTime, endDateTime, numberOfTicks, whatToShow, useRth, ignoreSize=False, miscOptions=None)
Bid_Ask, Trades, max:1000

* reqMktData(contract, genericTickList='', snapshot=False, regulatorySnapshot=False, mktDataOptions=None)
"100, 101, 104, 105,106", snapshot: False for realtime)
reqTickByTickData (endless ticks)

* reqHistogramData(contract, useRTH, period)[source]

* reqSecDefOptParams(underlyingSymbol, futFopExchange, underlyingSecType, underlyingConId), get option chain
"""

# max 50 request / sec per IB
#for i in range(10):
#    ib.sleep(0.2)
#    if ticker.modelGreeks is not None:
#        print (ticker.modelGreeks.delta)
#    else:
#        print("modelGreeks not yet available")

    
#    [ticker] = ib.reqTickers(spx)
#    spxValue = ticker.marketPrice()
#    chains = ib.reqSecDefOptParams(spx.symbol, '', spx.secType, spx.conId)
#
#
#df=util.df(chains)
#chain = next(c for c in chains if c.tradingClass == 'SPX' and c.exchange == 'SMART')
#strikes = [strike for strike in chain.strikes
#        if strike % 5 == 0
#        and spxValue - 20 < strike < spxValue + 20]
#expirations = sorted(exp for exp in chain.expirations)[:3]
#rights = ['P', 'C']
#
#contracts = [Option('SPX', expiration, strike, right, 'SMART', tradingClass='SPX')
#        for right in rights
#        for expiration in expirations
#        for strike in strikes]
#
#contracts = ib.qualifyContracts(*contracts)
#tickers = ib.reqTickers(*contracts)

# -*- coding: utf-8 -*-
"""
Business model: https://www.quantrocket.com/docs/
code sample -----
  https://github.com/erdewit/ib_insync

Tutorial:  https://www.youtube.com/watch?v=hogXB07OJ_I

https://github.com/anthonyng2/ib
https://www.quora.com/Which-platforms-allow-me-to-plug-in-trading-algorithms-written-in-Python-to-start-trading-and-not-just-backtesting
Created on Wed Sep 18 11:36:03 2019

https://groups.io/g/twsapi/
https://www.quantrocket.com/docs/api/

1. api doc.http://interactivebrokers.github.io/tws-api/functions.html
2. https://qoppac.blogspot.com/2017/03/interactive-brokers-native-python-api.html
3. https://www.quantstart.com/articles/Using-Python-IBPy-and-the-Interactive-Brokers-API-to-Automate-Trades
4. https://github.com/ranaroussi/ezibpy#request-market-data
download op chain
5. http://www.quantacademy.com/2014/09/options-chain-download-from-interactive-brokers-with-python/
6. http://www.tradinggeeks.net/downloads/ib-data-downloader/




Alt-2 scrape
https://testdriven.io/blog/building-a-concurrent-web-scraper-with-python-and-selenium/
https://github.com/calebpollman/web-scraping-parallel-processing/blob/master/script.py

"""