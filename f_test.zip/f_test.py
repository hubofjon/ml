# -*- coding: utf-8 -*-

from flask import Flask, request, render_template, url_for, redirect, session, flash, g
import os
import sqlite3
import pandas.io.sql as pd_sql

def create_db():
    with sqlite3.connect(r"C:\Users\qli1\BNS_wspace\flask\f_books\books.db") as connection:
        conn = connection.cursor()
        conn.execute("CREATE TABLE IF NOT EXISTS books(ticker TEXT, delta TEXT, exit_dt TEXT, mp REAL)")
        books_data = [
                ("Steven King", "IT", "Horror", 7.99),
                ("Dan Brown", "The Davinci Code", "Thriller", 8.99),
                ("Alexander Dumas", "The Count of Monte Cristo", "Adventure", 10.99),
                ("James H. Chase", "Shogun", "Action", 3.55)
            ]
        conn.executemany("INSERT INTO books VALUES(?, ?, ?, ?)", books_data)
        
        conn.execute("SELECT * FROM books")
        data = conn.fetchone()
        conn.close()
        print(data)

# for c9 users
host = os.getenv("IP", "127.0.0.1")
port = int(os.getenv("PORT", "8080"))

# configuration details
DATABASE = "C:\\Users\qli1\BNS_wspace\flask\f_trd\trd.db"
SECRET_KEY = "my_secret"

app = Flask(__name__)
app.config.from_object(__name__) # pulls in app configuration by looking for uppercase variables

# create function to connect to database
def connect_db():
#    return sqlite3.connect(app.config["C:\Users\qli1\BNS_wspace\flask\f_books\books.db"])
    connect=sqlite3.connect(r"C:\Users\qli1\BNS_wspace\flask\f_trd\trd2.db")
    return connect
    
    
# create views/routes
#@app.route("/")
#def login():
#    return render_template("login.html")
'''
    show_candy=['ticker','entry_p', 'earn_dt', 'div_dt', 'i_rsi', 'i_srtn_22_pct',\
       'i_rtn_22_pct', 'beta', 'fm_50', 'fm_200', 'fm_hi','fm_lo', 'event', 'date', 'si',\
       'exit_dt', 'i_mc']
    candy_extra=['act', 'term', 'exit_dt', 'comm', 'strike','exp_dt','last_p',\
        'iiv', 'beup', 'bedn', 'delta','vega','note',\
        'ip1','ic1','ip2','ic2','op1','oc1','op2','oc2',\
        'tgt_p','tgt_dt', 'entry_dt','exit_dt', 'mp'] 
'''
    
@app.route("/main")
def main():
    # create connection to db
    g.db = connect_db()
    # create a cursor to db
    conn = g.db.cursor()
    # execute a query against db
#    conn.execute("SELECT * FROM tbl_trade")
#    books_data = conn.fetchall()
    
    
    # how do we want to disexit_dt the data? In a list
    books = []
    # books data is a list of records that have same column items
    # i.e ticker, delta, exit_dt, mp, best represented in a dictionary
    # iterate over books data and populate books list with data
#    for book in books_data:
#        books.append({"ticker":book[0], "delta":book[1], "exit_dt":book[2], "mp":book[3]})
    
    df=pd_sql.read_sql("SELECT * FROM tbl_trade", g.db)
    for index, row in df.iterrows():  #"trd_id":df.index.values[index],
        books.append({ "ticker":df.loc[index,'ticker'], "delta":df.loc[index,'delta'],\
                "exit_dt":df.loc[index,'exit_dt'], "mp":df.loc[index,'mp']})
    # close db connection
    g.db.close()
    # pass books data to our template for use
    return render_template("main.html", books=books)

# edit route
@app.route("/edit", methods=["GET", "POST"])
def edit():
    msg = ""
    # get query string arguments
#    trd_id = request.args.get("trd_id")
    ticker = request.args.get("ticker")
    delta = request.args.get("delta")
    exit_dt = request.args.get("exit_dt")
    mp = request.args.get("mp")
    
    book = {
#        "trd_id": trd_id,
        "ticker":ticker,
        "delta":delta,
        "exit_dt":exit_dt,
        "mp":mp
    }
    
    if request.method == "POST":
        # get the data from form
 #       trd_id = request.form["trd_id"]
        ticker = request.form["ticker"]
        delta = request.form["delta"]
        exit_dt = request.form["exit_dt"]
        mp = request.form["mp"]
        
        # connect db and update record
        g.conn = connect_db()
        cursor = g.conn.cursor()
        cursor.execute("UPDATE tbl_trade SET ticker=?, delta=?, exit_dt=?, mp=?\
                       WHERE ticker=?", (ticker, delta, exit_dt, mp, ticker))
        
        g.conn.commit()
        g.conn.close()
        
        book = {
   #         "trd_id": trd_id,
            "ticker":ticker,
            "delta":delta,
            "exit_dt":exit_dt,
            "mp":mp
        }
        
        msg = "Record successfully updated!"
    
    return render_template('edit.html', book_record=book, message=msg)
    
if __name__ == "__main__":
    app.run(host=host, port=port, debug=True)
        