# -*- coding: utf-8 -*-
from flask import Flask, request, render_template, url_for, redirect, session, flash, g
import os
import sqlite3
import pandas.io.sql as pd_sql

host = os.getenv("IP", "127.0.0.1")
port = int(os.getenv("PORT", "8080"))

# configuration details
#DATABASE = "C:\\Users\qli1\BNS_wspace\flask\f_trd\trd.db"
#DATABASE = "C:\\pycode\db_op_20170907"
SECRET_KEY = "my_secret"

app = Flask(__name__)
app.config.from_object(__name__) # pulls in app configuration by looking for uppercase variables

def connect_db():
#    return sqlite3.connect(app.config["C:\Users\qli1\BNS_wspace\flask\f_books\books.db"])
    connect=sqlite3.connect(r"C:\pycode\db_op.db")
    return connect
    
@app.route("/trd_main")
def trd_main():
    # create connection to db
    g.db = connect_db()
    trades = []
    df=pd_sql.read_sql("SELECT * FROM tbl_c", g.db)
    df.sort_values(['ticker'], ascending=[True], inplace=True)
    for index, row in df.iterrows():  #"trd_id":df.index.values[index],
        trades.append({ "ticker":df.loc[index,'ticker'],  "mp":df.loc[index,'mp'], \
            "note":df.loc[index,'note'],"exp_dt":df.loc[index,'exp_dt'],"earn_dt":df.loc[index,'earn_dt'],\
            "div_dt":df.loc[index,'div_dt'],\
            "exit_dt":df.loc[index,'exit_dt'],"tgt_dt":df.loc[index,'tgt_dt'],"tgt_p":df.loc[index,'tgt_p'],\
            "ic1":df.loc[index,'ic1'],"ip1":df.loc[index,'ip1'],"ic2":df.loc[index,'ic2'],"ip2":df.loc[index,'ip2'],\
            "comm":df.loc[index,'comm'],\
            "oc1":df.loc[index,'oc1'],"op1":df.loc[index,'op1'],"oc2":df.loc[index,'oc2'],"op2":df.loc[index,'op2'], \
              "lsnv":df.loc[index,'lsnv'],"pc":df.loc[index,'pc'],"play":df.loc[index,'play'],"si":df.loc[index,'si'],\
              "beta":df.loc[index,'beta'],"delta":df.loc[index,'delta'],"vega":df.loc[index,'vega'],\
              "beup":df.loc[index,'beup'],"bedn":df.loc[index,'bedn'] ,"iv":df.loc[index,'iv']\
              })
    # pass books data to our template for use
    return render_template("trd_main.html", trades=trades)

# edit route
@app.route("/trd_edit", methods=["GET", "POST"])
def trd_edit():
    msg = ""
    # get query string arguments
    ticker = request.args.get("ticker")
    tgt_dt = request.args.get("tgt_dt")
    exit_dt = request.args.get("exit_dt")
    mp = request.args.get("mp")
    note = request.args.get("note")
    exp_dt = request.args.get("exp_dt")
    earn_dt = request.args.get("earn_dt")
    div_dt = request.args.get("div_dt")    
    tgt_p = request.args.get("tgt_p")
    ic1 = request.args.get("ic1")
    ip1 = request.args.get("ip1")
    ic2 = request.args.get("ic2")
    ip2 = request.args.get("ip2")
    comm = request.args.get("comm")
    oc1 = request.args.get("oc1")
    op1 = request.args.get("op1")
    oc2 = request.args.get("oc2")
    op2 = request.args.get("op2")
    lsnv = request.args.get("lsnv")
    pc = request.args.get("pc")
    play = request.args.get("play")
    si = request.args.get("si")    
    beta = request.args.get("beta")  
    delta = request.args.get("delta")
    vega = request.args.get("vega")
    beup = request.args.get("beup")    
    bedn = request.args.get("bedn")  
    iv = request.args.get("iv")      
    
    trd = {
#        "trd_id": trd_id,
        "ticker":ticker,
        "tgt_dt":tgt_dt,
        "exit_dt":exit_dt,
        "mp":mp,
        "note":note,
        "exp_dt":exp_dt,
        "earn_dt":earn_dt,
        "div_dt":div_dt,
        "tgt_p":tgt_p,
        "ic1":ic1,
        "ip1":ip1,
        "ic2":ic2,
        "ip2":ip2,
        "comm":comm,
        "lsnv":lsnv,
        "pc":pc,
        "play":play,
        "oc1":oc1,
        "op1":op1,
        "oc2":oc2,
        "op2":op2,  
        "si":si,
        "delta":delta,
        "vega":vega,
        "beup":beup,  
        "bedn":bedn,
        "beta":beta,        
        "iv":iv      
    }
    
    if request.method == "POST":
        # get the data from form
 #       trd_id = request.form["trd_id"]
        ticker = request.form["ticker"]
        tgt_dt = request.form["tgt_dt"]
        exit_dt = request.form["exit_dt"]
        mp = request.form["mp"]
        note = request.form["note"]
        exp_dt = request.form["exp_dt"]
        earn_dt = request.form["earn_dt"]
        div_dt = request.form["div_dt"]
        tgt_p= request.form["tgt_p"]
        ic1 = request.form["ic1"]
        ip1 = request.form["ip1"]
        ic2 = request.form["ic2"]
        ip2 = request.form["ip2"]
        comm= request.form["comm"]
        oc1 = request.form["oc1"]
        op1 = request.form["op1"]
        oc2 = request.form["oc2"]
        op2 = request.form["op2"]
        lsnv = request.form["lsnv"]
        pc = request.form["pc"]
        play = request.form["play"]
        si = request.form["si"]  
        beta = request.form["beta"] 
        delta = request.form["delta"]
        vega = request.form["vega"]
        beup = request.form["beup"]  
        bedn = request.form["bedn"]         
        iv = request.form["iv"]         
        
        # connect db and update record
        g.conn = connect_db()
        cursor = g.conn.cursor()
        cursor.execute("UPDATE tbl_c SET ticker=?, tgt_dt=?, exit_dt=?, mp=?, tgt_p=?\
                       ,note=?, exp_dt=?, earn_dt=?, div_dt=? \
                       ,ic1=?, ip1=?, ic2=?, ip2=?, comm=?,oc1=?, op1=?, oc2=?, op2=?, \
                       lsnv=?, pc=?, play=?, si=?, beta=?, delta=?, vega=?, beup=?, bedn=?, iv=? \
                       WHERE ticker=?", (ticker, tgt_dt, exit_dt, mp, tgt_p, note, exp_dt, earn_dt, div_dt, \
                       ic1, ip1, ic2, ip2, comm, oc1, op1, oc2, op2,lsnv,pc,play, si, beta, \
                       delta, vega, beup, bedn, iv, ticker))
        g.conn.commit()
        g.conn.close()
        trd = {
   #         "trd_id": trd_id,
            "ticker":ticker,
            "tgt_dt":tgt_dt,
            "exit_dt":exit_dt,
            "mp":mp,
            "note":note,
            "exp_dt":exp_dt,
            "earn_dt":earn_dt,
            "div_dt":div_dt,
            "tgt_p":tgt_p,
            "ic1":ic1,
            "ip1":ip1,
            "ic2":ic2,
            "ip2":ip2,
            "comm":comm,
            "lsnv":lsnv,
            "pc":pc,
            "play":play,
            "oc1":oc1,
            "op1":op1,
            "oc2":oc2,
            "op2":op2,
            "si":si,
            "delta":delta,
            "vega":vega,
            "beup":beup,  
            "bedn":bedn,
            "beta":beta,
            "iv":iv              
        }
        msg = "tbl_c successfully updated!"
    return render_template('trd_edit.html', t=trd, message=msg)

# add menu to tbl_spec_candy
@app.route("/spec_main")
def spec_main():
    # create connection to db
    g.db = connect_db()
    specs = []
    df=pd_sql.read_sql("SELECT * FROM tbl_spec_candy", g.db)

    df.sort_values(['date','ticker'], ascending=[False,True], inplace=True)
    df=df.head(20)
    for index, row in df.iterrows():  #"trd_id":df.index.values[index],
        specs.append({ "ticker":df.loc[index,'ticker'],  "date":df.loc[index,'date'], \
            "note":df.loc[index,'note'],"i_lsnv":df.loc[index,'i_lsnv'],"bet":df.loc[index,'bet']\
            ,"sec":df.loc[index,'sec'],"beta":df.loc[index,'beta'] ,"i_play":df.loc[index,'i_play']})
    # pass books data to our template for use
    return render_template("spec_main.html", specs=specs)

# spec_edit route
@app.route("/spec_edit", methods=["GET", "POST"])
def spec_edit():
    msg = ""
    # get query string arguments
    ticker = request.args.get("ticker")
    date = request.args.get("date")
    note = request.args.get("note")
    i_lsnv = request.args.get("i_lsnv")
    bet = request.args.get("bet")
    sec = request.args.get("sec")
    beta = request.args.get("beta")   
    i_play = request.args.get("i_play") 
    spec = {
#        "trd_id": trd_id,
        "ticker":ticker,
        "date":date,
        "note":note,
        "i_lsnv":i_lsnv,
        "bet":bet,
        "sec":sec,
        "beta":beta,
        "i_play":i_play
    }
    if request.method == "POST":
        # get the data from form
 #       trd_id = request.form["trd_id"]
        ticker = request.form["ticker"]
        date = request.form["date"]
        note = request.form["note"]
        i_lsnv = request.form["i_lsnv"]
        i_play = request.form["i_play"]
        bet = request.form["bet"]
        sec = request.form["sec"]
        beta = request.form["beta"]
        # connect db and update record
        g.conn = connect_db()
        cursor = g.conn.cursor()
        cursor.execute("UPDATE tbl_spec_candy SET ticker=?, date=?, note=?, i_lsnv=?, \
                       i_play=?,bet=?, sec=?, beta=?\
                       WHERE ticker=?", (ticker, date, note, i_lsnv, i_play, bet, sec, beta, ticker))
        g.conn.commit()
        g.conn.close()
        spec = {
   #         "trd_id": trd_id,
            "ticker":ticker,
            "date":date,
            "note":note,
            "i_lsnv":i_lsnv,
            "bet":bet,
            "sec":sec,
            "beta":beta,
            "i_play":i_play
        }
        msg = "tbl_spec_candy successfully updated!"
    return render_template('spec_edit.html', t=spec, message=msg)

# add menu to tbl_trd_candy
@app.route("/candy_main")
def candy_main():
    # create connection to db
    g.db = connect_db()
    candy = []
    df=pd_sql.read_sql("SELECT * FROM tbl_trade_candy", g.db)
    for index, row in df.iterrows():  #"trd_id":df.index.values[index],
        candy.append({ \
        "act":df.loc[index, 'act'], "entry_dt":df.loc[index, 'entry_dt'], "ticker":df.loc[index, 'ticker']\
        , "note":df.loc[index, 'note'], "si":df.loc[index, 'si']\
        , "bedn":df.loc[index, 'bedn'], "beup":df.loc[index, 'beup'], "comm":df.loc[index, 'comm']\
        , "div_dt":df.loc[index, 'div_dt'], "earn_dt":df.loc[index, 'earn_dt'], \
        "exp_dt":df.loc[index, 'exp_dt'], "entry_p":df.loc[index, 'entry_p'], "ic1":df.loc[index, 'ic1']\
        , "i_iv":df.loc[index, 'i_iv'], "ip1":df.loc[index, 'ip1'], "strike":df.loc[index, 'strike']\
        , "tgt_dt":df.loc[index, 'tgt_dt'], "tgt_p":df.loc[index, 'tgt_p']\
         ,"lsnv":df.loc[index,'lsnv'],"pc":df.loc[index,'pc'],"play":df.loc[index,'play']\
         ,"sec":df.loc[index,'sec'],"beta":df.loc[index,'beta'] \
         ,"delta":df.loc[index,'delta'],"vega":df.loc[index,'vega'],"mp":df.loc[index,'mp'] })
    # pass books data to our template for use
    return render_template("candy_main.html", candy=candy)

# candy_edit route
@app.route("/candy_edit", methods=["GET", "POST"])
def candy_edit():
    msg = ""
    # get query string arguments
    ticker = request.args.get("ticker")
    act = request.args.get("act")
    entry_dt = request.args.get("entry_dt")
    ticker = request.args.get("ticker")
    note = request.args.get("note")
    si = request.args.get("si")

    bedn = request.args.get("bedn")
    beup = request.args.get("beup")
    comm = request.args.get("comm")
    div_dt = request.args.get("div_dt")
    earn_dt = request.args.get("earn_dt")
    exp_dt = request.args.get("exp_dt")
    entry_p = request.args.get("entry_p")
    ic1 = request.args.get("ic1")
    i_iv = request.args.get("i_iv")
    ip1 = request.args.get("ip1")
    strike = request.args.get("strike")
    tgt_dt = request.args.get("tgt_dt")
    tgt_p = request.args.get("tgt_p")
    lsnv = request.args.get("lsnv")
    pc = request.args.get("pc")
    play = request.args.get("play")
    sec = request.args.get("sec")    
    beta = request.args.get("beta") 
    delta = request.args.get("delta")    
    vega = request.args.get("vega") 
    mp = request.args.get("mp")  
    
    candy = {
#        "trd_id": trd_id,
    "ticker":ticker,
    "act":act,
    "entry_dt":entry_dt,
    "ticker":ticker,
    "note":note,
    "si":si,

    "bedn":bedn,
    "beup":beup,
    "comm":comm,
    "div_dt":div_dt,
    "earn_dt":earn_dt,
    "exp_dt":exp_dt,
    "entry_p":entry_p,
    "ic1":ic1,
    "i_iv":i_iv,
    "ip1":ip1,
    "strike":strike,
    "tgt_dt":tgt_dt,
    "tgt_p":tgt_p,
    "lsnv":lsnv,
    "pc":pc,
    "play":play,
    "sec":sec,
    "beta":beta,
    "delta":delta,
    "vega":vega,
    "mp":mp    
    }
    
    if request.method == "POST":
        # get the data from form
 #       trd_id = request.form["trd_id"]
        ticker = request.form["ticker"]
        act = request.form["act"]
        entry_dt = request.form["entry_dt"]
        ticker = request.form["ticker"]
        note = request.form["note"]
        si = request.form["si"]
        play = request.form["play"]
        bedn = request.form["bedn"]
        beup = request.form["beup"]
        comm = request.form["comm"]
        div_dt = request.form["div_dt"]
        earn_dt = request.form["earn_dt"]
        exp_dt = request.form["exp_dt"]
        entry_p = request.form["entry_p"]
        ic1 = request.form["ic1"]
        i_iv = request.form["i_iv"]
        ip1 = request.form["ip1"]
        strike = request.form["strike"]
        tgt_dt = request.form["tgt_dt"]
        tgt_p = request.form["tgt_p"]
        lsnv = request.form["lsnv"]
        pc = request.form["pc"]
        play = request.form["play"]
        sec = request.form["sec"]  
        beta = request.form["beta"] 
        delta = request.form["delta"]  
        vega = request.form["vega"] 
        mp = request.form["mp"]       
        
        # connect db and update record
        g.conn = connect_db()
        cursor = g.conn.cursor()
        cursor.execute("UPDATE tbl_trade_candy SET ticker=?,act=?,entry_dt=?,ticker=?,note=?,si=?,\
                       bedn=?,beup=?,comm=?,div_dt=?,earn_dt=?,exp_dt=?,entry_p=?,ic1=?,i_iv=?,\
                       ip1=?,strike=?,tgt_dt=?,tgt_p=?,\
                       lsnv=?, pc=?, play=?, sec=?, beta=? , delta=?, vega=? , mp=?\
                       WHERE ticker=?", \
    (ticker,act,entry_dt,ticker,note,si,bedn,beup,comm, div_dt,earn_dt,exp_dt,\
     entry_p,ic1,i_iv,ip1,strike,tgt_dt,tgt_p,lsnv,pc,play,sec, beta, delta, vega,mp, ticker))
        g.conn.commit()
        g.conn.close()
    candy = {
#        "trd_id": trd_id,
        "ticker":ticker,
        "act":act,
        "entry_dt":entry_dt,
        "ticker":ticker,
        "note":note,
        "si":si,

        "bedn":bedn,
        "beup":beup,
        "comm":comm,
        "div_dt":div_dt,
        "earn_dt":earn_dt,
        "exp_dt":exp_dt,
        "entry_p":entry_p,
        "ic1":ic1,
        "i_iv":i_iv,
        "ip1":ip1,
        "strike":strike,
        "tgt_dt":tgt_dt,
        "tgt_p":tgt_p,
        "lsnv":lsnv,
         "pc":pc,
         "play":play,
         "sec":sec,
         "beta":beta,
         "delta":delta,
         "vega":vega,
         "mp":mp  
        }
    msg = "tbl_trade_candy successfully updated!"
    return render_template('candy_edit.html', t=candy, message=msg)

    
if __name__ == "__main__":
    app.run(host=host, port=port, debug=True)
        