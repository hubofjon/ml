import java.util.*;
import java.sql.*;

class CleanDB
{
  private Connection   connection     = null;
  private Connection   dumpTranConnection = null;
  private String       databaseName = null;
  private String       jdbcDriver     = null;
  private String       url            = null;
  private String       loginName      = null;
  private String       loginPwd       = null;
  private String       binaryType     = null;
  private String       tableNames      = null;
  private boolean _Default = true;
  private String VALUE_COL = null;
  private String graphTable = null;
  private String ctxTable = null;
  //private String indexTable = null;
  private String metaTable = null;
  private String clusterTable = null;

  CleanDB (String URL, String login, String passwd)
  {
    url = URL;
    loginName = login;
    loginPwd = passwd;
    graphTable = "vbins_graph_tbl";
    ctxTable = "vbins_ctx_tbl";
    //indexTable = "vbins_index_tbl";
    metaTable = "vbins_meta_tbl";
    clusterTable = "vbins_cluster_tbl";

    System.out.println("Database URL = " + url);
    if (url.startsWith("jdbc:interbase")) {
      jdbcDriver = new String("interbase.interclient.Driver");
    } else if (url.startsWith("jdbc:oracle")) {
      jdbcDriver = new String("oracle.jdbc.driver.OracleDriver");
    } else if (url.startsWith("jdbc:sybase")){
      databaseName = new String ("Sybase");
      jdbcDriver = new String("com.sybase.jdbc2.jdbc.SybDriver");
      //jdbcDriver = new String("com.sybase.jdbc.SybDriver");
    } else if (url.startsWith("jdbc:borland")){
      jdbcDriver = new String("com.borland.datastore.jdbc.DataStoreDriver");
    } else if (url.startsWith("jdbc:weblogic")){
      jdbcDriver = new String("weblogic.jdbc.mssqlserver4.Driver");
    } else if (url.startsWith("jdbc:db2")){
      jdbcDriver = new String("COM.ibm.db2.jdbc.app.DB2Driver");
    }

    System.out.println("JDBC Driver = " + jdbcDriver);
    if ( url.startsWith("jdbc:interbase")) {
      VALUE_COL = new String("INDEX_VALUE");
    } else {
      VALUE_COL = new String("INDEX_VALUE");
    }

    binaryType = url.startsWith("jdbc:oracle")
                   ? new String("LONG")
                   : url.startsWith("jdbc:sybase")
                   ? new String("TEXT")
                   : url.startsWith("jdbc:interbase")
                   ? new String("Blob SUB_TYPE 1")
                   : url.startsWith("jdbc:weblogic")
                   ? new String("text")
                   : url.startsWith("jdbc:db2")
                   ? new String("LONG VARCHAR")
                   : new String("CHAR(1500,1500)");

    tableNames = url.startsWith("jdbc:sybase")
                   ? new String("vbins")
                   : url.startsWith("jdbc:db2")
                   ? new String("VBINS")
                   : new String("VBINS");

    System.out.println("Binary type = " + binaryType);
    try
    {
       System.out.println("loading jdbc driver...");
       Class.forName (jdbcDriver); // load and register driver
       System.out.println("loaded jdbc driver");
    }
    catch (Exception ex)
    {
      System.out.println ("Could not load JDBC driver");
      ex.printStackTrace();
      System.exit(1);
    }

    System.out.println ("Establishing JDBC Connection ...");
    try
    {
       connection = DriverManager.getConnection (url,loginName,loginPwd);
       if (databaseName != null) {
         //dumpTranConnection = DriverManager.getConnection (url, "sa", "");
         dumpTranConnection = DriverManager.getConnection (url, loginName, loginPwd);
       } 
    }
    catch (SQLException ex)
    {
      ex.printStackTrace();
      System.out.println ("Could not connect to database");
    }

    try
    {
      System.out.println("Checking for VisiNaming tables in database");
      DatabaseMetaData dbmd = connection.getMetaData();
      String[] s = {"TABLE"};
      ResultSet rs = dbmd.getTables(null, null, tableNames+"%",s);
      int i = 0;
      while (rs.next())
      {
        ++i;
      }
      if (i > 0) {
        System.out.println("Tables exist.");
        cleanTables();
      }
    }
    catch (Exception ex)
    {
      System.out.println ("Cannot get MetaData");
    }
  }

   public void dumpSybaseLog() {
      try{
         Statement stmt = dumpTranConnection.createStatement();
         stmt.executeUpdate ("dump tran root_db with no_log");
         stmt.close();
      } catch (SQLException sqlex){
         System.out.println("SQL exception caught " + sqlex);
         sqlex.printStackTrace();
      }
   }

    public void finalize ()
    {
        try
        {
           if (dumpTranConnection != null) {
              dumpTranConnection.close();
           }
           connection.close();
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();
        }
    }
  
  public synchronized void cleanTables()
  {
    try
    {
      connection.setAutoCommit(false);
      Statement stmt = connection.createStatement();
      System.out.println("Cleaning Context Table");
      stmt.executeUpdate ("delete from " + ctxTable + " where CTX_INDEX > 0");
      System.out.println("Cleaning Graph Table");
      stmt.executeUpdate ("delete from " + graphTable + " where TYPE >= -2");
      System.out.println("Cleaning Meta Store Table");
      stmt.executeUpdate ("delete from " + metaTable + " where " + VALUE_COL + " > 0");
      stmt.executeUpdate ("insert into " + metaTable + " values ('CTX_INDEX', 0)");
      stmt.executeUpdate ("insert into " + metaTable + " values ('SCHEMA_VERSION', 1)");
      System.out.println("Cleaning Cluster Table");
      stmt.executeUpdate ("delete from " + clusterTable + " where CLUSTER_INDEX > 0");
      connection.commit();
      stmt.close();
      connection.setAutoCommit(true);
    }
    catch (SQLException ex)
    {
      ex.printStackTrace();
    }
  }

  public static void main(String[] args) 
  {
    if (args.length != 3) {
      System.out.println("\nUsage:");
      System.out.println("	java CleanDB <database_url> <login_name> <password>\n");
      System.exit(1); 
    }

    String url = new String(args[0]);
    String login = new String(args[1]);
    String passwd = new String(args[2]);

    CleanDB xConn = new CleanDB(url, login, passwd);
    xConn.finalize();
  }
};

