# -*- coding: utf-8 -*-
"""
Using 3rd party 
1. reqSecDefOptParams
2. reqContractDetails
3. reqHistoricalData
4. ib.reqHeadTimeStamp
5. recipes (vol calc, news, div, ratios, scanner)



"""

from ib_insync import *
util.startLoop()

ib = IB()
ib.connect('127.0.0.1', 7497, clientId=12)
spx = Index('SPX', 'CBOE')
kem=Option('kem', '20191220', 17, 'CALL', 'SMART',100, 'USD')
spx=kem
"""
testing details: 
kems = ib.reqContractDetails(kem)
ib.reqHeadTimeStamp(contract, whatToShow='TRADES', useRTH=True)
Historical tick data can be fetched with a maximum of 1000 ticks at a time. Either the start time or the end time must be given, and one of them must remain empty:
bars = ib.reqHistoricalData(
        contract,
        endDateTime='',
        durationStr='60 D',
        barSizeSetting='1 hour',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1)
"""

ib.qualifyContracts(spx)
[ticker] = ib.reqTickers(spx)
spxValue = ticker.marketPrice()
chains = ib.reqSecDefOptParams(spx.symbol, '', spx.secType, spx.conId)


df=util.df(chains)
chain = next(c for c in chains if c.tradingClass == 'SPX' and c.exchange == 'SMART')
strikes = [strike for strike in chain.strikes
        if strike % 5 == 0
        and spxValue - 20 < strike < spxValue + 20]
expirations = sorted(exp for exp in chain.expirations)[:3]
rights = ['P', 'C']

contracts = [Option('SPX', expiration, strike, right, 'SMART', tradingClass='SPX')
        for right in rights
        for expiration in expirations
        for strike in strikes]

contracts = ib.qualifyContracts(*contracts)
tickers = ib.reqTickers(*contracts)

#%%
def op_calc():
    option = Option('EOE', '20171215', 490, 'P', 'FTA', multiplier=100)
    
    calc = ib.calculateImpliedVolatility(
        option, optionPrice=6.1, underPrice=525))
    print(calc)
    
    calc = ib.calculateOptionPrice(
        option, volatility=0.14, underPrice=525))
    print(calc)
"""


ib.disconnect()


"""
use
1. pre_entry. CID chart (iv, p, vol)
bars = ib.reqHistoricalData(
        contract,
        endDateTime='',
        durationStr='60 D',
        barSizeSetting='1 hour',
        whatToShow='TRADES',
        useRTH=True,
        formatDate=1)

note: Ambiguous contracts are great to use with reqContractDetails
OptionForQuery()

"""
