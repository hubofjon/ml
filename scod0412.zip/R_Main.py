import pandas as pd
import datetime as datetime
from pandas.tseries.offsets import BDay
import warnings
warnings.filterwarnings("ignore")
pd.options.display.float_format = '{:.2f}'.format
from P_commons import read_sql, to_sql_append, to_sql_replace, bdate, backup_db
from R_update_price import update_pv_eod, trig_run, vpj_plot, trig_run_1, update_price_eod
from R_stat import stat_run_base, stat_VIEW, stat_PLOT, etf_corr, stat_sec_leadlag, stat_sec_sharpe
from R_track import track_raw, spec, re_spec,trade_candy, spec_track
from R_options import unop_mc, mc_intel, unop_bc, bc_intel, bmc_intel,  candy_combo, candy_track
from R_plot import plot_base, plot_QI
from R_senti import sentis, sentis_intel, senti_mc
import datetime

position_list=read_sql("SELECT ticker FROM tbl_c where exit_dt ='N' order by ticker").ticker
indicator_list=['AAPL','KLAC','URI','BID','EDIT','SGMO','PLNT','CDXS','MILN','LNGR']
extreme_list=['DF','FXE','ZBTC','GUSH','XNET','IDEX','MAXR','DBC']
trend_list=['EDIT','PLNT','SGMO']

q_date=bdate()
RUN_COUNT='n'
##    backup_db()
RUN_COUNT=input(" - copy db? flask_update? -- Run EOD?  yes/n:    ")
if RUN_COUNT=='yes':
    print(" ---- STARTS %s ----"%q_date)
    update_pv_eod('etf', q_date)  #  to tbl_pv_etf, (profile_etf list)
    update_pv_eod('sp500', q_date) #tbl_pv_ is the original raw table
    update_pv_eod('all', q_date)
    update_price_eod('etf', q_date) #same eod file, to tbl_price_sp, etf
    update_price_eod('sp500', q_date)
    print("-----positions ----")
    plot_base(q_date, position_list) #from tbl_pv_all
    RUN_COUNT='n'
    
    ds_sp=stat_run_base(q_date, 'sp500') #from tbl_price_, to tb_stat_
    ds_sec=stat_run_base(q_date, 'sec')
    ds_etf=stat_run_base(q_date, 'etf_all')
    df_stat=stat_VIEW(q_date) #from tb_stat_, view only
    stat_PLOT(q_date)   # from tb_stat_
    
    dmc=unop_mc(q_date)
    dmct=mc_intel(q_date)
    dbc=unop_bc(q_date)
    dbct=bc_intel(q_date)
    dbmct=bmc_intel(q_date)
    dc=candy_combo(q_date)
    
    df_sentis=sentis()
    sentis_intel(df_sentis, q_date)
    senti_mc()
    etf_corr()
    stat_sec_sharpe()
    stat_sec_leadlag(q_date)
    plot_QI()
    spec_track(q_date)
#    df_track=track_raw(q_date)
# -----------------------------------------------  #
#mutable funcion https://docs.python.org/3/faq/programming.html#how-do-i-write-a-function-with-output-parameters-call-by-reference
#https://stackoverflow.com/questions/38895768/python-pandas-dataframe-is-it-pass-by-value-or-pass-by-reference/38925257