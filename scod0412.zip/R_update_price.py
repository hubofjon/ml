"""
Function: 
    1. update_pv_eod
    2. update_price_eod
    3. trig_mark etc. 
"""
import pandas as pd
import numpy as np
import datetime as datetime
import pandas_datareader.data as web
from pandas_datareader import data, wb
import sys, os
import sqlite3 as db
import pandas.io.sql as pd_sql
from P_commons import read_sql, to_sql_replace, to_sql_append, get_conn, tbl_nodupe_append

#dir_eod='c:\\pycode\\eod'
dir_eod="C:\\Users\qli1\BNS_git"

def update_pv_eod(underlying, q_date):  #can update multiple datefiles
    """
    Use: append eod file "eoddata.com"
    data_src: USE file from eoddata.com
    data_dest: tbl_pv_etf/sp500/all
    """
    pro=read_sql("select * from profile_all")
    pro_etf=read_sql("select * from profile_etf")
    if underlying =='sp500':
        df_symbol=pro[pro.mkt=='SPY'].ticker.tolist()
    elif underlying =='etf':
        df_symbol=pro_etf.ticker.tolist()
    date_max=read_sql("SELECT max(date) FROM tbl_pv_etf", q_date).iloc[0,0]     
    date_max=date_max.replace('-','')
#    path='c:\\pycode\\eod'
    path_eod=r"%s"%dir_eod
    files=os.listdir(path_eod)
    files_csv=[f for f in files if f[:3]=='USE']
    if len(files_csv)==0:
        print("eod file not available")
        return
    df=pd.DataFrame()    
    for f in files_csv:
        date_csv=f[4:12]
        if (date_csv <=date_max) & (underlying=='etf'):
            print("price of '%s' already exit"%date_csv)
            sys.exit()
#        df_tmp=pd.read_csv(r'c:\pycode\eod\%s'%f)#, index_col=0)
        df_tmp=pd.read_csv(os.path.join(path_eod, f)) 
        if underlying !='all':  #if sp500 or etf
            df_tmp=df_tmp[df_tmp['A'].isin(df_symbol)]
        df_tmp.columns=[['ticker', 'date', 'open', 'high', 'low', 'close', 'volume']]    
        df=pd.concat([df,df_tmp], axis=0)
    df['date']=pd.to_datetime(df['date']).dt.date # convert str to datetime
    df.sort_values(['date','ticker'], ascending=['False', 'True'], inplace=True)
#    pd_sql.to_sql(df, "tbl_pv_%s"%underlying, conn, if_exists='append', index=False)
    tbl_nodupe_append(q_date, df, "tbl_pv_%s"%underlying)

def update_price_eod(underlying, q_date):#
    """
    Use: append eod file "eoddata.com"
    data_src: USE file from eoddata.com
    data_dest: tbl_price_sp500/etf
    """
    pro=read_sql("select * from profile_all")
    pro_etf=read_sql("select * from profile_etf")
    if underlying =='sp500':
        df_symbol=pro[pro.mkt=='SPY'].ticker.tolist()
    elif underlying =='etf':
        df_symbol=pro_etf.ticker.tolist()
    date_max=read_sql("SELECT max(date) FROM tbl_pv_etf", q_date).iloc[0,0]     
    date_max=date_max.replace('-','')
#    path='c:\\pycode\\eod'
    path_eod=r"%s"%dir_eod
    files=os.listdir(path_eod)
    files_csv=[f for f in files if f[:3]=='USE']
    if len(files_csv)==0:
        print("eod file not available")
        return
    df=pd.DataFrame()    
    for f in files_csv:
        date_csv=f[4:12]
        if (date_csv <=date_max) & (underlying=='etf'):
            print("price of '%s' already exit"%date_csv)
            sys.exit()
        df_tmp=pd.read_csv(os.path.join(path_eod, f)) 
        # filter df with series df_sp500
        df_tmp=df_tmp[df['A'].isin(df_symbol)]
        df_tmp=df.iloc[:,[0,1,5]] #ticker, date, close
        df_tmp=df.T
        df_tmp=df_tmp.rename(columns=df.iloc[0]) #convert row to columns name
        df_tmp['date']=df_tmp.iloc[1,1]
        df_tmp['date']=pd.to_datetime(df_tmp['date'])  #convert string to datetime
#        df.set_index('date', inplace=True)
#        df.index.name='date'
        df_tmp=df_tmp.iloc[2,:] #keep close only
        df=df.append(df_tmp)
#        os.remove(r'c:\pycode\eod\%s'%f)
    df.reset_index(drop=True, inplace=True)
    df.sort_values('date', ascending=True, inplace=True) 
#    eod_to_sql_append(df, underlying)
    tbl_nodupe_append(q_date, df, "tbl_price_%s"%underlying)
    return df

#def eod_to_sql_append(df, underlying):
#    conn=db.connect('c:\\pycode\db_op.db')
#    if underlying =='sp500':
#        pd_sql.to_sql(df, "tbl_price", conn, if_exists='append', index=False)
#    elif underlying =='etf':
#        pd_sql.to_sql(df, "tbl_price_etf", conn, if_exists='append', index=False)
#    print("%s eod: %s appended to tbl_price"%(underlying, todate))


    



