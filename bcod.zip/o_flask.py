# -*- coding: utf-8 -*-
from flask import Flask, request, render_template, url_for, redirect, session, flash, g
import os
#import sqlite3
import pandas.io.sql as pd_sql
import pandas as pd
from o_functions import sql_query, sql_query_var, sql_query_one, sql_read, sql_append, sql_edit_insert, sql_delete

host = os.getenv("IP", "127.0.0.1")
port = int(os.getenv("PORT", "5000"))
SECRET_KEY = "my_secret"
app = Flask(__name__)
app.config.from_object(__name__) # pulls in app configuration by looking for uppercase variables

#%% add menu to tbl_trd_candy
@app.route("/")
def op_main():
    results = sql_query(''' SELECT * FROM tbl_trade_candy ORDER BY ticker, pid''')
    return render_template('op_main.html', results=results) 
#%%
@app.route('/insert_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def insert_form():
    if request.method == 'GET':
        i_ticker = request.args.get('i_ticker')
        e_leg=sql_query_one(' SELECT * FROM tbl_trade_candy where ticker=?',([i_ticker]))
    results = sql_query(''' SELECT * FROM tbl_trade_candy ORDER BY ticker, pid''')
    msg="insert_form msg"
    return render_template('op_main.html', e_leg=e_leg, results=results, msg=msg)
#%%
@app.route('/insert',methods = ['POST', 'GET']) #this is when user submit after edit
def insert():
    if request.method == 'POST':	
        ticker = request.form["ticker"].upper()
        type = request.form["type"].upper()
        strike = request.form["strike"]
        exp_dt = request.form["exp_dt"]
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        comm = request.form["comm"]
        pid = request.form["pid"]
        play = request.form["play"]
        sql_edit_insert('INSERT INTO tbl_trade_candy (ticker, type, strike, exp_dt, ioc, iop,\
            comm, pid, play) VALUES (?,?,?,?,?,?,?,?,?)', (ticker, type, strike, exp_dt, ioc, iop,comm, pid, play) )
    e_leg=sql_query_one(' SELECT * FROM tbl_trade_candy where ticker=?',([ticker]))
    all_legs=sql_query_var(" SELECT * FROM tbl_trade_candy where ticker=? ",([ticker]))
    results = sql_query(''' SELECT * FROM tbl_trade_candy ORDER BY ticker, pid''')
    msg= "insert msg" #[ticker, play, pid]
    return render_template('op_main.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg)  
#%%
@app.route('/edit_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def edit_form():
    if request.method == 'GET':
        e_ticker = request.args.get('e_ticker')
        e_pid = request.args.get('e_pid')
        e_leg=sql_query_var(" SELECT * FROM tbl_trade_candy where ticker=? and pid=?",(e_ticker,e_pid))
        all_legs=sql_query_var(" SELECT * FROM tbl_trade_candy where ticker=? ",([e_ticker]))
    results = sql_query(''' SELECT * FROM tbl_trade_candy ORDER BY ticker, pid''')
    msg=e_pid
    return render_template('op_main.html', e_leg=e_leg[0], all_legs=all_legs, results=results, msg=msg)
#%%
@app.route('/edit',methods = ['POST', 'GET']) #this is when user submit after edit
def edit():
    if request.method == 'POST':	
        ticker = request.form["ticker"].upper()
        pid = request.form["pid"]
        type = request.form["type"].upper()
        strike = request.form["strike"]
        exp_dt = request.form["exp_dt"]
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        comm = request.form["comm"]
        play = request.form["play"]
        sql_edit_insert("UPDATE tbl_trade_candy SET type=?, strike=?, exp_dt=?, ioc=?, iop=?, comm=?,\
                play=? WHERE ticker=? and pid=?", (type, strike, exp_dt, ioc, iop, comm, play, ticker, pid)) 
        e_leg=sql_query_var(" SELECT * FROM tbl_trade_candy where ticker=? and pid=?",(ticker,pid))
        all_legs=sql_query_var(" SELECT * FROM tbl_trade_candy where ticker=? ",([ticker]))
    results = sql_query(''' SELECT * FROM tbl_trade_candy ORDER BY ticker, pid''')
    msg= "ticker, pid, vol" #[ticker, play, pid]
    return render_template('op_main.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg) 
#%%
@app.route('/delte',methods = ['GET']) #this is when user submit after edit
def delete():
    if request.method == 'GET':
        ticker = request.args.get('d_ticker')
        pid = request.args.get('d_pid')
        sql_delete("  DELETE FROM tbl_trade_candy where ticker = ? and pid = ? ", (ticker, pid) )
    results = sql_query(''' SELECT * FROM tbl_trade_candy ORDER BY ticker, pid''')
    msg= "ticker, pid, vol" #[ticker, play, pid]
    return render_template('op_main.html', results=results, msg=msg) 
if __name__ == "__main__":
    app.run(host=host, port=port, debug=True)

"""
RESOURCE:
    https://medium.com/@aliciagilbert.itsimplified/a-slick-crud-application-built-using-python-with-flask-and-sqlite3-to-teach-simple-mysql-queries-bd75e1109582
    https://github.com/itsimplified/slick-crud-app
    
    table: https://sarahleejane.github.io/learning/python/2015/08/09/simple-tables-in-webapps-using-flask-and-pandas-with-python.html
    #ajax table
    https://stackoverflow.com/questions/51468834/how-to-get-python-to-retrieve-user-inputted-data-from-a-dynamic-table-using-flas
{# 
         {% for key, value in result_dictionary.iteritems() %}
            <tr>
               <th> {{ key }} </th>
               <td> {{ value }} </td>
            </tr>
         {% endfor %}
	return a form in dictionary format:	 
	if request.method == 'POST':
    result = request.form
    return render_template("result.html",result = result)
	
	3. cookie
	   resp = make_response(render_template('readcookie.html'))
   resp.set_cookie('userID', user)
   name = request.cookies.get('userID')
   
   
#}
!! dataframe to table or pages
https://galaxydatatech.com/2018/03/31/passing-dataframe-web-page/
"""
    