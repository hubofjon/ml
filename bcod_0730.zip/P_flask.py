# -*- coding: utf-8 -*-
from flask import Flask, request, render_template, url_for, redirect, session, flash, g
import os
#import sqlite3
import pandas.io.sql as pd_sql
import pandas as pd
from o_functions import sql_query, sql_query_var, sql_query_one, sql_read, sql_append, sql_edit_insert, sql_delete
from P_commons import to_sql_replace, read_sql, bdate
from dateutil import parser

host = os.getenv("IP", "127.0.0.1")
port = int(os.getenv("PORT", "5000"))
candy_max_dt=read_sql("select max(date) from tbl_candy ").iloc[0,0].split()[0]
candy_track_max_dt=read_sql("select max(date) from tbl_candy_track ").iloc[0,0].split()[0]
candy_track_min_dt=read_sql("select DISTINCT date from tbl_candy order by date  \
                DESC LIMIT 10 ").iloc[9,0].split()[0]
q_date=bdate()
SECRET_KEY = "my_secret"
app = Flask(__name__)
app.config.from_object(__name__) # pulls in app configuration by looking for uppercase variables


#%% o_trd_html: add menu to tbl_trd_candy
@app.route("/o_trd")
def o_trd():
    results = sql_query(" SELECT * FROM tbl_oc WHERE exit_dt='N' and oexp_dt>='%s' ORDER BY ticker, pid, cid, entry_dt "%q_date)
    return render_template('o_trd.html', results=results) 
#%%
@app.route('/t_insert_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def t_insert_form():
    if request.method == 'GET':
        i_uid = request.args.get('i_uid')
        e_leg=sql_query_one(' SELECT * FROM tbl_oc where uid=?',([i_uid]))
        results = sql_query("select oc.*, v.earn_dt_mc, v.div_dt, v.iv, v.iv_chg_pct, v.iv_rank, \
            v.vol, v.sec as sec_mc from tbl_oc oc LEFT JOIN tbl_iv v on oc.ticker=v.ticker \
            WHERE oc.exit_dt='N' and oc.oexp_dt>='%s' and v.date='%s' ORDER BY ticker, pid, \
            cid, entry_dt"%(q_date, q_date))
    msg="insert_form msg"
    return render_template('o_trd.html', e_leg=e_leg, results=results, msg=msg)
#%%
@app.route('/t_insert',methods = ['POST', 'GET']) #this is when user submit after edit
def t_insert():
    if request.method == 'POST':	
        act = request.form["act"].upper()
        ticker = request.form["ticker"].upper()
        entry_dt = request.form["entry_dt"]
        type = request.form["type"].upper()
        strike = request.form["strike"]
        oexp_dt = request.form["oexp_dt"]
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        comm = request.form["comm"]
        pid = request.form["pid"].upper()
        play = request.form["play"].upper()
        exit_dt = request.form["exit_dt"]
        sec = request.form["sec"].upper()
        #rebuld cid/uid
        expiry=parser.parse(oexp_dt)
        expiry=expiry.strftime('%y%m%d')
        strike_tmp=str(int(float(strike) *1000)).rjust(8,'0')
        cid=ticker + '-' + expiry +type+strike_tmp
        uid=cid + pid + entry_dt
        df=sql_read("select * from tbl_oc")
        if uid in df['uid'].values:
            msg="insert: dupe, no insert"
        else: 
            sql_edit_insert('INSERT INTO tbl_oc (act, ticker, entry_dt, type, strike, oexp_dt, ioc, iop,\
            comm, pid, play, exit_dt, sec, cid, pid, uid) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', (act, ticker, entry_dt, type, strike,\
            oexp_dt, ioc, iop,comm, pid, play, exit_dt, sec, cid, pid,uid) )
            msg= "inserted"
    e_leg=sql_query_one(' SELECT * FROM tbl_oc where ticker=?',([ticker]))
    all_legs=sql_query_var(" SELECT * FROM tbl_oc where ticker=? ",([ticker]))
    results = sql_query("select oc.*, v.earn_dt_mc, v.div_dt, v.iv, v.iv_chg_pct, v.iv_rank, \
            v.vol, v.sec as sec_mc from tbl_oc oc LEFT JOIN tbl_iv v on oc.ticker=v.ticker \
            WHERE oc.exit_dt='N' and oc.oexp_dt>='%s' and v.date='%s' ORDER BY ticker, pid, \
            cid, entry_dt"%(q_date, q_date))
    #[ticker, play, pid]
    return render_template('o_trd.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg)  
#%%
@app.route('/t_edit_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def t_edit_form():
    if request.method == 'GET':
        e_ticker = request.args.get('e_ticker')
        e_pid = request.args.get('e_pid')
        e_uid = request.args.get('e_uid')
        e_leg=sql_query_var(" SELECT * FROM tbl_oc where uid=?",([e_uid]))
        all_legs=sql_query_var(" SELECT * FROM tbl_oc where ticker=? ",([e_ticker]))
        results = sql_query("select oc.*, v.earn_dt_mc, v.div_dt, v.iv, v.iv_chg_pct, v.iv_rank, \
            v.vol, v.sec as sec_mc from tbl_oc oc LEFT JOIN tbl_iv v on oc.ticker=v.ticker \
            WHERE oc.exit_dt='N' and oc.oexp_dt>='%s' and v.date='%s' ORDER BY ticker, pid, \
            cid, entry_dt"%(q_date, q_date))
    msg="t_edit_form"
    return render_template('o_trd.html', e_leg=e_leg[0], all_legs=all_legs, results=results, msg=msg)
#%%
@app.route('/t_edit',methods = ['POST', 'GET']) #this is when user submit after edit
def t_edit():
    if request.method == 'POST':	
        act = request.form["act"].upper()
        ticker = request.form["ticker"].upper()
        entry_dt = request.form["entry_dt"]
        pid = request.form["pid"].upper()
        type = request.form["type"].upper()[0]
        strike = request.form["strike"]
        oexp_dt = request.form["oexp_dt"]
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        comm = request.form["comm"]
        play = request.form["play"].upper()
        exit_dt = request.form["exit_dt"]
        sec = request.form["sec"].upper()
        old_uid = request.form["old_uid"]
        #rebuld cid/uid
        expiry=parser.parse(oexp_dt)
        expiry=expiry.strftime('%y%m%d')
        strike_tmp=str(int(float(strike) *1000)).rjust(8,'0')
        cid=ticker + '-' + expiry +type+strike_tmp
        uid=cid + pid + entry_dt
        
        sql_edit_insert("UPDATE tbl_oc SET act=?, type=?, strike=?, oexp_dt=?, ioc=?, iop=?, comm=?,\
                        play=?, exit_dt=?, sec=?, cid=?, pid=?, uid=? WHERE uid=?", (act, type, strike, oexp_dt, ioc,\
                        iop, comm, play, exit_dt, sec, cid, pid, uid, old_uid)) 
        e_leg=sql_query_var(" SELECT * FROM tbl_oc where ticker=? and pid=?",(ticker,pid))
        all_legs=sql_query_var(" SELECT * FROM tbl_oc where ticker=? ",([ticker]))
        results = sql_query("select oc.*, v.earn_dt_mc, v.div_dt, v.iv, v.iv_chg_pct, v.iv_rank, \
            v.vol, v.sec as sec_mc from tbl_oc oc LEFT JOIN tbl_iv v on oc.ticker=v.ticker \
            WHERE oc.exit_dt='N' and oc.oexp_dt>='%s' and v.date='%s' ORDER BY ticker, pid, \
            cid, entry_dt"%(q_date, q_date))
    msg= "t_edit success" 
    return render_template('o_trd.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg) 
#%%
@app.route('/t_delte',methods = ['GET']) #this is when user submit after edit
def t_delete():
    if request.method == 'GET':
#        ticker = request.args.get('d_ticker')
        uid = request.args.get('d_uid')
#        sql_delete("  DELETE FROM tbl_otrade_candy where ticker = ? and pid = ? ", (ticker, pid) )
        sql_delete("  DELETE FROM tbl_oc where uid= ? ", ([uid]) )
        results = sql_query("select oc.*, v.earn_dt_mc, v.div_dt, v.iv, v.iv_chg_pct, v.iv_rank, \
            v.vol, v.sec as sec_mc from tbl_oc oc LEFT JOIN tbl_iv v on oc.ticker=v.ticker \
            WHERE oc.exit_dt='N' and oc.oexp_dt>='%s' and v.date='%s' ORDER BY ticker, pid, \
            cid, entry_dt"%(q_date, q_date))
    msg= "delete_t msg" #[ticker, play, pid]
    return render_template('o_trd.html', results=results, msg=msg) 
#%%
@app.route('/flo_insert',methods = ['POST', 'GET']) #this is when user submit after edit
def flo_insert():
    if request.method == 'POST':	
        ticker = request.form["ticker"].upper()
        dc=sql_read("select * from tbl_candy where ticker ='%s' order by date desc"%ticker)
        if dc.empty:
            msg="%s: no candy history"%ticker
        else: 
            dc=dc.head(1)
            r=dc.to_dict('records')[0]
            act='IBQ'
            entry_dt = candy_max_dt
            pid= 'U1'
            play=''
            exit_dt='N'
            comm=0
            query='INSERT INTO tbl_oc (act, ticker, entry_dt, type, strike, oexp_dt, ioc, iop,\
            comm, pid, play, exit_dt, sec, cid, uid, beta, earn_dt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
            var=(act, r['ticker'], entry_dt, r['type'][0], r['strike'], r['oexp_dt'], r['ioc'], r['iop'],\
                comm, pid, play, exit_dt, r['sec'], r['cid'], r['tid'], r['beta'], r['earn_dt'] )
            sql_edit_insert(query, var)
            msg= "candy: %s inserted"%ticker
    e_leg=sql_query_one(' SELECT * FROM tbl_oc where ticker=?',([ticker]))
    all_legs=sql_query_var(" SELECT * FROM tbl_oc where ticker=? ",([ticker]))
    results = sql_query("select oc.*, v.earn_dt_mc, v.div_dt, v.iv, v.iv_chg_pct, v.iv_rank, \
            v.vol, v.sec as sec_mc from tbl_oc oc LEFT JOIN tbl_iv v on oc.ticker=v.ticker \
            WHERE oc.exit_dt='N' and oc.oexp_dt>='%s' and v.date='%s' ORDER BY ticker, pid, \
            cid, entry_dt"%(q_date, q_date))
    #[ticker, play, pid]
    return render_template('o_trd.html', e_leg=e_leg, all_legs=all_legs, results=results, msg=msg)  

#%% o_flow.html: add menu to tbl_trd_candy
@app.route("/o_flow")
def o_flow():
   
    return render_template('o_flow.html') 
#%%
@app.route('/flow_input',methods = ['POST', 'GET']) #this is when user submit after edit
def flow_input():
    if request.method == 'POST':	
        ticker = request.form["ticker"].upper()
        f_results=sql_query("select DISTINCT tid, ticker, ioc, iop, cid from tbl_candy_track where ticker ='%s'\
                            order by date desc LIMIT 10 "%ticker)
        msg="flow_input_candy_track  %s"%ticker
        if len(f_results)==0:
            f_results=sql_query("select DISTINCT tid, ticker, ioc, iop, cid from tbl_candy where ticker ='%s'\
                            order by date desc LIMIT 10 "%ticker)
            msg="flow_input_candy:  %s"%ticker
            if len(f_results)==0:
                msg="%s: no candy history"%ticker
        
        t_results=sql_query("select * from tbl_oc where exit_dt='N' \
			AND ticker ='%s' ORDER BY ticker,  pid, cid, entry_dt  "%ticker)
    #[ticker, play, pid]
    
    return render_template('o_flow.html', f_results=f_results, t_results=t_results, msg=msg)  

#%%
@app.route('/flow_insert',methods = ['POST', 'GET']) #this is when user submit after edit
def flow_insert():
    if request.method == 'GET':
        tid = request.args.get('tid').upper()
        ticker = request.args.get('ticker').upper()
#        msg="flow_insert_GET:  %s"%tid
#    if request.method == 'POST':	
#        tid = request.form["f_tid"].upper()
#		#get 'tid' from list, then find it from tbl_candy for all fields as input
        dc=read_sql("select * from tbl_candy where tid='%s' order by date desc LIMIT 10 "%tid)
        r=dc.to_dict('records')[0]
        act='IBQ'
        entry_dt = candy_max_dt
        pid= 'U1'
        play=''
        exit_dt='N'
        comm=0
        query='INSERT INTO tbl_oc (act, ticker, entry_dt, type, strike, oexp_dt, ioc, iop,\
            comm, pid, play, exit_dt, sec, cid, uid, beta, earn_dt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        var=(act, r['ticker'], entry_dt, r['type'][0], r['strike'], r['oexp_dt'], r['ioc'], r['iop'],\
            comm, pid, play, exit_dt, r['sec'], r['cid'], r['tid'], r['beta'], r['earn_dt'] )
        sql_edit_insert(query, var )
        msg= "flow_insert_POST into tbl_oc: %s inserted"%tid  
        
    f_results=sql_query("select DISTINCT tid, ticker, ioc, iop, cid from tbl_candy_track where ticker ='%s'\
                            order by date desc LIMIT 10 "%ticker)

    t_results=sql_query("select * from tbl_oc where exit_dt='N' \
			AND ticker ='%s' ORDER BY ticker,  pid, cid, entry_dt  "%ticker)
    #[ticker, play, pid]
    
    return render_template('o_flow.html', f_results=f_results, t_results=t_results, msg=msg)  

#%%
#  O_CANDY: candy@q_date
@app.route("/o_candy")
def o_candy():
#    results = sql_query(''' SELECT * FROM tbl_candy WHERE (watch IS NOT 'N' AND \
#            date='%s') OR watch ='Y' \
#            AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' ))\
#            ORDER BY watch '''%candy_max_dt)
    results = sql_query(''' SELECT * FROM tbl_candy WHERE (watch IS NOT 'N' AND \
            date>='%s') ORDER BY atm, bet DESC, why '''%candy_max_dt)
    return render_template('o_candy.html', results=results)     
#%%
@app.route('/o_edit_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def o_edit_form():
    if request.method == 'GET':
        e_tid = request.args.get('e_tid')
        e_leg=sql_query_one(' SELECT * FROM tbl_candy where tid=?',([e_tid]))
    results = sql_query(''' SELECT * FROM tbl_candy WHERE (watch IS NOT 'N' AND \
            date>='%s') ORDER BY atm, bet DESC, why '''%candy_max_dt)
    msg="o_edit_form"
    return render_template('o_candy.html', e_leg=e_leg,  results=results, msg=msg)
#%%
@app.route('/o_edit',methods = ['POST', 'GET']) #this is when user submit after edit
def o_edit():
    if request.method == 'POST':	
        tid = request.form["tid"]
        sec = request.form["sec"].upper()
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        bs = request.form["bs"].lower()
        watch = request.form["watch"].upper()
        sql_edit_insert("UPDATE tbl_candy SET ioc=?, iop=?, bs=?, watch=?, sec=?\
                WHERE tid=?", (ioc, iop, bs, watch, sec, tid))   
        sql_edit_insert("UPDATE tbl_candy_track SET ioc=?, iop=?, bs=?, watch=?, sec=? \
                WHERE tid=?", (ioc, iop, bs, watch, sec, tid))  
        sql_edit_insert("UPDATE tbl_candy_update SET ioc=?, iop=?, bs=?, watch=?, sec=? \
                WHERE tid=?", (ioc, iop, bs, watch, sec, tid)) 
    results = sql_query(''' SELECT * FROM tbl_candy WHERE (watch IS NOT 'N' AND \
            date>='%s') ORDER BY atm, bet DESC, why '''%candy_max_dt)
    msg=" o_edit msg"
    return render_template('o_candy.html', results=results, msg=msg)


#%%
# -_SPEC.html: tbl_candy_track@q_date with e_sig-ed
@app.route("/o_spec")
def o_spec():
#    results = sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
#            e_sig IS NOT NULL AND why IS NOT NULL AND candy_dt != date AND date='%s') OR watch ='Y' \
#            ORDER BY watch DESC,abs(mp_i_chg_pct), \
#            e_sig, why DESC, tid, o_dt '''%candy_track_max_dt)
    results=sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
            (e_sig IS NOT NULL OR why IS NOT NULL) AND candy_dt != '%s' AND date='%s') \
                AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' )) \
                ORDER BY vet DESC, abs(mp_i_chg_pct), watch DESC, e_sig, bs, why DESC, \
                tid, o_dt '''%(candy_track_max_dt, candy_track_max_dt))
    return render_template('o_spec.html', results=results)     
#%%
@app.route('/spec_edit_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def spec_edit_form():
    if request.method == 'GET':
        e_tid = request.args.get('e_tid')
        e_leg=sql_query_one(' SELECT * FROM tbl_candy where tid=?',([e_tid]))
    results=sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
            (e_sig IS NOT NULL OR why IS NOT NULL) AND candy_dt != '%s' AND date='%s') \
                AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' )) \
                ORDER BY vet DESC, abs(mp_i_chg_pct), watch DESC, e_sig, bs, why DESC, \
                tid, o_dt '''%(candy_track_max_dt, candy_track_max_dt))
    msg="spec_edit_form"
    return render_template('o_spec.html', e_leg=e_leg,  results=results, msg=msg)

#%%
# intel: update 'watch' to tbl_candy/update/track by TID!
@app.route('/spec_edit',methods = ['POST', 'GET']) #this is when user submit after edit
def spec_edit():
    if request.method == 'POST':	
        tid = request.form["tid"]
        sec = request.form["sec"].upper()
        ioc = request.form["ioc"]
        iop = request.form["iop"]
        bs = request.form["bs"].lower()
        watch = request.form["watch"].upper()
        sql_edit_insert("UPDATE tbl_candy_track SET ioc=?, iop=?, bs=?, watch=?, sec=? \
                WHERE tid=?", (ioc, iop, bs, watch, sec, tid))  
        sql_edit_insert("UPDATE tbl_candy_update SET ioc=?, iop=?, bs=?, watch=?, sec=? \
                WHERE tid=?", (ioc, iop, bs, watch, sec, tid)) 
        sql_edit_insert("UPDATE tbl_candy SET ioc=?, iop=?, bs=?, watch=?, sec=? \
                WHERE tid=?", (ioc, iop, bs, watch, sec, tid))   
    results=sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
            (e_sig IS NOT NULL OR why IS NOT NULL) AND candy_dt != '%s' AND date='%s') \
                AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' )) \
                ORDER BY vet DESC, abs(mp_i_chg_pct), watch DESC, e_sig, bs, why DESC, \
                tid, o_dt '''%(candy_track_max_dt, candy_track_max_dt))
    msg=" spec_edit msg"
    return render_template('o_spec.html', results=results, msg=msg)
#%%
@app.route('/ticker_form',methods = ['POST', 'GET']) #this is when user clicks edit link
def ticker_form():
    if request.method == 'GET':
        e_tid = request.args.get('e_tid')
        e_leg=sql_query_one(' SELECT * FROM tbl_candy where tid=?',([e_tid]))
    results=sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
            (e_sig IS NOT NULL OR why IS NOT NULL) AND candy_dt != '%s' AND date='%s') \
                AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' )) \
                ORDER BY vet DESC, abs(mp_i_chg_pct), watch DESC, e_sig, bs, why DESC, \
                tid, o_dt '''%(candy_track_max_dt, candy_track_max_dt))
    msg="spec_ticker_form"
    return render_template('o_spec.html', e_leg=e_leg,  results=results, msg=msg)
#%%
# Update to 'watch' is to tbl_candy (not track!!)
@app.route('/spec_edit_ticker',methods = ['POST', 'GET']) #this is when user submit after edit
def spec_edit_ticker():
    if request.method == 'POST':
        ticker = request.form["ticker"]
        watch = request.form["watch"].upper()
        sql_edit_insert("UPDATE tbl_candy SET watch=? \
                WHERE ticker=? AND date>= ?", (watch, ticker, candy_track_min_dt))  
        sql_edit_insert("UPDATE tbl_candy_update SET watch=? \
                WHERE ticker=? AND date>= ?", (watch, ticker, candy_track_min_dt))  
        sql_edit_insert("UPDATE tbl_candy_track SET watch=? \
                WHERE ticker=? AND date>= ?", (watch, ticker, candy_track_min_dt))  
    results=sql_query(''' SELECT * FROM tbl_candy_track WHERE (watch IS NOT 'N' AND \
            (e_sig IS NOT NULL OR why IS NOT NULL) AND candy_dt != '%s' AND date='%s') \
                AND (ticker NOT IN (select ticker from tbl_oc where exit_dt ='N' )) \
                ORDER BY vet DESC, abs(mp_i_chg_pct), watch DESC, e_sig, bs, why DESC, \
                tid, o_dt '''%(candy_track_max_dt, candy_track_max_dt))
    msg=" spec_edit msg"
    return render_template('o_spec.html', results=results, msg=msg)


if __name__ == "__main__":
    app.run(host=host, port=port, debug=True)

"""
RESOURCE:
    https://medium.com/@aliciagilbert.itsimplified/a-slick-crud-application-built-using-python-with-flask-and-sqlite3-to-teach-simple-mysql-queries-bd75e1109582
    https://github.com/itsimplified/slick-crud-app
    
    table: https://sarahleejane.github.io/learning/python/2015/08/09/simple-tables-in-webapps-using-flask-and-pandas-with-python.html
    #ajax table
    https://stackoverflow.com/questions/51468834/how-to-get-python-to-retrieve-user-inputted-data-from-a-dynamic-table-using-flas
{# 
         {% for key, value in result_dictionary.iteritems() %}
            <tr>
               <th> {{ key }} </th>
               <td> {{ value }} </td>
            </tr>
         {% endfor %}
	return a form in dictionary format:	 
	if request.method == 'POST':
    result = request.form
    return render_template("result.html",result = result)
	
	3. cookie
	   resp = make_response(render_template('readcookie.html'))
   resp.set_cookie('userID', user)
   name = request.cookies.get('userID')
   
   
#}
!! dataframe to table or pages
https://galaxydatatech.com/2018/03/31/passing-dataframe-web-page/

#flask_alchmey
https://www.codementor.io/garethdwyer/building-a-crud-application-with-flask-and-sqlalchemy-dm3wv7yu2
#ajax call
https://www.codementor.io/codementorteam/how-to-scrape-an-ajax-website-using-python-qw8fuitvi
https://stackoverflow.com/questions/55006553/scraping-an-ajax-web-page-using-python-and-requests
https://stackoverflow.com/questions/52228851/python-extract-xhr-response-data-from-website


Flask - spec_flo image
https://towardsdatascience.com/python-plotting-api-expose-your-scientific-python-plots-through-a-flask-api-31ec7555c4a8
scroll tabl
https://stackoverflow.com/questions/21168521/table-fixed-header-and-scrollable-body

"""
    